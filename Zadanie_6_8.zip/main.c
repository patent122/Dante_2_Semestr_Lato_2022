#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "dictionary.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main() {
    char* bufor = malloc(50);
    if (bufor == NULL) {
        printf("Failed to allocate memory");
        return 8;
    }
    int err;
    printf("Podaj nazwe pliku: ");
    scanf("%49[^\n]", bufor);
    FILE* plik = fopen(bufor, "rt");
    if (plik == NULL) {
        free(bufor);
        printf("Couldn't open file");
        return 4;
    }
    struct dictionary_t* dict = create_dictionary(10, &err);
    if (err != 0) {
        printf("Failed to allocate memory");
        free(bufor);
        fclose(plik);
        return 8;
    }
    int dlugosc = 0;
    while (1) {
        char znak = fgetc(plik);
        
        if (feof(plik)) {
            if (dlugosc != 0) {
                *(bufor + dlugosc) = '\0';
                if (dictionary_add_word(dict, bufor)) {
                    printf("Failed to allocate memory");
                    destroy_dictionary(&dict);
                    free(bufor);
                    fclose(plik);
                    return 8;
                }
            }
            break;
        }
        if (isalpha(znak) && dlugosc < 50) {
            *(bufor + dlugosc) = znak;
            dlugosc++;
        }
        else if (dlugosc > 0) {
            *(bufor + dlugosc) = '\0';
            if (dictionary_add_word(dict, bufor)) {
                printf("Failed to allocate memory");
                destroy_dictionary(&dict);
                free(bufor);
                fclose(plik);
                return 8;
            }
            dlugosc = 0;
        }
    }
    if (dict->size == 0) {
        printf("Nothing to show\n");
    }
    else
        dictionary_display(dict);
    fclose(plik);
    destroy_dictionary(&dict);
    free(bufor);
    return 0;
}


