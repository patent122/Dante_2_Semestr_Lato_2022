/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Lustrzane odbicia
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 21:19:21.351688
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[7][6] = {{ 135, 226, 171, 123, 24, 30}, { 224, 215, 52, 177, 252, 62}, { 199, 166, 77, 70, 193, 176}, { 0, 116, 84, 218, 159, 245}, { 161, 115, 237, 226, 115, 44}, { 203, 18, 130, 120, 198, 177}, { 225, 156, 90, 186, 51, 96}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("on.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                        test_error(arr->height == 7, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 7, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 7; ++i)
                            for (int j = 0; j < 6; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][5] = {{ 184, 208, 40, 148, 51}, { 241, 180, 243, 193, 168}, { 143, 231, 199, 48, 45}, { 91, 242, 199, 42, 11}, { 216, 71, 133, 232, 248}, { 126, 36, 8, 31, 29}, { 46, 230, 57, 209, 240}, { 67, 89, 230, 130, 186}, { 167, 43, 49, 100, 173}, { 210, 192, 33, 171, 202}, { 79, 145, 40, 161, 253}, { 41, 183, 255, 146, 178}, { 116, 58, 132, 138, 73}, { 127, 209, 60, 247, 216}, { 204, 35, 199, 81, 42}, { 22, 177, 101, 30, 177}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("boat.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                        test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 5; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][1] = {{ 63}, { 225}, { 64}, { 131}, { 162}, { 209}, { 12}, { 59}, { 197}, { 24}, { 52}, { 111}, { 80}, { 0}, { 159}, { 65}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("said.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][9] = {{ 93, 215, 55, 62, 154, 230, 126, 25, 182}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("example.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 46}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("run.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("clear.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("island.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("catch.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("wave.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("girl.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("soon.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("ease.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("seat.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("property.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("cow.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("dictionary.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("learn.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 2, "Funkcja load_image_t() powinna zwrócić kod błędu 2, a zwróciła %d", err_code);
                    if (!2)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[7][6] = {{ 135, 226, 171, 123, 24, 30}, { 224, 215, 52, 177, 252, 62}, { 199, 166, 77, 70, 193, 176}, { 0, 116, 84, 218, 159, 245}, { 161, 115, 237, 226, 115, 44}, { 203, 18, 130, 120, 198, 177}, { 225, 156, 90, 186, 51, 96}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("on.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                        test_error(arr->height == 7, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 7, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 7; ++i)
                            for (int j = 0; j < 6; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][5] = {{ 184, 208, 40, 148, 51}, { 241, 180, 243, 193, 168}, { 143, 231, 199, 48, 45}, { 91, 242, 199, 42, 11}, { 216, 71, 133, 232, 248}, { 126, 36, 8, 31, 29}, { 46, 230, 57, 209, 240}, { 67, 89, 230, 130, 186}, { 167, 43, 49, 100, 173}, { 210, 192, 33, 171, 202}, { 79, 145, 40, 161, 253}, { 41, 183, 255, 146, 178}, { 116, 58, 132, 138, 73}, { 127, 209, 60, 247, 216}, { 204, 35, 199, 81, 42}, { 22, 177, 101, 30, 177}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("boat.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                        test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 5; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][1] = {{ 63}, { 225}, { 64}, { 131}, { 162}, { 209}, { 12}, { 59}, { 197}, { 24}, { 52}, { 111}, { 80}, { 0}, { 159}, { 65}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("said.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][9] = {{ 93, 215, 55, 62, 154, 230, 126, 25, 182}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("example.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 46}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("run.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("clear.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("island.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("catch.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("wave.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("girl.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("soon.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("ease.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("seat.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("property.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("cow.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("dictionary.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][10] = {{ 162, 179, 209, 212, 160, 79, 186, 202, 137, 208}, { 86, 242, 104, 192, 244, 218, 55, 206, 199, 186}, { 171, 250, 200, 98, 217, 160, 61, 190, 215, 91}, { 34, 251, 217, 220, 153, 17, 10, 166, 37, 74}, { 52, 246, 237, 158, 126, 89, 53, 61, 156, 74}, { 240, 195, 24, 4, 174, 13, 38, 97, 251, 159}, { 228, 213, 94, 180, 38, 145, 249, 80, 153, 1}, { 175, 163, 47, 5, 98, 186, 150, 140, 225, 139}, { 140, 13, 47, 140, 83, 17, 27, 202, 60, 161}, { 61, 72, 172, 225, 120, 164, 78, 253, 32, 231}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("learn.txt", NULL);
                    printf("#####END#####");

                    if (!2)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 187 bajtów)
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 187 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(187);
    
    //
    // -----------
    //
    

            int array[4][8] = {{ 208, 126, 147, 164, 225, 50, 192, 61}, { 47, 91, 153, 183, 118, 125, 31, 25}, { 10, 55, 156, 86, 69, 105, 77, 129}, { 209, 121, 158, 116, 12, 130, 147, 152}};

            printf("#####START#####");                            
            struct image_t *arr = load_image_t("full.bin", NULL);
            printf("#####END#####");

            test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
            test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
            test_error(arr->height == 4, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 4, a ustawiła na %d", arr->height);

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            for (int i = 0; i < 4; ++i)
                for (int j = 0; j < 8; ++j)
                    test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


            printf("#####START#####");
            destroy_image(&arr);
            printf("#####END#####");

            test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(27);
    
    //
    // -----------
    //
    

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 59 bajtów)
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 59 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(59);
    
    //
    // -----------
    //
    

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 91 bajtów)
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 91 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(91);
    
    //
    // -----------
    //
    

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 123 bajtów)
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 123 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(123);
    
    //
    // -----------
    //
    

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 155 bajtów)
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 155 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(155);
    
    //
    // -----------
    //
    

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(27);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 59 bajtów)
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 59 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(59);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 91 bajtów)
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 91 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(91);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 123 bajtów)
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 123 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(123);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 155 bajtów)
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 155 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(155);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("full.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 50: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST50(void)
{
    // informacje o teście
    test_start(50, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t(NULL, &err_code);
                    printf("#####END#####");

                    test_error(err_code == 1, "Funkcja load_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 51: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST51(void)
{
    // informacje o teście
    test_start(51, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t(NULL, NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 52: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST52(void)
{
    // informacje o teście
    test_start(52, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][5] = {{ 152, 27, 31, 111, 7}, { 230, 7, 51, 220, 110}, { 229, 237, 6, 97, 99}, { 171, 116, 191, 86, 23}, { 205, 65, 232, 247, 187}, { 76, 236, 109, 69, 129}, { 37, 223, 250, 162, 99}, { 26, 28, 204, 169, 131}, { 165, 239, 57, 165, 8}, { 240, 62, 235, 247, 63}};
                    int array_negate[10][5] = {{ 103, 228, 224, 144, 248}, { 25, 248, 204, 35, 145}, { 26, 18, 249, 158, 156}, { 84, 139, 64, 169, 232}, { 50, 190, 23, 8, 68}, { 179, 19, 146, 186, 126}, { 218, 32, 5, 93, 156}, { 229, 227, 51, 86, 124}, { 90, 16, 198, 90, 247}, { 15, 193, 20, 8, 192}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("direct.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 10; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 10; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr_negate->ptr[i][j] == array_negate[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_negate[i][j], arr_negate->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_negate);
                    printf("#####END#####");

                    test_error(arr_negate == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 53: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST53(void)
{
    // informacje o teście
    test_start(53, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][7] = {{ 91, 12, 109, 118, 144, 131, 179}, { 116, 107, 132, 92, 89, 45, 148}, { 242, 242, 130, 176, 218, 195, 60}, { 55, 141, 76, 238, 210, 125, 105}, { 242, 240, 196, 32, 197, 254, 47}, { 49, 213, 245, 14, 200, 164, 28}, { 73, 209, 245, 253, 248, 19, 11}, { 32, 222, 244, 53, 202, 88, 244}, { 120, 114, 212, 27, 81, 241, 152}, { 57, 10, 198, 195, 92, 252, 129}, { 175, 144, 58, 145, 195, 247, 20}, { 229, 93, 138, 72, 15, 213, 178}, { 10, 94, 52, 12, 166, 21, 120}, { 12, 91, 100, 176, 223, 54, 30}, { 163, 252, 170, 22, 113, 179, 40}, { 42, 163, 243, 215, 138, 35, 249}};
                    int array_negate[16][7] = {{ 164, 243, 146, 137, 111, 124, 76}, { 139, 148, 123, 163, 166, 210, 107}, { 13, 13, 125, 79, 37, 60, 195}, { 200, 114, 179, 17, 45, 130, 150}, { 13, 15, 59, 223, 58, 1, 208}, { 206, 42, 10, 241, 55, 91, 227}, { 182, 46, 10, 2, 7, 236, 244}, { 223, 33, 11, 202, 53, 167, 11}, { 135, 141, 43, 228, 174, 14, 103}, { 198, 245, 57, 60, 163, 3, 126}, { 80, 111, 197, 110, 60, 8, 235}, { 26, 162, 117, 183, 240, 42, 77}, { 245, 161, 203, 243, 89, 234, 135}, { 243, 164, 155, 79, 32, 201, 225}, { 92, 3, 85, 233, 142, 76, 215}, { 213, 92, 12, 40, 117, 220, 6}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("down.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr_negate->ptr[i][j] == array_negate[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_negate[i][j], arr_negate->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_negate);
                    printf("#####END#####");

                    test_error(arr_negate == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 54: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST54(void)
{
    // informacje o teście
    test_start(54, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][1] = {{ 39}, { 146}, { 171}, { 245}, { 17}, { 62}, { 101}, { 197}, { 7}, { 154}, { 113}, { 77}, { 244}, { 187}, { 188}, { 46}, { 59}};
                    int array_negate[17][1] = {{ 216}, { 109}, { 84}, { 10}, { 238}, { 193}, { 154}, { 58}, { 248}, { 101}, { 142}, { 178}, { 11}, { 68}, { 67}, { 209}, { 196}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("coast.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr_negate->ptr[i][j] == array_negate[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_negate[i][j], arr_negate->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_negate);
                    printf("#####END#####");

                    test_error(arr_negate == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 55: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST55(void)
{
    // informacje o teście
    test_start(55, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][6] = {{ 18, 173, 35, 180, 217, 159}};
                    int array_negate[1][6] = {{ 237, 82, 220, 75, 38, 96}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("up.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr_negate->ptr[i][j] == array_negate[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_negate[i][j], arr_negate->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_negate);
                    printf("#####END#####");

                    test_error(arr_negate == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 56: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST56(void)
{
    // informacje o teście
    test_start(56, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 162}};
                    int array_negate[1][1] = {{ 93}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("art.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr_negate->ptr[i][j] == array_negate[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_negate[i][j], arr_negate->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_negate);
                    printf("#####END#####");

                    test_error(arr_negate == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 57: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST57(void)
{
    // informacje o teście
    test_start(57, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[91][88] = {{ 153, 190, 10, 241, 204, 21, 79, 42, 137, 34, 204, 85, 125, 250, 165, 120, 226, 244, 152, 227, 22, 67, 58, 177, 51, 81, 14, 134, 236, 141, 3, 170, 151, 44, 32, 87, 168, 159, 243, 138, 255, 245, 207, 18, 220, 40, 44, 153, 58, 3, 156, 80, 239, 22, 119, 32, 73, 111, 85, 189, 40, 183, 232, 248, 181, 221, 178, 245, 128, 228, 10, 129, 126, 62, 242, 157, 235, 107, 188, 132, 232, 117, 143, 219, 151, 219, 102, 96}, { 12, 59, 80, 46, 128, 247, 62, 232, 225, 35, 255, 126, 43, 215, 81, 154, 154, 14, 33, 64, 2, 75, 248, 243, 142, 210, 209, 141, 99, 46, 111, 121, 127, 187, 223, 137, 93, 198, 113, 85, 66, 236, 118, 7, 104, 218, 213, 121, 139, 141, 59, 27, 82, 162, 99, 51, 183, 82, 108, 21, 89, 79, 153, 217, 38, 8, 236, 17, 159, 86, 211, 116, 254, 231, 118, 57, 8, 233, 62, 234, 241, 27, 143, 204, 87, 198, 243, 164}, { 195, 11, 246, 212, 172, 7, 63, 39, 95, 168, 134, 210, 18, 22, 116, 59, 66, 52, 214, 9, 178, 194, 140, 186, 43, 111, 149, 159, 240, 13, 50, 151, 8, 226, 75, 229, 220, 201, 216, 94, 255, 206, 253, 65, 228, 243, 177, 41, 36, 140, 148, 102, 250, 50, 145, 106, 12, 169, 51, 221, 156, 170, 207, 213, 196, 205, 122, 131, 173, 253, 212, 15, 187, 55, 228, 121, 145, 240, 170, 12, 236, 183, 10, 136, 160, 123, 152, 179}, { 23, 139, 198, 228, 201, 64, 30, 206, 141, 245, 235, 36, 11, 33, 57, 117, 143, 204, 26, 141, 102, 32, 28, 111, 96, 215, 171, 220, 36, 2, 202, 174, 168, 164, 69, 35, 185, 38, 185, 150, 112, 116, 13, 200, 162, 79, 220, 18, 240, 47, 227, 202, 141, 217, 213, 60, 56, 192, 76, 147, 97, 122, 124, 205, 109, 129, 92, 131, 143, 130, 176, 110, 3, 72, 39, 58, 2, 133, 239, 222, 219, 42, 57, 222, 82, 192, 33, 122}, { 51, 9, 222, 11, 195, 250, 113, 83, 177, 158, 69, 87, 126, 218, 191, 75, 109, 190, 40, 176, 65, 94, 5, 167, 246, 228, 63, 178, 132, 166, 216, 132, 158, 146, 254, 138, 129, 71, 144, 174, 141, 210, 185, 89, 151, 93, 217, 201, 70, 42, 159, 129, 34, 72, 81, 32, 204, 133, 160, 66, 68, 226, 193, 157, 199, 79, 66, 27, 149, 255, 9, 115, 38, 185, 80, 224, 231, 203, 132, 186, 124, 205, 71, 81, 88, 140, 78, 72}, { 154, 148, 12, 160, 249, 50, 146, 203, 187, 106, 65, 37, 72, 12, 65, 118, 45, 18, 121, 130, 122, 212, 213, 34, 45, 92, 247, 8, 237, 147, 8, 162, 86, 105, 42, 40, 51, 154, 150, 220, 21, 129, 63, 205, 112, 99, 11, 38, 7, 83, 132, 71, 229, 243, 147, 126, 153, 178, 188, 160, 109, 165, 202, 234, 46, 42, 170, 1, 62, 113, 20, 61, 144, 173, 69, 80, 63, 5, 240, 18, 146, 16, 211, 148, 135, 1, 183, 223}, { 128, 158, 19, 66, 209, 218, 193, 24, 35, 239, 154, 89, 208, 157, 87, 199, 48, 39, 128, 59, 144, 114, 88, 98, 144, 191, 1, 69, 203, 240, 88, 227, 251, 69, 138, 21, 127, 112, 179, 133, 60, 27, 99, 176, 132, 229, 43, 190, 235, 47, 158, 245, 103, 233, 7, 207, 17, 19, 173, 155, 105, 112, 195, 100, 74, 121, 77, 201, 158, 124, 152, 174, 126, 183, 36, 135, 30, 210, 15, 253, 168, 216, 157, 98, 205, 91, 243, 185}, { 150, 110, 230, 167, 136, 135, 236, 60, 219, 95, 55, 244, 111, 220, 16, 66, 116, 133, 1, 170, 249, 113, 179, 224, 24, 128, 2, 163, 144, 118, 76, 42, 168, 182, 144, 218, 188, 70, 157, 82, 182, 6, 243, 19, 250, 82, 215, 230, 8, 213, 127, 255, 23, 97, 96, 66, 233, 76, 174, 221, 171, 181, 101, 30, 56, 193, 229, 150, 233, 182, 94, 110, 126, 178, 42, 21, 77, 165, 192, 145, 60, 98, 113, 74, 241, 78, 87, 66}, { 134, 92, 54, 18, 193, 34, 107, 56, 171, 165, 234, 196, 164, 252, 6, 118, 33, 123, 5, 62, 31, 155, 218, 223, 214, 78, 210, 220, 196, 213, 237, 80, 194, 35, 55, 94, 124, 72, 43, 250, 133, 130, 217, 223, 68, 104, 241, 116, 163, 200, 172, 171, 178, 154, 123, 126, 52, 17, 201, 32, 72, 227, 206, 24, 116, 13, 156, 89, 102, 43, 183, 6, 141, 45, 99, 246, 163, 41, 92, 66, 136, 220, 78, 52, 134, 76, 49, 121}, { 237, 3, 67, 10, 119, 183, 90, 17, 196, 84, 145, 212, 23, 95, 71, 42, 143, 19, 176, 191, 139, 13, 143, 164, 3, 226, 44, 43, 18, 208, 218, 188, 33, 161, 5, 27, 160, 162, 171, 210, 49, 98, 71, 103, 65, 85, 58, 234, 184, 68, 117, 127, 1, 133, 45, 153, 9, 223, 249, 43, 46, 121, 23, 133, 64, 204, 12, 118, 55, 64, 30, 224, 177, 96, 6, 51, 116, 252, 210, 98, 80, 127, 76, 249, 126, 39, 100, 255}, { 158, 254, 227, 92, 38, 38, 141, 209, 130, 203, 68, 181, 209, 239, 217, 105, 220, 250, 119, 193, 109, 83, 171, 64, 62, 167, 104, 36, 234, 189, 82, 15, 1, 220, 103, 193, 172, 21, 24, 40, 31, 250, 249, 215, 223, 83, 199, 125, 87, 226, 230, 79, 56, 80, 71, 37, 158, 187, 148, 138, 186, 12, 225, 195, 123, 79, 67, 112, 14, 254, 1, 8, 198, 166, 30, 202, 166, 87, 114, 49, 123, 107, 178, 63, 12, 92, 107, 165}, { 30, 66, 79, 200, 148, 8, 66, 29, 191, 103, 184, 232, 172, 4, 21, 210, 73, 187, 80, 36, 192, 181, 183, 86, 12, 240, 32, 226, 100, 144, 23, 178, 188, 137, 202, 194, 15, 192, 209, 26, 90, 144, 69, 137, 231, 16, 31, 115, 44, 20, 184, 131, 157, 159, 191, 5, 247, 106, 125, 189, 165, 204, 57, 87, 66, 19, 81, 17, 243, 106, 104, 4, 16, 233, 25, 4, 195, 175, 240, 142, 240, 205, 247, 144, 242, 240, 101, 178}, { 159, 196, 61, 92, 231, 86, 237, 87, 146, 175, 227, 149, 113, 91, 185, 12, 9, 93, 107, 136, 106, 143, 111, 91, 94, 62, 215, 243, 60, 105, 203, 108, 152, 118, 63, 76, 5, 6, 152, 70, 80, 202, 245, 144, 134, 133, 59, 50, 185, 88, 209, 124, 225, 81, 73, 23, 8, 123, 69, 182, 65, 255, 66, 75, 250, 168, 185, 205, 164, 72, 251, 151, 83, 51, 96, 111, 58, 35, 16, 7, 31, 235, 231, 14, 45, 24, 221, 30}, { 219, 119, 42, 142, 114, 58, 193, 112, 119, 188, 183, 244, 238, 160, 134, 133, 167, 206, 188, 40, 78, 157, 179, 133, 185, 40, 161, 244, 185, 174, 54, 255, 186, 142, 205, 114, 81, 111, 8, 32, 51, 191, 203, 161, 188, 5, 152, 195, 4, 138, 254, 255, 194, 105, 197, 170, 232, 86, 124, 152, 131, 75, 76, 125, 183, 67, 24, 50, 243, 27, 244, 163, 123, 188, 254, 50, 189, 169, 76, 227, 103, 158, 92, 135, 176, 198, 46, 193}, { 179, 122, 171, 129, 210, 134, 1, 134, 4, 240, 82, 239, 70, 65, 112, 162, 156, 57, 128, 64, 162, 105, 24, 255, 55, 177, 90, 202, 62, 231, 69, 161, 226, 240, 220, 69, 130, 245, 151, 218, 93, 218, 242, 56, 166, 38, 225, 196, 149, 133, 74, 1, 91, 50, 42, 243, 2, 142, 226, 47, 123, 180, 181, 202, 123, 60, 114, 228, 118, 104, 131, 33, 183, 123, 136, 65, 14, 124, 106, 36, 254, 92, 240, 203, 141, 153, 196, 15}, { 47, 213, 63, 225, 251, 120, 79, 2, 148, 135, 11, 251, 137, 46, 78, 63, 158, 157, 183, 82, 98, 212, 145, 99, 80, 51, 179, 122, 42, 181, 218, 8, 244, 130, 56, 174, 153, 139, 203, 206, 43, 106, 67, 251, 55, 75, 74, 217, 78, 252, 92, 37, 127, 66, 158, 7, 118, 205, 12, 93, 140, 178, 28, 124, 49, 177, 208, 89, 4, 212, 159, 133, 31, 88, 151, 220, 99, 178, 142, 162, 255, 204, 49, 197, 196, 14, 199, 156}, { 125, 235, 119, 116, 49, 176, 143, 182, 118, 5, 99, 54, 120, 216, 156, 80, 218, 217, 15, 48, 104, 116, 40, 76, 58, 150, 124, 48, 115, 146, 159, 67, 96, 127, 96, 20, 198, 160, 137, 248, 30, 104, 120, 148, 25, 134, 12, 67, 150, 232, 220, 35, 166, 29, 70, 236, 205, 44, 133, 212, 95, 137, 214, 116, 65, 126, 19, 171, 31, 203, 58, 119, 232, 120, 105, 94, 218, 27, 149, 130, 164, 215, 80, 11, 67, 135, 204, 176}, { 155, 165, 206, 62, 179, 116, 137, 70, 82, 14, 51, 169, 83, 134, 43, 34, 213, 20, 10, 238, 253, 252, 249, 220, 186, 15, 235, 110, 33, 10, 250, 243, 174, 78, 178, 209, 63, 179, 201, 201, 196, 20, 155, 7, 49, 112, 54, 92, 153, 180, 34, 39, 228, 176, 40, 250, 30, 82, 131, 0, 209, 115, 236, 98, 114, 99, 71, 76, 127, 80, 178, 46, 0, 63, 238, 201, 78, 104, 18, 141, 17, 37, 97, 34, 23, 228, 138, 21}, { 222, 106, 178, 155, 176, 35, 148, 48, 3, 229, 25, 86, 46, 68, 38, 123, 67, 67, 29, 142, 127, 129, 183, 234, 253, 4, 166, 165, 228, 6, 209, 61, 96, 132, 49, 240, 30, 156, 84, 95, 98, 61, 240, 211, 154, 167, 100, 38, 73, 110, 60, 48, 241, 235, 25, 14, 203, 13, 86, 88, 109, 85, 163, 138, 161, 114, 114, 205, 8, 161, 182, 101, 20, 34, 116, 112, 138, 210, 124, 84, 247, 135, 102, 84, 63, 187, 227, 198}, { 89, 53, 182, 220, 112, 29, 27, 233, 30, 74, 215, 145, 122, 111, 231, 4, 124, 173, 3, 91, 204, 23, 105, 209, 44, 135, 109, 167, 73, 118, 58, 16, 153, 128, 229, 45, 202, 69, 109, 30, 93, 223, 3, 161, 187, 29, 7, 64, 88, 39, 21, 47, 50, 219, 92, 44, 88, 13, 126, 214, 151, 33, 22, 254, 46, 18, 74, 107, 165, 95, 229, 196, 128, 33, 6, 62, 207, 130, 22, 80, 167, 200, 233, 127, 104, 229, 175, 226}, { 176, 22, 211, 66, 123, 92, 147, 254, 219, 60, 218, 151, 41, 103, 43, 47, 87, 196, 143, 143, 68, 252, 0, 187, 175, 153, 221, 209, 122, 67, 13, 144, 213, 106, 191, 227, 38, 83, 135, 252, 140, 92, 214, 229, 127, 33, 150, 231, 171, 167, 18, 191, 117, 158, 50, 109, 137, 146, 188, 18, 4, 68, 167, 152, 230, 14, 69, 41, 208, 215, 153, 233, 185, 175, 30, 184, 43, 99, 200, 21, 207, 149, 24, 164, 169, 120, 147, 144}, { 248, 210, 184, 43, 65, 132, 43, 86, 39, 237, 144, 164, 9, 204, 167, 50, 22, 255, 116, 158, 133, 150, 140, 76, 152, 199, 74, 22, 93, 47, 32, 87, 86, 31, 224, 127, 58, 178, 190, 1, 126, 214, 50, 228, 74, 56, 204, 25, 220, 177, 27, 103, 120, 91, 60, 123, 42, 80, 43, 113, 160, 227, 221, 25, 196, 87, 107, 104, 11, 172, 238, 10, 164, 170, 93, 157, 104, 181, 165, 171, 26, 176, 180, 12, 213, 57, 147, 174}, { 71, 44, 88, 8, 65, 243, 173, 137, 40, 202, 249, 204, 127, 110, 48, 122, 236, 14, 48, 157, 15, 225, 131, 228, 114, 112, 162, 63, 56, 123, 6, 73, 103, 122, 230, 37, 94, 31, 49, 97, 128, 214, 53, 212, 65, 13, 152, 227, 100, 231, 103, 164, 150, 209, 236, 90, 112, 56, 129, 39, 72, 221, 82, 155, 226, 213, 61, 144, 244, 50, 1, 203, 227, 251, 129, 178, 173, 7, 141, 142, 184, 173, 255, 19, 122, 175, 103, 147}, { 127, 85, 151, 221, 181, 121, 16, 100, 15, 226, 217, 133, 137, 225, 251, 239, 185, 203, 138, 77, 80, 94, 160, 22, 89, 117, 161, 65, 153, 252, 192, 116, 164, 148, 37, 88, 4, 202, 249, 249, 225, 13, 210, 58, 127, 9, 232, 124, 94, 97, 119, 245, 18, 149, 182, 245, 29, 44, 126, 180, 29, 97, 152, 212, 161, 169, 139, 182, 51, 2, 179, 42, 180, 238, 152, 236, 219, 84, 182, 192, 77, 212, 6, 252, 32, 39, 8, 46}, { 26, 167, 232, 177, 38, 24, 108, 187, 170, 40, 70, 30, 133, 183, 216, 179, 124, 176, 138, 94, 3, 46, 145, 152, 13, 23, 150, 63, 111, 141, 210, 29, 98, 27, 236, 237, 198, 156, 225, 105, 120, 203, 90, 109, 0, 237, 240, 92, 98, 64, 180, 41, 187, 137, 167, 148, 46, 85, 86, 191, 96, 242, 58, 189, 78, 46, 116, 207, 22, 177, 236, 144, 208, 249, 14, 156, 77, 188, 211, 231, 250, 12, 58, 25, 215, 241, 41, 240}, { 104, 121, 200, 112, 62, 70, 159, 2, 37, 217, 182, 230, 188, 95, 240, 174, 43, 241, 141, 166, 249, 103, 207, 58, 109, 70, 63, 106, 28, 36, 101, 231, 130, 171, 247, 82, 24, 208, 62, 6, 203, 185, 189, 25, 201, 42, 195, 56, 174, 240, 202, 229, 86, 128, 92, 188, 254, 15, 48, 31, 111, 21, 3, 70, 138, 223, 97, 83, 132, 14, 61, 5, 16, 113, 32, 40, 158, 160, 28, 211, 246, 197, 36, 5, 127, 158, 101, 188}, { 206, 110, 243, 28, 188, 39, 214, 124, 53, 33, 143, 239, 2, 151, 218, 139, 222, 250, 177, 130, 51, 5, 230, 171, 221, 217, 179, 46, 38, 136, 26, 55, 245, 106, 71, 54, 85, 65, 153, 164, 49, 148, 3, 55, 52, 199, 151, 19, 123, 150, 162, 171, 15, 133, 186, 55, 36, 136, 207, 182, 228, 41, 60, 163, 77, 126, 154, 58, 110, 116, 80, 114, 215, 171, 27, 89, 111, 99, 79, 222, 61, 5, 54, 86, 187, 182, 171, 155}, { 213, 83, 52, 171, 43, 208, 252, 191, 206, 169, 47, 192, 105, 105, 124, 142, 20, 209, 187, 225, 177, 1, 253, 147, 43, 97, 199, 20, 170, 217, 187, 37, 74, 115, 247, 215, 206, 197, 248, 54, 213, 32, 39, 83, 190, 139, 41, 182, 164, 210, 39, 236, 30, 107, 204, 129, 180, 55, 222, 72, 139, 204, 186, 90, 133, 12, 44, 170, 93, 88, 254, 8, 250, 251, 207, 235, 253, 59, 252, 41, 204, 55, 229, 185, 163, 13, 28, 87}, { 6, 238, 197, 31, 68, 167, 185, 175, 91, 171, 51, 98, 113, 124, 17, 121, 175, 236, 145, 5, 122, 83, 97, 120, 25, 205, 127, 73, 76, 75, 209, 221, 133, 226, 54, 231, 254, 105, 60, 20, 200, 124, 210, 240, 197, 208, 253, 81, 255, 137, 34, 220, 132, 247, 133, 160, 104, 114, 103, 225, 128, 192, 189, 237, 157, 29, 85, 138, 5, 145, 115, 30, 38, 121, 113, 119, 196, 128, 82, 12, 229, 89, 21, 113, 124, 48, 57, 40}, { 70, 68, 248, 168, 161, 187, 3, 6, 166, 230, 184, 235, 161, 98, 63, 108, 11, 90, 81, 61, 111, 165, 174, 123, 118, 226, 156, 79, 0, 157, 47, 166, 240, 209, 4, 253, 39, 3, 208, 115, 134, 3, 9, 97, 80, 38, 166, 55, 171, 173, 98, 199, 197, 119, 170, 249, 217, 195, 197, 186, 154, 77, 6, 239, 127, 200, 97, 111, 36, 153, 61, 216, 224, 208, 39, 142, 53, 31, 37, 14, 194, 158, 232, 0, 97, 206, 140, 91}, { 186, 220, 42, 86, 79, 153, 4, 171, 197, 45, 161, 47, 222, 222, 47, 37, 65, 249, 113, 157, 32, 113, 115, 232, 131, 26, 231, 64, 214, 201, 217, 204, 176, 128, 7, 37, 100, 31, 199, 147, 36, 88, 55, 228, 196, 210, 230, 70, 170, 98, 16, 215, 134, 145, 243, 173, 99, 37, 34, 228, 35, 151, 85, 95, 76, 83, 195, 235, 255, 37, 73, 173, 213, 55, 161, 130, 206, 81, 155, 4, 30, 151, 41, 180, 254, 112, 59, 133}, { 142, 152, 253, 134, 240, 76, 206, 92, 149, 209, 161, 170, 13, 124, 175, 131, 198, 233, 120, 55, 211, 14, 132, 244, 109, 115, 219, 27, 200, 140, 246, 32, 131, 159, 35, 168, 37, 128, 89, 167, 75, 121, 141, 66, 44, 4, 203, 151, 49, 194, 238, 38, 231, 83, 29, 138, 110, 243, 60, 10, 186, 96, 70, 251, 150, 142, 43, 140, 226, 157, 3, 192, 158, 148, 236, 169, 222, 175, 65, 82, 25, 223, 66, 11, 180, 37, 13, 62}, { 137, 240, 72, 140, 123, 221, 181, 178, 128, 121, 19, 83, 117, 2, 95, 76, 19, 104, 139, 154, 138, 86, 201, 184, 233, 60, 99, 102, 59, 122, 103, 172, 240, 83, 122, 18, 9, 87, 197, 193, 140, 113, 105, 226, 133, 242, 24, 78, 25, 131, 187, 183, 36, 212, 92, 186, 25, 123, 204, 67, 250, 88, 14, 38, 198, 65, 31, 224, 9, 124, 41, 183, 188, 71, 37, 7, 150, 255, 202, 150, 168, 71, 140, 6, 169, 121, 96, 67}, { 140, 177, 96, 125, 67, 155, 33, 223, 4, 15, 177, 253, 57, 68, 189, 51, 25, 115, 118, 0, 87, 34, 23, 113, 202, 224, 14, 188, 157, 212, 240, 246, 62, 48, 208, 185, 241, 193, 75, 85, 122, 253, 230, 177, 230, 45, 247, 93, 247, 100, 189, 193, 123, 102, 182, 135, 160, 174, 17, 223, 229, 114, 120, 196, 80, 12, 134, 249, 109, 113, 214, 23, 95, 159, 151, 88, 125, 158, 94, 102, 131, 31, 116, 131, 63, 174, 111, 223}, { 221, 120, 12, 211, 18, 252, 173, 181, 139, 51, 142, 227, 157, 26, 223, 47, 11, 152, 36, 150, 108, 252, 3, 130, 241, 186, 152, 114, 25, 133, 151, 223, 2, 4, 146, 85, 70, 157, 110, 117, 175, 228, 109, 208, 42, 211, 23, 167, 163, 28, 240, 239, 166, 223, 247, 106, 174, 177, 33, 21, 232, 181, 203, 5, 172, 84, 244, 160, 241, 4, 48, 196, 27, 226, 124, 110, 238, 81, 129, 21, 219, 197, 9, 231, 88, 163, 178, 132}, { 57, 35, 120, 12, 245, 45, 185, 79, 129, 15, 82, 3, 194, 214, 141, 236, 164, 209, 21, 57, 161, 41, 167, 192, 100, 7, 80, 179, 76, 178, 246, 191, 121, 223, 248, 167, 159, 102, 195, 210, 156, 231, 82, 195, 42, 30, 193, 14, 110, 224, 209, 183, 81, 77, 134, 212, 126, 78, 173, 146, 201, 151, 126, 225, 30, 55, 1, 18, 174, 157, 244, 9, 149, 252, 199, 246, 93, 7, 176, 1, 157, 167, 236, 165, 112, 193, 41, 242}, { 69, 95, 228, 30, 2, 98, 241, 67, 183, 185, 10, 152, 135, 148, 8, 195, 227, 252, 44, 17, 144, 240, 106, 91, 187, 85, 117, 34, 175, 222, 190, 127, 186, 203, 235, 108, 112, 94, 191, 229, 237, 125, 6, 251, 100, 180, 41, 2, 29, 14, 176, 145, 154, 44, 248, 110, 64, 178, 12, 130, 206, 89, 66, 141, 108, 49, 77, 44, 135, 202, 40, 227, 68, 174, 203, 227, 213, 40, 213, 167, 192, 15, 165, 80, 233, 147, 22, 129}, { 149, 102, 184, 30, 140, 56, 48, 46, 232, 126, 37, 253, 209, 248, 153, 40, 229, 168, 216, 13, 159, 46, 24, 89, 85, 119, 191, 163, 145, 82, 23, 77, 60, 103, 143, 72, 236, 232, 170, 34, 87, 55, 219, 232, 220, 223, 223, 244, 71, 201, 217, 51, 195, 228, 242, 28, 124, 223, 81, 16, 202, 145, 46, 159, 63, 39, 42, 17, 115, 248, 163, 31, 209, 172, 186, 80, 229, 50, 120, 221, 197, 156, 105, 115, 217, 100, 131, 88}, { 249, 77, 23, 65, 101, 31, 122, 172, 255, 192, 201, 179, 96, 160, 115, 16, 26, 170, 82, 139, 107, 108, 105, 56, 56, 242, 99, 191, 164, 45, 47, 49, 47, 14, 98, 113, 8, 226, 233, 248, 5, 244, 248, 173, 216, 247, 78, 191, 45, 65, 106, 77, 230, 143, 41, 114, 71, 223, 85, 116, 76, 14, 90, 132, 199, 165, 235, 221, 115, 224, 217, 246, 161, 85, 12, 182, 171, 177, 93, 58, 121, 246, 216, 160, 193, 195, 102, 230}, { 66, 252, 121, 90, 110, 42, 205, 133, 152, 255, 216, 153, 148, 77, 142, 89, 221, 124, 102, 149, 110, 118, 84, 30, 215, 67, 81, 134, 223, 165, 139, 169, 218, 150, 246, 110, 188, 189, 72, 125, 194, 26, 54, 244, 138, 135, 193, 5, 128, 65, 136, 2, 95, 105, 66, 155, 86, 72, 108, 182, 199, 199, 186, 126, 27, 59, 155, 102, 108, 204, 198, 248, 215, 17, 138, 88, 65, 182, 51, 4, 203, 130, 194, 119, 122, 210, 70, 29}, { 69, 57, 190, 176, 89, 172, 67, 19, 205, 238, 26, 206, 25, 99, 12, 163, 8, 158, 117, 191, 18, 147, 144, 201, 7, 82, 51, 167, 92, 56, 1, 67, 134, 119, 232, 32, 24, 37, 87, 181, 10, 50, 61, 182, 2, 92, 128, 10, 232, 126, 218, 7, 174, 206, 92, 75, 222, 175, 105, 56, 83, 208, 244, 78, 184, 46, 200, 205, 31, 126, 173, 215, 17, 114, 148, 13, 216, 211, 1, 199, 90, 29, 164, 195, 222, 248, 127, 108}, { 25, 151, 213, 194, 96, 147, 209, 79, 233, 198, 130, 1, 17, 177, 64, 228, 155, 40, 16, 214, 104, 241, 21, 181, 253, 230, 50, 15, 51, 47, 200, 215, 10, 160, 234, 6, 76, 177, 24, 46, 161, 65, 236, 246, 23, 13, 8, 116, 219, 53, 184, 56, 28, 222, 255, 198, 245, 149, 157, 127, 146, 175, 128, 205, 15, 90, 174, 194, 232, 167, 225, 234, 173, 197, 115, 191, 167, 77, 168, 219, 9, 137, 32, 209, 148, 175, 140, 151}, { 74, 165, 146, 251, 79, 145, 18, 167, 222, 79, 202, 215, 216, 209, 54, 63, 209, 150, 162, 85, 181, 112, 209, 198, 64, 252, 5, 44, 143, 93, 106, 40, 99, 2, 251, 243, 154, 107, 195, 38, 235, 231, 73, 11, 58, 155, 35, 114, 248, 51, 251, 221, 243, 75, 58, 144, 50, 177, 236, 212, 136, 252, 169, 142, 255, 129, 118, 78, 51, 131, 78, 197, 183, 188, 200, 53, 116, 25, 67, 254, 110, 58, 53, 140, 39, 231, 168, 132}, { 248, 110, 64, 247, 213, 38, 227, 1, 117, 145, 161, 63, 48, 120, 32, 143, 148, 30, 223, 210, 230, 201, 118, 10, 136, 124, 117, 21, 20, 177, 100, 170, 120, 55, 118, 89, 77, 140, 254, 23, 19, 38, 183, 33, 87, 194, 29, 131, 212, 52, 82, 157, 12, 231, 231, 236, 208, 143, 159, 197, 51, 139, 195, 210, 150, 61, 89, 199, 24, 82, 39, 222, 161, 3, 85, 105, 149, 185, 23, 139, 185, 225, 234, 131, 38, 154, 139, 7}, { 128, 11, 40, 134, 120, 157, 120, 183, 53, 120, 166, 99, 89, 102, 12, 81, 60, 30, 151, 96, 120, 121, 223, 129, 155, 128, 29, 217, 1, 154, 44, 93, 229, 232, 37, 156, 233, 20, 22, 45, 67, 174, 169, 43, 130, 45, 145, 152, 17, 133, 243, 164, 36, 36, 159, 188, 0, 129, 250, 140, 184, 124, 35, 166, 233, 29, 74, 192, 52, 62, 6, 253, 22, 108, 218, 138, 251, 164, 250, 222, 147, 177, 31, 177, 51, 128, 239, 224}, { 86, 135, 186, 230, 140, 135, 217, 187, 109, 14, 46, 105, 204, 211, 12, 212, 143, 33, 36, 108, 248, 151, 27, 234, 80, 116, 9, 19, 121, 46, 54, 14, 23, 130, 152, 251, 235, 2, 103, 35, 52, 122, 32, 143, 220, 48, 1, 96, 171, 233, 34, 208, 83, 14, 174, 130, 171, 189, 51, 135, 18, 24, 216, 104, 157, 69, 66, 247, 174, 212, 174, 167, 95, 156, 8, 194, 99, 48, 137, 140, 78, 41, 157, 244, 149, 161, 70, 142}, { 110, 201, 26, 73, 240, 141, 160, 205, 157, 114, 231, 40, 54, 140, 87, 57, 158, 76, 202, 227, 182, 23, 114, 250, 122, 40, 117, 254, 34, 146, 209, 192, 211, 43, 73, 102, 41, 137, 78, 172, 180, 214, 184, 54, 14, 173, 204, 224, 117, 233, 61, 250, 59, 60, 97, 232, 123, 194, 44, 77, 56, 244, 90, 61, 215, 228, 147, 6, 120, 212, 178, 54, 98, 178, 87, 63, 246, 207, 182, 203, 196, 216, 170, 250, 53, 81, 26, 171}, { 233, 210, 15, 16, 75, 57, 161, 184, 238, 197, 97, 122, 244, 103, 225, 244, 14, 158, 155, 55, 102, 22, 140, 225, 36, 29, 26, 116, 135, 162, 136, 48, 99, 212, 184, 162, 30, 123, 196, 206, 91, 134, 116, 250, 48, 5, 171, 195, 145, 137, 227, 155, 172, 115, 47, 51, 199, 0, 236, 142, 58, 105, 173, 127, 164, 188, 125, 231, 221, 121, 113, 123, 210, 176, 172, 69, 136, 26, 78, 190, 68, 183, 176, 129, 43, 166, 87, 82}, { 248, 37, 38, 184, 248, 55, 45, 214, 181, 196, 189, 87, 75, 4, 187, 78, 159, 66, 248, 214, 94, 228, 177, 245, 32, 48, 148, 84, 237, 91, 222, 97, 168, 9, 28, 37, 47, 248, 85, 234, 43, 184, 234, 230, 39, 211, 89, 53, 155, 234, 171, 16, 196, 6, 182, 88, 125, 8, 66, 43, 31, 158, 88, 194, 145, 166, 213, 57, 20, 80, 27, 179, 243, 251, 132, 216, 103, 54, 229, 85, 12, 207, 231, 163, 125, 219, 179, 180}, { 239, 71, 126, 245, 254, 165, 29, 205, 55, 170, 86, 230, 202, 229, 24, 85, 85, 112, 85, 220, 135, 195, 187, 170, 176, 44, 98, 180, 130, 184, 38, 116, 46, 162, 103, 141, 145, 106, 147, 128, 99, 152, 168, 20, 93, 111, 80, 187, 61, 119, 104, 76, 107, 9, 243, 100, 198, 0, 125, 147, 192, 177, 130, 99, 136, 102, 241, 31, 120, 219, 107, 89, 163, 88, 91, 190, 251, 21, 27, 182, 48, 56, 147, 162, 239, 156, 80, 149}, { 141, 141, 58, 184, 79, 145, 174, 17, 88, 46, 84, 86, 127, 128, 2, 64, 240, 126, 218, 147, 68, 72, 123, 106, 165, 235, 254, 150, 251, 136, 97, 98, 238, 26, 75, 64, 192, 219, 85, 15, 247, 1, 69, 253, 39, 18, 70, 152, 101, 237, 89, 198, 56, 15, 98, 105, 176, 147, 244, 1, 219, 5, 176, 233, 68, 234, 173, 35, 41, 216, 70, 219, 54, 38, 211, 233, 221, 81, 62, 116, 185, 126, 224, 110, 216, 54, 23, 207}, { 160, 67, 219, 21, 197, 74, 84, 127, 146, 199, 163, 147, 55, 178, 249, 44, 55, 81, 244, 28, 32, 91, 194, 141, 135, 125, 64, 52, 202, 141, 197, 202, 232, 210, 192, 81, 14, 23, 100, 118, 138, 129, 229, 123, 120, 152, 241, 113, 172, 21, 32, 48, 56, 222, 2, 141, 121, 129, 162, 55, 240, 214, 63, 104, 204, 5, 90, 54, 83, 83, 202, 143, 239, 167, 104, 185, 105, 139, 38, 64, 201, 34, 98, 148, 22, 132, 30, 177}, { 194, 145, 78, 230, 251, 201, 136, 123, 201, 67, 191, 250, 11, 215, 249, 168, 145, 52, 97, 105, 165, 103, 49, 101, 71, 240, 173, 164, 194, 178, 206, 174, 195, 74, 175, 153, 84, 175, 92, 119, 179, 83, 19, 27, 196, 206, 216, 117, 171, 237, 248, 96, 20, 170, 180, 87, 12, 180, 231, 72, 27, 4, 83, 222, 251, 103, 211, 65, 131, 110, 118, 133, 26, 235, 139, 72, 106, 215, 166, 176, 104, 138, 90, 5, 43, 169, 38, 89}, { 82, 27, 111, 234, 135, 104, 10, 148, 203, 30, 182, 223, 199, 187, 223, 54, 199, 237, 53, 221, 147, 152, 37, 40, 198, 134, 76, 17, 111, 56, 182, 54, 85, 139, 113, 197, 157, 105, 88, 131, 118, 245, 94, 152, 43, 24, 99, 182, 152, 37, 237, 36, 29, 46, 87, 36, 227, 254, 208, 149, 137, 225, 224, 191, 70, 123, 178, 55, 147, 31, 109, 48, 11, 35, 213, 129, 0, 125, 2, 103, 180, 14, 170, 42, 98, 154, 123, 2}, { 187, 191, 139, 5, 220, 124, 81, 244, 63, 52, 67, 44, 245, 135, 24, 17, 160, 164, 37, 224, 71, 22, 199, 125, 1, 208, 63, 90, 94, 24, 120, 159, 190, 229, 191, 2, 127, 130, 73, 134, 228, 253, 153, 173, 186, 217, 172, 125, 111, 220, 86, 59, 73, 51, 114, 115, 183, 50, 87, 203, 249, 117, 165, 241, 251, 162, 248, 15, 1, 85, 35, 255, 53, 158, 64, 77, 198, 165, 47, 186, 24, 81, 1, 29, 65, 239, 189, 238}, { 157, 49, 196, 28, 164, 26, 234, 239, 43, 232, 131, 155, 93, 185, 238, 214, 3, 94, 152, 194, 172, 172, 149, 193, 18, 130, 90, 74, 225, 182, 249, 224, 36, 59, 62, 65, 171, 65, 115, 173, 26, 233, 170, 224, 83, 10, 23, 83, 215, 142, 169, 74, 47, 193, 35, 47, 206, 191, 35, 233, 138, 129, 241, 65, 109, 223, 20, 132, 58, 222, 10, 223, 85, 74, 202, 151, 218, 3, 74, 163, 163, 78, 23, 139, 183, 138, 217, 87}, { 39, 43, 249, 56, 167, 13, 198, 30, 171, 164, 167, 100, 189, 121, 14, 95, 223, 103, 220, 4, 145, 219, 8, 145, 162, 51, 189, 181, 103, 104, 3, 250, 152, 211, 11, 17, 82, 63, 238, 73, 64, 41, 177, 227, 190, 45, 64, 203, 160, 77, 57, 184, 219, 58, 198, 239, 121, 74, 170, 114, 177, 36, 192, 22, 85, 60, 96, 188, 99, 100, 55, 46, 144, 2, 233, 102, 61, 220, 108, 193, 82, 220, 213, 207, 96, 237, 118, 151}, { 216, 63, 141, 223, 156, 82, 120, 218, 46, 155, 88, 91, 216, 63, 115, 21, 13, 106, 88, 18, 27, 57, 140, 187, 153, 206, 239, 54, 25, 235, 42, 96, 74, 213, 23, 161, 179, 147, 168, 194, 41, 227, 55, 106, 41, 131, 69, 64, 253, 32, 72, 209, 81, 159, 21, 205, 194, 70, 7, 137, 107, 22, 153, 47, 61, 178, 185, 165, 205, 176, 255, 146, 157, 99, 34, 89, 32, 85, 207, 156, 194, 57, 52, 205, 45, 160, 32, 151}, { 248, 155, 67, 156, 88, 247, 101, 82, 128, 35, 244, 182, 245, 8, 132, 23, 8, 16, 132, 85, 146, 126, 10, 15, 154, 125, 201, 103, 36, 51, 116, 186, 84, 125, 64, 216, 57, 189, 22, 191, 220, 108, 233, 163, 125, 101, 47, 164, 0, 14, 11, 43, 180, 126, 181, 36, 158, 205, 229, 225, 107, 164, 87, 248, 105, 205, 139, 148, 189, 209, 65, 123, 98, 133, 207, 151, 246, 77, 212, 244, 6, 58, 133, 56, 214, 126, 85, 155}, { 10, 194, 172, 121, 228, 127, 160, 62, 164, 113, 95, 254, 37, 255, 173, 251, 211, 183, 36, 63, 8, 114, 13, 12, 255, 148, 76, 35, 97, 99, 240, 144, 107, 139, 162, 33, 117, 207, 248, 175, 177, 36, 132, 224, 117, 121, 239, 31, 221, 40, 95, 156, 114, 245, 14, 66, 226, 162, 115, 215, 242, 191, 149, 247, 77, 178, 253, 91, 242, 108, 143, 6, 37, 46, 103, 125, 23, 74, 1, 117, 45, 22, 160, 31, 245, 112, 23, 141}, { 95, 161, 192, 197, 46, 151, 233, 158, 44, 189, 247, 212, 193, 128, 49, 164, 122, 194, 223, 53, 37, 203, 233, 83, 247, 248, 10, 164, 212, 206, 87, 6, 247, 190, 157, 75, 137, 151, 26, 79, 68, 144, 5, 142, 161, 175, 33, 171, 191, 142, 50, 230, 253, 226, 108, 22, 39, 74, 19, 28, 27, 105, 212, 84, 141, 185, 220, 56, 40, 210, 79, 151, 112, 97, 200, 4, 198, 25, 66, 198, 119, 151, 118, 81, 63, 30, 94, 240}, { 52, 131, 18, 40, 73, 115, 121, 168, 78, 39, 151, 239, 37, 193, 227, 98, 222, 60, 97, 69, 189, 6, 100, 173, 158, 187, 210, 137, 121, 180, 102, 203, 163, 216, 95, 59, 113, 6, 119, 28, 187, 163, 95, 120, 189, 106, 197, 37, 83, 20, 234, 119, 186, 28, 38, 131, 177, 168, 217, 62, 216, 67, 108, 175, 1, 45, 101, 59, 17, 142, 86, 165, 124, 22, 47, 97, 34, 221, 68, 129, 165, 15, 176, 254, 116, 158, 63, 71}, { 183, 230, 97, 19, 218, 107, 202, 77, 165, 183, 31, 134, 108, 15, 179, 187, 81, 174, 143, 84, 117, 245, 222, 234, 147, 237, 191, 212, 137, 60, 1, 176, 64, 98, 211, 23, 5, 148, 165, 8, 237, 30, 143, 73, 149, 50, 114, 111, 112, 43, 8, 64, 223, 189, 113, 225, 67, 200, 90, 112, 102, 164, 22, 29, 218, 35, 101, 54, 83, 36, 191, 97, 223, 211, 151, 14, 129, 18, 50, 33, 23, 219, 100, 18, 125, 150, 69, 69}, { 237, 62, 225, 8, 70, 251, 120, 219, 47, 184, 170, 10, 240, 194, 23, 131, 124, 187, 7, 127, 165, 58, 212, 140, 247, 181, 115, 233, 34, 218, 157, 177, 163, 203, 145, 162, 11, 126, 195, 115, 103, 239, 230, 148, 86, 147, 204, 176, 202, 125, 165, 95, 41, 41, 59, 60, 107, 42, 165, 226, 88, 174, 180, 128, 219, 123, 60, 20, 12, 165, 133, 60, 174, 36, 167, 232, 144, 216, 174, 150, 155, 122, 142, 156, 234, 41, 151, 117}, { 214, 73, 196, 8, 24, 253, 252, 104, 192, 154, 213, 0, 18, 1, 45, 75, 198, 210, 235, 103, 21, 2, 209, 151, 218, 225, 148, 16, 213, 214, 184, 102, 230, 236, 6, 198, 6, 152, 222, 171, 59, 136, 81, 148, 133, 171, 238, 12, 79, 200, 102, 5, 145, 211, 251, 57, 222, 178, 76, 102, 57, 142, 141, 245, 72, 209, 121, 180, 112, 188, 201, 35, 50, 143, 242, 48, 168, 71, 6, 233, 246, 56, 195, 185, 18, 56, 89, 150}, { 136, 209, 217, 34, 132, 234, 50, 236, 171, 158, 95, 241, 228, 84, 112, 252, 18, 2, 140, 213, 133, 22, 217, 176, 58, 44, 202, 0, 50, 169, 133, 188, 43, 139, 62, 191, 82, 244, 92, 135, 29, 49, 4, 62, 148, 92, 221, 128, 18, 153, 233, 126, 29, 203, 153, 144, 160, 219, 224, 10, 128, 246, 109, 128, 171, 49, 197, 39, 198, 204, 231, 235, 1, 21, 72, 57, 131, 165, 156, 82, 147, 130, 236, 67, 231, 170, 208, 107}, { 91, 141, 102, 138, 206, 187, 241, 235, 24, 7, 201, 229, 65, 14, 228, 39, 195, 152, 223, 103, 233, 91, 7, 12, 180, 145, 70, 203, 137, 119, 66, 77, 94, 156, 75, 219, 115, 33, 223, 201, 76, 9, 185, 181, 36, 212, 206, 138, 236, 36, 178, 63, 134, 10, 130, 13, 20, 157, 146, 190, 35, 17, 160, 29, 138, 74, 71, 218, 90, 69, 20, 14, 125, 196, 42, 189, 48, 111, 127, 9, 168, 101, 212, 217, 44, 157, 96, 8}, { 6, 248, 36, 212, 244, 195, 236, 213, 21, 42, 220, 54, 144, 232, 242, 85, 158, 100, 58, 107, 253, 208, 29, 7, 121, 204, 225, 243, 107, 85, 37, 78, 11, 46, 55, 137, 39, 53, 30, 228, 5, 75, 99, 23, 146, 118, 159, 58, 201, 94, 85, 123, 109, 122, 79, 137, 144, 40, 150, 225, 87, 5, 31, 13, 80, 159, 136, 248, 65, 39, 11, 184, 69, 139, 160, 62, 252, 176, 94, 179, 148, 202, 253, 76, 13, 200, 183, 255}, { 119, 100, 212, 121, 153, 91, 77, 76, 92, 168, 74, 248, 198, 247, 59, 177, 30, 172, 119, 72, 78, 112, 117, 177, 139, 127, 128, 113, 187, 17, 252, 47, 128, 167, 52, 202, 134, 29, 241, 103, 93, 173, 48, 189, 253, 179, 209, 182, 151, 36, 110, 195, 227, 132, 142, 41, 94, 13, 168, 215, 135, 81, 229, 189, 16, 93, 87, 190, 209, 211, 179, 172, 149, 103, 38, 58, 59, 236, 178, 210, 68, 157, 38, 111, 118, 217, 81, 253}, { 60, 137, 115, 46, 198, 251, 115, 85, 120, 231, 70, 161, 252, 242, 178, 128, 120, 30, 57, 3, 217, 178, 100, 214, 220, 113, 40, 237, 158, 2, 194, 73, 152, 206, 39, 216, 203, 172, 220, 127, 19, 199, 182, 229, 98, 35, 162, 23, 15, 121, 159, 148, 237, 233, 170, 41, 233, 89, 221, 111, 11, 29, 25, 162, 152, 146, 125, 6, 0, 113, 127, 68, 50, 2, 33, 150, 169, 50, 84, 90, 224, 34, 240, 112, 205, 171, 94, 190}, { 112, 44, 208, 71, 88, 93, 225, 168, 4, 245, 214, 6, 226, 71, 35, 134, 25, 215, 12, 255, 124, 12, 15, 198, 2, 1, 45, 17, 30, 165, 97, 26, 1, 188, 157, 22, 19, 174, 203, 236, 56, 46, 92, 82, 55, 77, 73, 204, 227, 78, 88, 211, 69, 81, 249, 234, 123, 32, 207, 49, 214, 71, 199, 43, 11, 95, 31, 169, 116, 179, 153, 162, 49, 133, 134, 124, 3, 86, 242, 136, 94, 172, 143, 66, 93, 169, 41, 38}, { 68, 13, 240, 17, 19, 133, 112, 159, 9, 130, 111, 52, 171, 101, 152, 18, 152, 245, 53, 145, 54, 178, 151, 251, 163, 21, 118, 5, 175, 140, 203, 223, 187, 218, 60, 104, 202, 113, 193, 225, 123, 180, 95, 126, 3, 113, 92, 219, 236, 196, 25, 177, 172, 206, 212, 197, 58, 116, 17, 38, 7, 166, 189, 23, 134, 236, 220, 91, 97, 177, 220, 150, 249, 85, 35, 5, 238, 202, 195, 12, 146, 153, 204, 56, 168, 121, 61, 64}, { 113, 243, 228, 154, 64, 220, 105, 178, 0, 112, 219, 138, 87, 102, 11, 138, 33, 93, 129, 189, 44, 126, 27, 75, 21, 77, 24, 139, 205, 225, 136, 8, 116, 127, 182, 78, 121, 253, 70, 144, 6, 173, 135, 165, 68, 57, 141, 180, 155, 40, 76, 90, 13, 103, 62, 134, 105, 197, 64, 222, 97, 98, 187, 100, 43, 183, 23, 37, 74, 229, 166, 148, 42, 161, 114, 117, 99, 134, 14, 211, 116, 155, 254, 34, 90, 41, 79, 145}, { 210, 108, 54, 24, 31, 118, 237, 12, 26, 118, 39, 159, 168, 164, 52, 200, 17, 214, 6, 205, 81, 181, 122, 9, 178, 224, 243, 241, 252, 73, 231, 53, 70, 72, 46, 230, 127, 83, 13, 195, 219, 5, 49, 215, 224, 213, 146, 237, 131, 96, 43, 244, 106, 63, 255, 139, 145, 11, 146, 84, 117, 138, 22, 130, 139, 75, 209, 21, 37, 249, 10, 140, 48, 54, 43, 42, 78, 158, 10, 236, 46, 219, 160, 240, 45, 1, 220, 6}, { 1, 200, 119, 68, 25, 205, 245, 178, 111, 57, 218, 224, 167, 61, 253, 168, 13, 154, 4, 246, 39, 148, 90, 217, 45, 1, 2, 179, 57, 97, 112, 98, 79, 3, 188, 45, 95, 10, 90, 36, 80, 192, 33, 177, 32, 45, 29, 239, 216, 119, 42, 151, 83, 18, 230, 148, 7, 190, 205, 169, 186, 222, 149, 31, 171, 53, 181, 47, 79, 65, 133, 181, 148, 162, 19, 188, 176, 81, 184, 106, 6, 141, 179, 85, 87, 19, 36, 157}, { 180, 229, 227, 174, 118, 147, 63, 204, 219, 84, 83, 240, 96, 235, 117, 69, 129, 14, 25, 56, 217, 230, 194, 109, 63, 151, 245, 219, 243, 125, 21, 224, 245, 186, 61, 58, 117, 58, 13, 51, 27, 33, 64, 142, 56, 86, 202, 78, 78, 12, 44, 13, 212, 109, 37, 192, 18, 168, 41, 41, 255, 34, 225, 124, 81, 12, 160, 33, 171, 170, 152, 180, 172, 194, 203, 160, 220, 92, 88, 193, 92, 101, 2, 103, 193, 96, 200, 64}, { 13, 220, 167, 46, 73, 91, 83, 177, 2, 47, 171, 232, 57, 13, 197, 112, 89, 234, 227, 106, 62, 150, 191, 132, 225, 203, 208, 188, 141, 18, 241, 6, 181, 112, 65, 155, 149, 109, 116, 240, 133, 199, 51, 170, 218, 188, 166, 143, 0, 33, 36, 255, 167, 135, 67, 39, 215, 42, 73, 37, 254, 33, 207, 141, 117, 143, 113, 14, 4, 80, 72, 68, 212, 235, 168, 242, 40, 236, 127, 175, 247, 170, 178, 60, 153, 225, 232, 47}, { 18, 150, 29, 13, 151, 41, 192, 205, 168, 116, 144, 210, 140, 208, 191, 214, 218, 126, 116, 178, 140, 14, 132, 88, 2, 13, 244, 186, 222, 209, 140, 198, 212, 79, 63, 59, 121, 48, 127, 212, 146, 68, 141, 29, 85, 74, 115, 170, 158, 153, 208, 210, 29, 162, 237, 214, 57, 107, 16, 32, 173, 147, 224, 245, 150, 140, 230, 135, 138, 99, 234, 162, 50, 153, 36, 138, 9, 74, 70, 19, 242, 32, 76, 174, 53, 178, 193, 67}, { 203, 133, 115, 208, 224, 208, 80, 109, 204, 245, 163, 249, 94, 81, 125, 75, 20, 27, 19, 66, 32, 67, 1, 189, 139, 196, 169, 251, 200, 244, 57, 215, 163, 214, 206, 73, 209, 135, 23, 109, 245, 51, 9, 189, 230, 27, 58, 109, 100, 89, 164, 177, 143, 136, 242, 9, 97, 211, 222, 159, 142, 210, 75, 81, 76, 177, 22, 245, 181, 231, 164, 59, 242, 171, 193, 65, 187, 69, 238, 13, 78, 99, 177, 186, 68, 131, 153, 128}, { 229, 50, 158, 129, 64, 213, 37, 57, 81, 49, 47, 15, 250, 16, 94, 195, 89, 250, 146, 53, 96, 232, 168, 102, 156, 150, 249, 69, 226, 83, 206, 253, 118, 177, 11, 94, 134, 9, 111, 165, 43, 41, 196, 209, 175, 60, 98, 19, 83, 49, 82, 232, 225, 216, 171, 94, 106, 226, 27, 241, 183, 225, 223, 28, 240, 16, 115, 36, 201, 15, 119, 35, 95, 237, 252, 76, 56, 237, 151, 27, 140, 236, 162, 33, 43, 160, 72, 180}, { 176, 28, 14, 215, 180, 26, 179, 213, 242, 188, 234, 177, 42, 204, 35, 160, 139, 199, 251, 24, 16, 8, 111, 140, 217, 98, 220, 117, 222, 57, 27, 25, 169, 101, 66, 75, 12, 133, 218, 91, 79, 245, 108, 79, 226, 225, 245, 242, 78, 128, 88, 162, 133, 204, 185, 69, 39, 157, 107, 184, 33, 149, 139, 15, 94, 38, 237, 167, 213, 161, 1, 182, 177, 42, 124, 152, 79, 39, 94, 14, 187, 71, 0, 167, 226, 29, 218, 202}, { 247, 82, 80, 111, 146, 206, 252, 64, 26, 175, 188, 63, 142, 15, 97, 152, 153, 139, 220, 174, 14, 187, 71, 18, 175, 98, 90, 66, 198, 34, 150, 176, 71, 77, 87, 196, 36, 14, 156, 240, 17, 29, 250, 1, 205, 111, 22, 131, 40, 220, 184, 8, 197, 236, 157, 206, 174, 103, 109, 249, 117, 120, 227, 85, 216, 105, 25, 78, 73, 231, 114, 195, 229, 254, 105, 51, 35, 51, 125, 128, 249, 164, 206, 0, 217, 237, 175, 124}, { 35, 140, 189, 195, 239, 221, 247, 119, 74, 0, 60, 59, 46, 209, 50, 73, 152, 121, 16, 109, 140, 42, 144, 200, 245, 139, 183, 74, 10, 27, 225, 124, 19, 195, 198, 185, 11, 23, 253, 241, 152, 192, 131, 99, 116, 123, 82, 110, 253, 231, 81, 226, 165, 124, 221, 12, 123, 237, 9, 128, 111, 231, 64, 95, 76, 131, 184, 135, 1, 255, 3, 94, 85, 180, 204, 177, 198, 8, 66, 81, 216, 224, 145, 64, 223, 177, 13, 153}, { 18, 100, 41, 251, 225, 159, 141, 214, 11, 201, 195, 3, 104, 153, 51, 205, 93, 222, 128, 27, 62, 218, 250, 30, 139, 214, 169, 83, 164, 50, 250, 195, 72, 167, 179, 13, 250, 91, 90, 63, 20, 172, 229, 4, 199, 95, 157, 130, 65, 165, 138, 150, 162, 243, 9, 201, 2, 66, 231, 178, 233, 187, 67, 155, 144, 166, 79, 153, 36, 147, 158, 251, 123, 193, 182, 145, 136, 2, 121, 184, 165, 66, 63, 75, 30, 204, 203, 239}, { 86, 123, 181, 169, 215, 110, 250, 181, 58, 146, 223, 131, 109, 47, 123, 27, 245, 167, 143, 89, 255, 218, 55, 79, 140, 175, 153, 161, 91, 1, 182, 192, 105, 163, 238, 33, 195, 166, 99, 252, 255, 201, 160, 71, 47, 237, 225, 137, 17, 117, 136, 57, 164, 255, 48, 39, 127, 30, 223, 220, 28, 32, 113, 215, 216, 3, 56, 45, 245, 112, 38, 174, 232, 130, 72, 82, 151, 89, 128, 156, 103, 91, 231, 204, 112, 35, 12, 151}, { 229, 97, 248, 172, 49, 113, 214, 34, 40, 204, 68, 169, 149, 238, 59, 178, 125, 219, 132, 185, 130, 200, 74, 200, 35, 114, 88, 41, 142, 17, 4, 173, 78, 224, 247, 87, 165, 115, 174, 98, 219, 108, 252, 203, 67, 192, 203, 128, 108, 160, 37, 88, 37, 78, 73, 188, 23, 123, 157, 136, 212, 202, 43, 244, 221, 190, 222, 160, 57, 253, 237, 109, 186, 120, 155, 123, 161, 224, 173, 152, 72, 64, 132, 252, 123, 185, 149, 34}, { 126, 135, 5, 182, 164, 61, 92, 197, 78, 37, 151, 168, 14, 204, 58, 172, 114, 252, 200, 7, 100, 1, 246, 93, 119, 155, 152, 156, 114, 224, 7, 59, 237, 222, 41, 211, 61, 216, 93, 97, 37, 143, 123, 157, 183, 107, 247, 68, 111, 189, 161, 111, 5, 84, 204, 181, 168, 169, 242, 113, 66, 154, 86, 135, 73, 166, 247, 37, 48, 178, 104, 135, 13, 75, 9, 115, 190, 107, 47, 128, 204, 127, 138, 225, 117, 214, 167, 127}, { 174, 231, 250, 167, 185, 153, 169, 98, 159, 203, 182, 80, 116, 53, 35, 156, 103, 182, 126, 3, 188, 105, 0, 46, 130, 91, 180, 75, 188, 32, 215, 75, 116, 189, 224, 51, 225, 185, 101, 241, 8, 56, 138, 106, 134, 40, 47, 212, 213, 115, 199, 211, 143, 166, 78, 185, 60, 209, 232, 56, 82, 155, 157, 124, 131, 103, 3, 78, 180, 202, 50, 136, 213, 74, 45, 88, 95, 144, 154, 165, 1, 239, 27, 155, 172, 208, 20, 120}, { 144, 103, 20, 38, 168, 163, 37, 179, 192, 0, 238, 13, 47, 1, 92, 67, 146, 172, 205, 159, 134, 249, 202, 22, 236, 73, 219, 162, 228, 58, 22, 24, 90, 14, 101, 23, 112, 162, 112, 153, 99, 63, 90, 196, 160, 146, 56, 11, 236, 47, 172, 113, 25, 2, 83, 202, 197, 246, 251, 239, 28, 237, 88, 38, 172, 138, 7, 140, 140, 64, 182, 12, 102, 200, 98, 181, 72, 177, 31, 60, 103, 67, 104, 247, 1, 92, 36, 153}, { 34, 43, 241, 89, 178, 192, 128, 0, 223, 33, 138, 172, 160, 254, 27, 146, 211, 178, 167, 83, 19, 87, 220, 153, 161, 50, 205, 233, 3, 182, 165, 124, 131, 158, 169, 54, 22, 155, 217, 204, 234, 149, 39, 209, 101, 74, 188, 11, 48, 148, 146, 222, 190, 105, 54, 185, 247, 219, 28, 153, 176, 7, 34, 129, 104, 127, 255, 81, 155, 54, 73, 227, 200, 188, 149, 241, 65, 72, 70, 37, 85, 37, 245, 90, 60, 251, 114, 126}, { 229, 134, 126, 125, 212, 136, 77, 224, 211, 35, 253, 46, 95, 19, 198, 94, 151, 115, 176, 178, 148, 147, 203, 157, 221, 148, 107, 246, 55, 185, 179, 255, 8, 201, 180, 92, 18, 43, 68, 156, 237, 224, 226, 64, 71, 159, 173, 227, 254, 37, 178, 49, 241, 178, 138, 175, 135, 64, 189, 29, 59, 209, 168, 134, 252, 12, 185, 210, 109, 6, 28, 219, 35, 210, 74, 218, 148, 113, 162, 104, 184, 104, 30, 169, 93, 116, 18, 137}};
                    int array_negate[91][88] = {{ 102, 65, 245, 14, 51, 234, 176, 213, 118, 221, 51, 170, 130, 5, 90, 135, 29, 11, 103, 28, 233, 188, 197, 78, 204, 174, 241, 121, 19, 114, 252, 85, 104, 211, 223, 168, 87, 96, 12, 117, 0, 10, 48, 237, 35, 215, 211, 102, 197, 252, 99, 175, 16, 233, 136, 223, 182, 144, 170, 66, 215, 72, 23, 7, 74, 34, 77, 10, 127, 27, 245, 126, 129, 193, 13, 98, 20, 148, 67, 123, 23, 138, 112, 36, 104, 36, 153, 159}, { 243, 196, 175, 209, 127, 8, 193, 23, 30, 220, 0, 129, 212, 40, 174, 101, 101, 241, 222, 191, 253, 180, 7, 12, 113, 45, 46, 114, 156, 209, 144, 134, 128, 68, 32, 118, 162, 57, 142, 170, 189, 19, 137, 248, 151, 37, 42, 134, 116, 114, 196, 228, 173, 93, 156, 204, 72, 173, 147, 234, 166, 176, 102, 38, 217, 247, 19, 238, 96, 169, 44, 139, 1, 24, 137, 198, 247, 22, 193, 21, 14, 228, 112, 51, 168, 57, 12, 91}, { 60, 244, 9, 43, 83, 248, 192, 216, 160, 87, 121, 45, 237, 233, 139, 196, 189, 203, 41, 246, 77, 61, 115, 69, 212, 144, 106, 96, 15, 242, 205, 104, 247, 29, 180, 26, 35, 54, 39, 161, 0, 49, 2, 190, 27, 12, 78, 214, 219, 115, 107, 153, 5, 205, 110, 149, 243, 86, 204, 34, 99, 85, 48, 42, 59, 50, 133, 124, 82, 2, 43, 240, 68, 200, 27, 134, 110, 15, 85, 243, 19, 72, 245, 119, 95, 132, 103, 76}, { 232, 116, 57, 27, 54, 191, 225, 49, 114, 10, 20, 219, 244, 222, 198, 138, 112, 51, 229, 114, 153, 223, 227, 144, 159, 40, 84, 35, 219, 253, 53, 81, 87, 91, 186, 220, 70, 217, 70, 105, 143, 139, 242, 55, 93, 176, 35, 237, 15, 208, 28, 53, 114, 38, 42, 195, 199, 63, 179, 108, 158, 133, 131, 50, 146, 126, 163, 124, 112, 125, 79, 145, 252, 183, 216, 197, 253, 122, 16, 33, 36, 213, 198, 33, 173, 63, 222, 133}, { 204, 246, 33, 244, 60, 5, 142, 172, 78, 97, 186, 168, 129, 37, 64, 180, 146, 65, 215, 79, 190, 161, 250, 88, 9, 27, 192, 77, 123, 89, 39, 123, 97, 109, 1, 117, 126, 184, 111, 81, 114, 45, 70, 166, 104, 162, 38, 54, 185, 213, 96, 126, 221, 183, 174, 223, 51, 122, 95, 189, 187, 29, 62, 98, 56, 176, 189, 228, 106, 0, 246, 140, 217, 70, 175, 31, 24, 52, 123, 69, 131, 50, 184, 174, 167, 115, 177, 183}, { 101, 107, 243, 95, 6, 205, 109, 52, 68, 149, 190, 218, 183, 243, 190, 137, 210, 237, 134, 125, 133, 43, 42, 221, 210, 163, 8, 247, 18, 108, 247, 93, 169, 150, 213, 215, 204, 101, 105, 35, 234, 126, 192, 50, 143, 156, 244, 217, 248, 172, 123, 184, 26, 12, 108, 129, 102, 77, 67, 95, 146, 90, 53, 21, 209, 213, 85, 254, 193, 142, 235, 194, 111, 82, 186, 175, 192, 250, 15, 237, 109, 239, 44, 107, 120, 254, 72, 32}, { 127, 97, 236, 189, 46, 37, 62, 231, 220, 16, 101, 166, 47, 98, 168, 56, 207, 216, 127, 196, 111, 141, 167, 157, 111, 64, 254, 186, 52, 15, 167, 28, 4, 186, 117, 234, 128, 143, 76, 122, 195, 228, 156, 79, 123, 26, 212, 65, 20, 208, 97, 10, 152, 22, 248, 48, 238, 236, 82, 100, 150, 143, 60, 155, 181, 134, 178, 54, 97, 131, 103, 81, 129, 72, 219, 120, 225, 45, 240, 2, 87, 39, 98, 157, 50, 164, 12, 70}, { 105, 145, 25, 88, 119, 120, 19, 195, 36, 160, 200, 11, 144, 35, 239, 189, 139, 122, 254, 85, 6, 142, 76, 31, 231, 127, 253, 92, 111, 137, 179, 213, 87, 73, 111, 37, 67, 185, 98, 173, 73, 249, 12, 236, 5, 173, 40, 25, 247, 42, 128, 0, 232, 158, 159, 189, 22, 179, 81, 34, 84, 74, 154, 225, 199, 62, 26, 105, 22, 73, 161, 145, 129, 77, 213, 234, 178, 90, 63, 110, 195, 157, 142, 181, 14, 177, 168, 189}, { 121, 163, 201, 237, 62, 221, 148, 199, 84, 90, 21, 59, 91, 3, 249, 137, 222, 132, 250, 193, 224, 100, 37, 32, 41, 177, 45, 35, 59, 42, 18, 175, 61, 220, 200, 161, 131, 183, 212, 5, 122, 125, 38, 32, 187, 151, 14, 139, 92, 55, 83, 84, 77, 101, 132, 129, 203, 238, 54, 223, 183, 28, 49, 231, 139, 242, 99, 166, 153, 212, 72, 249, 114, 210, 156, 9, 92, 214, 163, 189, 119, 35, 177, 203, 121, 179, 206, 134}, { 18, 252, 188, 245, 136, 72, 165, 238, 59, 171, 110, 43, 232, 160, 184, 213, 112, 236, 79, 64, 116, 242, 112, 91, 252, 29, 211, 212, 237, 47, 37, 67, 222, 94, 250, 228, 95, 93, 84, 45, 206, 157, 184, 152, 190, 170, 197, 21, 71, 187, 138, 128, 254, 122, 210, 102, 246, 32, 6, 212, 209, 134, 232, 122, 191, 51, 243, 137, 200, 191, 225, 31, 78, 159, 249, 204, 139, 3, 45, 157, 175, 128, 179, 6, 129, 216, 155, 0}, { 97, 1, 28, 163, 217, 217, 114, 46, 125, 52, 187, 74, 46, 16, 38, 150, 35, 5, 136, 62, 146, 172, 84, 191, 193, 88, 151, 219, 21, 66, 173, 240, 254, 35, 152, 62, 83, 234, 231, 215, 224, 5, 6, 40, 32, 172, 56, 130, 168, 29, 25, 176, 199, 175, 184, 218, 97, 68, 107, 117, 69, 243, 30, 60, 132, 176, 188, 143, 241, 1, 254, 247, 57, 89, 225, 53, 89, 168, 141, 206, 132, 148, 77, 192, 243, 163, 148, 90}, { 225, 189, 176, 55, 107, 247, 189, 226, 64, 152, 71, 23, 83, 251, 234, 45, 182, 68, 175, 219, 63, 74, 72, 169, 243, 15, 223, 29, 155, 111, 232, 77, 67, 118, 53, 61, 240, 63, 46, 229, 165, 111, 186, 118, 24, 239, 224, 140, 211, 235, 71, 124, 98, 96, 64, 250, 8, 149, 130, 66, 90, 51, 198, 168, 189, 236, 174, 238, 12, 149, 151, 251, 239, 22, 230, 251, 60, 80, 15, 113, 15, 50, 8, 111, 13, 15, 154, 77}, { 96, 59, 194, 163, 24, 169, 18, 168, 109, 80, 28, 106, 142, 164, 70, 243, 246, 162, 148, 119, 149, 112, 144, 164, 161, 193, 40, 12, 195, 150, 52, 147, 103, 137, 192, 179, 250, 249, 103, 185, 175, 53, 10, 111, 121, 122, 196, 205, 70, 167, 46, 131, 30, 174, 182, 232, 247, 132, 186, 73, 190, 0, 189, 180, 5, 87, 70, 50, 91, 183, 4, 104, 172, 204, 159, 144, 197, 220, 239, 248, 224, 20, 24, 241, 210, 231, 34, 225}, { 36, 136, 213, 113, 141, 197, 62, 143, 136, 67, 72, 11, 17, 95, 121, 122, 88, 49, 67, 215, 177, 98, 76, 122, 70, 215, 94, 11, 70, 81, 201, 0, 69, 113, 50, 141, 174, 144, 247, 223, 204, 64, 52, 94, 67, 250, 103, 60, 251, 117, 1, 0, 61, 150, 58, 85, 23, 169, 131, 103, 124, 180, 179, 130, 72, 188, 231, 205, 12, 228, 11, 92, 132, 67, 1, 205, 66, 86, 179, 28, 152, 97, 163, 120, 79, 57, 209, 62}, { 76, 133, 84, 126, 45, 121, 254, 121, 251, 15, 173, 16, 185, 190, 143, 93, 99, 198, 127, 191, 93, 150, 231, 0, 200, 78, 165, 53, 193, 24, 186, 94, 29, 15, 35, 186, 125, 10, 104, 37, 162, 37, 13, 199, 89, 217, 30, 59, 106, 122, 181, 254, 164, 205, 213, 12, 253, 113, 29, 208, 132, 75, 74, 53, 132, 195, 141, 27, 137, 151, 124, 222, 72, 132, 119, 190, 241, 131, 149, 219, 1, 163, 15, 52, 114, 102, 59, 240}, { 208, 42, 192, 30, 4, 135, 176, 253, 107, 120, 244, 4, 118, 209, 177, 192, 97, 98, 72, 173, 157, 43, 110, 156, 175, 204, 76, 133, 213, 74, 37, 247, 11, 125, 199, 81, 102, 116, 52, 49, 212, 149, 188, 4, 200, 180, 181, 38, 177, 3, 163, 218, 128, 189, 97, 248, 137, 50, 243, 162, 115, 77, 227, 131, 206, 78, 47, 166, 251, 43, 96, 122, 224, 167, 104, 35, 156, 77, 113, 93, 0, 51, 206, 58, 59, 241, 56, 99}, { 130, 20, 136, 139, 206, 79, 112, 73, 137, 250, 156, 201, 135, 39, 99, 175, 37, 38, 240, 207, 151, 139, 215, 179, 197, 105, 131, 207, 140, 109, 96, 188, 159, 128, 159, 235, 57, 95, 118, 7, 225, 151, 135, 107, 230, 121, 243, 188, 105, 23, 35, 220, 89, 226, 185, 19, 50, 211, 122, 43, 160, 118, 41, 139, 190, 129, 236, 84, 224, 52, 197, 136, 23, 135, 150, 161, 37, 228, 106, 125, 91, 40, 175, 244, 188, 120, 51, 79}, { 100, 90, 49, 193, 76, 139, 118, 185, 173, 241, 204, 86, 172, 121, 212, 221, 42, 235, 245, 17, 2, 3, 6, 35, 69, 240, 20, 145, 222, 245, 5, 12, 81, 177, 77, 46, 192, 76, 54, 54, 59, 235, 100, 248, 206, 143, 201, 163, 102, 75, 221, 216, 27, 79, 215, 5, 225, 173, 124, 255, 46, 140, 19, 157, 141, 156, 184, 179, 128, 175, 77, 209, 255, 192, 17, 54, 177, 151, 237, 114, 238, 218, 158, 221, 232, 27, 117, 234}, { 33, 149, 77, 100, 79, 220, 107, 207, 252, 26, 230, 169, 209, 187, 217, 132, 188, 188, 226, 113, 128, 126, 72, 21, 2, 251, 89, 90, 27, 249, 46, 194, 159, 123, 206, 15, 225, 99, 171, 160, 157, 194, 15, 44, 101, 88, 155, 217, 182, 145, 195, 207, 14, 20, 230, 241, 52, 242, 169, 167, 146, 170, 92, 117, 94, 141, 141, 50, 247, 94, 73, 154, 235, 221, 139, 143, 117, 45, 131, 171, 8, 120, 153, 171, 192, 68, 28, 57}, { 166, 202, 73, 35, 143, 226, 228, 22, 225, 181, 40, 110, 133, 144, 24, 251, 131, 82, 252, 164, 51, 232, 150, 46, 211, 120, 146, 88, 182, 137, 197, 239, 102, 127, 26, 210, 53, 186, 146, 225, 162, 32, 252, 94, 68, 226, 248, 191, 167, 216, 234, 208, 205, 36, 163, 211, 167, 242, 129, 41, 104, 222, 233, 1, 209, 237, 181, 148, 90, 160, 26, 59, 127, 222, 249, 193, 48, 125, 233, 175, 88, 55, 22, 128, 151, 26, 80, 29}, { 79, 233, 44, 189, 132, 163, 108, 1, 36, 195, 37, 104, 214, 152, 212, 208, 168, 59, 112, 112, 187, 3, 255, 68, 80, 102, 34, 46, 133, 188, 242, 111, 42, 149, 64, 28, 217, 172, 120, 3, 115, 163, 41, 26, 128, 222, 105, 24, 84, 88, 237, 64, 138, 97, 205, 146, 118, 109, 67, 237, 251, 187, 88, 103, 25, 241, 186, 214, 47, 40, 102, 22, 70, 80, 225, 71, 212, 156, 55, 234, 48, 106, 231, 91, 86, 135, 108, 111}, { 7, 45, 71, 212, 190, 123, 212, 169, 216, 18, 111, 91, 246, 51, 88, 205, 233, 0, 139, 97, 122, 105, 115, 179, 103, 56, 181, 233, 162, 208, 223, 168, 169, 224, 31, 128, 197, 77, 65, 254, 129, 41, 205, 27, 181, 199, 51, 230, 35, 78, 228, 152, 135, 164, 195, 132, 213, 175, 212, 142, 95, 28, 34, 230, 59, 168, 148, 151, 244, 83, 17, 245, 91, 85, 162, 98, 151, 74, 90, 84, 229, 79, 75, 243, 42, 198, 108, 81}, { 184, 211, 167, 247, 190, 12, 82, 118, 215, 53, 6, 51, 128, 145, 207, 133, 19, 241, 207, 98, 240, 30, 124, 27, 141, 143, 93, 192, 199, 132, 249, 182, 152, 133, 25, 218, 161, 224, 206, 158, 127, 41, 202, 43, 190, 242, 103, 28, 155, 24, 152, 91, 105, 46, 19, 165, 143, 199, 126, 216, 183, 34, 173, 100, 29, 42, 194, 111, 11, 205, 254, 52, 28, 4, 126, 77, 82, 248, 114, 113, 71, 82, 0, 236, 133, 80, 152, 108}, { 128, 170, 104, 34, 74, 134, 239, 155, 240, 29, 38, 122, 118, 30, 4, 16, 70, 52, 117, 178, 175, 161, 95, 233, 166, 138, 94, 190, 102, 3, 63, 139, 91, 107, 218, 167, 251, 53, 6, 6, 30, 242, 45, 197, 128, 246, 23, 131, 161, 158, 136, 10, 237, 106, 73, 10, 226, 211, 129, 75, 226, 158, 103, 43, 94, 86, 116, 73, 204, 253, 76, 213, 75, 17, 103, 19, 36, 171, 73, 63, 178, 43, 249, 3, 223, 216, 247, 209}, { 229, 88, 23, 78, 217, 231, 147, 68, 85, 215, 185, 225, 122, 72, 39, 76, 131, 79, 117, 161, 252, 209, 110, 103, 242, 232, 105, 192, 144, 114, 45, 226, 157, 228, 19, 18, 57, 99, 30, 150, 135, 52, 165, 146, 255, 18, 15, 163, 157, 191, 75, 214, 68, 118, 88, 107, 209, 170, 169, 64, 159, 13, 197, 66, 177, 209, 139, 48, 233, 78, 19, 111, 47, 6, 241, 99, 178, 67, 44, 24, 5, 243, 197, 230, 40, 14, 214, 15}, { 151, 134, 55, 143, 193, 185, 96, 253, 218, 38, 73, 25, 67, 160, 15, 81, 212, 14, 114, 89, 6, 152, 48, 197, 146, 185, 192, 149, 227, 219, 154, 24, 125, 84, 8, 173, 231, 47, 193, 249, 52, 70, 66, 230, 54, 213, 60, 199, 81, 15, 53, 26, 169, 127, 163, 67, 1, 240, 207, 224, 144, 234, 252, 185, 117, 32, 158, 172, 123, 241, 194, 250, 239, 142, 223, 215, 97, 95, 227, 44, 9, 58, 219, 250, 128, 97, 154, 67}, { 49, 145, 12, 227, 67, 216, 41, 131, 202, 222, 112, 16, 253, 104, 37, 116, 33, 5, 78, 125, 204, 250, 25, 84, 34, 38, 76, 209, 217, 119, 229, 200, 10, 149, 184, 201, 170, 190, 102, 91, 206, 107, 252, 200, 203, 56, 104, 236, 132, 105, 93, 84, 240, 122, 69, 200, 219, 119, 48, 73, 27, 214, 195, 92, 178, 129, 101, 197, 145, 139, 175, 141, 40, 84, 228, 166, 144, 156, 176, 33, 194, 250, 201, 169, 68, 73, 84, 100}, { 42, 172, 203, 84, 212, 47, 3, 64, 49, 86, 208, 63, 150, 150, 131, 113, 235, 46, 68, 30, 78, 254, 2, 108, 212, 158, 56, 235, 85, 38, 68, 218, 181, 140, 8, 40, 49, 58, 7, 201, 42, 223, 216, 172, 65, 116, 214, 73, 91, 45, 216, 19, 225, 148, 51, 126, 75, 200, 33, 183, 116, 51, 69, 165, 122, 243, 211, 85, 162, 167, 1, 247, 5, 4, 48, 20, 2, 196, 3, 214, 51, 200, 26, 70, 92, 242, 227, 168}, { 249, 17, 58, 224, 187, 88, 70, 80, 164, 84, 204, 157, 142, 131, 238, 134, 80, 19, 110, 250, 133, 172, 158, 135, 230, 50, 128, 182, 179, 180, 46, 34, 122, 29, 201, 24, 1, 150, 195, 235, 55, 131, 45, 15, 58, 47, 2, 174, 0, 118, 221, 35, 123, 8, 122, 95, 151, 141, 152, 30, 127, 63, 66, 18, 98, 226, 170, 117, 250, 110, 140, 225, 217, 134, 142, 136, 59, 127, 173, 243, 26, 166, 234, 142, 131, 207, 198, 215}, { 185, 187, 7, 87, 94, 68, 252, 249, 89, 25, 71, 20, 94, 157, 192, 147, 244, 165, 174, 194, 144, 90, 81, 132, 137, 29, 99, 176, 255, 98, 208, 89, 15, 46, 251, 2, 216, 252, 47, 140, 121, 252, 246, 158, 175, 217, 89, 200, 84, 82, 157, 56, 58, 136, 85, 6, 38, 60, 58, 69, 101, 178, 249, 16, 128, 55, 158, 144, 219, 102, 194, 39, 31, 47, 216, 113, 202, 224, 218, 241, 61, 97, 23, 255, 158, 49, 115, 164}, { 69, 35, 213, 169, 176, 102, 251, 84, 58, 210, 94, 208, 33, 33, 208, 218, 190, 6, 142, 98, 223, 142, 140, 23, 124, 229, 24, 191, 41, 54, 38, 51, 79, 127, 248, 218, 155, 224, 56, 108, 219, 167, 200, 27, 59, 45, 25, 185, 85, 157, 239, 40, 121, 110, 12, 82, 156, 218, 221, 27, 220, 104, 170, 160, 179, 172, 60, 20, 0, 218, 182, 82, 42, 200, 94, 125, 49, 174, 100, 251, 225, 104, 214, 75, 1, 143, 196, 122}, { 113, 103, 2, 121, 15, 179, 49, 163, 106, 46, 94, 85, 242, 131, 80, 124, 57, 22, 135, 200, 44, 241, 123, 11, 146, 140, 36, 228, 55, 115, 9, 223, 124, 96, 220, 87, 218, 127, 166, 88, 180, 134, 114, 189, 211, 251, 52, 104, 206, 61, 17, 217, 24, 172, 226, 117, 145, 12, 195, 245, 69, 159, 185, 4, 105, 113, 212, 115, 29, 98, 252, 63, 97, 107, 19, 86, 33, 80, 190, 173, 230, 32, 189, 244, 75, 218, 242, 193}, { 118, 15, 183, 115, 132, 34, 74, 77, 127, 134, 236, 172, 138, 253, 160, 179, 236, 151, 116, 101, 117, 169, 54, 71, 22, 195, 156, 153, 196, 133, 152, 83, 15, 172, 133, 237, 246, 168, 58, 62, 115, 142, 150, 29, 122, 13, 231, 177, 230, 124, 68, 72, 219, 43, 163, 69, 230, 132, 51, 188, 5, 167, 241, 217, 57, 190, 224, 31, 246, 131, 214, 72, 67, 184, 218, 248, 105, 0, 53, 105, 87, 184, 115, 249, 86, 134, 159, 188}, { 115, 78, 159, 130, 188, 100, 222, 32, 251, 240, 78, 2, 198, 187, 66, 204, 230, 140, 137, 255, 168, 221, 232, 142, 53, 31, 241, 67, 98, 43, 15, 9, 193, 207, 47, 70, 14, 62, 180, 170, 133, 2, 25, 78, 25, 210, 8, 162, 8, 155, 66, 62, 132, 153, 73, 120, 95, 81, 238, 32, 26, 141, 135, 59, 175, 243, 121, 6, 146, 142, 41, 232, 160, 96, 104, 167, 130, 97, 161, 153, 124, 224, 139, 124, 192, 81, 144, 32}, { 34, 135, 243, 44, 237, 3, 82, 74, 116, 204, 113, 28, 98, 229, 32, 208, 244, 103, 219, 105, 147, 3, 252, 125, 14, 69, 103, 141, 230, 122, 104, 32, 253, 251, 109, 170, 185, 98, 145, 138, 80, 27, 146, 47, 213, 44, 232, 88, 92, 227, 15, 16, 89, 32, 8, 149, 81, 78, 222, 234, 23, 74, 52, 250, 83, 171, 11, 95, 14, 251, 207, 59, 228, 29, 131, 145, 17, 174, 126, 234, 36, 58, 246, 24, 167, 92, 77, 123}, { 198, 220, 135, 243, 10, 210, 70, 176, 126, 240, 173, 252, 61, 41, 114, 19, 91, 46, 234, 198, 94, 214, 88, 63, 155, 248, 175, 76, 179, 77, 9, 64, 134, 32, 7, 88, 96, 153, 60, 45, 99, 24, 173, 60, 213, 225, 62, 241, 145, 31, 46, 72, 174, 178, 121, 43, 129, 177, 82, 109, 54, 104, 129, 30, 225, 200, 254, 237, 81, 98, 11, 246, 106, 3, 56, 9, 162, 248, 79, 254, 98, 88, 19, 90, 143, 62, 214, 13}, { 186, 160, 27, 225, 253, 157, 14, 188, 72, 70, 245, 103, 120, 107, 247, 60, 28, 3, 211, 238, 111, 15, 149, 164, 68, 170, 138, 221, 80, 33, 65, 128, 69, 52, 20, 147, 143, 161, 64, 26, 18, 130, 249, 4, 155, 75, 214, 253, 226, 241, 79, 110, 101, 211, 7, 145, 191, 77, 243, 125, 49, 166, 189, 114, 147, 206, 178, 211, 120, 53, 215, 28, 187, 81, 52, 28, 42, 215, 42, 88, 63, 240, 90, 175, 22, 108, 233, 126}, { 106, 153, 71, 225, 115, 199, 207, 209, 23, 129, 218, 2, 46, 7, 102, 215, 26, 87, 39, 242, 96, 209, 231, 166, 170, 136, 64, 92, 110, 173, 232, 178, 195, 152, 112, 183, 19, 23, 85, 221, 168, 200, 36, 23, 35, 32, 32, 11, 184, 54, 38, 204, 60, 27, 13, 227, 131, 32, 174, 239, 53, 110, 209, 96, 192, 216, 213, 238, 140, 7, 92, 224, 46, 83, 69, 175, 26, 205, 135, 34, 58, 99, 150, 140, 38, 155, 124, 167}, { 6, 178, 232, 190, 154, 224, 133, 83, 0, 63, 54, 76, 159, 95, 140, 239, 229, 85, 173, 116, 148, 147, 150, 199, 199, 13, 156, 64, 91, 210, 208, 206, 208, 241, 157, 142, 247, 29, 22, 7, 250, 11, 7, 82, 39, 8, 177, 64, 210, 190, 149, 178, 25, 112, 214, 141, 184, 32, 170, 139, 179, 241, 165, 123, 56, 90, 20, 34, 140, 31, 38, 9, 94, 170, 243, 73, 84, 78, 162, 197, 134, 9, 39, 95, 62, 60, 153, 25}, { 189, 3, 134, 165, 145, 213, 50, 122, 103, 0, 39, 102, 107, 178, 113, 166, 34, 131, 153, 106, 145, 137, 171, 225, 40, 188, 174, 121, 32, 90, 116, 86, 37, 105, 9, 145, 67, 66, 183, 130, 61, 229, 201, 11, 117, 120, 62, 250, 127, 190, 119, 253, 160, 150, 189, 100, 169, 183, 147, 73, 56, 56, 69, 129, 228, 196, 100, 153, 147, 51, 57, 7, 40, 238, 117, 167, 190, 73, 204, 251, 52, 125, 61, 136, 133, 45, 185, 226}, { 186, 198, 65, 79, 166, 83, 188, 236, 50, 17, 229, 49, 230, 156, 243, 92, 247, 97, 138, 64, 237, 108, 111, 54, 248, 173, 204, 88, 163, 199, 254, 188, 121, 136, 23, 223, 231, 218, 168, 74, 245, 205, 194, 73, 253, 163, 127, 245, 23, 129, 37, 248, 81, 49, 163, 180, 33, 80, 150, 199, 172, 47, 11, 177, 71, 209, 55, 50, 224, 129, 82, 40, 238, 141, 107, 242, 39, 44, 254, 56, 165, 226, 91, 60, 33, 7, 128, 147}, { 230, 104, 42, 61, 159, 108, 46, 176, 22, 57, 125, 254, 238, 78, 191, 27, 100, 215, 239, 41, 151, 14, 234, 74, 2, 25, 205, 240, 204, 208, 55, 40, 245, 95, 21, 249, 179, 78, 231, 209, 94, 190, 19, 9, 232, 242, 247, 139, 36, 202, 71, 199, 227, 33, 0, 57, 10, 106, 98, 128, 109, 80, 127, 50, 240, 165, 81, 61, 23, 88, 30, 21, 82, 58, 140, 64, 88, 178, 87, 36, 246, 118, 223, 46, 107, 80, 115, 104}, { 181, 90, 109, 4, 176, 110, 237, 88, 33, 176, 53, 40, 39, 46, 201, 192, 46, 105, 93, 170, 74, 143, 46, 57, 191, 3, 250, 211, 112, 162, 149, 215, 156, 253, 4, 12, 101, 148, 60, 217, 20, 24, 182, 244, 197, 100, 220, 141, 7, 204, 4, 34, 12, 180, 197, 111, 205, 78, 19, 43, 119, 3, 86, 113, 0, 126, 137, 177, 204, 124, 177, 58, 72, 67, 55, 202, 139, 230, 188, 1, 145, 197, 202, 115, 216, 24, 87, 123}, { 7, 145, 191, 8, 42, 217, 28, 254, 138, 110, 94, 192, 207, 135, 223, 112, 107, 225, 32, 45, 25, 54, 137, 245, 119, 131, 138, 234, 235, 78, 155, 85, 135, 200, 137, 166, 178, 115, 1, 232, 236, 217, 72, 222, 168, 61, 226, 124, 43, 203, 173, 98, 243, 24, 24, 19, 47, 112, 96, 58, 204, 116, 60, 45, 105, 194, 166, 56, 231, 173, 216, 33, 94, 252, 170, 150, 106, 70, 232, 116, 70, 30, 21, 124, 217, 101, 116, 248}, { 127, 244, 215, 121, 135, 98, 135, 72, 202, 135, 89, 156, 166, 153, 243, 174, 195, 225, 104, 159, 135, 134, 32, 126, 100, 127, 226, 38, 254, 101, 211, 162, 26, 23, 218, 99, 22, 235, 233, 210, 188, 81, 86, 212, 125, 210, 110, 103, 238, 122, 12, 91, 219, 219, 96, 67, 255, 126, 5, 115, 71, 131, 220, 89, 22, 226, 181, 63, 203, 193, 249, 2, 233, 147, 37, 117, 4, 91, 5, 33, 108, 78, 224, 78, 204, 127, 16, 31}, { 169, 120, 69, 25, 115, 120, 38, 68, 146, 241, 209, 150, 51, 44, 243, 43, 112, 222, 219, 147, 7, 104, 228, 21, 175, 139, 246, 236, 134, 209, 201, 241, 232, 125, 103, 4, 20, 253, 152, 220, 203, 133, 223, 112, 35, 207, 254, 159, 84, 22, 221, 47, 172, 241, 81, 125, 84, 66, 204, 120, 237, 231, 39, 151, 98, 186, 189, 8, 81, 43, 81, 88, 160, 99, 247, 61, 156, 207, 118, 115, 177, 214, 98, 11, 106, 94, 185, 113}, { 145, 54, 229, 182, 15, 114, 95, 50, 98, 141, 24, 215, 201, 115, 168, 198, 97, 179, 53, 28, 73, 232, 141, 5, 133, 215, 138, 1, 221, 109, 46, 63, 44, 212, 182, 153, 214, 118, 177, 83, 75, 41, 71, 201, 241, 82, 51, 31, 138, 22, 194, 5, 196, 195, 158, 23, 132, 61, 211, 178, 199, 11, 165, 194, 40, 27, 108, 249, 135, 43, 77, 201, 157, 77, 168, 192, 9, 48, 73, 52, 59, 39, 85, 5, 202, 174, 229, 84}, { 22, 45, 240, 239, 180, 198, 94, 71, 17, 58, 158, 133, 11, 152, 30, 11, 241, 97, 100, 200, 153, 233, 115, 30, 219, 226, 229, 139, 120, 93, 119, 207, 156, 43, 71, 93, 225, 132, 59, 49, 164, 121, 139, 5, 207, 250, 84, 60, 110, 118, 28, 100, 83, 140, 208, 204, 56, 255, 19, 113, 197, 150, 82, 128, 91, 67, 130, 24, 34, 134, 142, 132, 45, 79, 83, 186, 119, 229, 177, 65, 187, 72, 79, 126, 212, 89, 168, 173}, { 7, 218, 217, 71, 7, 200, 210, 41, 74, 59, 66, 168, 180, 251, 68, 177, 96, 189, 7, 41, 161, 27, 78, 10, 223, 207, 107, 171, 18, 164, 33, 158, 87, 246, 227, 218, 208, 7, 170, 21, 212, 71, 21, 25, 216, 44, 166, 202, 100, 21, 84, 239, 59, 249, 73, 167, 130, 247, 189, 212, 224, 97, 167, 61, 110, 89, 42, 198, 235, 175, 228, 76, 12, 4, 123, 39, 152, 201, 26, 170, 243, 48, 24, 92, 130, 36, 76, 75}, { 16, 184, 129, 10, 1, 90, 226, 50, 200, 85, 169, 25, 53, 26, 231, 170, 170, 143, 170, 35, 120, 60, 68, 85, 79, 211, 157, 75, 125, 71, 217, 139, 209, 93, 152, 114, 110, 149, 108, 127, 156, 103, 87, 235, 162, 144, 175, 68, 194, 136, 151, 179, 148, 246, 12, 155, 57, 255, 130, 108, 63, 78, 125, 156, 119, 153, 14, 224, 135, 36, 148, 166, 92, 167, 164, 65, 4, 234, 228, 73, 207, 199, 108, 93, 16, 99, 175, 106}, { 114, 114, 197, 71, 176, 110, 81, 238, 167, 209, 171, 169, 128, 127, 253, 191, 15, 129, 37, 108, 187, 183, 132, 149, 90, 20, 1, 105, 4, 119, 158, 157, 17, 229, 180, 191, 63, 36, 170, 240, 8, 254, 186, 2, 216, 237, 185, 103, 154, 18, 166, 57, 199, 240, 157, 150, 79, 108, 11, 254, 36, 250, 79, 22, 187, 21, 82, 220, 214, 39, 185, 36, 201, 217, 44, 22, 34, 174, 193, 139, 70, 129, 31, 145, 39, 201, 232, 48}, { 95, 188, 36, 234, 58, 181, 171, 128, 109, 56, 92, 108, 200, 77, 6, 211, 200, 174, 11, 227, 223, 164, 61, 114, 120, 130, 191, 203, 53, 114, 58, 53, 23, 45, 63, 174, 241, 232, 155, 137, 117, 126, 26, 132, 135, 103, 14, 142, 83, 234, 223, 207, 199, 33, 253, 114, 134, 126, 93, 200, 15, 41, 192, 151, 51, 250, 165, 201, 172, 172, 53, 112, 16, 88, 151, 70, 150, 116, 217, 191, 54, 221, 157, 107, 233, 123, 225, 78}, { 61, 110, 177, 25, 4, 54, 119, 132, 54, 188, 64, 5, 244, 40, 6, 87, 110, 203, 158, 150, 90, 152, 206, 154, 184, 15, 82, 91, 61, 77, 49, 81, 60, 181, 80, 102, 171, 80, 163, 136, 76, 172, 236, 228, 59, 49, 39, 138, 84, 18, 7, 159, 235, 85, 75, 168, 243, 75, 24, 183, 228, 251, 172, 33, 4, 152, 44, 190, 124, 145, 137, 122, 229, 20, 116, 183, 149, 40, 89, 79, 151, 117, 165, 250, 212, 86, 217, 166}, { 173, 228, 144, 21, 120, 151, 245, 107, 52, 225, 73, 32, 56, 68, 32, 201, 56, 18, 202, 34, 108, 103, 218, 215, 57, 121, 179, 238, 144, 199, 73, 201, 170, 116, 142, 58, 98, 150, 167, 124, 137, 10, 161, 103, 212, 231, 156, 73, 103, 218, 18, 219, 226, 209, 168, 219, 28, 1, 47, 106, 118, 30, 31, 64, 185, 132, 77, 200, 108, 224, 146, 207, 244, 220, 42, 126, 255, 130, 253, 152, 75, 241, 85, 213, 157, 101, 132, 253}, { 68, 64, 116, 250, 35, 131, 174, 11, 192, 203, 188, 211, 10, 120, 231, 238, 95, 91, 218, 31, 184, 233, 56, 130, 254, 47, 192, 165, 161, 231, 135, 96, 65, 26, 64, 253, 128, 125, 182, 121, 27, 2, 102, 82, 69, 38, 83, 130, 144, 35, 169, 196, 182, 204, 141, 140, 72, 205, 168, 52, 6, 138, 90, 14, 4, 93, 7, 240, 254, 170, 220, 0, 202, 97, 191, 178, 57, 90, 208, 69, 231, 174, 254, 226, 190, 16, 66, 17}, { 98, 206, 59, 227, 91, 229, 21, 16, 212, 23, 124, 100, 162, 70, 17, 41, 252, 161, 103, 61, 83, 83, 106, 62, 237, 125, 165, 181, 30, 73, 6, 31, 219, 196, 193, 190, 84, 190, 140, 82, 229, 22, 85, 31, 172, 245, 232, 172, 40, 113, 86, 181, 208, 62, 220, 208, 49, 64, 220, 22, 117, 126, 14, 190, 146, 32, 235, 123, 197, 33, 245, 32, 170, 181, 53, 104, 37, 252, 181, 92, 92, 177, 232, 116, 72, 117, 38, 168}, { 216, 212, 6, 199, 88, 242, 57, 225, 84, 91, 88, 155, 66, 134, 241, 160, 32, 152, 35, 251, 110, 36, 247, 110, 93, 204, 66, 74, 152, 151, 252, 5, 103, 44, 244, 238, 173, 192, 17, 182, 191, 214, 78, 28, 65, 210, 191, 52, 95, 178, 198, 71, 36, 197, 57, 16, 134, 181, 85, 141, 78, 219, 63, 233, 170, 195, 159, 67, 156, 155, 200, 209, 111, 253, 22, 153, 194, 35, 147, 62, 173, 35, 42, 48, 159, 18, 137, 104}, { 39, 192, 114, 32, 99, 173, 135, 37, 209, 100, 167, 164, 39, 192, 140, 234, 242, 149, 167, 237, 228, 198, 115, 68, 102, 49, 16, 201, 230, 20, 213, 159, 181, 42, 232, 94, 76, 108, 87, 61, 214, 28, 200, 149, 214, 124, 186, 191, 2, 223, 183, 46, 174, 96, 234, 50, 61, 185, 248, 118, 148, 233, 102, 208, 194, 77, 70, 90, 50, 79, 0, 109, 98, 156, 221, 166, 223, 170, 48, 99, 61, 198, 203, 50, 210, 95, 223, 104}, { 7, 100, 188, 99, 167, 8, 154, 173, 127, 220, 11, 73, 10, 247, 123, 232, 247, 239, 123, 170, 109, 129, 245, 240, 101, 130, 54, 152, 219, 204, 139, 69, 171, 130, 191, 39, 198, 66, 233, 64, 35, 147, 22, 92, 130, 154, 208, 91, 255, 241, 244, 212, 75, 129, 74, 219, 97, 50, 26, 30, 148, 91, 168, 7, 150, 50, 116, 107, 66, 46, 190, 132, 157, 122, 48, 104, 9, 178, 43, 11, 249, 197, 122, 199, 41, 129, 170, 100}, { 245, 61, 83, 134, 27, 128, 95, 193, 91, 142, 160, 1, 218, 0, 82, 4, 44, 72, 219, 192, 247, 141, 242, 243, 0, 107, 179, 220, 158, 156, 15, 111, 148, 116, 93, 222, 138, 48, 7, 80, 78, 219, 123, 31, 138, 134, 16, 224, 34, 215, 160, 99, 141, 10, 241, 189, 29, 93, 140, 40, 13, 64, 106, 8, 178, 77, 2, 164, 13, 147, 112, 249, 218, 209, 152, 130, 232, 181, 254, 138, 210, 233, 95, 224, 10, 143, 232, 114}, { 160, 94, 63, 58, 209, 104, 22, 97, 211, 66, 8, 43, 62, 127, 206, 91, 133, 61, 32, 202, 218, 52, 22, 172, 8, 7, 245, 91, 43, 49, 168, 249, 8, 65, 98, 180, 118, 104, 229, 176, 187, 111, 250, 113, 94, 80, 222, 84, 64, 113, 205, 25, 2, 29, 147, 233, 216, 181, 236, 227, 228, 150, 43, 171, 114, 70, 35, 199, 215, 45, 176, 104, 143, 158, 55, 251, 57, 230, 189, 57, 136, 104, 137, 174, 192, 225, 161, 15}, { 203, 124, 237, 215, 182, 140, 134, 87, 177, 216, 104, 16, 218, 62, 28, 157, 33, 195, 158, 186, 66, 249, 155, 82, 97, 68, 45, 118, 134, 75, 153, 52, 92, 39, 160, 196, 142, 249, 136, 227, 68, 92, 160, 135, 66, 149, 58, 218, 172, 235, 21, 136, 69, 227, 217, 124, 78, 87, 38, 193, 39, 188, 147, 80, 254, 210, 154, 196, 238, 113, 169, 90, 131, 233, 208, 158, 221, 34, 187, 126, 90, 240, 79, 1, 139, 97, 192, 184}, { 72, 25, 158, 236, 37, 148, 53, 178, 90, 72, 224, 121, 147, 240, 76, 68, 174, 81, 112, 171, 138, 10, 33, 21, 108, 18, 64, 43, 118, 195, 254, 79, 191, 157, 44, 232, 250, 107, 90, 247, 18, 225, 112, 182, 106, 205, 141, 144, 143, 212, 247, 191, 32, 66, 142, 30, 188, 55, 165, 143, 153, 91, 233, 226, 37, 220, 154, 201, 172, 219, 64, 158, 32, 44, 104, 241, 126, 237, 205, 222, 232, 36, 155, 237, 130, 105, 186, 186}, { 18, 193, 30, 247, 185, 4, 135, 36, 208, 71, 85, 245, 15, 61, 232, 124, 131, 68, 248, 128, 90, 197, 43, 115, 8, 74, 140, 22, 221, 37, 98, 78, 92, 52, 110, 93, 244, 129, 60, 140, 152, 16, 25, 107, 169, 108, 51, 79, 53, 130, 90, 160, 214, 214, 196, 195, 148, 213, 90, 29, 167, 81, 75, 127, 36, 132, 195, 235, 243, 90, 122, 195, 81, 219, 88, 23, 111, 39, 81, 105, 100, 133, 113, 99, 21, 214, 104, 138}, { 41, 182, 59, 247, 231, 2, 3, 151, 63, 101, 42, 255, 237, 254, 210, 180, 57, 45, 20, 152, 234, 253, 46, 104, 37, 30, 107, 239, 42, 41, 71, 153, 25, 19, 249, 57, 249, 103, 33, 84, 196, 119, 174, 107, 122, 84, 17, 243, 176, 55, 153, 250, 110, 44, 4, 198, 33, 77, 179, 153, 198, 113, 114, 10, 183, 46, 134, 75, 143, 67, 54, 220, 205, 112, 13, 207, 87, 184, 249, 22, 9, 199, 60, 70, 237, 199, 166, 105}, { 119, 46, 38, 221, 123, 21, 205, 19, 84, 97, 160, 14, 27, 171, 143, 3, 237, 253, 115, 42, 122, 233, 38, 79, 197, 211, 53, 255, 205, 86, 122, 67, 212, 116, 193, 64, 173, 11, 163, 120, 226, 206, 251, 193, 107, 163, 34, 127, 237, 102, 22, 129, 226, 52, 102, 111, 95, 36, 31, 245, 127, 9, 146, 127, 84, 206, 58, 216, 57, 51, 24, 20, 254, 234, 183, 198, 124, 90, 99, 173, 108, 125, 19, 188, 24, 85, 47, 148}, { 164, 114, 153, 117, 49, 68, 14, 20, 231, 248, 54, 26, 190, 241, 27, 216, 60, 103, 32, 152, 22, 164, 248, 243, 75, 110, 185, 52, 118, 136, 189, 178, 161, 99, 180, 36, 140, 222, 32, 54, 179, 246, 70, 74, 219, 43, 49, 117, 19, 219, 77, 192, 121, 245, 125, 242, 235, 98, 109, 65, 220, 238, 95, 226, 117, 181, 184, 37, 165, 186, 235, 241, 130, 59, 213, 66, 207, 144, 128, 246, 87, 154, 43, 38, 211, 98, 159, 247}, { 249, 7, 219, 43, 11, 60, 19, 42, 234, 213, 35, 201, 111, 23, 13, 170, 97, 155, 197, 148, 2, 47, 226, 248, 134, 51, 30, 12, 148, 170, 218, 177, 244, 209, 200, 118, 216, 202, 225, 27, 250, 180, 156, 232, 109, 137, 96, 197, 54, 161, 170, 132, 146, 133, 176, 118, 111, 215, 105, 30, 168, 250, 224, 242, 175, 96, 119, 7, 190, 216, 244, 71, 186, 116, 95, 193, 3, 79, 161, 76, 107, 53, 2, 179, 242, 55, 72, 0}, { 136, 155, 43, 134, 102, 164, 178, 179, 163, 87, 181, 7, 57, 8, 196, 78, 225, 83, 136, 183, 177, 143, 138, 78, 116, 128, 127, 142, 68, 238, 3, 208, 127, 88, 203, 53, 121, 226, 14, 152, 162, 82, 207, 66, 2, 76, 46, 73, 104, 219, 145, 60, 28, 123, 113, 214, 161, 242, 87, 40, 120, 174, 26, 66, 239, 162, 168, 65, 46, 44, 76, 83, 106, 152, 217, 197, 196, 19, 77, 45, 187, 98, 217, 144, 137, 38, 174, 2}, { 195, 118, 140, 209, 57, 4, 140, 170, 135, 24, 185, 94, 3, 13, 77, 127, 135, 225, 198, 252, 38, 77, 155, 41, 35, 142, 215, 18, 97, 253, 61, 182, 103, 49, 216, 39, 52, 83, 35, 128, 236, 56, 73, 26, 157, 220, 93, 232, 240, 134, 96, 107, 18, 22, 85, 214, 22, 166, 34, 144, 244, 226, 230, 93, 103, 109, 130, 249, 255, 142, 128, 187, 205, 253, 222, 105, 86, 205, 171, 165, 31, 221, 15, 143, 50, 84, 161, 65}, { 143, 211, 47, 184, 167, 162, 30, 87, 251, 10, 41, 249, 29, 184, 220, 121, 230, 40, 243, 0, 131, 243, 240, 57, 253, 254, 210, 238, 225, 90, 158, 229, 254, 67, 98, 233, 236, 81, 52, 19, 199, 209, 163, 173, 200, 178, 182, 51, 28, 177, 167, 44, 186, 174, 6, 21, 132, 223, 48, 206, 41, 184, 56, 212, 244, 160, 224, 86, 139, 76, 102, 93, 206, 122, 121, 131, 252, 169, 13, 119, 161, 83, 112, 189, 162, 86, 214, 217}, { 187, 242, 15, 238, 236, 122, 143, 96, 246, 125, 144, 203, 84, 154, 103, 237, 103, 10, 202, 110, 201, 77, 104, 4, 92, 234, 137, 250, 80, 115, 52, 32, 68, 37, 195, 151, 53, 142, 62, 30, 132, 75, 160, 129, 252, 142, 163, 36, 19, 59, 230, 78, 83, 49, 43, 58, 197, 139, 238, 217, 248, 89, 66, 232, 121, 19, 35, 164, 158, 78, 35, 105, 6, 170, 220, 250, 17, 53, 60, 243, 109, 102, 51, 199, 87, 134, 194, 191}, { 142, 12, 27, 101, 191, 35, 150, 77, 255, 143, 36, 117, 168, 153, 244, 117, 222, 162, 126, 66, 211, 129, 228, 180, 234, 178, 231, 116, 50, 30, 119, 247, 139, 128, 73, 177, 134, 2, 185, 111, 249, 82, 120, 90, 187, 198, 114, 75, 100, 215, 179, 165, 242, 152, 193, 121, 150, 58, 191, 33, 158, 157, 68, 155, 212, 72, 232, 218, 181, 26, 89, 107, 213, 94, 141, 138, 156, 121, 241, 44, 139, 100, 1, 221, 165, 214, 176, 110}, { 45, 147, 201, 231, 224, 137, 18, 243, 229, 137, 216, 96, 87, 91, 203, 55, 238, 41, 249, 50, 174, 74, 133, 246, 77, 31, 12, 14, 3, 182, 24, 202, 185, 183, 209, 25, 128, 172, 242, 60, 36, 250, 206, 40, 31, 42, 109, 18, 124, 159, 212, 11, 149, 192, 0, 116, 110, 244, 109, 171, 138, 117, 233, 125, 116, 180, 46, 234, 218, 6, 245, 115, 207, 201, 212, 213, 177, 97, 245, 19, 209, 36, 95, 15, 210, 254, 35, 249}, { 254, 55, 136, 187, 230, 50, 10, 77, 144, 198, 37, 31, 88, 194, 2, 87, 242, 101, 251, 9, 216, 107, 165, 38, 210, 254, 253, 76, 198, 158, 143, 157, 176, 252, 67, 210, 160, 245, 165, 219, 175, 63, 222, 78, 223, 210, 226, 16, 39, 136, 213, 104, 172, 237, 25, 107, 248, 65, 50, 86, 69, 33, 106, 224, 84, 202, 74, 208, 176, 190, 122, 74, 107, 93, 236, 67, 79, 174, 71, 149, 249, 114, 76, 170, 168, 236, 219, 98}, { 75, 26, 28, 81, 137, 108, 192, 51, 36, 171, 172, 15, 159, 20, 138, 186, 126, 241, 230, 199, 38, 25, 61, 146, 192, 104, 10, 36, 12, 130, 234, 31, 10, 69, 194, 197, 138, 197, 242, 204, 228, 222, 191, 113, 199, 169, 53, 177, 177, 243, 211, 242, 43, 146, 218, 63, 237, 87, 214, 214, 0, 221, 30, 131, 174, 243, 95, 222, 84, 85, 103, 75, 83, 61, 52, 95, 35, 163, 167, 62, 163, 154, 253, 152, 62, 159, 55, 191}, { 242, 35, 88, 209, 182, 164, 172, 78, 253, 208, 84, 23, 198, 242, 58, 143, 166, 21, 28, 149, 193, 105, 64, 123, 30, 52, 47, 67, 114, 237, 14, 249, 74, 143, 190, 100, 106, 146, 139, 15, 122, 56, 204, 85, 37, 67, 89, 112, 255, 222, 219, 0, 88, 120, 188, 216, 40, 213, 182, 218, 1, 222, 48, 114, 138, 112, 142, 241, 251, 175, 183, 187, 43, 20, 87, 13, 215, 19, 128, 80, 8, 85, 77, 195, 102, 30, 23, 208}, { 237, 105, 226, 242, 104, 214, 63, 50, 87, 139, 111, 45, 115, 47, 64, 41, 37, 129, 139, 77, 115, 241, 123, 167, 253, 242, 11, 69, 33, 46, 115, 57, 43, 176, 192, 196, 134, 207, 128, 43, 109, 187, 114, 226, 170, 181, 140, 85, 97, 102, 47, 45, 226, 93, 18, 41, 198, 148, 239, 223, 82, 108, 31, 10, 105, 115, 25, 120, 117, 156, 21, 93, 205, 102, 219, 117, 246, 181, 185, 236, 13, 223, 179, 81, 202, 77, 62, 188}, { 52, 122, 140, 47, 31, 47, 175, 146, 51, 10, 92, 6, 161, 174, 130, 180, 235, 228, 236, 189, 223, 188, 254, 66, 116, 59, 86, 4, 55, 11, 198, 40, 92, 41, 49, 182, 46, 120, 232, 146, 10, 204, 246, 66, 25, 228, 197, 146, 155, 166, 91, 78, 112, 119, 13, 246, 158, 44, 33, 96, 113, 45, 180, 174, 179, 78, 233, 10, 74, 24, 91, 196, 13, 84, 62, 190, 68, 186, 17, 242, 177, 156, 78, 69, 187, 124, 102, 127}, { 26, 205, 97, 126, 191, 42, 218, 198, 174, 206, 208, 240, 5, 239, 161, 60, 166, 5, 109, 202, 159, 23, 87, 153, 99, 105, 6, 186, 29, 172, 49, 2, 137, 78, 244, 161, 121, 246, 144, 90, 212, 214, 59, 46, 80, 195, 157, 236, 172, 206, 173, 23, 30, 39, 84, 161, 149, 29, 228, 14, 72, 30, 32, 227, 15, 239, 140, 219, 54, 240, 136, 220, 160, 18, 3, 179, 199, 18, 104, 228, 115, 19, 93, 222, 212, 95, 183, 75}, { 79, 227, 241, 40, 75, 229, 76, 42, 13, 67, 21, 78, 213, 51, 220, 95, 116, 56, 4, 231, 239, 247, 144, 115, 38, 157, 35, 138, 33, 198, 228, 230, 86, 154, 189, 180, 243, 122, 37, 164, 176, 10, 147, 176, 29, 30, 10, 13, 177, 127, 167, 93, 122, 51, 70, 186, 216, 98, 148, 71, 222, 106, 116, 240, 161, 217, 18, 88, 42, 94, 254, 73, 78, 213, 131, 103, 176, 216, 161, 241, 68, 184, 255, 88, 29, 226, 37, 53}, { 8, 173, 175, 144, 109, 49, 3, 191, 229, 80, 67, 192, 113, 240, 158, 103, 102, 116, 35, 81, 241, 68, 184, 237, 80, 157, 165, 189, 57, 221, 105, 79, 184, 178, 168, 59, 219, 241, 99, 15, 238, 226, 5, 254, 50, 144, 233, 124, 215, 35, 71, 247, 58, 19, 98, 49, 81, 152, 146, 6, 138, 135, 28, 170, 39, 150, 230, 177, 182, 24, 141, 60, 26, 1, 150, 204, 220, 204, 130, 127, 6, 91, 49, 255, 38, 18, 80, 131}, { 220, 115, 66, 60, 16, 34, 8, 136, 181, 255, 195, 196, 209, 46, 205, 182, 103, 134, 239, 146, 115, 213, 111, 55, 10, 116, 72, 181, 245, 228, 30, 131, 236, 60, 57, 70, 244, 232, 2, 14, 103, 63, 124, 156, 139, 132, 173, 145, 2, 24, 174, 29, 90, 131, 34, 243, 132, 18, 246, 127, 144, 24, 191, 160, 179, 124, 71, 120, 254, 0, 252, 161, 170, 75, 51, 78, 57, 247, 189, 174, 39, 31, 110, 191, 32, 78, 242, 102}, { 237, 155, 214, 4, 30, 96, 114, 41, 244, 54, 60, 252, 151, 102, 204, 50, 162, 33, 127, 228, 193, 37, 5, 225, 116, 41, 86, 172, 91, 205, 5, 60, 183, 88, 76, 242, 5, 164, 165, 192, 235, 83, 26, 251, 56, 160, 98, 125, 190, 90, 117, 105, 93, 12, 246, 54, 253, 189, 24, 77, 22, 68, 188, 100, 111, 89, 176, 102, 219, 108, 97, 4, 132, 62, 73, 110, 119, 253, 134, 71, 90, 189, 192, 180, 225, 51, 52, 16}, { 169, 132, 74, 86, 40, 145, 5, 74, 197, 109, 32, 124, 146, 208, 132, 228, 10, 88, 112, 166, 0, 37, 200, 176, 115, 80, 102, 94, 164, 254, 73, 63, 150, 92, 17, 222, 60, 89, 156, 3, 0, 54, 95, 184, 208, 18, 30, 118, 238, 138, 119, 198, 91, 0, 207, 216, 128, 225, 32, 35, 227, 223, 142, 40, 39, 252, 199, 210, 10, 143, 217, 81, 23, 125, 183, 173, 104, 166, 127, 99, 152, 164, 24, 51, 143, 220, 243, 104}, { 26, 158, 7, 83, 206, 142, 41, 221, 215, 51, 187, 86, 106, 17, 196, 77, 130, 36, 123, 70, 125, 55, 181, 55, 220, 141, 167, 214, 113, 238, 251, 82, 177, 31, 8, 168, 90, 140, 81, 157, 36, 147, 3, 52, 188, 63, 52, 127, 147, 95, 218, 167, 218, 177, 182, 67, 232, 132, 98, 119, 43, 53, 212, 11, 34, 65, 33, 95, 198, 2, 18, 146, 69, 135, 100, 132, 94, 31, 82, 103, 183, 191, 123, 3, 132, 70, 106, 221}, { 129, 120, 250, 73, 91, 194, 163, 58, 177, 218, 104, 87, 241, 51, 197, 83, 141, 3, 55, 248, 155, 254, 9, 162, 136, 100, 103, 99, 141, 31, 248, 196, 18, 33, 214, 44, 194, 39, 162, 158, 218, 112, 132, 98, 72, 148, 8, 187, 144, 66, 94, 144, 250, 171, 51, 74, 87, 86, 13, 142, 189, 101, 169, 120, 182, 89, 8, 218, 207, 77, 151, 120, 242, 180, 246, 140, 65, 148, 208, 127, 51, 128, 117, 30, 138, 41, 88, 128}, { 81, 24, 5, 88, 70, 102, 86, 157, 96, 52, 73, 175, 139, 202, 220, 99, 152, 73, 129, 252, 67, 150, 255, 209, 125, 164, 75, 180, 67, 223, 40, 180, 139, 66, 31, 204, 30, 70, 154, 14, 247, 199, 117, 149, 121, 215, 208, 43, 42, 140, 56, 44, 112, 89, 177, 70, 195, 46, 23, 199, 173, 100, 98, 131, 124, 152, 252, 177, 75, 53, 205, 119, 42, 181, 210, 167, 160, 111, 101, 90, 254, 16, 228, 100, 83, 47, 235, 135}, { 111, 152, 235, 217, 87, 92, 218, 76, 63, 255, 17, 242, 208, 254, 163, 188, 109, 83, 50, 96, 121, 6, 53, 233, 19, 182, 36, 93, 27, 197, 233, 231, 165, 241, 154, 232, 143, 93, 143, 102, 156, 192, 165, 59, 95, 109, 199, 244, 19, 208, 83, 142, 230, 253, 172, 53, 58, 9, 4, 16, 227, 18, 167, 217, 83, 117, 248, 115, 115, 191, 73, 243, 153, 55, 157, 74, 183, 78, 224, 195, 152, 188, 151, 8, 254, 163, 219, 102}, { 221, 212, 14, 166, 77, 63, 127, 255, 32, 222, 117, 83, 95, 1, 228, 109, 44, 77, 88, 172, 236, 168, 35, 102, 94, 205, 50, 22, 252, 73, 90, 131, 124, 97, 86, 201, 233, 100, 38, 51, 21, 106, 216, 46, 154, 181, 67, 244, 207, 107, 109, 33, 65, 150, 201, 70, 8, 36, 227, 102, 79, 248, 221, 126, 151, 128, 0, 174, 100, 201, 182, 28, 55, 67, 106, 14, 190, 183, 185, 218, 170, 218, 10, 165, 195, 4, 141, 129}, { 26, 121, 129, 130, 43, 119, 178, 31, 44, 220, 2, 209, 160, 236, 57, 161, 104, 140, 79, 77, 107, 108, 52, 98, 34, 107, 148, 9, 200, 70, 76, 0, 247, 54, 75, 163, 237, 212, 187, 99, 18, 31, 29, 191, 184, 96, 82, 28, 1, 218, 77, 206, 14, 77, 117, 80, 120, 191, 66, 226, 196, 46, 87, 121, 3, 243, 70, 45, 146, 249, 227, 36, 220, 45, 181, 37, 107, 142, 93, 151, 71, 151, 225, 86, 162, 139, 237, 118}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("range.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 88, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 88, a ustawiła na %d", arr->width);
                    test_error(arr->height == 91, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 91, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 91; ++i)
                        for (int j = 0; j < 88; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 91; ++i)
                        for (int j = 0; j < 88; ++j)
                            test_error(arr_negate->ptr[i][j] == array_negate[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_negate[i][j], arr_negate->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_negate);
                    printf("#####END#####");

                    test_error(arr_negate == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 58: Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 246 bajtów)
//
void UTEST58(void)
{
    // informacje o teście
    test_start(58, "Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 246 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(246);
    
    //
    // -----------
    //
    

                int array[2][10] = {{ 31, 103, 234, 185, 57, 207, 223, 191, 194, 107}, { 197, 212, 13, 4, 69, 28, 19, 37, 188, 109}};
                int array_negate[2][10] = {{ 224, 152, 21, 70, 198, 48, 32, 64, 61, 148}, { 58, 43, 242, 251, 186, 227, 236, 218, 67, 146}};

                int err_code = 2;

                printf("#####START#####");                            
                struct image_t *arr = load_image_t("season.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                test_error(arr->height == 2, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 2, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 2; ++i)
                    for (int j = 0; j < 10; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                printf("#####START#####");                            
                struct image_t *arr_negate = image_negate(arr);
                printf("#####END#####");

                for (int i = 0; i < 2; ++i)
                    for (int j = 0; j < 10; ++j)
                        test_error(arr_negate->ptr[i][j] == array_negate[i][j], "Funkcja image_negate() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_negate[i][j], arr_negate->ptr[i][j]);


                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                printf("#####START#####");
                destroy_image(&arr_negate);
                printf("#####END#####");

                test_error(arr_negate == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 59: Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 123 bajtów)
//
void UTEST59(void)
{
    // informacje o teście
    test_start(59, "Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 123 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(123);
    
    //
    // -----------
    //
    

                    int array[2][10] = {{ 31, 103, 234, 185, 57, 207, 223, 191, 194, 107}, { 197, 212, 13, 4, 69, 28, 19, 37, 188, 109}};
        
                    int err_code = 1;
        
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("season.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 2, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 2, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 2; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 60: Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 147 bajtów)
//
void UTEST60(void)
{
    // informacje o teście
    test_start(60, "Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 147 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(147);
    
    //
    // -----------
    //
    

                    int array[2][10] = {{ 31, 103, 234, 185, 57, 207, 223, 191, 194, 107}, { 197, 212, 13, 4, 69, 28, 19, 37, 188, 109}};
        
                    int err_code = 1;
        
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("season.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 2, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 2, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 2; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 61: Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 163 bajtów)
//
void UTEST61(void)
{
    // informacje o teście
    test_start(61, "Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 163 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(163);
    
    //
    // -----------
    //
    

                    int array[2][10] = {{ 31, 103, 234, 185, 57, 207, 223, 191, 194, 107}, { 197, 212, 13, 4, 69, 28, 19, 37, 188, 109}};
        
                    int err_code = 3;
        
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("season.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 2, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 2, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 2; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 62: Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 203 bajtów)
//
void UTEST62(void)
{
    // informacje o teście
    test_start(62, "Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 203 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(203);
    
    //
    // -----------
    //
    

                    int array[2][10] = {{ 31, 103, 234, 185, 57, 207, 223, 191, 194, 107}, { 197, 212, 13, 4, 69, 28, 19, 37, 188, 109}};
        
                    int err_code = 1;
        
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("season.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 2, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 2, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 2; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 63: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST63(void)
{
    // informacje o teście
    test_start(63, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                printf("#####START#####");                            
                struct image_t *arr_negate = image_negate(NULL);
                printf("#####END#####");

                test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 64: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST64(void)
{
    // informacje o teście
    test_start(64, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            
                    int array[15][10] = {{ 205, 197, 50, 22, 130, 210, 72, 169, 237, 157}, { 85, 131, 201, 234, 224, 203, 129, 173, 120, 15}, { 144, 128, 208, 12, 75, 128, 50, 231, 4, 132}, { 104, 181, 191, 239, 226, 94, 123, 254, 252, 6}, { 136, 34, 252, 176, 194, 188, 211, 151, 223, 110}, { 220, 27, 114, 37, 83, 63, 123, 205, 9, 142}, { 97, 214, 30, 53, 138, 186, 116, 73, 195, 131}, { 208, 101, 129, 12, 236, 221, 145, 193, 67, 210}, { 222, 230, 191, 81, 240, 230, 191, 37, 108, 16}, { 228, 90, 101, 165, 248, 180, 76, 247, 127, 42}, { 37, 198, 191, 161, 138, 198, 145, 90, 190, 238}, { 223, 148, 194, 194, 182, 250, 64, 243, 244, 193}, { 200, 199, 253, 93, 109, 143, 43, 104, 212, 152}, { 253, 130, 130, 70, 68, 97, 112, 206, 32, 48}, { 123, 204, 189, 189, 72, 160, 63, 64, 171, 51}};
            
                    int err_code = 4;
            
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("tall.bin", &err_code);
                    printf("#####END#####");
            
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
            
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    arr->width = 10;
                    arr->height = -15;
            
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");
            
                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");
            
                    arr->width = 10;
                    arr->height = 15;            
            
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
            
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 65: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST65(void)
{
    // informacje o teście
    test_start(65, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            
                    int array[15][10] = {{ 205, 197, 50, 22, 130, 210, 72, 169, 237, 157}, { 85, 131, 201, 234, 224, 203, 129, 173, 120, 15}, { 144, 128, 208, 12, 75, 128, 50, 231, 4, 132}, { 104, 181, 191, 239, 226, 94, 123, 254, 252, 6}, { 136, 34, 252, 176, 194, 188, 211, 151, 223, 110}, { 220, 27, 114, 37, 83, 63, 123, 205, 9, 142}, { 97, 214, 30, 53, 138, 186, 116, 73, 195, 131}, { 208, 101, 129, 12, 236, 221, 145, 193, 67, 210}, { 222, 230, 191, 81, 240, 230, 191, 37, 108, 16}, { 228, 90, 101, 165, 248, 180, 76, 247, 127, 42}, { 37, 198, 191, 161, 138, 198, 145, 90, 190, 238}, { 223, 148, 194, 194, 182, 250, 64, 243, 244, 193}, { 200, 199, 253, 93, 109, 143, 43, 104, 212, 152}, { 253, 130, 130, 70, 68, 97, 112, 206, 32, 48}, { 123, 204, 189, 189, 72, 160, 63, 64, 171, 51}};
            
                    int err_code = 4;
            
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("tall.bin", &err_code);
                    printf("#####END#####");
            
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
            
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    arr->width = -10;
                    arr->height = -15;
            
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");
            
                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");
            
                    arr->width = 10;
                    arr->height = 15;            
            
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
            
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 66: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST66(void)
{
    // informacje o teście
    test_start(66, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            
                    int array[15][10] = {{ 205, 197, 50, 22, 130, 210, 72, 169, 237, 157}, { 85, 131, 201, 234, 224, 203, 129, 173, 120, 15}, { 144, 128, 208, 12, 75, 128, 50, 231, 4, 132}, { 104, 181, 191, 239, 226, 94, 123, 254, 252, 6}, { 136, 34, 252, 176, 194, 188, 211, 151, 223, 110}, { 220, 27, 114, 37, 83, 63, 123, 205, 9, 142}, { 97, 214, 30, 53, 138, 186, 116, 73, 195, 131}, { 208, 101, 129, 12, 236, 221, 145, 193, 67, 210}, { 222, 230, 191, 81, 240, 230, 191, 37, 108, 16}, { 228, 90, 101, 165, 248, 180, 76, 247, 127, 42}, { 37, 198, 191, 161, 138, 198, 145, 90, 190, 238}, { 223, 148, 194, 194, 182, 250, 64, 243, 244, 193}, { 200, 199, 253, 93, 109, 143, 43, 104, 212, 152}, { 253, 130, 130, 70, 68, 97, 112, 206, 32, 48}, { 123, 204, 189, 189, 72, 160, 63, 64, 171, 51}};
            
                    int err_code = 1;
            
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("tall.bin", &err_code);
                    printf("#####END#####");
            
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
            
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    arr->width = -10;
                    arr->height = 15;
            
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");
            
                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");
            
                    arr->width = 10;
                    arr->height = 15;            
            
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
            
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 67: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST67(void)
{
    // informacje o teście
    test_start(67, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            
                    int array[15][10] = {{ 205, 197, 50, 22, 130, 210, 72, 169, 237, 157}, { 85, 131, 201, 234, 224, 203, 129, 173, 120, 15}, { 144, 128, 208, 12, 75, 128, 50, 231, 4, 132}, { 104, 181, 191, 239, 226, 94, 123, 254, 252, 6}, { 136, 34, 252, 176, 194, 188, 211, 151, 223, 110}, { 220, 27, 114, 37, 83, 63, 123, 205, 9, 142}, { 97, 214, 30, 53, 138, 186, 116, 73, 195, 131}, { 208, 101, 129, 12, 236, 221, 145, 193, 67, 210}, { 222, 230, 191, 81, 240, 230, 191, 37, 108, 16}, { 228, 90, 101, 165, 248, 180, 76, 247, 127, 42}, { 37, 198, 191, 161, 138, 198, 145, 90, 190, 238}, { 223, 148, 194, 194, 182, 250, 64, 243, 244, 193}, { 200, 199, 253, 93, 109, 143, 43, 104, 212, 152}, { 253, 130, 130, 70, 68, 97, 112, 206, 32, 48}, { 123, 204, 189, 189, 72, 160, 63, 64, 171, 51}};
            
                    int err_code = 1;
            
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("tall.bin", &err_code);
                    printf("#####END#####");
            
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
            
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    arr->width = 10;
                    arr->height = 0;
            
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");
            
                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");
            
                    arr->width = 10;
                    arr->height = 15;            
            
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
            
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 68: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST68(void)
{
    // informacje o teście
    test_start(68, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            
                    int array[15][10] = {{ 205, 197, 50, 22, 130, 210, 72, 169, 237, 157}, { 85, 131, 201, 234, 224, 203, 129, 173, 120, 15}, { 144, 128, 208, 12, 75, 128, 50, 231, 4, 132}, { 104, 181, 191, 239, 226, 94, 123, 254, 252, 6}, { 136, 34, 252, 176, 194, 188, 211, 151, 223, 110}, { 220, 27, 114, 37, 83, 63, 123, 205, 9, 142}, { 97, 214, 30, 53, 138, 186, 116, 73, 195, 131}, { 208, 101, 129, 12, 236, 221, 145, 193, 67, 210}, { 222, 230, 191, 81, 240, 230, 191, 37, 108, 16}, { 228, 90, 101, 165, 248, 180, 76, 247, 127, 42}, { 37, 198, 191, 161, 138, 198, 145, 90, 190, 238}, { 223, 148, 194, 194, 182, 250, 64, 243, 244, 193}, { 200, 199, 253, 93, 109, 143, 43, 104, 212, 152}, { 253, 130, 130, 70, 68, 97, 112, 206, 32, 48}, { 123, 204, 189, 189, 72, 160, 63, 64, 171, 51}};
            
                    int err_code = 1;
            
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("tall.bin", &err_code);
                    printf("#####END#####");
            
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
            
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    arr->width = 0;
                    arr->height = 15;
            
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");
            
                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");
            
                    arr->width = 10;
                    arr->height = 15;            
            
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
            
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 69: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST69(void)
{
    // informacje o teście
    test_start(69, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            
                    int array[15][10] = {{ 205, 197, 50, 22, 130, 210, 72, 169, 237, 157}, { 85, 131, 201, 234, 224, 203, 129, 173, 120, 15}, { 144, 128, 208, 12, 75, 128, 50, 231, 4, 132}, { 104, 181, 191, 239, 226, 94, 123, 254, 252, 6}, { 136, 34, 252, 176, 194, 188, 211, 151, 223, 110}, { 220, 27, 114, 37, 83, 63, 123, 205, 9, 142}, { 97, 214, 30, 53, 138, 186, 116, 73, 195, 131}, { 208, 101, 129, 12, 236, 221, 145, 193, 67, 210}, { 222, 230, 191, 81, 240, 230, 191, 37, 108, 16}, { 228, 90, 101, 165, 248, 180, 76, 247, 127, 42}, { 37, 198, 191, 161, 138, 198, 145, 90, 190, 238}, { 223, 148, 194, 194, 182, 250, 64, 243, 244, 193}, { 200, 199, 253, 93, 109, 143, 43, 104, 212, 152}, { 253, 130, 130, 70, 68, 97, 112, 206, 32, 48}, { 123, 204, 189, 189, 72, 160, 63, 64, 171, 51}};
            
                    int err_code = 3;
            
                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("tall.bin", &err_code);
                    printf("#####END#####");
            
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
            
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
            
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    arr->width = 0;
                    arr->height = 0;
            
                    printf("#####START#####");                            
                    struct image_t *arr_negate = image_negate(arr);
                    printf("#####END#####");
            
                    test_error(arr_negate == NULL, "Funkcja image_negate() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");
            
                    arr->width = 10;
                    arr->height = 15;            
            
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
            
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 70: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST70(void)
{
    // informacje o teście
    test_start(70, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][7] = {{ 147, 171, 161, 65, 15, 118, 67}, { 42, 2, 173, 253, 204, 210, 11}, { 196, 56, 114, 195, 174, 247, 253}, { 40, 1, 250, 52, 227, 0, 136}, { 204, 183, 138, 24, 255, 227, 75}, { 90, 242, 201, 68, 251, 33, 191}, { 42, 43, 179, 98, 209, 186, 116}, { 47, 149, 226, 19, 224, 148, 153}, { 211, 17, 34, 118, 169, 78, 204}, { 35, 164, 79, 140, 185, 1, 18}};
                    int array_flip_horizontal[10][7] = {{ 35, 164, 79, 140, 185, 1, 18}, { 211, 17, 34, 118, 169, 78, 204}, { 47, 149, 226, 19, 224, 148, 153}, { 42, 43, 179, 98, 209, 186, 116}, { 90, 242, 201, 68, 251, 33, 191}, { 204, 183, 138, 24, 255, 227, 75}, { 40, 1, 250, 52, 227, 0, 136}, { 196, 56, 114, 195, 174, 247, 253}, { 42, 2, 173, 253, 204, 210, 11}, { 147, 171, 161, 65, 15, 118, 67}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("suggest.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 10; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 10; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr_flip_horizontal->ptr[i][j] == array_flip_horizontal[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_horizontal[i][j], arr_flip_horizontal->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_horizontal);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 71: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST71(void)
{
    // informacje o teście
    test_start(71, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[18][6] = {{ 106, 176, 220, 65, 48, 160}, { 169, 181, 54, 137, 49, 91}, { 33, 117, 95, 28, 117, 105}, { 124, 234, 199, 245, 175, 56}, { 120, 180, 155, 93, 167, 74}, { 106, 36, 195, 23, 250, 180}, { 28, 182, 116, 252, 43, 184}, { 86, 250, 45, 220, 140, 117}, { 253, 231, 12, 123, 210, 162}, { 183, 2, 84, 251, 120, 17}, { 253, 234, 176, 216, 106, 103}, { 144, 255, 11, 156, 93, 103}, { 54, 243, 92, 60, 96, 121}, { 88, 34, 13, 88, 96, 103}, { 159, 113, 32, 124, 11, 223}, { 148, 202, 241, 184, 19, 198}, { 206, 73, 137, 125, 79, 144}, { 17, 159, 138, 189, 255, 207}};
                    int array_flip_horizontal[18][6] = {{ 17, 159, 138, 189, 255, 207}, { 206, 73, 137, 125, 79, 144}, { 148, 202, 241, 184, 19, 198}, { 159, 113, 32, 124, 11, 223}, { 88, 34, 13, 88, 96, 103}, { 54, 243, 92, 60, 96, 121}, { 144, 255, 11, 156, 93, 103}, { 253, 234, 176, 216, 106, 103}, { 183, 2, 84, 251, 120, 17}, { 253, 231, 12, 123, 210, 162}, { 86, 250, 45, 220, 140, 117}, { 28, 182, 116, 252, 43, 184}, { 106, 36, 195, 23, 250, 180}, { 120, 180, 155, 93, 167, 74}, { 124, 234, 199, 245, 175, 56}, { 33, 117, 95, 28, 117, 105}, { 169, 181, 54, 137, 49, 91}, { 106, 176, 220, 65, 48, 160}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("week.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr_flip_horizontal->ptr[i][j] == array_flip_horizontal[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_horizontal[i][j], arr_flip_horizontal->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_horizontal);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 72: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST72(void)
{
    // informacje o teście
    test_start(72, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][1] = {{ 237}, { 24}, { 219}, { 78}, { 101}, { 144}, { 176}, { 224}, { 180}, { 68}, { 240}, { 65}, { 96}, { 119}, { 250}, { 222}};
                    int array_flip_horizontal[16][1] = {{ 222}, { 250}, { 119}, { 96}, { 65}, { 240}, { 68}, { 180}, { 224}, { 176}, { 144}, { 101}, { 78}, { 219}, { 24}, { 237}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("branch.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr_flip_horizontal->ptr[i][j] == array_flip_horizontal[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_horizontal[i][j], arr_flip_horizontal->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_horizontal);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 73: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST73(void)
{
    // informacje o teście
    test_start(73, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][10] = {{ 213, 47, 98, 29, 91, 148, 86, 26, 178, 200}};
                    int array_flip_horizontal[1][10] = {{ 213, 47, 98, 29, 91, 148, 86, 26, 178, 200}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("spread.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr_flip_horizontal->ptr[i][j] == array_flip_horizontal[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_horizontal[i][j], arr_flip_horizontal->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_horizontal);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 74: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST74(void)
{
    // informacje o teście
    test_start(74, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 220}};
                    int array_flip_horizontal[1][1] = {{ 220}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("equal.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr_flip_horizontal->ptr[i][j] == array_flip_horizontal[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_horizontal[i][j], arr_flip_horizontal->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_horizontal);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 75: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST75(void)
{
    // informacje o teście
    test_start(75, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[100][67] = {{ 1, 148, 200, 24, 207, 221, 75, 47, 79, 200, 201, 249, 249, 130, 153, 116, 156, 203, 252, 140, 223, 39, 83, 220, 13, 117, 4, 104, 98, 143, 88, 170, 76, 243, 252, 226, 117, 101, 193, 36, 25, 38, 43, 69, 168, 164, 27, 186, 104, 11, 33, 27, 30, 246, 59, 28, 180, 84, 118, 119, 161, 174, 62, 91, 178, 253, 173}, { 255, 160, 255, 137, 152, 61, 128, 89, 169, 254, 147, 221, 6, 214, 36, 183, 221, 23, 38, 205, 171, 178, 50, 239, 128, 113, 42, 91, 153, 56, 61, 105, 239, 145, 72, 185, 88, 119, 63, 19, 197, 115, 173, 100, 152, 143, 55, 100, 145, 71, 217, 120, 207, 100, 71, 229, 17, 237, 33, 142, 189, 63, 98, 32, 244, 139, 180}, { 252, 233, 248, 208, 155, 17, 217, 248, 62, 225, 228, 8, 46, 78, 14, 230, 230, 208, 21, 172, 6, 225, 60, 235, 212, 88, 208, 185, 206, 66, 26, 105, 128, 12, 35, 178, 137, 9, 39, 33, 223, 119, 0, 198, 225, 146, 15, 231, 42, 253, 244, 60, 22, 232, 114, 118, 90, 197, 114, 180, 116, 4, 91, 93, 226, 160, 210}, { 28, 252, 102, 32, 206, 82, 84, 134, 82, 51, 184, 153, 6, 201, 152, 17, 57, 56, 243, 156, 227, 218, 235, 227, 129, 136, 134, 74, 227, 30, 140, 186, 231, 130, 95, 54, 61, 60, 90, 238, 91, 54, 31, 148, 57, 61, 213, 0, 195, 235, 218, 16, 65, 132, 76, 13, 39, 204, 115, 24, 222, 146, 149, 172, 35, 178, 3}, { 200, 183, 171, 78, 64, 175, 164, 176, 249, 2, 133, 205, 66, 245, 225, 206, 194, 12, 245, 192, 199, 81, 119, 255, 175, 180, 12, 27, 129, 58, 170, 175, 63, 117, 201, 152, 242, 172, 113, 61, 178, 59, 208, 145, 20, 29, 185, 120, 107, 37, 203, 16, 6, 251, 122, 71, 37, 222, 188, 168, 135, 215, 47, 101, 228, 123, 246}, { 53, 201, 49, 127, 57, 150, 81, 164, 74, 66, 94, 103, 163, 78, 172, 51, 115, 215, 133, 60, 245, 114, 119, 7, 33, 247, 179, 163, 218, 252, 34, 212, 36, 170, 155, 86, 254, 146, 206, 188, 28, 146, 38, 78, 235, 137, 193, 90, 90, 78, 194, 246, 34, 170, 202, 30, 100, 97, 110, 91, 225, 94, 33, 31, 67, 69, 67}, { 95, 25, 252, 45, 132, 144, 75, 19, 81, 24, 251, 78, 217, 243, 27, 48, 188, 232, 231, 62, 140, 127, 160, 219, 138, 236, 180, 3, 192, 64, 164, 100, 154, 102, 137, 53, 18, 124, 219, 28, 215, 116, 62, 112, 162, 100, 98, 48, 52, 100, 222, 242, 248, 204, 66, 77, 215, 30, 131, 56, 30, 126, 118, 162, 219, 24, 44}, { 133, 74, 210, 213, 47, 117, 198, 134, 89, 156, 9, 69, 36, 203, 111, 80, 234, 218, 41, 195, 182, 89, 162, 49, 241, 49, 29, 12, 233, 148, 23, 120, 68, 98, 78, 197, 174, 162, 229, 185, 105, 195, 210, 230, 187, 230, 50, 12, 133, 115, 151, 56, 147, 163, 88, 180, 140, 141, 153, 26, 85, 121, 55, 147, 16, 194, 15}, { 109, 150, 82, 22, 74, 60, 161, 18, 215, 48, 174, 21, 68, 136, 92, 255, 183, 166, 177, 242, 246, 150, 120, 162, 68, 216, 153, 17, 128, 3, 181, 84, 7, 231, 94, 124, 73, 114, 33, 46, 158, 83, 252, 67, 39, 84, 134, 92, 46, 28, 106, 37, 178, 244, 226, 107, 187, 118, 192, 228, 122, 39, 80, 111, 210, 13, 168}, { 244, 137, 210, 209, 237, 38, 46, 195, 42, 19, 155, 25, 217, 113, 237, 187, 152, 64, 191, 238, 145, 115, 37, 131, 31, 71, 165, 180, 57, 210, 99, 50, 137, 67, 95, 81, 4, 27, 172, 165, 0, 190, 90, 28, 139, 58, 85, 211, 124, 184, 14, 138, 13, 221, 255, 143, 108, 63, 86, 50, 146, 131, 127, 112, 111, 156, 151}, { 160, 188, 2, 128, 154, 155, 187, 161, 31, 50, 76, 229, 80, 175, 68, 64, 69, 193, 1, 5, 185, 255, 20, 207, 11, 59, 127, 219, 45, 32, 37, 189, 200, 144, 30, 142, 135, 235, 123, 39, 126, 185, 49, 226, 179, 210, 158, 146, 231, 138, 20, 33, 247, 130, 195, 19, 93, 248, 253, 80, 150, 175, 189, 251, 18, 219, 241}, { 126, 91, 220, 228, 0, 135, 56, 44, 237, 14, 239, 6, 132, 166, 145, 33, 7, 59, 106, 137, 223, 154, 19, 22, 70, 181, 185, 184, 45, 241, 152, 48, 91, 132, 47, 156, 97, 26, 147, 220, 112, 149, 52, 122, 245, 250, 154, 168, 26, 199, 177, 206, 112, 16, 170, 233, 74, 177, 154, 84, 23, 155, 224, 50, 89, 246, 224}, { 102, 160, 157, 172, 248, 198, 81, 71, 106, 31, 73, 222, 53, 236, 252, 81, 9, 161, 14, 156, 168, 171, 123, 19, 163, 168, 224, 228, 153, 18, 230, 139, 148, 224, 205, 59, 50, 171, 186, 23, 144, 0, 238, 111, 202, 182, 202, 97, 128, 24, 237, 221, 59, 209, 92, 213, 72, 41, 97, 121, 23, 1, 177, 38, 105, 89, 69}, { 83, 137, 158, 138, 35, 179, 166, 226, 86, 70, 96, 35, 183, 122, 100, 58, 84, 109, 54, 195, 19, 245, 185, 57, 201, 175, 196, 104, 40, 45, 189, 157, 93, 33, 123, 19, 31, 94, 195, 136, 130, 49, 198, 71, 89, 190, 217, 97, 48, 102, 132, 112, 135, 145, 198, 231, 56, 237, 155, 139, 1, 158, 169, 134, 66, 30, 96}, { 29, 67, 224, 174, 57, 50, 164, 141, 2, 49, 179, 4, 150, 38, 244, 97, 59, 167, 144, 127, 49, 175, 114, 81, 134, 112, 78, 179, 148, 109, 192, 15, 83, 131, 198, 64, 43, 122, 116, 18, 104, 172, 134, 87, 211, 247, 118, 192, 196, 200, 115, 34, 17, 73, 4, 30, 79, 170, 174, 32, 222, 104, 121, 24, 112, 111, 165}, { 15, 110, 244, 12, 154, 52, 30, 44, 40, 87, 182, 209, 105, 156, 96, 243, 135, 110, 93, 120, 159, 163, 68, 55, 166, 251, 129, 210, 38, 113, 105, 5, 14, 107, 53, 20, 245, 31, 114, 97, 71, 6, 18, 119, 74, 165, 114, 101, 41, 213, 76, 248, 149, 228, 172, 124, 228, 203, 198, 162, 51, 83, 176, 0, 40, 23, 78}, { 229, 81, 15, 128, 201, 58, 205, 201, 92, 22, 242, 182, 99, 226, 174, 150, 45, 197, 66, 229, 183, 85, 72, 26, 58, 128, 191, 188, 27, 193, 10, 71, 38, 159, 5, 161, 233, 44, 42, 219, 101, 251, 72, 20, 206, 88, 252, 181, 82, 23, 131, 159, 140, 239, 188, 231, 2, 79, 21, 221, 33, 155, 2, 128, 203, 114, 119}, { 36, 187, 214, 138, 109, 181, 133, 169, 159, 84, 55, 158, 20, 166, 45, 68, 59, 249, 3, 108, 238, 70, 59, 40, 55, 99, 132, 244, 44, 79, 28, 235, 141, 246, 12, 188, 210, 48, 27, 33, 249, 120, 144, 212, 189, 190, 125, 88, 251, 220, 233, 26, 126, 176, 232, 178, 88, 212, 219, 253, 19, 200, 191, 55, 227, 26, 80}, { 175, 108, 201, 92, 215, 184, 85, 4, 36, 71, 82, 6, 152, 86, 223, 82, 194, 33, 160, 237, 248, 10, 234, 234, 203, 126, 193, 153, 159, 208, 143, 46, 219, 119, 153, 213, 196, 100, 133, 93, 248, 114, 47, 159, 147, 87, 48, 82, 27, 221, 74, 85, 159, 34, 110, 249, 16, 87, 76, 91, 33, 62, 175, 159, 64, 102, 0}, { 242, 122, 165, 22, 55, 183, 178, 77, 60, 221, 106, 166, 254, 78, 154, 8, 188, 74, 133, 180, 195, 53, 97, 118, 124, 129, 17, 192, 186, 44, 190, 83, 204, 187, 50, 54, 86, 109, 182, 201, 133, 166, 49, 221, 7, 240, 108, 216, 244, 71, 178, 222, 200, 75, 221, 161, 126, 30, 46, 18, 87, 248, 26, 159, 252, 170, 200}, { 238, 85, 181, 166, 228, 242, 65, 165, 182, 184, 137, 23, 128, 237, 94, 173, 250, 152, 130, 15, 185, 254, 186, 248, 0, 144, 38, 51, 101, 252, 203, 32, 238, 225, 139, 190, 104, 242, 202, 234, 96, 200, 76, 188, 70, 61, 37, 157, 7, 52, 210, 46, 169, 129, 250, 229, 61, 93, 76, 142, 251, 74, 201, 230, 106, 161, 102}, { 107, 129, 211, 55, 12, 117, 95, 23, 141, 142, 70, 164, 125, 67, 191, 236, 78, 163, 47, 10, 143, 103, 182, 232, 204, 198, 241, 55, 40, 111, 57, 235, 237, 91, 189, 29, 32, 206, 163, 76, 180, 105, 132, 90, 216, 33, 147, 148, 123, 122, 40, 170, 96, 33, 49, 110, 225, 55, 179, 110, 73, 135, 227, 61, 45, 114, 64}, { 12, 168, 43, 110, 83, 174, 56, 203, 77, 166, 152, 23, 98, 201, 39, 30, 249, 25, 118, 5, 116, 70, 0, 67, 73, 159, 110, 209, 58, 173, 213, 244, 140, 166, 25, 213, 243, 38, 221, 171, 144, 92, 252, 170, 154, 164, 22, 202, 84, 148, 252, 160, 223, 229, 43, 233, 247, 117, 63, 90, 29, 240, 39, 58, 235, 169, 82}, { 74, 170, 188, 144, 168, 119, 123, 47, 89, 66, 19, 25, 254, 247, 50, 110, 113, 161, 180, 187, 24, 204, 218, 151, 3, 159, 19, 207, 166, 234, 93, 13, 84, 26, 250, 184, 252, 240, 13, 223, 8, 171, 5, 128, 151, 160, 151, 163, 119, 190, 122, 239, 73, 170, 176, 202, 40, 181, 192, 230, 37, 90, 43, 31, 156, 152, 57}, { 198, 180, 176, 19, 244, 151, 74, 182, 84, 157, 233, 13, 109, 249, 70, 25, 58, 58, 78, 73, 225, 158, 199, 197, 139, 233, 12, 199, 172, 76, 14, 202, 172, 194, 24, 187, 51, 7, 154, 200, 201, 64, 128, 124, 2, 40, 18, 23, 109, 96, 15, 29, 23, 98, 80, 194, 183, 11, 212, 64, 72, 176, 167, 241, 231, 225, 106}, { 93, 165, 24, 134, 43, 95, 18, 65, 54, 158, 168, 183, 66, 25, 187, 125, 150, 247, 71, 232, 126, 202, 91, 182, 91, 174, 93, 12, 215, 83, 57, 250, 152, 236, 238, 19, 227, 118, 125, 200, 23, 129, 83, 12, 226, 233, 195, 165, 84, 28, 57, 164, 236, 99, 19, 66, 39, 58, 227, 106, 8, 122, 213, 48, 118, 23, 215}, { 165, 8, 217, 222, 169, 213, 214, 164, 165, 13, 68, 234, 10, 34, 10, 124, 171, 10, 96, 27, 40, 243, 31, 103, 16, 153, 249, 130, 211, 99, 153, 29, 240, 25, 166, 121, 190, 94, 57, 4, 72, 197, 148, 117, 87, 145, 234, 221, 222, 253, 123, 13, 110, 249, 192, 174, 83, 94, 28, 61, 207, 122, 4, 140, 187, 242, 220}, { 15, 142, 9, 76, 187, 229, 218, 42, 133, 118, 208, 69, 238, 48, 138, 181, 107, 255, 123, 123, 211, 211, 10, 185, 44, 194, 188, 148, 52, 129, 161, 185, 218, 12, 147, 201, 128, 55, 193, 172, 181, 69, 208, 154, 203, 255, 100, 197, 75, 220, 215, 209, 57, 137, 61, 21, 159, 122, 19, 158, 30, 29, 142, 18, 232, 255, 191}, { 128, 250, 48, 120, 59, 174, 221, 37, 236, 97, 135, 208, 101, 130, 176, 24, 223, 0, 38, 255, 189, 149, 250, 103, 117, 169, 136, 134, 12, 173, 255, 30, 99, 95, 203, 174, 46, 147, 155, 198, 219, 160, 160, 175, 23, 81, 86, 149, 166, 77, 96, 119, 106, 32, 104, 61, 143, 6, 127, 71, 219, 171, 147, 127, 198, 97, 68}, { 87, 180, 8, 203, 144, 123, 52, 40, 2, 38, 204, 34, 23, 248, 116, 148, 229, 132, 32, 83, 85, 63, 146, 135, 9, 32, 75, 155, 60, 4, 213, 2, 133, 105, 25, 20, 239, 9, 33, 14, 30, 68, 217, 17, 114, 12, 48, 247, 3, 231, 169, 119, 235, 85, 232, 138, 211, 30, 242, 219, 171, 5, 70, 157, 86, 50, 159}, { 171, 10, 192, 23, 90, 220, 168, 47, 212, 105, 31, 187, 182, 153, 62, 241, 51, 13, 60, 106, 92, 230, 127, 198, 99, 89, 252, 206, 107, 254, 227, 116, 208, 32, 164, 171, 85, 85, 108, 20, 63, 18, 80, 183, 144, 37, 16, 181, 86, 58, 142, 29, 73, 195, 194, 174, 3, 29, 112, 120, 118, 67, 145, 239, 29, 202, 80}, { 205, 235, 54, 18, 244, 215, 136, 92, 149, 238, 32, 232, 235, 147, 225, 87, 214, 80, 31, 87, 209, 8, 239, 120, 42, 137, 144, 116, 204, 223, 63, 234, 88, 113, 126, 114, 48, 118, 175, 230, 107, 209, 123, 233, 214, 128, 244, 144, 71, 9, 80, 52, 241, 206, 129, 43, 150, 110, 173, 8, 237, 113, 169, 200, 3, 123, 106}, { 14, 109, 212, 190, 202, 169, 244, 38, 248, 21, 221, 195, 38, 175, 241, 105, 45, 37, 25, 180, 25, 133, 186, 6, 123, 153, 227, 39, 10, 118, 215, 128, 208, 60, 206, 194, 150, 188, 212, 77, 111, 147, 89, 184, 120, 35, 238, 133, 15, 200, 222, 197, 196, 205, 118, 228, 82, 233, 166, 110, 58, 67, 116, 236, 56, 213, 6}, { 173, 123, 233, 0, 158, 76, 1, 52, 51, 120, 229, 26, 134, 34, 248, 154, 27, 193, 16, 244, 119, 25, 238, 227, 225, 241, 94, 194, 213, 42, 195, 111, 216, 102, 56, 193, 35, 109, 184, 177, 30, 200, 180, 50, 11, 172, 60, 163, 76, 208, 49, 181, 91, 27, 189, 139, 226, 116, 151, 160, 62, 148, 134, 180, 208, 46, 75}, { 164, 103, 76, 90, 230, 126, 144, 40, 15, 208, 188, 69, 253, 170, 12, 197, 50, 32, 61, 158, 26, 247, 118, 20, 144, 153, 119, 238, 193, 249, 152, 102, 170, 75, 129, 216, 189, 183, 118, 205, 202, 242, 188, 180, 127, 6, 211, 222, 244, 182, 1, 193, 237, 193, 182, 158, 208, 182, 70, 37, 140, 10, 163, 243, 183, 34, 112}, { 187, 90, 169, 205, 146, 146, 85, 253, 211, 82, 78, 156, 55, 108, 187, 171, 232, 128, 124, 102, 218, 224, 141, 130, 101, 118, 68, 0, 123, 161, 39, 226, 18, 195, 54, 207, 142, 235, 128, 46, 0, 234, 71, 91, 204, 216, 190, 141, 173, 36, 164, 98, 53, 248, 140, 102, 100, 69, 32, 80, 117, 10, 192, 176, 59, 220, 57}, { 41, 75, 36, 30, 220, 131, 188, 57, 61, 121, 175, 193, 8, 59, 9, 158, 83, 211, 254, 150, 28, 122, 112, 175, 190, 58, 171, 69, 15, 157, 89, 24, 214, 32, 120, 103, 84, 88, 110, 50, 133, 177, 166, 152, 62, 105, 237, 129, 26, 94, 147, 101, 120, 92, 172, 247, 254, 223, 140, 48, 114, 122, 3, 138, 193, 22, 85}, { 221, 0, 243, 217, 242, 48, 225, 83, 77, 242, 14, 144, 14, 61, 0, 124, 169, 176, 6, 22, 76, 9, 65, 93, 83, 49, 196, 228, 248, 5, 226, 125, 195, 39, 128, 28, 120, 190, 254, 171, 158, 3, 180, 111, 88, 174, 199, 62, 224, 223, 70, 31, 251, 225, 97, 184, 130, 66, 213, 218, 7, 72, 15, 12, 201, 182, 228}, { 135, 84, 179, 75, 132, 220, 255, 213, 80, 243, 211, 182, 233, 237, 51, 165, 248, 247, 45, 48, 92, 72, 243, 227, 125, 106, 89, 205, 35, 12, 149, 190, 113, 205, 9, 242, 170, 101, 91, 236, 46, 71, 238, 128, 74, 69, 114, 42, 143, 116, 196, 58, 156, 80, 152, 235, 232, 197, 199, 115, 80, 54, 182, 203, 109, 120, 148}, { 70, 179, 217, 6, 33, 133, 59, 221, 207, 74, 20, 96, 236, 229, 207, 13, 181, 204, 13, 16, 99, 161, 20, 220, 58, 91, 139, 20, 41, 173, 252, 241, 174, 204, 8, 65, 5, 150, 26, 80, 11, 80, 194, 116, 73, 159, 24, 110, 127, 31, 68, 179, 32, 241, 149, 131, 95, 167, 224, 76, 83, 105, 164, 21, 150, 92, 122}, { 237, 78, 245, 94, 44, 164, 74, 55, 168, 198, 33, 158, 17, 144, 99, 133, 195, 140, 52, 60, 70, 27, 154, 31, 17, 248, 88, 88, 50, 18, 216, 156, 74, 107, 249, 27, 17, 31, 76, 112, 245, 120, 182, 112, 149, 103, 152, 246, 53, 52, 184, 66, 202, 123, 162, 132, 170, 101, 246, 252, 247, 46, 35, 63, 105, 145, 80}, { 221, 207, 122, 214, 234, 98, 182, 222, 253, 189, 147, 108, 20, 203, 238, 180, 16, 24, 240, 143, 68, 27, 52, 45, 43, 128, 66, 151, 136, 32, 91, 128, 203, 222, 161, 43, 194, 205, 4, 0, 35, 165, 108, 175, 110, 61, 76, 128, 168, 7, 138, 99, 91, 81, 140, 224, 162, 226, 119, 212, 90, 67, 152, 114, 102, 199, 233}, { 38, 253, 166, 55, 1, 46, 96, 61, 179, 253, 243, 176, 83, 218, 75, 20, 246, 207, 25, 220, 145, 211, 0, 174, 62, 213, 137, 81, 250, 24, 119, 156, 109, 169, 5, 8, 193, 65, 152, 169, 92, 204, 132, 130, 245, 158, 177, 54, 1, 116, 15, 7, 191, 185, 70, 116, 145, 85, 79, 88, 154, 242, 1, 204, 22, 243, 80}, { 57, 123, 244, 115, 156, 90, 235, 104, 15, 97, 85, 22, 72, 185, 234, 210, 124, 41, 200, 71, 226, 115, 229, 150, 56, 37, 172, 111, 191, 136, 93, 174, 191, 57, 90, 177, 34, 1, 206, 42, 76, 207, 230, 0, 57, 142, 161, 91, 20, 17, 216, 57, 112, 46, 147, 159, 238, 73, 2, 123, 112, 92, 19, 244, 226, 155, 17}, { 128, 212, 187, 103, 133, 90, 46, 67, 121, 73, 192, 73, 92, 45, 172, 204, 175, 200, 28, 236, 145, 33, 119, 124, 219, 117, 11, 98, 243, 176, 198, 118, 78, 16, 209, 182, 1, 165, 126, 39, 198, 223, 26, 89, 122, 251, 54, 223, 217, 34, 137, 110, 178, 188, 193, 117, 5, 175, 28, 179, 9, 37, 212, 179, 77, 199, 70}, { 3, 193, 180, 1, 238, 118, 30, 172, 186, 223, 46, 251, 246, 94, 3, 92, 234, 15, 231, 128, 111, 110, 155, 207, 101, 25, 206, 205, 40, 45, 37, 207, 78, 209, 246, 34, 90, 214, 249, 112, 234, 201, 238, 17, 17, 153, 166, 122, 224, 252, 177, 146, 101, 158, 226, 255, 86, 253, 39, 208, 212, 229, 232, 199, 138, 253, 123}, { 174, 34, 4, 92, 180, 27, 92, 183, 32, 93, 54, 139, 79, 210, 92, 38, 208, 36, 16, 152, 9, 108, 173, 107, 25, 188, 203, 95, 238, 13, 43, 18, 145, 126, 94, 134, 47, 242, 93, 6, 157, 192, 1, 159, 158, 185, 64, 78, 79, 136, 204, 101, 37, 250, 40, 237, 112, 72, 217, 121, 8, 215, 32, 154, 85, 221, 75}, { 105, 114, 225, 114, 45, 60, 252, 192, 51, 156, 206, 156, 76, 215, 151, 20, 22, 19, 178, 150, 75, 210, 143, 167, 82, 237, 89, 179, 215, 253, 122, 65, 234, 224, 183, 2, 147, 33, 14, 106, 91, 88, 223, 250, 213, 16, 97, 247, 226, 34, 85, 224, 102, 90, 206, 46, 187, 72, 227, 58, 106, 5, 147, 164, 224, 161, 45}, { 250, 148, 248, 147, 51, 219, 63, 190, 174, 233, 95, 16, 22, 24, 246, 83, 13, 241, 245, 88, 193, 206, 232, 245, 222, 89, 30, 67, 111, 23, 165, 48, 196, 163, 59, 123, 153, 249, 185, 198, 9, 129, 45, 73, 169, 2, 54, 55, 208, 30, 17, 25, 255, 158, 193, 121, 150, 22, 70, 219, 167, 234, 189, 107, 250, 36, 141}, { 180, 238, 11, 187, 67, 178, 58, 19, 202, 127, 21, 77, 59, 226, 28, 52, 108, 117, 61, 12, 108, 254, 139, 212, 161, 161, 213, 5, 108, 54, 1, 128, 132, 39, 180, 184, 242, 32, 135, 126, 151, 202, 199, 86, 223, 229, 230, 178, 215, 164, 197, 34, 247, 129, 58, 66, 137, 113, 228, 25, 244, 231, 159, 207, 207, 27, 63}, { 169, 15, 15, 227, 5, 110, 191, 111, 72, 109, 166, 148, 26, 224, 226, 113, 207, 129, 158, 192, 133, 15, 178, 39, 229, 142, 159, 44, 161, 156, 216, 94, 139, 171, 248, 107, 203, 174, 68, 242, 216, 72, 123, 144, 231, 190, 6, 73, 126, 117, 18, 66, 233, 89, 228, 166, 176, 182, 159, 160, 4, 164, 247, 201, 68, 200, 92}, { 255, 190, 82, 26, 243, 242, 183, 90, 35, 170, 119, 216, 68, 73, 190, 159, 146, 253, 167, 68, 176, 161, 10, 135, 198, 116, 189, 75, 2, 181, 117, 61, 214, 70, 223, 157, 187, 204, 48, 7, 235, 18, 126, 164, 91, 35, 54, 235, 64, 111, 15, 134, 246, 194, 57, 110, 24, 146, 191, 184, 101, 241, 7, 227, 116, 105, 160}, { 192, 170, 7, 243, 132, 235, 20, 247, 182, 169, 183, 74, 229, 11, 47, 87, 253, 147, 76, 252, 160, 226, 123, 247, 0, 229, 5, 158, 38, 224, 250, 169, 108, 11, 193, 199, 128, 183, 104, 5, 11, 202, 175, 137, 174, 171, 125, 247, 12, 252, 211, 250, 124, 128, 219, 202, 127, 230, 29, 103, 78, 72, 8, 104, 198, 208, 175}, { 238, 88, 82, 178, 219, 215, 209, 46, 161, 44, 4, 29, 94, 130, 252, 251, 23, 119, 14, 31, 157, 55, 138, 213, 113, 73, 150, 58, 212, 127, 101, 99, 193, 205, 110, 233, 182, 9, 169, 61, 134, 105, 170, 34, 80, 140, 10, 217, 176, 145, 175, 164, 58, 59, 55, 113, 23, 197, 216, 214, 211, 116, 55, 20, 71, 84, 99}, { 212, 65, 44, 205, 98, 54, 107, 67, 48, 149, 17, 190, 182, 105, 161, 55, 173, 21, 159, 125, 139, 13, 220, 115, 7, 35, 221, 3, 87, 25, 62, 126, 200, 23, 133, 147, 232, 68, 109, 71, 227, 48, 170, 137, 88, 113, 147, 230, 192, 34, 109, 120, 233, 128, 4, 102, 24, 100, 91, 136, 143, 212, 171, 39, 111, 145, 225}, { 68, 123, 82, 33, 118, 217, 224, 195, 153, 115, 196, 38, 130, 96, 14, 128, 158, 167, 20, 251, 50, 143, 235, 71, 111, 225, 13, 137, 99, 93, 193, 52, 128, 178, 72, 127, 13, 255, 16, 221, 101, 38, 187, 76, 197, 52, 112, 190, 140, 174, 223, 210, 123, 2, 67, 164, 69, 253, 104, 189, 253, 34, 35, 143, 43, 164, 238}, { 6, 193, 98, 42, 137, 182, 119, 205, 194, 209, 157, 73, 153, 77, 81, 238, 222, 230, 151, 127, 166, 54, 12, 34, 238, 249, 248, 196, 193, 90, 3, 116, 73, 244, 174, 248, 80, 12, 232, 8, 156, 161, 20, 119, 75, 194, 25, 54, 193, 64, 44, 26, 98, 155, 85, 136, 36, 229, 244, 93, 77, 1, 241, 211, 148, 203, 201}, { 43, 243, 64, 219, 15, 137, 59, 253, 73, 33, 29, 33, 97, 73, 231, 212, 25, 244, 197, 81, 207, 96, 7, 127, 168, 200, 121, 25, 53, 94, 116, 87, 169, 195, 242, 213, 81, 168, 93, 4, 32, 216, 121, 116, 78, 179, 30, 165, 133, 164, 124, 79, 99, 83, 27, 34, 1, 107, 175, 133, 159, 202, 235, 187, 18, 209, 237}, { 200, 106, 231, 176, 103, 131, 243, 160, 175, 28, 170, 30, 53, 19, 71, 156, 59, 98, 235, 192, 60, 193, 28, 78, 130, 161, 94, 86, 180, 192, 149, 92, 118, 170, 230, 32, 191, 16, 36, 183, 13, 176, 177, 15, 71, 62, 50, 20, 200, 244, 130, 193, 202, 70, 176, 251, 76, 195, 88, 59, 138, 206, 237, 115, 91, 195, 219}, { 238, 31, 115, 249, 70, 43, 110, 149, 168, 125, 224, 24, 183, 189, 29, 148, 252, 25, 3, 153, 84, 105, 67, 216, 73, 62, 181, 122, 247, 192, 237, 239, 122, 98, 7, 140, 245, 173, 158, 133, 36, 200, 117, 25, 40, 93, 4, 128, 154, 31, 134, 237, 135, 253, 68, 155, 55, 186, 68, 139, 225, 28, 120, 12, 184, 55, 254}, { 255, 148, 94, 105, 111, 188, 189, 226, 49, 0, 93, 60, 27, 192, 134, 117, 92, 189, 107, 192, 184, 78, 166, 34, 116, 152, 88, 80, 157, 106, 186, 188, 31, 117, 115, 9, 166, 56, 80, 89, 30, 13, 163, 79, 41, 51, 189, 245, 1, 54, 131, 128, 110, 23, 174, 49, 153, 50, 192, 166, 45, 0, 138, 157, 59, 139, 156}, { 214, 225, 85, 239, 116, 159, 58, 25, 174, 92, 48, 119, 65, 184, 36, 237, 47, 87, 168, 225, 105, 232, 35, 210, 154, 208, 143, 33, 49, 11, 61, 50, 76, 187, 61, 62, 75, 220, 64, 184, 216, 20, 96, 101, 83, 16, 2, 186, 32, 3, 209, 29, 67, 246, 248, 194, 245, 245, 43, 96, 144, 102, 227, 141, 222, 59, 149}, { 102, 98, 152, 77, 138, 109, 105, 198, 41, 135, 146, 211, 42, 78, 215, 227, 156, 201, 44, 3, 85, 18, 33, 158, 49, 24, 99, 140, 151, 195, 126, 149, 6, 169, 156, 28, 236, 40, 190, 157, 84, 250, 59, 199, 21, 203, 198, 6, 141, 103, 56, 52, 198, 93, 154, 149, 101, 179, 79, 237, 78, 3, 207, 209, 14, 75, 241}, { 209, 174, 126, 141, 113, 151, 149, 228, 70, 173, 209, 239, 7, 255, 96, 154, 232, 130, 235, 187, 56, 189, 243, 197, 215, 118, 0, 83, 1, 12, 165, 211, 5, 128, 8, 90, 23, 64, 203, 115, 182, 71, 225, 67, 155, 216, 54, 194, 138, 24, 206, 117, 23, 186, 30, 227, 253, 230, 230, 215, 162, 10, 59, 215, 57, 159, 231}, { 251, 36, 134, 134, 59, 200, 73, 86, 178, 16, 194, 253, 146, 26, 202, 118, 149, 19, 34, 3, 45, 243, 247, 170, 5, 181, 233, 128, 225, 140, 121, 53, 147, 162, 19, 37, 16, 51, 219, 36, 99, 123, 147, 239, 220, 109, 232, 176, 208, 83, 181, 196, 191, 27, 246, 63, 72, 8, 96, 35, 215, 76, 50, 36, 214, 130, 217}, { 196, 148, 207, 106, 104, 67, 163, 248, 115, 84, 15, 194, 76, 206, 106, 35, 20, 196, 151, 17, 209, 219, 227, 11, 162, 122, 234, 156, 74, 1, 166, 232, 53, 109, 236, 193, 158, 113, 240, 145, 138, 6, 66, 50, 126, 99, 132, 49, 35, 10, 39, 157, 117, 75, 213, 56, 225, 76, 66, 165, 87, 119, 165, 39, 102, 62, 73}, { 144, 116, 166, 230, 8, 30, 251, 177, 223, 204, 10, 10, 81, 245, 116, 154, 181, 21, 116, 132, 33, 136, 67, 228, 187, 38, 193, 161, 184, 5, 240, 237, 191, 240, 243, 157, 180, 2, 248, 178, 155, 131, 208, 187, 89, 106, 82, 202, 195, 132, 212, 255, 14, 172, 30, 194, 73, 179, 126, 141, 237, 152, 226, 77, 84, 138, 125}, { 161, 129, 233, 17, 146, 245, 252, 93, 79, 9, 187, 142, 210, 83, 67, 170, 185, 19, 49, 181, 146, 100, 58, 199, 39, 141, 201, 160, 192, 96, 210, 246, 188, 37, 60, 236, 242, 227, 126, 42, 2, 59, 106, 112, 154, 230, 152, 49, 68, 41, 27, 43, 222, 229, 86, 62, 38, 16, 72, 167, 135, 26, 244, 83, 222, 37, 14}, { 80, 49, 99, 145, 66, 3, 128, 70, 197, 106, 5, 46, 73, 23, 153, 241, 68, 230, 236, 36, 22, 97, 179, 17, 231, 84, 193, 133, 177, 10, 218, 41, 183, 123, 203, 81, 223, 124, 243, 223, 123, 41, 6, 65, 185, 204, 17, 8, 149, 135, 215, 52, 178, 116, 169, 15, 102, 120, 134, 141, 214, 230, 219, 15, 151, 59, 32}, { 171, 72, 215, 127, 231, 88, 208, 142, 3, 108, 253, 214, 236, 195, 74, 169, 139, 106, 91, 170, 165, 58, 102, 142, 101, 186, 106, 146, 88, 64, 53, 246, 133, 199, 126, 42, 212, 168, 184, 118, 237, 180, 6, 179, 243, 14, 14, 78, 97, 11, 120, 86, 125, 168, 56, 59, 71, 225, 12, 205, 151, 207, 118, 65, 47, 15, 16}, { 135, 16, 86, 50, 210, 113, 165, 242, 189, 0, 246, 228, 203, 3, 7, 120, 240, 101, 159, 130, 78, 116, 254, 53, 160, 123, 153, 142, 30, 208, 81, 192, 12, 255, 77, 90, 7, 96, 32, 20, 94, 57, 43, 245, 238, 211, 125, 83, 21, 177, 63, 96, 30, 186, 220, 19, 200, 202, 242, 123, 61, 183, 197, 92, 233, 117, 46}, { 19, 102, 232, 189, 226, 30, 127, 22, 223, 52, 198, 241, 54, 51, 232, 35, 125, 76, 187, 216, 28, 10, 210, 109, 126, 186, 87, 235, 235, 244, 167, 247, 100, 34, 38, 59, 161, 106, 181, 195, 113, 131, 168, 113, 171, 212, 27, 235, 84, 234, 51, 148, 79, 57, 30, 204, 66, 149, 122, 11, 47, 206, 71, 122, 112, 204, 241}, { 2, 40, 185, 240, 229, 238, 76, 114, 21, 117, 190, 124, 150, 243, 187, 61, 3, 7, 107, 2, 145, 60, 96, 227, 95, 89, 34, 150, 196, 202, 148, 18, 153, 80, 180, 255, 173, 200, 117, 198, 201, 255, 60, 79, 202, 12, 118, 155, 13, 140, 14, 148, 182, 238, 236, 248, 171, 116, 108, 73, 91, 56, 33, 8, 140, 92, 88}, { 30, 117, 208, 111, 73, 100, 227, 53, 68, 221, 242, 79, 168, 109, 72, 102, 169, 61, 126, 122, 186, 53, 167, 23, 214, 170, 213, 106, 229, 86, 34, 65, 175, 150, 24, 64, 2, 79, 39, 191, 66, 244, 252, 206, 157, 79, 52, 4, 40, 66, 119, 188, 181, 201, 138, 192, 95, 123, 117, 103, 40, 62, 157, 134, 82, 106, 165}, { 74, 50, 70, 248, 118, 2, 156, 181, 231, 250, 113, 113, 106, 4, 240, 15, 105, 101, 206, 127, 228, 103, 232, 9, 204, 15, 167, 62, 213, 134, 245, 221, 31, 103, 146, 49, 76, 11, 130, 21, 175, 5, 5, 98, 3, 136, 175, 223, 98, 208, 59, 115, 218, 188, 147, 170, 165, 249, 149, 154, 235, 207, 177, 74, 50, 8, 14}, { 185, 24, 125, 13, 41, 219, 60, 0, 98, 100, 80, 240, 29, 241, 132, 20, 190, 191, 46, 244, 117, 117, 252, 45, 10, 25, 120, 248, 177, 65, 191, 70, 10, 215, 238, 29, 196, 155, 118, 3, 82, 190, 255, 40, 235, 192, 16, 200, 37, 130, 69, 154, 73, 38, 167, 50, 103, 132, 43, 78, 119, 211, 21, 236, 150, 214, 173}, { 213, 16, 174, 199, 116, 177, 68, 219, 49, 134, 192, 140, 190, 203, 99, 171, 132, 165, 20, 224, 254, 152, 172, 14, 32, 144, 19, 176, 13, 131, 197, 177, 123, 255, 193, 176, 81, 244, 47, 209, 248, 103, 24, 164, 63, 89, 164, 145, 49, 244, 97, 120, 153, 191, 27, 124, 154, 151, 201, 191, 187, 182, 25, 170, 220, 190, 57}, { 115, 220, 55, 148, 208, 247, 230, 13, 226, 43, 247, 137, 11, 190, 50, 56, 154, 77, 234, 64, 73, 239, 79, 148, 43, 176, 208, 124, 12, 193, 85, 235, 35, 250, 49, 0, 80, 237, 97, 134, 89, 24, 149, 15, 238, 183, 223, 233, 136, 145, 63, 250, 165, 168, 29, 12, 88, 73, 111, 107, 180, 216, 79, 186, 25, 118, 36}, { 119, 98, 108, 212, 48, 19, 135, 106, 70, 129, 80, 53, 93, 134, 198, 225, 164, 206, 137, 68, 237, 88, 245, 75, 219, 213, 253, 182, 194, 165, 64, 206, 149, 82, 234, 32, 84, 59, 48, 3, 200, 4, 20, 66, 116, 3, 24, 53, 203, 233, 230, 34, 93, 169, 113, 133, 137, 152, 181, 190, 105, 161, 219, 227, 112, 169, 96}, { 137, 124, 78, 182, 128, 223, 20, 130, 217, 3, 250, 157, 182, 92, 240, 79, 37, 193, 19, 154, 35, 231, 199, 98, 211, 4, 251, 18, 87, 64, 191, 179, 0, 21, 237, 43, 130, 77, 105, 196, 224, 60, 95, 241, 147, 19, 197, 30, 47, 170, 146, 44, 100, 38, 254, 193, 112, 121, 166, 46, 162, 81, 16, 96, 254, 221, 164}, { 147, 166, 123, 202, 140, 72, 226, 240, 184, 166, 1, 64, 71, 56, 119, 208, 42, 138, 253, 233, 129, 7, 154, 9, 206, 143, 245, 46, 192, 198, 78, 41, 146, 60, 34, 189, 133, 15, 120, 157, 120, 122, 203, 36, 150, 206, 55, 38, 229, 13, 129, 230, 199, 76, 29, 7, 204, 182, 179, 236, 174, 75, 0, 247, 169, 212, 17}, { 15, 206, 242, 236, 10, 211, 20, 161, 16, 247, 189, 21, 16, 56, 61, 104, 45, 94, 92, 202, 241, 207, 11, 73, 81, 122, 81, 155, 21, 1, 158, 148, 158, 196, 52, 125, 254, 181, 254, 163, 249, 229, 57, 122, 15, 108, 84, 222, 157, 142, 19, 202, 119, 227, 28, 224, 26, 220, 166, 28, 19, 172, 254, 46, 208, 42, 73}, { 82, 193, 171, 151, 55, 200, 29, 200, 181, 168, 25, 200, 11, 21, 43, 62, 177, 73, 136, 168, 58, 40, 233, 231, 67, 107, 245, 212, 206, 175, 113, 225, 246, 82, 144, 172, 147, 130, 6, 221, 172, 83, 255, 154, 206, 138, 248, 72, 123, 251, 243, 210, 128, 215, 231, 74, 222, 183, 124, 34, 195, 172, 182, 136, 195, 110, 191}, { 210, 142, 229, 145, 242, 35, 11, 6, 159, 207, 86, 180, 69, 220, 35, 170, 131, 139, 200, 137, 118, 168, 95, 136, 48, 59, 169, 139, 36, 120, 14, 121, 132, 113, 221, 45, 245, 78, 31, 80, 169, 53, 111, 183, 18, 215, 252, 29, 84, 162, 202, 68, 139, 63, 98, 103, 219, 241, 29, 16, 95, 149, 22, 135, 189, 115, 91}, { 102, 199, 39, 53, 223, 102, 141, 42, 177, 83, 43, 203, 82, 3, 138, 178, 212, 65, 215, 247, 59, 166, 12, 252, 209, 89, 111, 141, 88, 163, 204, 129, 206, 229, 157, 40, 107, 74, 226, 196, 32, 130, 40, 222, 65, 24, 197, 50, 104, 82, 161, 123, 222, 42, 50, 239, 85, 159, 13, 183, 231, 214, 232, 84, 78, 143, 212}, { 123, 203, 205, 213, 11, 16, 221, 82, 15, 132, 224, 121, 162, 239, 36, 34, 213, 54, 160, 92, 2, 89, 74, 52, 140, 139, 235, 170, 66, 49, 200, 207, 55, 44, 131, 223, 78, 246, 51, 232, 212, 215, 95, 155, 231, 138, 0, 15, 164, 15, 32, 99, 237, 244, 22, 91, 85, 22, 119, 210, 34, 32, 191, 70, 8, 206, 51}, { 217, 138, 177, 13, 112, 67, 100, 80, 82, 177, 185, 187, 154, 48, 132, 57, 132, 76, 68, 110, 147, 204, 171, 57, 14, 155, 44, 176, 37, 83, 113, 85, 136, 178, 138, 38, 174, 229, 42, 209, 60, 40, 242, 170, 121, 229, 50, 108, 152, 190, 128, 89, 240, 185, 190, 226, 125, 61, 2, 137, 153, 57, 8, 155, 104, 22, 183}, { 106, 64, 52, 128, 249, 184, 59, 134, 201, 171, 194, 39, 158, 71, 189, 227, 218, 172, 2, 186, 212, 74, 248, 165, 128, 12, 161, 247, 239, 158, 120, 182, 100, 229, 81, 73, 206, 200, 98, 33, 182, 11, 45, 177, 195, 139, 48, 38, 186, 133, 45, 246, 0, 52, 128, 93, 48, 222, 234, 102, 147, 150, 33, 75, 168, 213, 235}, { 253, 222, 29, 173, 23, 240, 242, 140, 180, 3, 123, 125, 36, 23, 75, 90, 24, 209, 203, 5, 197, 101, 176, 225, 249, 12, 26, 234, 42, 241, 16, 37, 136, 172, 144, 146, 45, 82, 228, 155, 38, 247, 184, 141, 56, 141, 207, 206, 102, 2, 65, 199, 15, 174, 92, 30, 22, 151, 91, 28, 123, 227, 162, 46, 66, 237, 79}, { 111, 170, 237, 98, 101, 171, 25, 84, 236, 72, 211, 193, 236, 26, 148, 3, 192, 91, 31, 233, 117, 168, 113, 145, 104, 217, 158, 4, 145, 96, 232, 26, 150, 63, 62, 150, 147, 65, 228, 17, 55, 225, 66, 56, 233, 207, 100, 153, 120, 186, 150, 207, 45, 169, 231, 18, 82, 203, 13, 140, 251, 23, 237, 156, 145, 114, 105}, { 232, 100, 54, 63, 166, 61, 223, 131, 214, 77, 213, 242, 15, 117, 39, 32, 190, 29, 249, 143, 220, 134, 4, 124, 240, 37, 140, 105, 28, 43, 87, 200, 186, 13, 251, 16, 225, 246, 59, 239, 158, 21, 55, 179, 25, 202, 66, 117, 61, 225, 72, 51, 76, 64, 235, 112, 105, 91, 199, 189, 58, 58, 204, 142, 234, 157, 4}, { 162, 114, 81, 123, 0, 199, 27, 93, 220, 46, 18, 83, 28, 224, 136, 57, 136, 157, 240, 197, 204, 253, 52, 169, 114, 222, 158, 251, 201, 66, 1, 40, 61, 41, 36, 119, 235, 92, 255, 113, 99, 65, 67, 157, 19, 207, 229, 160, 217, 169, 123, 102, 88, 79, 236, 218, 197, 192, 234, 91, 146, 95, 133, 116, 225, 145, 204}, { 113, 10, 227, 223, 65, 112, 214, 82, 117, 63, 163, 191, 116, 249, 129, 53, 110, 62, 38, 39, 235, 193, 249, 93, 102, 200, 15, 252, 226, 217, 193, 99, 115, 72, 3, 138, 237, 56, 21, 207, 190, 255, 116, 34, 64, 60, 30, 1, 91, 38, 184, 74, 191, 212, 214, 233, 177, 39, 75, 227, 95, 241, 23, 202, 179, 71, 147}, { 214, 1, 21, 47, 135, 142, 75, 13, 106, 158, 173, 61, 86, 135, 61, 113, 124, 169, 186, 108, 187, 35, 254, 55, 87, 221, 238, 233, 252, 121, 156, 110, 162, 225, 91, 211, 239, 243, 172, 120, 206, 196, 23, 76, 53, 17, 149, 198, 81, 70, 28, 223, 188, 141, 206, 57, 195, 68, 24, 128, 139, 22, 208, 87, 102, 122, 227}, { 22, 6, 222, 114, 180, 81, 10, 109, 182, 41, 4, 110, 141, 130, 67, 30, 242, 242, 43, 170, 118, 66, 83, 253, 62, 238, 153, 90, 99, 31, 211, 87, 174, 215, 12, 206, 165, 64, 73, 209, 78, 203, 138, 37, 158, 59, 19, 139, 186, 56, 110, 183, 247, 143, 188, 210, 250, 211, 115, 250, 117, 118, 101, 153, 70, 46, 147}, { 158, 54, 11, 222, 116, 83, 216, 212, 158, 165, 250, 70, 184, 150, 214, 212, 91, 130, 134, 81, 27, 45, 145, 113, 120, 221, 231, 154, 179, 231, 129, 11, 148, 97, 233, 8, 242, 44, 119, 35, 207, 122, 220, 102, 89, 63, 181, 234, 27, 166, 168, 84, 8, 227, 106, 53, 222, 153, 138, 119, 248, 177, 42, 12, 176, 204, 72}, { 206, 85, 163, 82, 44, 237, 99, 44, 142, 221, 234, 124, 5, 124, 100, 200, 184, 85, 42, 54, 14, 212, 13, 13, 138, 58, 228, 125, 27, 160, 190, 174, 110, 94, 139, 233, 218, 219, 176, 170, 240, 133, 44, 15, 191, 84, 83, 38, 138, 101, 179, 254, 70, 200, 94, 187, 180, 141, 21, 32, 108, 127, 84, 103, 27, 40, 70}, { 1, 154, 114, 180, 221, 114, 5, 43, 197, 97, 126, 183, 92, 205, 38, 237, 47, 62, 50, 18, 110, 182, 23, 0, 126, 24, 162, 234, 105, 175, 132, 167, 61, 11, 92, 208, 45, 200, 229, 68, 230, 130, 189, 218, 252, 21, 152, 63, 74, 19, 130, 148, 58, 130, 78, 137, 68, 116, 146, 154, 86, 145, 75, 200, 246, 59, 112}, { 101, 10, 162, 180, 214, 136, 140, 208, 207, 37, 20, 173, 142, 200, 62, 233, 90, 75, 114, 35, 205, 55, 190, 7, 100, 128, 235, 123, 97, 160, 93, 215, 202, 29, 98, 88, 1, 179, 20, 7, 70, 118, 55, 176, 15, 224, 72, 132, 118, 250, 144, 198, 65, 251, 205, 89, 240, 242, 16, 59, 218, 119, 126, 179, 156, 228, 31}, { 207, 201, 74, 218, 60, 68, 66, 91, 0, 98, 130, 57, 229, 15, 93, 184, 190, 227, 99, 51, 118, 43, 231, 216, 129, 7, 69, 148, 154, 178, 254, 201, 79, 170, 98, 118, 86, 192, 248, 82, 140, 193, 145, 131, 136, 26, 32, 234, 241, 102, 29, 203, 191, 34, 108, 32, 49, 29, 6, 85, 179, 12, 90, 198, 207, 118, 141}};
                    int array_flip_horizontal[100][67] = {{ 207, 201, 74, 218, 60, 68, 66, 91, 0, 98, 130, 57, 229, 15, 93, 184, 190, 227, 99, 51, 118, 43, 231, 216, 129, 7, 69, 148, 154, 178, 254, 201, 79, 170, 98, 118, 86, 192, 248, 82, 140, 193, 145, 131, 136, 26, 32, 234, 241, 102, 29, 203, 191, 34, 108, 32, 49, 29, 6, 85, 179, 12, 90, 198, 207, 118, 141}, { 101, 10, 162, 180, 214, 136, 140, 208, 207, 37, 20, 173, 142, 200, 62, 233, 90, 75, 114, 35, 205, 55, 190, 7, 100, 128, 235, 123, 97, 160, 93, 215, 202, 29, 98, 88, 1, 179, 20, 7, 70, 118, 55, 176, 15, 224, 72, 132, 118, 250, 144, 198, 65, 251, 205, 89, 240, 242, 16, 59, 218, 119, 126, 179, 156, 228, 31}, { 1, 154, 114, 180, 221, 114, 5, 43, 197, 97, 126, 183, 92, 205, 38, 237, 47, 62, 50, 18, 110, 182, 23, 0, 126, 24, 162, 234, 105, 175, 132, 167, 61, 11, 92, 208, 45, 200, 229, 68, 230, 130, 189, 218, 252, 21, 152, 63, 74, 19, 130, 148, 58, 130, 78, 137, 68, 116, 146, 154, 86, 145, 75, 200, 246, 59, 112}, { 206, 85, 163, 82, 44, 237, 99, 44, 142, 221, 234, 124, 5, 124, 100, 200, 184, 85, 42, 54, 14, 212, 13, 13, 138, 58, 228, 125, 27, 160, 190, 174, 110, 94, 139, 233, 218, 219, 176, 170, 240, 133, 44, 15, 191, 84, 83, 38, 138, 101, 179, 254, 70, 200, 94, 187, 180, 141, 21, 32, 108, 127, 84, 103, 27, 40, 70}, { 158, 54, 11, 222, 116, 83, 216, 212, 158, 165, 250, 70, 184, 150, 214, 212, 91, 130, 134, 81, 27, 45, 145, 113, 120, 221, 231, 154, 179, 231, 129, 11, 148, 97, 233, 8, 242, 44, 119, 35, 207, 122, 220, 102, 89, 63, 181, 234, 27, 166, 168, 84, 8, 227, 106, 53, 222, 153, 138, 119, 248, 177, 42, 12, 176, 204, 72}, { 22, 6, 222, 114, 180, 81, 10, 109, 182, 41, 4, 110, 141, 130, 67, 30, 242, 242, 43, 170, 118, 66, 83, 253, 62, 238, 153, 90, 99, 31, 211, 87, 174, 215, 12, 206, 165, 64, 73, 209, 78, 203, 138, 37, 158, 59, 19, 139, 186, 56, 110, 183, 247, 143, 188, 210, 250, 211, 115, 250, 117, 118, 101, 153, 70, 46, 147}, { 214, 1, 21, 47, 135, 142, 75, 13, 106, 158, 173, 61, 86, 135, 61, 113, 124, 169, 186, 108, 187, 35, 254, 55, 87, 221, 238, 233, 252, 121, 156, 110, 162, 225, 91, 211, 239, 243, 172, 120, 206, 196, 23, 76, 53, 17, 149, 198, 81, 70, 28, 223, 188, 141, 206, 57, 195, 68, 24, 128, 139, 22, 208, 87, 102, 122, 227}, { 113, 10, 227, 223, 65, 112, 214, 82, 117, 63, 163, 191, 116, 249, 129, 53, 110, 62, 38, 39, 235, 193, 249, 93, 102, 200, 15, 252, 226, 217, 193, 99, 115, 72, 3, 138, 237, 56, 21, 207, 190, 255, 116, 34, 64, 60, 30, 1, 91, 38, 184, 74, 191, 212, 214, 233, 177, 39, 75, 227, 95, 241, 23, 202, 179, 71, 147}, { 162, 114, 81, 123, 0, 199, 27, 93, 220, 46, 18, 83, 28, 224, 136, 57, 136, 157, 240, 197, 204, 253, 52, 169, 114, 222, 158, 251, 201, 66, 1, 40, 61, 41, 36, 119, 235, 92, 255, 113, 99, 65, 67, 157, 19, 207, 229, 160, 217, 169, 123, 102, 88, 79, 236, 218, 197, 192, 234, 91, 146, 95, 133, 116, 225, 145, 204}, { 232, 100, 54, 63, 166, 61, 223, 131, 214, 77, 213, 242, 15, 117, 39, 32, 190, 29, 249, 143, 220, 134, 4, 124, 240, 37, 140, 105, 28, 43, 87, 200, 186, 13, 251, 16, 225, 246, 59, 239, 158, 21, 55, 179, 25, 202, 66, 117, 61, 225, 72, 51, 76, 64, 235, 112, 105, 91, 199, 189, 58, 58, 204, 142, 234, 157, 4}, { 111, 170, 237, 98, 101, 171, 25, 84, 236, 72, 211, 193, 236, 26, 148, 3, 192, 91, 31, 233, 117, 168, 113, 145, 104, 217, 158, 4, 145, 96, 232, 26, 150, 63, 62, 150, 147, 65, 228, 17, 55, 225, 66, 56, 233, 207, 100, 153, 120, 186, 150, 207, 45, 169, 231, 18, 82, 203, 13, 140, 251, 23, 237, 156, 145, 114, 105}, { 253, 222, 29, 173, 23, 240, 242, 140, 180, 3, 123, 125, 36, 23, 75, 90, 24, 209, 203, 5, 197, 101, 176, 225, 249, 12, 26, 234, 42, 241, 16, 37, 136, 172, 144, 146, 45, 82, 228, 155, 38, 247, 184, 141, 56, 141, 207, 206, 102, 2, 65, 199, 15, 174, 92, 30, 22, 151, 91, 28, 123, 227, 162, 46, 66, 237, 79}, { 106, 64, 52, 128, 249, 184, 59, 134, 201, 171, 194, 39, 158, 71, 189, 227, 218, 172, 2, 186, 212, 74, 248, 165, 128, 12, 161, 247, 239, 158, 120, 182, 100, 229, 81, 73, 206, 200, 98, 33, 182, 11, 45, 177, 195, 139, 48, 38, 186, 133, 45, 246, 0, 52, 128, 93, 48, 222, 234, 102, 147, 150, 33, 75, 168, 213, 235}, { 217, 138, 177, 13, 112, 67, 100, 80, 82, 177, 185, 187, 154, 48, 132, 57, 132, 76, 68, 110, 147, 204, 171, 57, 14, 155, 44, 176, 37, 83, 113, 85, 136, 178, 138, 38, 174, 229, 42, 209, 60, 40, 242, 170, 121, 229, 50, 108, 152, 190, 128, 89, 240, 185, 190, 226, 125, 61, 2, 137, 153, 57, 8, 155, 104, 22, 183}, { 123, 203, 205, 213, 11, 16, 221, 82, 15, 132, 224, 121, 162, 239, 36, 34, 213, 54, 160, 92, 2, 89, 74, 52, 140, 139, 235, 170, 66, 49, 200, 207, 55, 44, 131, 223, 78, 246, 51, 232, 212, 215, 95, 155, 231, 138, 0, 15, 164, 15, 32, 99, 237, 244, 22, 91, 85, 22, 119, 210, 34, 32, 191, 70, 8, 206, 51}, { 102, 199, 39, 53, 223, 102, 141, 42, 177, 83, 43, 203, 82, 3, 138, 178, 212, 65, 215, 247, 59, 166, 12, 252, 209, 89, 111, 141, 88, 163, 204, 129, 206, 229, 157, 40, 107, 74, 226, 196, 32, 130, 40, 222, 65, 24, 197, 50, 104, 82, 161, 123, 222, 42, 50, 239, 85, 159, 13, 183, 231, 214, 232, 84, 78, 143, 212}, { 210, 142, 229, 145, 242, 35, 11, 6, 159, 207, 86, 180, 69, 220, 35, 170, 131, 139, 200, 137, 118, 168, 95, 136, 48, 59, 169, 139, 36, 120, 14, 121, 132, 113, 221, 45, 245, 78, 31, 80, 169, 53, 111, 183, 18, 215, 252, 29, 84, 162, 202, 68, 139, 63, 98, 103, 219, 241, 29, 16, 95, 149, 22, 135, 189, 115, 91}, { 82, 193, 171, 151, 55, 200, 29, 200, 181, 168, 25, 200, 11, 21, 43, 62, 177, 73, 136, 168, 58, 40, 233, 231, 67, 107, 245, 212, 206, 175, 113, 225, 246, 82, 144, 172, 147, 130, 6, 221, 172, 83, 255, 154, 206, 138, 248, 72, 123, 251, 243, 210, 128, 215, 231, 74, 222, 183, 124, 34, 195, 172, 182, 136, 195, 110, 191}, { 15, 206, 242, 236, 10, 211, 20, 161, 16, 247, 189, 21, 16, 56, 61, 104, 45, 94, 92, 202, 241, 207, 11, 73, 81, 122, 81, 155, 21, 1, 158, 148, 158, 196, 52, 125, 254, 181, 254, 163, 249, 229, 57, 122, 15, 108, 84, 222, 157, 142, 19, 202, 119, 227, 28, 224, 26, 220, 166, 28, 19, 172, 254, 46, 208, 42, 73}, { 147, 166, 123, 202, 140, 72, 226, 240, 184, 166, 1, 64, 71, 56, 119, 208, 42, 138, 253, 233, 129, 7, 154, 9, 206, 143, 245, 46, 192, 198, 78, 41, 146, 60, 34, 189, 133, 15, 120, 157, 120, 122, 203, 36, 150, 206, 55, 38, 229, 13, 129, 230, 199, 76, 29, 7, 204, 182, 179, 236, 174, 75, 0, 247, 169, 212, 17}, { 137, 124, 78, 182, 128, 223, 20, 130, 217, 3, 250, 157, 182, 92, 240, 79, 37, 193, 19, 154, 35, 231, 199, 98, 211, 4, 251, 18, 87, 64, 191, 179, 0, 21, 237, 43, 130, 77, 105, 196, 224, 60, 95, 241, 147, 19, 197, 30, 47, 170, 146, 44, 100, 38, 254, 193, 112, 121, 166, 46, 162, 81, 16, 96, 254, 221, 164}, { 119, 98, 108, 212, 48, 19, 135, 106, 70, 129, 80, 53, 93, 134, 198, 225, 164, 206, 137, 68, 237, 88, 245, 75, 219, 213, 253, 182, 194, 165, 64, 206, 149, 82, 234, 32, 84, 59, 48, 3, 200, 4, 20, 66, 116, 3, 24, 53, 203, 233, 230, 34, 93, 169, 113, 133, 137, 152, 181, 190, 105, 161, 219, 227, 112, 169, 96}, { 115, 220, 55, 148, 208, 247, 230, 13, 226, 43, 247, 137, 11, 190, 50, 56, 154, 77, 234, 64, 73, 239, 79, 148, 43, 176, 208, 124, 12, 193, 85, 235, 35, 250, 49, 0, 80, 237, 97, 134, 89, 24, 149, 15, 238, 183, 223, 233, 136, 145, 63, 250, 165, 168, 29, 12, 88, 73, 111, 107, 180, 216, 79, 186, 25, 118, 36}, { 213, 16, 174, 199, 116, 177, 68, 219, 49, 134, 192, 140, 190, 203, 99, 171, 132, 165, 20, 224, 254, 152, 172, 14, 32, 144, 19, 176, 13, 131, 197, 177, 123, 255, 193, 176, 81, 244, 47, 209, 248, 103, 24, 164, 63, 89, 164, 145, 49, 244, 97, 120, 153, 191, 27, 124, 154, 151, 201, 191, 187, 182, 25, 170, 220, 190, 57}, { 185, 24, 125, 13, 41, 219, 60, 0, 98, 100, 80, 240, 29, 241, 132, 20, 190, 191, 46, 244, 117, 117, 252, 45, 10, 25, 120, 248, 177, 65, 191, 70, 10, 215, 238, 29, 196, 155, 118, 3, 82, 190, 255, 40, 235, 192, 16, 200, 37, 130, 69, 154, 73, 38, 167, 50, 103, 132, 43, 78, 119, 211, 21, 236, 150, 214, 173}, { 74, 50, 70, 248, 118, 2, 156, 181, 231, 250, 113, 113, 106, 4, 240, 15, 105, 101, 206, 127, 228, 103, 232, 9, 204, 15, 167, 62, 213, 134, 245, 221, 31, 103, 146, 49, 76, 11, 130, 21, 175, 5, 5, 98, 3, 136, 175, 223, 98, 208, 59, 115, 218, 188, 147, 170, 165, 249, 149, 154, 235, 207, 177, 74, 50, 8, 14}, { 30, 117, 208, 111, 73, 100, 227, 53, 68, 221, 242, 79, 168, 109, 72, 102, 169, 61, 126, 122, 186, 53, 167, 23, 214, 170, 213, 106, 229, 86, 34, 65, 175, 150, 24, 64, 2, 79, 39, 191, 66, 244, 252, 206, 157, 79, 52, 4, 40, 66, 119, 188, 181, 201, 138, 192, 95, 123, 117, 103, 40, 62, 157, 134, 82, 106, 165}, { 2, 40, 185, 240, 229, 238, 76, 114, 21, 117, 190, 124, 150, 243, 187, 61, 3, 7, 107, 2, 145, 60, 96, 227, 95, 89, 34, 150, 196, 202, 148, 18, 153, 80, 180, 255, 173, 200, 117, 198, 201, 255, 60, 79, 202, 12, 118, 155, 13, 140, 14, 148, 182, 238, 236, 248, 171, 116, 108, 73, 91, 56, 33, 8, 140, 92, 88}, { 19, 102, 232, 189, 226, 30, 127, 22, 223, 52, 198, 241, 54, 51, 232, 35, 125, 76, 187, 216, 28, 10, 210, 109, 126, 186, 87, 235, 235, 244, 167, 247, 100, 34, 38, 59, 161, 106, 181, 195, 113, 131, 168, 113, 171, 212, 27, 235, 84, 234, 51, 148, 79, 57, 30, 204, 66, 149, 122, 11, 47, 206, 71, 122, 112, 204, 241}, { 135, 16, 86, 50, 210, 113, 165, 242, 189, 0, 246, 228, 203, 3, 7, 120, 240, 101, 159, 130, 78, 116, 254, 53, 160, 123, 153, 142, 30, 208, 81, 192, 12, 255, 77, 90, 7, 96, 32, 20, 94, 57, 43, 245, 238, 211, 125, 83, 21, 177, 63, 96, 30, 186, 220, 19, 200, 202, 242, 123, 61, 183, 197, 92, 233, 117, 46}, { 171, 72, 215, 127, 231, 88, 208, 142, 3, 108, 253, 214, 236, 195, 74, 169, 139, 106, 91, 170, 165, 58, 102, 142, 101, 186, 106, 146, 88, 64, 53, 246, 133, 199, 126, 42, 212, 168, 184, 118, 237, 180, 6, 179, 243, 14, 14, 78, 97, 11, 120, 86, 125, 168, 56, 59, 71, 225, 12, 205, 151, 207, 118, 65, 47, 15, 16}, { 80, 49, 99, 145, 66, 3, 128, 70, 197, 106, 5, 46, 73, 23, 153, 241, 68, 230, 236, 36, 22, 97, 179, 17, 231, 84, 193, 133, 177, 10, 218, 41, 183, 123, 203, 81, 223, 124, 243, 223, 123, 41, 6, 65, 185, 204, 17, 8, 149, 135, 215, 52, 178, 116, 169, 15, 102, 120, 134, 141, 214, 230, 219, 15, 151, 59, 32}, { 161, 129, 233, 17, 146, 245, 252, 93, 79, 9, 187, 142, 210, 83, 67, 170, 185, 19, 49, 181, 146, 100, 58, 199, 39, 141, 201, 160, 192, 96, 210, 246, 188, 37, 60, 236, 242, 227, 126, 42, 2, 59, 106, 112, 154, 230, 152, 49, 68, 41, 27, 43, 222, 229, 86, 62, 38, 16, 72, 167, 135, 26, 244, 83, 222, 37, 14}, { 144, 116, 166, 230, 8, 30, 251, 177, 223, 204, 10, 10, 81, 245, 116, 154, 181, 21, 116, 132, 33, 136, 67, 228, 187, 38, 193, 161, 184, 5, 240, 237, 191, 240, 243, 157, 180, 2, 248, 178, 155, 131, 208, 187, 89, 106, 82, 202, 195, 132, 212, 255, 14, 172, 30, 194, 73, 179, 126, 141, 237, 152, 226, 77, 84, 138, 125}, { 196, 148, 207, 106, 104, 67, 163, 248, 115, 84, 15, 194, 76, 206, 106, 35, 20, 196, 151, 17, 209, 219, 227, 11, 162, 122, 234, 156, 74, 1, 166, 232, 53, 109, 236, 193, 158, 113, 240, 145, 138, 6, 66, 50, 126, 99, 132, 49, 35, 10, 39, 157, 117, 75, 213, 56, 225, 76, 66, 165, 87, 119, 165, 39, 102, 62, 73}, { 251, 36, 134, 134, 59, 200, 73, 86, 178, 16, 194, 253, 146, 26, 202, 118, 149, 19, 34, 3, 45, 243, 247, 170, 5, 181, 233, 128, 225, 140, 121, 53, 147, 162, 19, 37, 16, 51, 219, 36, 99, 123, 147, 239, 220, 109, 232, 176, 208, 83, 181, 196, 191, 27, 246, 63, 72, 8, 96, 35, 215, 76, 50, 36, 214, 130, 217}, { 209, 174, 126, 141, 113, 151, 149, 228, 70, 173, 209, 239, 7, 255, 96, 154, 232, 130, 235, 187, 56, 189, 243, 197, 215, 118, 0, 83, 1, 12, 165, 211, 5, 128, 8, 90, 23, 64, 203, 115, 182, 71, 225, 67, 155, 216, 54, 194, 138, 24, 206, 117, 23, 186, 30, 227, 253, 230, 230, 215, 162, 10, 59, 215, 57, 159, 231}, { 102, 98, 152, 77, 138, 109, 105, 198, 41, 135, 146, 211, 42, 78, 215, 227, 156, 201, 44, 3, 85, 18, 33, 158, 49, 24, 99, 140, 151, 195, 126, 149, 6, 169, 156, 28, 236, 40, 190, 157, 84, 250, 59, 199, 21, 203, 198, 6, 141, 103, 56, 52, 198, 93, 154, 149, 101, 179, 79, 237, 78, 3, 207, 209, 14, 75, 241}, { 214, 225, 85, 239, 116, 159, 58, 25, 174, 92, 48, 119, 65, 184, 36, 237, 47, 87, 168, 225, 105, 232, 35, 210, 154, 208, 143, 33, 49, 11, 61, 50, 76, 187, 61, 62, 75, 220, 64, 184, 216, 20, 96, 101, 83, 16, 2, 186, 32, 3, 209, 29, 67, 246, 248, 194, 245, 245, 43, 96, 144, 102, 227, 141, 222, 59, 149}, { 255, 148, 94, 105, 111, 188, 189, 226, 49, 0, 93, 60, 27, 192, 134, 117, 92, 189, 107, 192, 184, 78, 166, 34, 116, 152, 88, 80, 157, 106, 186, 188, 31, 117, 115, 9, 166, 56, 80, 89, 30, 13, 163, 79, 41, 51, 189, 245, 1, 54, 131, 128, 110, 23, 174, 49, 153, 50, 192, 166, 45, 0, 138, 157, 59, 139, 156}, { 238, 31, 115, 249, 70, 43, 110, 149, 168, 125, 224, 24, 183, 189, 29, 148, 252, 25, 3, 153, 84, 105, 67, 216, 73, 62, 181, 122, 247, 192, 237, 239, 122, 98, 7, 140, 245, 173, 158, 133, 36, 200, 117, 25, 40, 93, 4, 128, 154, 31, 134, 237, 135, 253, 68, 155, 55, 186, 68, 139, 225, 28, 120, 12, 184, 55, 254}, { 200, 106, 231, 176, 103, 131, 243, 160, 175, 28, 170, 30, 53, 19, 71, 156, 59, 98, 235, 192, 60, 193, 28, 78, 130, 161, 94, 86, 180, 192, 149, 92, 118, 170, 230, 32, 191, 16, 36, 183, 13, 176, 177, 15, 71, 62, 50, 20, 200, 244, 130, 193, 202, 70, 176, 251, 76, 195, 88, 59, 138, 206, 237, 115, 91, 195, 219}, { 43, 243, 64, 219, 15, 137, 59, 253, 73, 33, 29, 33, 97, 73, 231, 212, 25, 244, 197, 81, 207, 96, 7, 127, 168, 200, 121, 25, 53, 94, 116, 87, 169, 195, 242, 213, 81, 168, 93, 4, 32, 216, 121, 116, 78, 179, 30, 165, 133, 164, 124, 79, 99, 83, 27, 34, 1, 107, 175, 133, 159, 202, 235, 187, 18, 209, 237}, { 6, 193, 98, 42, 137, 182, 119, 205, 194, 209, 157, 73, 153, 77, 81, 238, 222, 230, 151, 127, 166, 54, 12, 34, 238, 249, 248, 196, 193, 90, 3, 116, 73, 244, 174, 248, 80, 12, 232, 8, 156, 161, 20, 119, 75, 194, 25, 54, 193, 64, 44, 26, 98, 155, 85, 136, 36, 229, 244, 93, 77, 1, 241, 211, 148, 203, 201}, { 68, 123, 82, 33, 118, 217, 224, 195, 153, 115, 196, 38, 130, 96, 14, 128, 158, 167, 20, 251, 50, 143, 235, 71, 111, 225, 13, 137, 99, 93, 193, 52, 128, 178, 72, 127, 13, 255, 16, 221, 101, 38, 187, 76, 197, 52, 112, 190, 140, 174, 223, 210, 123, 2, 67, 164, 69, 253, 104, 189, 253, 34, 35, 143, 43, 164, 238}, { 212, 65, 44, 205, 98, 54, 107, 67, 48, 149, 17, 190, 182, 105, 161, 55, 173, 21, 159, 125, 139, 13, 220, 115, 7, 35, 221, 3, 87, 25, 62, 126, 200, 23, 133, 147, 232, 68, 109, 71, 227, 48, 170, 137, 88, 113, 147, 230, 192, 34, 109, 120, 233, 128, 4, 102, 24, 100, 91, 136, 143, 212, 171, 39, 111, 145, 225}, { 238, 88, 82, 178, 219, 215, 209, 46, 161, 44, 4, 29, 94, 130, 252, 251, 23, 119, 14, 31, 157, 55, 138, 213, 113, 73, 150, 58, 212, 127, 101, 99, 193, 205, 110, 233, 182, 9, 169, 61, 134, 105, 170, 34, 80, 140, 10, 217, 176, 145, 175, 164, 58, 59, 55, 113, 23, 197, 216, 214, 211, 116, 55, 20, 71, 84, 99}, { 192, 170, 7, 243, 132, 235, 20, 247, 182, 169, 183, 74, 229, 11, 47, 87, 253, 147, 76, 252, 160, 226, 123, 247, 0, 229, 5, 158, 38, 224, 250, 169, 108, 11, 193, 199, 128, 183, 104, 5, 11, 202, 175, 137, 174, 171, 125, 247, 12, 252, 211, 250, 124, 128, 219, 202, 127, 230, 29, 103, 78, 72, 8, 104, 198, 208, 175}, { 255, 190, 82, 26, 243, 242, 183, 90, 35, 170, 119, 216, 68, 73, 190, 159, 146, 253, 167, 68, 176, 161, 10, 135, 198, 116, 189, 75, 2, 181, 117, 61, 214, 70, 223, 157, 187, 204, 48, 7, 235, 18, 126, 164, 91, 35, 54, 235, 64, 111, 15, 134, 246, 194, 57, 110, 24, 146, 191, 184, 101, 241, 7, 227, 116, 105, 160}, { 169, 15, 15, 227, 5, 110, 191, 111, 72, 109, 166, 148, 26, 224, 226, 113, 207, 129, 158, 192, 133, 15, 178, 39, 229, 142, 159, 44, 161, 156, 216, 94, 139, 171, 248, 107, 203, 174, 68, 242, 216, 72, 123, 144, 231, 190, 6, 73, 126, 117, 18, 66, 233, 89, 228, 166, 176, 182, 159, 160, 4, 164, 247, 201, 68, 200, 92}, { 180, 238, 11, 187, 67, 178, 58, 19, 202, 127, 21, 77, 59, 226, 28, 52, 108, 117, 61, 12, 108, 254, 139, 212, 161, 161, 213, 5, 108, 54, 1, 128, 132, 39, 180, 184, 242, 32, 135, 126, 151, 202, 199, 86, 223, 229, 230, 178, 215, 164, 197, 34, 247, 129, 58, 66, 137, 113, 228, 25, 244, 231, 159, 207, 207, 27, 63}, { 250, 148, 248, 147, 51, 219, 63, 190, 174, 233, 95, 16, 22, 24, 246, 83, 13, 241, 245, 88, 193, 206, 232, 245, 222, 89, 30, 67, 111, 23, 165, 48, 196, 163, 59, 123, 153, 249, 185, 198, 9, 129, 45, 73, 169, 2, 54, 55, 208, 30, 17, 25, 255, 158, 193, 121, 150, 22, 70, 219, 167, 234, 189, 107, 250, 36, 141}, { 105, 114, 225, 114, 45, 60, 252, 192, 51, 156, 206, 156, 76, 215, 151, 20, 22, 19, 178, 150, 75, 210, 143, 167, 82, 237, 89, 179, 215, 253, 122, 65, 234, 224, 183, 2, 147, 33, 14, 106, 91, 88, 223, 250, 213, 16, 97, 247, 226, 34, 85, 224, 102, 90, 206, 46, 187, 72, 227, 58, 106, 5, 147, 164, 224, 161, 45}, { 174, 34, 4, 92, 180, 27, 92, 183, 32, 93, 54, 139, 79, 210, 92, 38, 208, 36, 16, 152, 9, 108, 173, 107, 25, 188, 203, 95, 238, 13, 43, 18, 145, 126, 94, 134, 47, 242, 93, 6, 157, 192, 1, 159, 158, 185, 64, 78, 79, 136, 204, 101, 37, 250, 40, 237, 112, 72, 217, 121, 8, 215, 32, 154, 85, 221, 75}, { 3, 193, 180, 1, 238, 118, 30, 172, 186, 223, 46, 251, 246, 94, 3, 92, 234, 15, 231, 128, 111, 110, 155, 207, 101, 25, 206, 205, 40, 45, 37, 207, 78, 209, 246, 34, 90, 214, 249, 112, 234, 201, 238, 17, 17, 153, 166, 122, 224, 252, 177, 146, 101, 158, 226, 255, 86, 253, 39, 208, 212, 229, 232, 199, 138, 253, 123}, { 128, 212, 187, 103, 133, 90, 46, 67, 121, 73, 192, 73, 92, 45, 172, 204, 175, 200, 28, 236, 145, 33, 119, 124, 219, 117, 11, 98, 243, 176, 198, 118, 78, 16, 209, 182, 1, 165, 126, 39, 198, 223, 26, 89, 122, 251, 54, 223, 217, 34, 137, 110, 178, 188, 193, 117, 5, 175, 28, 179, 9, 37, 212, 179, 77, 199, 70}, { 57, 123, 244, 115, 156, 90, 235, 104, 15, 97, 85, 22, 72, 185, 234, 210, 124, 41, 200, 71, 226, 115, 229, 150, 56, 37, 172, 111, 191, 136, 93, 174, 191, 57, 90, 177, 34, 1, 206, 42, 76, 207, 230, 0, 57, 142, 161, 91, 20, 17, 216, 57, 112, 46, 147, 159, 238, 73, 2, 123, 112, 92, 19, 244, 226, 155, 17}, { 38, 253, 166, 55, 1, 46, 96, 61, 179, 253, 243, 176, 83, 218, 75, 20, 246, 207, 25, 220, 145, 211, 0, 174, 62, 213, 137, 81, 250, 24, 119, 156, 109, 169, 5, 8, 193, 65, 152, 169, 92, 204, 132, 130, 245, 158, 177, 54, 1, 116, 15, 7, 191, 185, 70, 116, 145, 85, 79, 88, 154, 242, 1, 204, 22, 243, 80}, { 221, 207, 122, 214, 234, 98, 182, 222, 253, 189, 147, 108, 20, 203, 238, 180, 16, 24, 240, 143, 68, 27, 52, 45, 43, 128, 66, 151, 136, 32, 91, 128, 203, 222, 161, 43, 194, 205, 4, 0, 35, 165, 108, 175, 110, 61, 76, 128, 168, 7, 138, 99, 91, 81, 140, 224, 162, 226, 119, 212, 90, 67, 152, 114, 102, 199, 233}, { 237, 78, 245, 94, 44, 164, 74, 55, 168, 198, 33, 158, 17, 144, 99, 133, 195, 140, 52, 60, 70, 27, 154, 31, 17, 248, 88, 88, 50, 18, 216, 156, 74, 107, 249, 27, 17, 31, 76, 112, 245, 120, 182, 112, 149, 103, 152, 246, 53, 52, 184, 66, 202, 123, 162, 132, 170, 101, 246, 252, 247, 46, 35, 63, 105, 145, 80}, { 70, 179, 217, 6, 33, 133, 59, 221, 207, 74, 20, 96, 236, 229, 207, 13, 181, 204, 13, 16, 99, 161, 20, 220, 58, 91, 139, 20, 41, 173, 252, 241, 174, 204, 8, 65, 5, 150, 26, 80, 11, 80, 194, 116, 73, 159, 24, 110, 127, 31, 68, 179, 32, 241, 149, 131, 95, 167, 224, 76, 83, 105, 164, 21, 150, 92, 122}, { 135, 84, 179, 75, 132, 220, 255, 213, 80, 243, 211, 182, 233, 237, 51, 165, 248, 247, 45, 48, 92, 72, 243, 227, 125, 106, 89, 205, 35, 12, 149, 190, 113, 205, 9, 242, 170, 101, 91, 236, 46, 71, 238, 128, 74, 69, 114, 42, 143, 116, 196, 58, 156, 80, 152, 235, 232, 197, 199, 115, 80, 54, 182, 203, 109, 120, 148}, { 221, 0, 243, 217, 242, 48, 225, 83, 77, 242, 14, 144, 14, 61, 0, 124, 169, 176, 6, 22, 76, 9, 65, 93, 83, 49, 196, 228, 248, 5, 226, 125, 195, 39, 128, 28, 120, 190, 254, 171, 158, 3, 180, 111, 88, 174, 199, 62, 224, 223, 70, 31, 251, 225, 97, 184, 130, 66, 213, 218, 7, 72, 15, 12, 201, 182, 228}, { 41, 75, 36, 30, 220, 131, 188, 57, 61, 121, 175, 193, 8, 59, 9, 158, 83, 211, 254, 150, 28, 122, 112, 175, 190, 58, 171, 69, 15, 157, 89, 24, 214, 32, 120, 103, 84, 88, 110, 50, 133, 177, 166, 152, 62, 105, 237, 129, 26, 94, 147, 101, 120, 92, 172, 247, 254, 223, 140, 48, 114, 122, 3, 138, 193, 22, 85}, { 187, 90, 169, 205, 146, 146, 85, 253, 211, 82, 78, 156, 55, 108, 187, 171, 232, 128, 124, 102, 218, 224, 141, 130, 101, 118, 68, 0, 123, 161, 39, 226, 18, 195, 54, 207, 142, 235, 128, 46, 0, 234, 71, 91, 204, 216, 190, 141, 173, 36, 164, 98, 53, 248, 140, 102, 100, 69, 32, 80, 117, 10, 192, 176, 59, 220, 57}, { 164, 103, 76, 90, 230, 126, 144, 40, 15, 208, 188, 69, 253, 170, 12, 197, 50, 32, 61, 158, 26, 247, 118, 20, 144, 153, 119, 238, 193, 249, 152, 102, 170, 75, 129, 216, 189, 183, 118, 205, 202, 242, 188, 180, 127, 6, 211, 222, 244, 182, 1, 193, 237, 193, 182, 158, 208, 182, 70, 37, 140, 10, 163, 243, 183, 34, 112}, { 173, 123, 233, 0, 158, 76, 1, 52, 51, 120, 229, 26, 134, 34, 248, 154, 27, 193, 16, 244, 119, 25, 238, 227, 225, 241, 94, 194, 213, 42, 195, 111, 216, 102, 56, 193, 35, 109, 184, 177, 30, 200, 180, 50, 11, 172, 60, 163, 76, 208, 49, 181, 91, 27, 189, 139, 226, 116, 151, 160, 62, 148, 134, 180, 208, 46, 75}, { 14, 109, 212, 190, 202, 169, 244, 38, 248, 21, 221, 195, 38, 175, 241, 105, 45, 37, 25, 180, 25, 133, 186, 6, 123, 153, 227, 39, 10, 118, 215, 128, 208, 60, 206, 194, 150, 188, 212, 77, 111, 147, 89, 184, 120, 35, 238, 133, 15, 200, 222, 197, 196, 205, 118, 228, 82, 233, 166, 110, 58, 67, 116, 236, 56, 213, 6}, { 205, 235, 54, 18, 244, 215, 136, 92, 149, 238, 32, 232, 235, 147, 225, 87, 214, 80, 31, 87, 209, 8, 239, 120, 42, 137, 144, 116, 204, 223, 63, 234, 88, 113, 126, 114, 48, 118, 175, 230, 107, 209, 123, 233, 214, 128, 244, 144, 71, 9, 80, 52, 241, 206, 129, 43, 150, 110, 173, 8, 237, 113, 169, 200, 3, 123, 106}, { 171, 10, 192, 23, 90, 220, 168, 47, 212, 105, 31, 187, 182, 153, 62, 241, 51, 13, 60, 106, 92, 230, 127, 198, 99, 89, 252, 206, 107, 254, 227, 116, 208, 32, 164, 171, 85, 85, 108, 20, 63, 18, 80, 183, 144, 37, 16, 181, 86, 58, 142, 29, 73, 195, 194, 174, 3, 29, 112, 120, 118, 67, 145, 239, 29, 202, 80}, { 87, 180, 8, 203, 144, 123, 52, 40, 2, 38, 204, 34, 23, 248, 116, 148, 229, 132, 32, 83, 85, 63, 146, 135, 9, 32, 75, 155, 60, 4, 213, 2, 133, 105, 25, 20, 239, 9, 33, 14, 30, 68, 217, 17, 114, 12, 48, 247, 3, 231, 169, 119, 235, 85, 232, 138, 211, 30, 242, 219, 171, 5, 70, 157, 86, 50, 159}, { 128, 250, 48, 120, 59, 174, 221, 37, 236, 97, 135, 208, 101, 130, 176, 24, 223, 0, 38, 255, 189, 149, 250, 103, 117, 169, 136, 134, 12, 173, 255, 30, 99, 95, 203, 174, 46, 147, 155, 198, 219, 160, 160, 175, 23, 81, 86, 149, 166, 77, 96, 119, 106, 32, 104, 61, 143, 6, 127, 71, 219, 171, 147, 127, 198, 97, 68}, { 15, 142, 9, 76, 187, 229, 218, 42, 133, 118, 208, 69, 238, 48, 138, 181, 107, 255, 123, 123, 211, 211, 10, 185, 44, 194, 188, 148, 52, 129, 161, 185, 218, 12, 147, 201, 128, 55, 193, 172, 181, 69, 208, 154, 203, 255, 100, 197, 75, 220, 215, 209, 57, 137, 61, 21, 159, 122, 19, 158, 30, 29, 142, 18, 232, 255, 191}, { 165, 8, 217, 222, 169, 213, 214, 164, 165, 13, 68, 234, 10, 34, 10, 124, 171, 10, 96, 27, 40, 243, 31, 103, 16, 153, 249, 130, 211, 99, 153, 29, 240, 25, 166, 121, 190, 94, 57, 4, 72, 197, 148, 117, 87, 145, 234, 221, 222, 253, 123, 13, 110, 249, 192, 174, 83, 94, 28, 61, 207, 122, 4, 140, 187, 242, 220}, { 93, 165, 24, 134, 43, 95, 18, 65, 54, 158, 168, 183, 66, 25, 187, 125, 150, 247, 71, 232, 126, 202, 91, 182, 91, 174, 93, 12, 215, 83, 57, 250, 152, 236, 238, 19, 227, 118, 125, 200, 23, 129, 83, 12, 226, 233, 195, 165, 84, 28, 57, 164, 236, 99, 19, 66, 39, 58, 227, 106, 8, 122, 213, 48, 118, 23, 215}, { 198, 180, 176, 19, 244, 151, 74, 182, 84, 157, 233, 13, 109, 249, 70, 25, 58, 58, 78, 73, 225, 158, 199, 197, 139, 233, 12, 199, 172, 76, 14, 202, 172, 194, 24, 187, 51, 7, 154, 200, 201, 64, 128, 124, 2, 40, 18, 23, 109, 96, 15, 29, 23, 98, 80, 194, 183, 11, 212, 64, 72, 176, 167, 241, 231, 225, 106}, { 74, 170, 188, 144, 168, 119, 123, 47, 89, 66, 19, 25, 254, 247, 50, 110, 113, 161, 180, 187, 24, 204, 218, 151, 3, 159, 19, 207, 166, 234, 93, 13, 84, 26, 250, 184, 252, 240, 13, 223, 8, 171, 5, 128, 151, 160, 151, 163, 119, 190, 122, 239, 73, 170, 176, 202, 40, 181, 192, 230, 37, 90, 43, 31, 156, 152, 57}, { 12, 168, 43, 110, 83, 174, 56, 203, 77, 166, 152, 23, 98, 201, 39, 30, 249, 25, 118, 5, 116, 70, 0, 67, 73, 159, 110, 209, 58, 173, 213, 244, 140, 166, 25, 213, 243, 38, 221, 171, 144, 92, 252, 170, 154, 164, 22, 202, 84, 148, 252, 160, 223, 229, 43, 233, 247, 117, 63, 90, 29, 240, 39, 58, 235, 169, 82}, { 107, 129, 211, 55, 12, 117, 95, 23, 141, 142, 70, 164, 125, 67, 191, 236, 78, 163, 47, 10, 143, 103, 182, 232, 204, 198, 241, 55, 40, 111, 57, 235, 237, 91, 189, 29, 32, 206, 163, 76, 180, 105, 132, 90, 216, 33, 147, 148, 123, 122, 40, 170, 96, 33, 49, 110, 225, 55, 179, 110, 73, 135, 227, 61, 45, 114, 64}, { 238, 85, 181, 166, 228, 242, 65, 165, 182, 184, 137, 23, 128, 237, 94, 173, 250, 152, 130, 15, 185, 254, 186, 248, 0, 144, 38, 51, 101, 252, 203, 32, 238, 225, 139, 190, 104, 242, 202, 234, 96, 200, 76, 188, 70, 61, 37, 157, 7, 52, 210, 46, 169, 129, 250, 229, 61, 93, 76, 142, 251, 74, 201, 230, 106, 161, 102}, { 242, 122, 165, 22, 55, 183, 178, 77, 60, 221, 106, 166, 254, 78, 154, 8, 188, 74, 133, 180, 195, 53, 97, 118, 124, 129, 17, 192, 186, 44, 190, 83, 204, 187, 50, 54, 86, 109, 182, 201, 133, 166, 49, 221, 7, 240, 108, 216, 244, 71, 178, 222, 200, 75, 221, 161, 126, 30, 46, 18, 87, 248, 26, 159, 252, 170, 200}, { 175, 108, 201, 92, 215, 184, 85, 4, 36, 71, 82, 6, 152, 86, 223, 82, 194, 33, 160, 237, 248, 10, 234, 234, 203, 126, 193, 153, 159, 208, 143, 46, 219, 119, 153, 213, 196, 100, 133, 93, 248, 114, 47, 159, 147, 87, 48, 82, 27, 221, 74, 85, 159, 34, 110, 249, 16, 87, 76, 91, 33, 62, 175, 159, 64, 102, 0}, { 36, 187, 214, 138, 109, 181, 133, 169, 159, 84, 55, 158, 20, 166, 45, 68, 59, 249, 3, 108, 238, 70, 59, 40, 55, 99, 132, 244, 44, 79, 28, 235, 141, 246, 12, 188, 210, 48, 27, 33, 249, 120, 144, 212, 189, 190, 125, 88, 251, 220, 233, 26, 126, 176, 232, 178, 88, 212, 219, 253, 19, 200, 191, 55, 227, 26, 80}, { 229, 81, 15, 128, 201, 58, 205, 201, 92, 22, 242, 182, 99, 226, 174, 150, 45, 197, 66, 229, 183, 85, 72, 26, 58, 128, 191, 188, 27, 193, 10, 71, 38, 159, 5, 161, 233, 44, 42, 219, 101, 251, 72, 20, 206, 88, 252, 181, 82, 23, 131, 159, 140, 239, 188, 231, 2, 79, 21, 221, 33, 155, 2, 128, 203, 114, 119}, { 15, 110, 244, 12, 154, 52, 30, 44, 40, 87, 182, 209, 105, 156, 96, 243, 135, 110, 93, 120, 159, 163, 68, 55, 166, 251, 129, 210, 38, 113, 105, 5, 14, 107, 53, 20, 245, 31, 114, 97, 71, 6, 18, 119, 74, 165, 114, 101, 41, 213, 76, 248, 149, 228, 172, 124, 228, 203, 198, 162, 51, 83, 176, 0, 40, 23, 78}, { 29, 67, 224, 174, 57, 50, 164, 141, 2, 49, 179, 4, 150, 38, 244, 97, 59, 167, 144, 127, 49, 175, 114, 81, 134, 112, 78, 179, 148, 109, 192, 15, 83, 131, 198, 64, 43, 122, 116, 18, 104, 172, 134, 87, 211, 247, 118, 192, 196, 200, 115, 34, 17, 73, 4, 30, 79, 170, 174, 32, 222, 104, 121, 24, 112, 111, 165}, { 83, 137, 158, 138, 35, 179, 166, 226, 86, 70, 96, 35, 183, 122, 100, 58, 84, 109, 54, 195, 19, 245, 185, 57, 201, 175, 196, 104, 40, 45, 189, 157, 93, 33, 123, 19, 31, 94, 195, 136, 130, 49, 198, 71, 89, 190, 217, 97, 48, 102, 132, 112, 135, 145, 198, 231, 56, 237, 155, 139, 1, 158, 169, 134, 66, 30, 96}, { 102, 160, 157, 172, 248, 198, 81, 71, 106, 31, 73, 222, 53, 236, 252, 81, 9, 161, 14, 156, 168, 171, 123, 19, 163, 168, 224, 228, 153, 18, 230, 139, 148, 224, 205, 59, 50, 171, 186, 23, 144, 0, 238, 111, 202, 182, 202, 97, 128, 24, 237, 221, 59, 209, 92, 213, 72, 41, 97, 121, 23, 1, 177, 38, 105, 89, 69}, { 126, 91, 220, 228, 0, 135, 56, 44, 237, 14, 239, 6, 132, 166, 145, 33, 7, 59, 106, 137, 223, 154, 19, 22, 70, 181, 185, 184, 45, 241, 152, 48, 91, 132, 47, 156, 97, 26, 147, 220, 112, 149, 52, 122, 245, 250, 154, 168, 26, 199, 177, 206, 112, 16, 170, 233, 74, 177, 154, 84, 23, 155, 224, 50, 89, 246, 224}, { 160, 188, 2, 128, 154, 155, 187, 161, 31, 50, 76, 229, 80, 175, 68, 64, 69, 193, 1, 5, 185, 255, 20, 207, 11, 59, 127, 219, 45, 32, 37, 189, 200, 144, 30, 142, 135, 235, 123, 39, 126, 185, 49, 226, 179, 210, 158, 146, 231, 138, 20, 33, 247, 130, 195, 19, 93, 248, 253, 80, 150, 175, 189, 251, 18, 219, 241}, { 244, 137, 210, 209, 237, 38, 46, 195, 42, 19, 155, 25, 217, 113, 237, 187, 152, 64, 191, 238, 145, 115, 37, 131, 31, 71, 165, 180, 57, 210, 99, 50, 137, 67, 95, 81, 4, 27, 172, 165, 0, 190, 90, 28, 139, 58, 85, 211, 124, 184, 14, 138, 13, 221, 255, 143, 108, 63, 86, 50, 146, 131, 127, 112, 111, 156, 151}, { 109, 150, 82, 22, 74, 60, 161, 18, 215, 48, 174, 21, 68, 136, 92, 255, 183, 166, 177, 242, 246, 150, 120, 162, 68, 216, 153, 17, 128, 3, 181, 84, 7, 231, 94, 124, 73, 114, 33, 46, 158, 83, 252, 67, 39, 84, 134, 92, 46, 28, 106, 37, 178, 244, 226, 107, 187, 118, 192, 228, 122, 39, 80, 111, 210, 13, 168}, { 133, 74, 210, 213, 47, 117, 198, 134, 89, 156, 9, 69, 36, 203, 111, 80, 234, 218, 41, 195, 182, 89, 162, 49, 241, 49, 29, 12, 233, 148, 23, 120, 68, 98, 78, 197, 174, 162, 229, 185, 105, 195, 210, 230, 187, 230, 50, 12, 133, 115, 151, 56, 147, 163, 88, 180, 140, 141, 153, 26, 85, 121, 55, 147, 16, 194, 15}, { 95, 25, 252, 45, 132, 144, 75, 19, 81, 24, 251, 78, 217, 243, 27, 48, 188, 232, 231, 62, 140, 127, 160, 219, 138, 236, 180, 3, 192, 64, 164, 100, 154, 102, 137, 53, 18, 124, 219, 28, 215, 116, 62, 112, 162, 100, 98, 48, 52, 100, 222, 242, 248, 204, 66, 77, 215, 30, 131, 56, 30, 126, 118, 162, 219, 24, 44}, { 53, 201, 49, 127, 57, 150, 81, 164, 74, 66, 94, 103, 163, 78, 172, 51, 115, 215, 133, 60, 245, 114, 119, 7, 33, 247, 179, 163, 218, 252, 34, 212, 36, 170, 155, 86, 254, 146, 206, 188, 28, 146, 38, 78, 235, 137, 193, 90, 90, 78, 194, 246, 34, 170, 202, 30, 100, 97, 110, 91, 225, 94, 33, 31, 67, 69, 67}, { 200, 183, 171, 78, 64, 175, 164, 176, 249, 2, 133, 205, 66, 245, 225, 206, 194, 12, 245, 192, 199, 81, 119, 255, 175, 180, 12, 27, 129, 58, 170, 175, 63, 117, 201, 152, 242, 172, 113, 61, 178, 59, 208, 145, 20, 29, 185, 120, 107, 37, 203, 16, 6, 251, 122, 71, 37, 222, 188, 168, 135, 215, 47, 101, 228, 123, 246}, { 28, 252, 102, 32, 206, 82, 84, 134, 82, 51, 184, 153, 6, 201, 152, 17, 57, 56, 243, 156, 227, 218, 235, 227, 129, 136, 134, 74, 227, 30, 140, 186, 231, 130, 95, 54, 61, 60, 90, 238, 91, 54, 31, 148, 57, 61, 213, 0, 195, 235, 218, 16, 65, 132, 76, 13, 39, 204, 115, 24, 222, 146, 149, 172, 35, 178, 3}, { 252, 233, 248, 208, 155, 17, 217, 248, 62, 225, 228, 8, 46, 78, 14, 230, 230, 208, 21, 172, 6, 225, 60, 235, 212, 88, 208, 185, 206, 66, 26, 105, 128, 12, 35, 178, 137, 9, 39, 33, 223, 119, 0, 198, 225, 146, 15, 231, 42, 253, 244, 60, 22, 232, 114, 118, 90, 197, 114, 180, 116, 4, 91, 93, 226, 160, 210}, { 255, 160, 255, 137, 152, 61, 128, 89, 169, 254, 147, 221, 6, 214, 36, 183, 221, 23, 38, 205, 171, 178, 50, 239, 128, 113, 42, 91, 153, 56, 61, 105, 239, 145, 72, 185, 88, 119, 63, 19, 197, 115, 173, 100, 152, 143, 55, 100, 145, 71, 217, 120, 207, 100, 71, 229, 17, 237, 33, 142, 189, 63, 98, 32, 244, 139, 180}, { 1, 148, 200, 24, 207, 221, 75, 47, 79, 200, 201, 249, 249, 130, 153, 116, 156, 203, 252, 140, 223, 39, 83, 220, 13, 117, 4, 104, 98, 143, 88, 170, 76, 243, 252, 226, 117, 101, 193, 36, 25, 38, 43, 69, 168, 164, 27, 186, 104, 11, 33, 27, 30, 246, 59, 28, 180, 84, 118, 119, 161, 174, 62, 91, 178, 253, 173}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("go.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 67, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 67, a ustawiła na %d", arr->width);
                    test_error(arr->height == 100, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 100, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 100; ++i)
                        for (int j = 0; j < 67; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 100; ++i)
                        for (int j = 0; j < 67; ++j)
                            test_error(arr_flip_horizontal->ptr[i][j] == array_flip_horizontal[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_horizontal[i][j], arr_flip_horizontal->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_horizontal);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 76: Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 438 bajtów)
//
void UTEST76(void)
{
    // informacje o teście
    test_start(76, "Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 438 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(438);
    
    //
    // -----------
    //
    

                int array[4][10] = {{ 168, 98, 231, 229, 224, 0, 219, 222, 48, 95}, { 16, 24, 182, 50, 48, 190, 223, 83, 69, 20}, { 167, 136, 99, 43, 123, 16, 131, 123, 211, 77}, { 44, 191, 63, 183, 157, 155, 109, 8, 241, 245}};
                int array_flip_horizontal[4][10] = {{ 44, 191, 63, 183, 157, 155, 109, 8, 241, 245}, { 167, 136, 99, 43, 123, 16, 131, 123, 211, 77}, { 16, 24, 182, 50, 48, 190, 223, 83, 69, 20}, { 168, 98, 231, 229, 224, 0, 219, 222, 48, 95}};

                int err_code = 0;

                printf("#####START#####");                            
                struct image_t *arr = load_image_t("about.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                test_error(arr->height == 4, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 4, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                    for (int j = 0; j < 10; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                printf("#####START#####");                            
                struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                printf("#####END#####");

                for (int i = 0; i < 4; ++i)
                    for (int j = 0; j < 10; ++j)
                        test_error(arr_flip_horizontal->ptr[i][j] == array_flip_horizontal[i][j], "Funkcja image_flip_horizontal() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_horizontal[i][j], arr_flip_horizontal->ptr[i][j]);


                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                printf("#####START#####");
                destroy_image(&arr_flip_horizontal);
                printf("#####END#####");

                test_error(arr_flip_horizontal == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 77: Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 219 bajtów)
//
void UTEST77(void)
{
    // informacje o teście
    test_start(77, "Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 219 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(219);
    
    //
    // -----------
    //
    

                    int array[4][10] = {{ 168, 98, 231, 229, 224, 0, 219, 222, 48, 95}, { 16, 24, 182, 50, 48, 190, 223, 83, 69, 20}, { 167, 136, 99, 43, 123, 16, 131, 123, 211, 77}, { 44, 191, 63, 183, 157, 155, 109, 8, 241, 245}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("about.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 4, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 4, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 4; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 78: Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 243 bajtów)
//
void UTEST78(void)
{
    // informacje o teście
    test_start(78, "Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 243 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(243);
    
    //
    // -----------
    //
    

                    int array[4][10] = {{ 168, 98, 231, 229, 224, 0, 219, 222, 48, 95}, { 16, 24, 182, 50, 48, 190, 223, 83, 69, 20}, { 167, 136, 99, 43, 123, 16, 131, 123, 211, 77}, { 44, 191, 63, 183, 157, 155, 109, 8, 241, 245}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("about.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 4, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 4, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 4; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 79: Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 275 bajtów)
//
void UTEST79(void)
{
    // informacje o teście
    test_start(79, "Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 275 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(275);
    
    //
    // -----------
    //
    

                    int array[4][10] = {{ 168, 98, 231, 229, 224, 0, 219, 222, 48, 95}, { 16, 24, 182, 50, 48, 190, 223, 83, 69, 20}, { 167, 136, 99, 43, 123, 16, 131, 123, 211, 77}, { 44, 191, 63, 183, 157, 155, 109, 8, 241, 245}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("about.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 4, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 4, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 4; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 80: Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 315 bajtów)
//
void UTEST80(void)
{
    // informacje o teście
    test_start(80, "Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 315 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(315);
    
    //
    // -----------
    //
    

                    int array[4][10] = {{ 168, 98, 231, 229, 224, 0, 219, 222, 48, 95}, { 16, 24, 182, 50, 48, 190, 223, 83, 69, 20}, { 167, 136, 99, 43, 123, 16, 131, 123, 211, 77}, { 44, 191, 63, 183, 157, 155, 109, 8, 241, 245}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("about.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 4, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 4, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 4; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 81: Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 355 bajtów)
//
void UTEST81(void)
{
    // informacje o teście
    test_start(81, "Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 355 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(355);
    
    //
    // -----------
    //
    

                    int array[4][10] = {{ 168, 98, 231, 229, 224, 0, 219, 222, 48, 95}, { 16, 24, 182, 50, 48, 190, 223, 83, 69, 20}, { 167, 136, 99, 43, 123, 16, 131, 123, 211, 77}, { 44, 191, 63, 183, 157, 155, 109, 8, 241, 245}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("about.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 4, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 4, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 4; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 82: Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 395 bajtów)
//
void UTEST82(void)
{
    // informacje o teście
    test_start(82, "Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 395 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(395);
    
    //
    // -----------
    //
    

                    int array[4][10] = {{ 168, 98, 231, 229, 224, 0, 219, 222, 48, 95}, { 16, 24, 182, 50, 48, 190, 223, 83, 69, 20}, { 167, 136, 99, 43, 123, 16, 131, 123, 211, 77}, { 44, 191, 63, 183, 157, 155, 109, 8, 241, 245}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("about.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 4, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 4, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 4; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 83: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST83(void)
{
    // informacje o teście
    test_start(83, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");                            
                struct image_t *arr_flip_horizontal = image_flip_horizontal(NULL);
                printf("#####END#####");

                test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 84: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST84(void)
{
    // informacje o teście
    test_start(84, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][10] = {{ 4, 188, 170, 145, 98, 4, 159, 214, 132, 104}, { 233, 246, 65, 148, 58, 202, 121, 26, 77, 84}, { 225, 185, 202, 203, 204, 74, 214, 3, 130, 137}, { 208, 47, 58, 193, 52, 49, 62, 45, 25, 192}, { 93, 4, 34, 59, 146, 250, 122, 188, 15, 60}, { 156, 217, 212, 246, 227, 214, 40, 24, 95, 106}, { 142, 64, 26, 5, 35, 115, 191, 232, 26, 199}, { 3, 28, 87, 51, 48, 151, 36, 20, 154, 85}, { 138, 161, 96, 47, 130, 236, 101, 208, 213, 180}, { 40, 87, 86, 98, 35, 61, 39, 76, 52, 24}, { 81, 12, 224, 130, 195, 49, 123, 3, 50, 68}, { 147, 176, 117, 1, 187, 119, 14, 30, 252, 119}, { 13, 231, 46, 171, 167, 178, 72, 54, 87, 170}, { 192, 68, 146, 214, 71, 140, 28, 7, 179, 23}, { 191, 198, 84, 23, 49, 66, 240, 84, 34, 30}, { 210, 225, 62, 238, 22, 95, 184, 125, 84, 241}, { 2, 195, 199, 69, 196, 148, 119, 67, 237, 248}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("pull.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 10;
                    arr->height = -17;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 10;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 85: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST85(void)
{
    // informacje o teście
    test_start(85, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][10] = {{ 4, 188, 170, 145, 98, 4, 159, 214, 132, 104}, { 233, 246, 65, 148, 58, 202, 121, 26, 77, 84}, { 225, 185, 202, 203, 204, 74, 214, 3, 130, 137}, { 208, 47, 58, 193, 52, 49, 62, 45, 25, 192}, { 93, 4, 34, 59, 146, 250, 122, 188, 15, 60}, { 156, 217, 212, 246, 227, 214, 40, 24, 95, 106}, { 142, 64, 26, 5, 35, 115, 191, 232, 26, 199}, { 3, 28, 87, 51, 48, 151, 36, 20, 154, 85}, { 138, 161, 96, 47, 130, 236, 101, 208, 213, 180}, { 40, 87, 86, 98, 35, 61, 39, 76, 52, 24}, { 81, 12, 224, 130, 195, 49, 123, 3, 50, 68}, { 147, 176, 117, 1, 187, 119, 14, 30, 252, 119}, { 13, 231, 46, 171, 167, 178, 72, 54, 87, 170}, { 192, 68, 146, 214, 71, 140, 28, 7, 179, 23}, { 191, 198, 84, 23, 49, 66, 240, 84, 34, 30}, { 210, 225, 62, 238, 22, 95, 184, 125, 84, 241}, { 2, 195, 199, 69, 196, 148, 119, 67, 237, 248}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("pull.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -10;
                    arr->height = -17;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 10;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 86: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST86(void)
{
    // informacje o teście
    test_start(86, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][10] = {{ 4, 188, 170, 145, 98, 4, 159, 214, 132, 104}, { 233, 246, 65, 148, 58, 202, 121, 26, 77, 84}, { 225, 185, 202, 203, 204, 74, 214, 3, 130, 137}, { 208, 47, 58, 193, 52, 49, 62, 45, 25, 192}, { 93, 4, 34, 59, 146, 250, 122, 188, 15, 60}, { 156, 217, 212, 246, 227, 214, 40, 24, 95, 106}, { 142, 64, 26, 5, 35, 115, 191, 232, 26, 199}, { 3, 28, 87, 51, 48, 151, 36, 20, 154, 85}, { 138, 161, 96, 47, 130, 236, 101, 208, 213, 180}, { 40, 87, 86, 98, 35, 61, 39, 76, 52, 24}, { 81, 12, 224, 130, 195, 49, 123, 3, 50, 68}, { 147, 176, 117, 1, 187, 119, 14, 30, 252, 119}, { 13, 231, 46, 171, 167, 178, 72, 54, 87, 170}, { 192, 68, 146, 214, 71, 140, 28, 7, 179, 23}, { 191, 198, 84, 23, 49, 66, 240, 84, 34, 30}, { 210, 225, 62, 238, 22, 95, 184, 125, 84, 241}, { 2, 195, 199, 69, 196, 148, 119, 67, 237, 248}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("pull.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -10;
                    arr->height = 17;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 10;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 87: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST87(void)
{
    // informacje o teście
    test_start(87, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][10] = {{ 4, 188, 170, 145, 98, 4, 159, 214, 132, 104}, { 233, 246, 65, 148, 58, 202, 121, 26, 77, 84}, { 225, 185, 202, 203, 204, 74, 214, 3, 130, 137}, { 208, 47, 58, 193, 52, 49, 62, 45, 25, 192}, { 93, 4, 34, 59, 146, 250, 122, 188, 15, 60}, { 156, 217, 212, 246, 227, 214, 40, 24, 95, 106}, { 142, 64, 26, 5, 35, 115, 191, 232, 26, 199}, { 3, 28, 87, 51, 48, 151, 36, 20, 154, 85}, { 138, 161, 96, 47, 130, 236, 101, 208, 213, 180}, { 40, 87, 86, 98, 35, 61, 39, 76, 52, 24}, { 81, 12, 224, 130, 195, 49, 123, 3, 50, 68}, { 147, 176, 117, 1, 187, 119, 14, 30, 252, 119}, { 13, 231, 46, 171, 167, 178, 72, 54, 87, 170}, { 192, 68, 146, 214, 71, 140, 28, 7, 179, 23}, { 191, 198, 84, 23, 49, 66, 240, 84, 34, 30}, { 210, 225, 62, 238, 22, 95, 184, 125, 84, 241}, { 2, 195, 199, 69, 196, 148, 119, 67, 237, 248}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("pull.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 10;
                    arr->height = 0;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 10;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 88: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST88(void)
{
    // informacje o teście
    test_start(88, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][10] = {{ 4, 188, 170, 145, 98, 4, 159, 214, 132, 104}, { 233, 246, 65, 148, 58, 202, 121, 26, 77, 84}, { 225, 185, 202, 203, 204, 74, 214, 3, 130, 137}, { 208, 47, 58, 193, 52, 49, 62, 45, 25, 192}, { 93, 4, 34, 59, 146, 250, 122, 188, 15, 60}, { 156, 217, 212, 246, 227, 214, 40, 24, 95, 106}, { 142, 64, 26, 5, 35, 115, 191, 232, 26, 199}, { 3, 28, 87, 51, 48, 151, 36, 20, 154, 85}, { 138, 161, 96, 47, 130, 236, 101, 208, 213, 180}, { 40, 87, 86, 98, 35, 61, 39, 76, 52, 24}, { 81, 12, 224, 130, 195, 49, 123, 3, 50, 68}, { 147, 176, 117, 1, 187, 119, 14, 30, 252, 119}, { 13, 231, 46, 171, 167, 178, 72, 54, 87, 170}, { 192, 68, 146, 214, 71, 140, 28, 7, 179, 23}, { 191, 198, 84, 23, 49, 66, 240, 84, 34, 30}, { 210, 225, 62, 238, 22, 95, 184, 125, 84, 241}, { 2, 195, 199, 69, 196, 148, 119, 67, 237, 248}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("pull.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 17;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 10;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 89: Sprawdzanie poprawności działania funkcji image_flip_horizontal
//
void UTEST89(void)
{
    // informacje o teście
    test_start(89, "Sprawdzanie poprawności działania funkcji image_flip_horizontal", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][10] = {{ 4, 188, 170, 145, 98, 4, 159, 214, 132, 104}, { 233, 246, 65, 148, 58, 202, 121, 26, 77, 84}, { 225, 185, 202, 203, 204, 74, 214, 3, 130, 137}, { 208, 47, 58, 193, 52, 49, 62, 45, 25, 192}, { 93, 4, 34, 59, 146, 250, 122, 188, 15, 60}, { 156, 217, 212, 246, 227, 214, 40, 24, 95, 106}, { 142, 64, 26, 5, 35, 115, 191, 232, 26, 199}, { 3, 28, 87, 51, 48, 151, 36, 20, 154, 85}, { 138, 161, 96, 47, 130, 236, 101, 208, 213, 180}, { 40, 87, 86, 98, 35, 61, 39, 76, 52, 24}, { 81, 12, 224, 130, 195, 49, 123, 3, 50, 68}, { 147, 176, 117, 1, 187, 119, 14, 30, 252, 119}, { 13, 231, 46, 171, 167, 178, 72, 54, 87, 170}, { 192, 68, 146, 214, 71, 140, 28, 7, 179, 23}, { 191, 198, 84, 23, 49, 66, 240, 84, 34, 30}, { 210, 225, 62, 238, 22, 95, 184, 125, 84, 241}, { 2, 195, 199, 69, 196, 148, 119, 67, 237, 248}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("pull.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_horizontal = image_flip_horizontal(arr);
                    printf("#####END#####");

                    test_error(arr_flip_horizontal == NULL, "Funkcja image_flip_horizontal() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 10;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 90: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST90(void)
{
    // informacje o teście
    test_start(90, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[5][6] = {{ 243, 54, 13, 21, 129, 29}, { 50, 173, 240, 24, 185, 17}, { 191, 123, 38, 182, 84, 172}, { 35, 89, 105, 47, 24, 231}, { 171, 118, 192, 152, 74, 25}};
                    int array_flip_vertical[5][6] = {{ 29, 129, 21, 13, 54, 243}, { 17, 185, 24, 240, 173, 50}, { 172, 84, 182, 38, 123, 191}, { 231, 24, 47, 105, 89, 35}, { 25, 74, 152, 192, 118, 171}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("brother.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 5, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 5, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 5; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 5; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr_flip_vertical->ptr[i][j] == array_flip_vertical[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_vertical[i][j], arr_flip_vertical->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_vertical);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 91: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST91(void)
{
    // informacje o teście
    test_start(91, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][9] = {{ 190, 233, 121, 241, 240, 18, 18, 254, 73}, { 90, 91, 77, 116, 96, 236, 144, 144, 222}, { 79, 126, 149, 201, 171, 4, 51, 41, 17}, { 185, 142, 220, 232, 57, 15, 150, 32, 164}, { 115, 140, 239, 0, 115, 133, 113, 139, 222}, { 24, 13, 136, 38, 165, 167, 206, 13, 66}, { 239, 237, 109, 139, 174, 83, 145, 165, 110}, { 181, 220, 185, 134, 45, 72, 153, 249, 193}, { 18, 239, 220, 251, 186, 181, 117, 145, 120}, { 115, 110, 63, 255, 190, 218, 162, 141, 40}, { 249, 97, 87, 172, 89, 233, 186, 217, 107}, { 35, 236, 208, 103, 122, 209, 255, 23, 187}, { 190, 244, 93, 225, 113, 206, 206, 56, 38}, { 189, 231, 27, 218, 116, 254, 170, 191, 97}, { 174, 195, 89, 233, 101, 66, 166, 138, 192}, { 68, 196, 201, 153, 69, 253, 124, 29, 195}, { 165, 162, 116, 123, 186, 56, 74, 161, 246}, { 113, 177, 3, 230, 86, 215, 68, 73, 27}, { 51, 113, 66, 64, 25, 211, 174, 133, 176}};
                    int array_flip_vertical[19][9] = {{ 73, 254, 18, 18, 240, 241, 121, 233, 190}, { 222, 144, 144, 236, 96, 116, 77, 91, 90}, { 17, 41, 51, 4, 171, 201, 149, 126, 79}, { 164, 32, 150, 15, 57, 232, 220, 142, 185}, { 222, 139, 113, 133, 115, 0, 239, 140, 115}, { 66, 13, 206, 167, 165, 38, 136, 13, 24}, { 110, 165, 145, 83, 174, 139, 109, 237, 239}, { 193, 249, 153, 72, 45, 134, 185, 220, 181}, { 120, 145, 117, 181, 186, 251, 220, 239, 18}, { 40, 141, 162, 218, 190, 255, 63, 110, 115}, { 107, 217, 186, 233, 89, 172, 87, 97, 249}, { 187, 23, 255, 209, 122, 103, 208, 236, 35}, { 38, 56, 206, 206, 113, 225, 93, 244, 190}, { 97, 191, 170, 254, 116, 218, 27, 231, 189}, { 192, 138, 166, 66, 101, 233, 89, 195, 174}, { 195, 29, 124, 253, 69, 153, 201, 196, 68}, { 246, 161, 74, 56, 186, 123, 116, 162, 165}, { 27, 73, 68, 215, 86, 230, 3, 177, 113}, { 176, 133, 174, 211, 25, 64, 66, 113, 51}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("table.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr_flip_vertical->ptr[i][j] == array_flip_vertical[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_vertical[i][j], arr_flip_vertical->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_vertical);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 92: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST92(void)
{
    // informacje o teście
    test_start(92, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][1] = {{ 182}, { 159}, { 36}, { 250}, { 84}, { 171}, { 56}, { 63}, { 21}, { 63}, { 83}, { 7}, { 11}, { 164}, { 89}, { 237}};
                    int array_flip_vertical[16][1] = {{ 182}, { 159}, { 36}, { 250}, { 84}, { 171}, { 56}, { 63}, { 21}, { 63}, { 83}, { 7}, { 11}, { 164}, { 89}, { 237}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("tone.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr_flip_vertical->ptr[i][j] == array_flip_vertical[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_vertical[i][j], arr_flip_vertical->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_vertical);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 93: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST93(void)
{
    // informacje o teście
    test_start(93, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][6] = {{ 194, 48, 231, 60, 193, 158}};
                    int array_flip_vertical[1][6] = {{ 158, 193, 60, 231, 48, 194}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("oxygen.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr_flip_vertical->ptr[i][j] == array_flip_vertical[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_vertical[i][j], arr_flip_vertical->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_vertical);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 94: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST94(void)
{
    // informacje o teście
    test_start(94, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 182}};
                    int array_flip_vertical[1][1] = {{ 182}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("don't.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr_flip_vertical->ptr[i][j] == array_flip_vertical[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_vertical[i][j], arr_flip_vertical->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_vertical);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 95: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST95(void)
{
    // informacje o teście
    test_start(95, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[82][72] = {{ 73, 217, 180, 252, 93, 141, 170, 148, 254, 203, 91, 212, 32, 226, 105, 93, 139, 123, 62, 96, 5, 235, 75, 76, 146, 247, 202, 163, 111, 16, 114, 111, 241, 157, 196, 84, 36, 60, 109, 246, 220, 27, 127, 242, 130, 217, 248, 129, 248, 109, 162, 121, 95, 110, 133, 55, 200, 133, 96, 69, 249, 88, 212, 22, 241, 214, 160, 115, 188, 148, 215, 158}, { 219, 86, 165, 32, 153, 169, 229, 121, 246, 143, 237, 233, 140, 10, 222, 26, 5, 73, 113, 43, 194, 70, 78, 8, 121, 77, 108, 147, 56, 62, 19, 243, 89, 169, 246, 179, 230, 5, 9, 105, 25, 15, 88, 237, 18, 215, 154, 201, 68, 198, 250, 90, 96, 248, 222, 96, 211, 34, 155, 99, 148, 143, 135, 157, 31, 14, 130, 195, 133, 178, 151, 76}, { 98, 211, 246, 202, 234, 198, 171, 112, 240, 19, 114, 133, 71, 153, 30, 141, 127, 191, 13, 6, 241, 122, 106, 178, 41, 97, 240, 59, 215, 201, 42, 132, 201, 46, 193, 6, 110, 198, 133, 245, 194, 184, 231, 73, 15, 105, 255, 77, 65, 50, 95, 93, 84, 31, 44, 1, 60, 60, 54, 154, 182, 250, 208, 203, 217, 164, 19, 29, 41, 145, 111, 182}, { 69, 239, 252, 19, 74, 8, 245, 36, 247, 158, 33, 121, 104, 141, 132, 185, 137, 205, 247, 228, 68, 207, 242, 2, 106, 179, 179, 184, 85, 115, 61, 173, 158, 120, 33, 32, 196, 9, 204, 160, 195, 113, 254, 20, 164, 47, 67, 164, 173, 182, 26, 124, 41, 215, 146, 145, 154, 114, 36, 152, 227, 239, 133, 115, 71, 31, 174, 243, 100, 52, 246, 189}, { 17, 34, 76, 243, 187, 38, 127, 219, 50, 235, 8, 249, 9, 239, 186, 83, 60, 115, 218, 201, 177, 166, 58, 171, 97, 40, 104, 37, 71, 133, 217, 121, 14, 33, 166, 231, 167, 63, 171, 140, 204, 190, 88, 13, 246, 115, 138, 166, 25, 135, 111, 134, 91, 132, 179, 240, 149, 120, 190, 153, 26, 31, 225, 14, 35, 103, 117, 83, 232, 123, 46, 112}, { 116, 92, 123, 58, 11, 147, 165, 198, 223, 221, 182, 152, 41, 164, 160, 146, 96, 220, 138, 158, 21, 220, 202, 230, 216, 197, 120, 107, 75, 192, 0, 85, 57, 161, 79, 186, 87, 10, 13, 144, 87, 252, 20, 186, 127, 98, 203, 47, 232, 91, 172, 63, 222, 77, 121, 132, 91, 91, 18, 234, 43, 114, 206, 200, 254, 172, 153, 193, 192, 99, 133, 70}, { 94, 94, 201, 12, 46, 246, 205, 44, 235, 22, 154, 191, 253, 0, 124, 77, 109, 79, 208, 99, 77, 77, 255, 97, 2, 166, 71, 29, 27, 242, 254, 147, 38, 213, 40, 124, 239, 170, 175, 67, 172, 189, 72, 212, 9, 165, 49, 5, 100, 181, 60, 87, 13, 75, 189, 175, 188, 74, 140, 51, 128, 200, 19, 106, 163, 36, 210, 202, 202, 19, 63, 152}, { 7, 13, 255, 43, 57, 132, 166, 192, 193, 107, 41, 18, 19, 72, 81, 94, 25, 241, 229, 96, 52, 208, 223, 101, 30, 80, 249, 95, 51, 81, 191, 52, 114, 163, 95, 173, 185, 236, 152, 108, 211, 117, 169, 104, 26, 232, 208, 83, 161, 102, 112, 21, 202, 187, 22, 252, 119, 207, 13, 22, 114, 109, 92, 164, 165, 255, 220, 101, 104, 121, 74, 10}, { 102, 109, 236, 162, 153, 168, 14, 60, 139, 141, 231, 241, 169, 183, 93, 78, 187, 74, 89, 201, 221, 136, 106, 197, 108, 46, 125, 118, 57, 64, 125, 59, 94, 58, 97, 20, 249, 172, 42, 14, 105, 15, 90, 177, 18, 171, 162, 56, 206, 147, 86, 126, 62, 149, 87, 31, 192, 40, 253, 165, 30, 142, 82, 126, 91, 46, 255, 171, 251, 93, 246, 185}, { 97, 29, 28, 164, 189, 25, 25, 31, 91, 48, 215, 188, 196, 79, 88, 129, 196, 222, 206, 44, 231, 123, 132, 247, 128, 62, 76, 35, 219, 33, 109, 89, 219, 208, 67, 93, 78, 247, 36, 158, 76, 210, 170, 113, 20, 13, 73, 182, 11, 74, 172, 99, 230, 241, 176, 87, 176, 199, 67, 184, 19, 205, 58, 144, 58, 119, 199, 24, 21, 195, 107, 138}, { 175, 232, 202, 210, 0, 238, 236, 43, 208, 4, 87, 203, 108, 95, 9, 86, 108, 64, 230, 131, 137, 78, 120, 97, 245, 41, 150, 196, 155, 29, 27, 167, 174, 39, 114, 26, 184, 17, 121, 137, 243, 195, 31, 238, 205, 156, 211, 234, 48, 86, 195, 187, 45, 246, 135, 170, 69, 194, 108, 94, 0, 119, 88, 32, 223, 247, 158, 85, 193, 213, 44, 242}, { 87, 84, 116, 135, 67, 242, 48, 13, 29, 216, 28, 26, 60, 110, 176, 135, 182, 26, 235, 75, 21, 38, 2, 232, 52, 133, 68, 243, 216, 190, 137, 10, 163, 93, 140, 253, 153, 157, 35, 6, 115, 47, 218, 0, 159, 28, 45, 9, 215, 147, 159, 195, 244, 196, 209, 101, 141, 49, 64, 98, 91, 48, 197, 41, 57, 63, 183, 220, 140, 156, 162, 91}, { 29, 181, 66, 240, 194, 181, 162, 250, 65, 163, 134, 172, 178, 16, 107, 196, 38, 6, 82, 12, 31, 14, 198, 54, 116, 239, 235, 37, 255, 183, 10, 207, 164, 92, 74, 144, 239, 27, 196, 20, 250, 114, 88, 65, 16, 131, 32, 87, 170, 87, 128, 7, 103, 110, 209, 94, 255, 155, 182, 219, 144, 173, 80, 158, 156, 196, 115, 39, 140, 113, 215, 152}, { 107, 57, 49, 157, 178, 227, 183, 177, 64, 6, 111, 40, 121, 96, 43, 139, 249, 144, 98, 126, 133, 64, 166, 194, 162, 36, 180, 168, 23, 244, 28, 6, 186, 163, 220, 131, 112, 130, 85, 131, 3, 154, 7, 217, 79, 15, 169, 144, 171, 89, 67, 41, 156, 49, 169, 102, 200, 64, 174, 18, 241, 61, 167, 74, 221, 210, 228, 243, 231, 31, 165, 70}, { 166, 161, 219, 94, 83, 156, 120, 128, 169, 241, 94, 24, 147, 35, 129, 198, 171, 211, 94, 138, 154, 231, 156, 78, 33, 201, 62, 114, 75, 91, 42, 49, 121, 198, 142, 252, 197, 169, 131, 45, 104, 175, 26, 120, 65, 9, 112, 183, 78, 164, 128, 15, 230, 251, 15, 84, 175, 8, 31, 202, 194, 131, 47, 248, 166, 20, 185, 163, 147, 95, 40, 223}, { 3, 124, 74, 171, 41, 84, 70, 9, 38, 66, 71, 53, 46, 5, 169, 10, 187, 45, 35, 101, 118, 255, 253, 118, 64, 130, 188, 7, 52, 119, 117, 33, 190, 54, 236, 96, 8, 12, 23, 216, 220, 240, 65, 126, 37, 58, 96, 102, 46, 129, 255, 233, 144, 25, 9, 51, 140, 211, 161, 28, 44, 247, 23, 154, 81, 197, 243, 240, 50, 44, 59, 4}, { 78, 26, 206, 23, 195, 240, 27, 33, 36, 161, 143, 229, 232, 231, 145, 168, 236, 42, 220, 28, 48, 103, 36, 89, 142, 146, 234, 105, 42, 17, 167, 122, 79, 212, 144, 55, 24, 24, 80, 36, 107, 16, 146, 63, 222, 55, 171, 146, 156, 111, 172, 176, 97, 212, 40, 121, 60, 167, 15, 13, 175, 86, 33, 77, 85, 63, 6, 254, 23, 51, 190, 253}, { 225, 229, 32, 150, 199, 39, 89, 76, 154, 61, 233, 241, 44, 3, 201, 63, 27, 104, 153, 97, 150, 82, 142, 226, 62, 207, 150, 95, 153, 30, 81, 186, 158, 225, 12, 110, 157, 36, 120, 230, 249, 145, 172, 20, 0, 52, 191, 28, 232, 187, 29, 84, 169, 135, 17, 241, 245, 216, 132, 84, 85, 254, 166, 208, 7, 203, 146, 17, 13, 224, 69, 103}, { 0, 233, 89, 66, 111, 247, 1, 152, 169, 170, 0, 114, 16, 133, 213, 110, 223, 152, 148, 161, 244, 19, 197, 253, 11, 227, 80, 88, 243, 101, 175, 98, 156, 241, 188, 138, 238, 50, 21, 164, 2, 172, 101, 252, 203, 72, 92, 139, 219, 102, 111, 224, 97, 237, 103, 173, 145, 58, 183, 97, 55, 28, 231, 198, 209, 100, 23, 232, 137, 219, 105, 216}, { 77, 59, 249, 64, 184, 223, 50, 85, 60, 247, 209, 23, 58, 140, 21, 82, 208, 85, 167, 46, 3, 207, 5, 73, 141, 92, 174, 65, 106, 188, 182, 152, 238, 146, 16, 249, 136, 236, 248, 165, 127, 19, 144, 97, 139, 11, 239, 139, 222, 213, 34, 241, 94, 187, 97, 30, 15, 239, 98, 49, 86, 141, 95, 9, 195, 74, 203, 137, 131, 197, 140, 224}, { 211, 20, 163, 31, 143, 86, 255, 81, 222, 240, 53, 122, 128, 72, 12, 0, 74, 135, 117, 103, 75, 106, 238, 94, 74, 69, 233, 219, 55, 110, 25, 219, 91, 208, 188, 52, 143, 191, 101, 187, 17, 61, 118, 131, 113, 196, 158, 207, 147, 242, 170, 67, 79, 146, 207, 108, 26, 142, 55, 176, 25, 57, 173, 80, 145, 48, 83, 169, 21, 45, 118, 249}, { 152, 71, 164, 114, 212, 59, 63, 11, 204, 165, 67, 216, 201, 115, 254, 45, 94, 82, 94, 235, 149, 109, 235, 212, 95, 236, 87, 9, 244, 33, 238, 134, 128, 2, 86, 20, 206, 47, 87, 241, 193, 185, 1, 29, 248, 239, 173, 151, 134, 119, 188, 4, 226, 80, 65, 1, 220, 38, 78, 155, 252, 133, 123, 134, 117, 8, 75, 53, 32, 115, 194, 115}, { 240, 36, 225, 73, 249, 17, 238, 18, 76, 145, 62, 225, 157, 157, 55, 251, 199, 244, 223, 116, 225, 23, 84, 148, 142, 145, 214, 42, 88, 82, 21, 242, 66, 147, 128, 68, 29, 137, 61, 69, 57, 125, 105, 161, 29, 25, 233, 95, 44, 225, 157, 101, 119, 186, 144, 25, 157, 153, 12, 6, 132, 5, 182, 129, 212, 183, 7, 163, 133, 133, 19, 143}, { 106, 22, 228, 139, 155, 144, 72, 69, 53, 254, 230, 238, 27, 46, 128, 17, 178, 158, 111, 27, 130, 81, 47, 126, 150, 98, 80, 42, 39, 244, 58, 144, 72, 73, 151, 226, 14, 58, 199, 76, 195, 152, 51, 199, 115, 124, 71, 225, 179, 228, 57, 53, 204, 130, 89, 87, 220, 49, 44, 84, 2, 69, 55, 14, 204, 166, 17, 135, 53, 229, 18, 59}, { 244, 196, 55, 105, 5, 181, 245, 203, 225, 4, 90, 83, 253, 164, 185, 19, 216, 73, 141, 203, 30, 113, 73, 182, 193, 49, 163, 211, 145, 2, 85, 3, 211, 205, 184, 42, 229, 228, 89, 80, 204, 206, 152, 119, 243, 51, 189, 248, 24, 38, 80, 228, 229, 35, 93, 209, 166, 181, 160, 244, 175, 130, 170, 110, 226, 252, 157, 118, 227, 219, 190, 77}, { 94, 22, 97, 49, 8, 194, 160, 11, 13, 156, 196, 159, 226, 54, 156, 130, 159, 121, 43, 145, 244, 133, 177, 31, 209, 184, 113, 131, 18, 131, 29, 141, 153, 214, 17, 188, 192, 43, 63, 253, 239, 240, 197, 223, 202, 173, 105, 162, 40, 222, 142, 20, 212, 117, 191, 68, 23, 77, 121, 178, 116, 202, 99, 101, 155, 96, 122, 61, 132, 208, 117, 30}, { 239, 141, 101, 206, 167, 153, 203, 124, 184, 143, 106, 208, 49, 51, 147, 234, 123, 202, 79, 3, 135, 172, 22, 9, 253, 85, 128, 9, 112, 182, 63, 151, 237, 66, 120, 53, 180, 242, 175, 57, 196, 143, 184, 210, 112, 95, 53, 186, 221, 115, 12, 181, 96, 245, 7, 66, 184, 211, 47, 102, 71, 5, 191, 182, 197, 169, 211, 94, 112, 16, 158, 36}, { 106, 119, 75, 238, 238, 192, 53, 32, 166, 155, 127, 142, 72, 83, 134, 124, 79, 163, 134, 96, 31, 165, 11, 172, 42, 4, 108, 240, 255, 239, 43, 205, 113, 222, 104, 150, 196, 30, 59, 176, 63, 153, 249, 160, 94, 253, 236, 171, 221, 131, 103, 194, 115, 210, 182, 142, 33, 84, 50, 188, 22, 253, 73, 226, 159, 58, 159, 226, 213, 42, 46, 43}, { 71, 203, 231, 234, 67, 47, 39, 81, 195, 112, 235, 91, 55, 237, 55, 100, 32, 128, 26, 254, 73, 77, 170, 124, 92, 137, 251, 117, 50, 86, 212, 3, 47, 188, 106, 55, 138, 56, 77, 13, 131, 14, 85, 221, 203, 251, 233, 52, 213, 141, 200, 143, 111, 20, 24, 166, 244, 152, 91, 225, 104, 176, 19, 42, 126, 40, 120, 158, 168, 225, 150, 217}, { 93, 129, 146, 51, 169, 35, 108, 79, 84, 121, 48, 240, 122, 74, 90, 188, 197, 215, 127, 12, 104, 29, 227, 81, 33, 123, 89, 196, 129, 15, 212, 254, 85, 94, 138, 102, 47, 156, 39, 203, 10, 151, 59, 204, 120, 36, 190, 20, 15, 37, 213, 115, 87, 156, 191, 32, 245, 109, 18, 115, 43, 77, 68, 233, 220, 240, 48, 34, 53, 209, 13, 34}, { 242, 22, 134, 221, 44, 125, 121, 116, 220, 88, 186, 11, 47, 250, 233, 127, 233, 237, 233, 183, 191, 42, 185, 204, 81, 191, 81, 148, 168, 181, 189, 157, 32, 75, 61, 87, 92, 255, 91, 83, 142, 96, 1, 237, 74, 167, 215, 201, 110, 115, 56, 231, 101, 230, 143, 184, 84, 160, 29, 44, 238, 193, 43, 91, 80, 107, 31, 161, 39, 50, 146, 122}, { 203, 245, 26, 212, 220, 233, 74, 204, 52, 78, 169, 137, 146, 76, 97, 173, 90, 242, 231, 118, 148, 135, 107, 194, 151, 248, 34, 245, 123, 233, 188, 93, 83, 2, 42, 40, 0, 222, 138, 71, 214, 237, 33, 171, 92, 78, 30, 121, 111, 60, 159, 5, 79, 91, 146, 165, 107, 240, 187, 80, 117, 91, 162, 59, 250, 113, 84, 34, 222, 95, 130, 146}, { 8, 231, 123, 141, 195, 80, 38, 145, 232, 104, 43, 63, 190, 29, 100, 82, 115, 211, 78, 253, 233, 155, 42, 194, 85, 103, 52, 223, 182, 70, 128, 224, 104, 153, 120, 135, 178, 83, 138, 162, 36, 54, 147, 248, 128, 233, 29, 192, 10, 29, 136, 158, 115, 62, 145, 77, 67, 119, 115, 53, 114, 214, 122, 221, 24, 108, 88, 200, 141, 162, 202, 72}, { 139, 141, 145, 72, 142, 80, 210, 146, 55, 92, 52, 13, 185, 13, 72, 49, 0, 78, 96, 97, 88, 165, 152, 134, 226, 178, 128, 124, 144, 7, 250, 246, 117, 7, 4, 89, 135, 45, 59, 126, 249, 70, 31, 110, 40, 168, 243, 220, 235, 199, 97, 114, 66, 242, 76, 194, 34, 21, 226, 51, 25, 244, 167, 211, 168, 38, 54, 249, 158, 105, 84, 81}, { 225, 155, 77, 55, 68, 237, 12, 87, 219, 230, 72, 251, 144, 7, 116, 103, 59, 95, 167, 111, 93, 236, 85, 102, 105, 173, 244, 69, 149, 135, 160, 183, 122, 79, 215, 145, 90, 139, 215, 138, 218, 79, 173, 17, 250, 1, 137, 37, 88, 72, 222, 162, 3, 81, 201, 237, 129, 4, 94, 81, 230, 96, 156, 222, 162, 116, 35, 61, 230, 7, 74, 237}, { 55, 19, 22, 64, 241, 34, 125, 64, 235, 43, 180, 48, 109, 246, 217, 134, 254, 216, 30, 209, 181, 142, 155, 198, 205, 31, 105, 70, 173, 218, 174, 92, 12, 150, 91, 109, 218, 225, 57, 236, 30, 23, 107, 233, 56, 30, 73, 71, 28, 132, 108, 49, 169, 192, 57, 37, 49, 97, 245, 97, 68, 41, 163, 69, 74, 244, 27, 172, 38, 67, 180, 91}, { 2, 120, 243, 80, 125, 116, 224, 193, 44, 182, 227, 65, 76, 101, 46, 165, 115, 92, 163, 138, 78, 157, 3, 190, 219, 192, 92, 73, 224, 159, 163, 235, 43, 185, 40, 9, 28, 56, 239, 119, 56, 119, 18, 250, 234, 40, 34, 173, 125, 56, 172, 38, 5, 169, 103, 127, 74, 203, 12, 206, 73, 160, 143, 164, 207, 152, 50, 244, 171, 136, 223, 175}, { 82, 129, 126, 132, 25, 76, 142, 25, 206, 146, 137, 119, 219, 74, 246, 220, 230, 89, 120, 18, 158, 108, 224, 45, 4, 154, 43, 205, 24, 247, 69, 21, 70, 253, 228, 241, 170, 67, 103, 40, 118, 100, 231, 183, 119, 241, 150, 61, 43, 62, 34, 120, 133, 207, 113, 77, 126, 180, 133, 85, 9, 96, 150, 28, 78, 203, 168, 32, 173, 129, 70, 70}, { 212, 108, 213, 230, 7, 136, 202, 111, 189, 155, 40, 6, 57, 149, 82, 135, 96, 126, 111, 171, 54, 123, 237, 156, 218, 2, 77, 14, 84, 61, 142, 193, 203, 68, 172, 82, 73, 251, 137, 254, 48, 186, 156, 174, 231, 103, 27, 209, 230, 115, 223, 2, 37, 15, 55, 77, 212, 123, 17, 91, 215, 41, 240, 56, 179, 190, 13, 37, 67, 148, 164, 191}, { 0, 57, 246, 173, 98, 122, 17, 242, 226, 44, 86, 135, 195, 75, 228, 59, 124, 205, 161, 29, 156, 102, 216, 80, 154, 100, 117, 50, 245, 46, 61, 136, 178, 83, 91, 206, 38, 49, 6, 4, 4, 201, 112, 219, 74, 142, 92, 80, 188, 202, 183, 176, 86, 145, 129, 207, 147, 147, 130, 115, 162, 35, 150, 232, 201, 201, 179, 146, 21, 82, 127, 99}, { 130, 111, 249, 127, 235, 55, 101, 239, 209, 242, 113, 106, 238, 64, 246, 198, 214, 246, 241, 42, 154, 80, 251, 252, 5, 253, 192, 149, 51, 232, 75, 217, 168, 126, 227, 58, 6, 43, 198, 214, 27, 231, 52, 167, 191, 56, 141, 1, 237, 151, 201, 221, 128, 146, 255, 243, 230, 98, 41, 87, 39, 55, 99, 248, 33, 111, 162, 184, 27, 212, 101, 140}, { 6, 128, 215, 68, 101, 173, 167, 131, 55, 227, 128, 179, 120, 52, 87, 30, 200, 128, 2, 41, 191, 117, 203, 202, 155, 55, 87, 237, 43, 19, 160, 162, 203, 236, 10, 66, 114, 219, 188, 122, 137, 52, 31, 16, 56, 79, 148, 105, 183, 236, 22, 70, 206, 9, 78, 147, 133, 156, 141, 86, 76, 228, 28, 186, 72, 168, 243, 76, 169, 220, 202, 228}, { 250, 45, 202, 91, 247, 248, 56, 130, 37, 160, 196, 101, 115, 145, 188, 71, 176, 98, 65, 144, 247, 199, 230, 183, 107, 35, 249, 251, 79, 216, 146, 236, 215, 29, 154, 69, 29, 77, 105, 103, 156, 251, 106, 197, 42, 37, 86, 106, 95, 120, 253, 112, 77, 138, 102, 116, 185, 126, 62, 15, 7, 238, 167, 102, 20, 27, 27, 70, 62, 233, 105, 237}, { 206, 77, 148, 112, 47, 121, 193, 14, 186, 14, 30, 201, 69, 179, 75, 155, 199, 79, 229, 171, 35, 143, 187, 159, 18, 240, 97, 6, 56, 112, 27, 88, 184, 116, 165, 169, 185, 223, 245, 182, 63, 150, 220, 21, 7, 97, 86, 102, 27, 255, 251, 63, 124, 54, 166, 18, 60, 253, 110, 153, 224, 180, 182, 28, 222, 133, 175, 106, 251, 29, 89, 147}, { 124, 65, 57, 161, 171, 209, 57, 69, 232, 107, 105, 158, 174, 227, 62, 131, 235, 36, 129, 115, 218, 34, 240, 95, 9, 25, 60, 54, 111, 184, 62, 2, 251, 236, 111, 189, 243, 12, 103, 110, 98, 92, 88, 49, 43, 25, 152, 253, 208, 244, 175, 67, 2, 130, 124, 149, 113, 246, 113, 200, 19, 196, 159, 162, 113, 166, 243, 146, 19, 228, 149, 69}, { 250, 42, 248, 197, 13, 4, 200, 151, 100, 217, 196, 55, 189, 220, 51, 198, 21, 186, 171, 104, 192, 56, 188, 7, 116, 16, 94, 211, 245, 238, 198, 218, 6, 161, 73, 125, 81, 67, 174, 204, 213, 86, 20, 22, 177, 136, 20, 221, 238, 61, 142, 132, 236, 242, 219, 82, 188, 176, 226, 232, 215, 92, 247, 201, 18, 249, 203, 9, 17, 189, 147, 139}, { 229, 1, 35, 0, 30, 198, 247, 244, 31, 224, 141, 14, 61, 191, 174, 122, 178, 172, 115, 173, 67, 45, 161, 158, 227, 116, 143, 15, 104, 171, 138, 188, 64, 161, 12, 51, 9, 235, 186, 15, 69, 92, 27, 168, 21, 139, 144, 128, 19, 68, 59, 157, 130, 165, 43, 120, 19, 250, 9, 242, 4, 38, 82, 14, 136, 240, 233, 109, 79, 49, 189, 121}, { 148, 2, 5, 95, 177, 76, 81, 49, 32, 222, 219, 252, 51, 126, 164, 159, 168, 30, 132, 112, 65, 111, 114, 79, 123, 107, 236, 37, 26, 101, 178, 217, 128, 102, 216, 223, 215, 142, 178, 231, 7, 19, 98, 18, 242, 30, 35, 121, 204, 208, 253, 244, 33, 66, 31, 170, 179, 169, 21, 11, 164, 183, 36, 44, 19, 198, 111, 176, 192, 195, 39, 183}, { 189, 105, 72, 94, 41, 248, 122, 88, 114, 248, 253, 130, 29, 53, 229, 99, 166, 187, 84, 140, 201, 125, 20, 42, 233, 163, 141, 250, 18, 62, 153, 128, 64, 206, 62, 227, 238, 110, 4, 247, 96, 44, 44, 63, 77, 82, 228, 99, 172, 45, 111, 60, 157, 34, 103, 170, 167, 245, 220, 189, 187, 83, 122, 221, 8, 234, 158, 1, 168, 207, 192, 136}, { 32, 94, 92, 19, 137, 113, 24, 249, 183, 122, 209, 140, 148, 57, 118, 95, 158, 8, 177, 181, 137, 240, 4, 160, 177, 91, 209, 26, 246, 24, 72, 226, 199, 29, 211, 46, 12, 244, 19, 214, 11, 184, 105, 123, 168, 113, 254, 91, 105, 121, 77, 205, 214, 40, 21, 133, 85, 95, 102, 74, 201, 136, 110, 248, 110, 251, 178, 153, 35, 209, 78, 123}, { 142, 213, 100, 94, 204, 130, 194, 81, 244, 141, 4, 139, 73, 133, 117, 93, 148, 0, 35, 82, 213, 60, 185, 77, 229, 234, 203, 90, 89, 162, 218, 52, 98, 140, 106, 214, 161, 122, 218, 65, 170, 246, 42, 119, 238, 86, 153, 29, 226, 48, 121, 17, 11, 207, 50, 104, 148, 120, 87, 86, 192, 146, 234, 32, 91, 92, 27, 77, 139, 19, 243, 10}, { 182, 29, 222, 195, 166, 215, 17, 243, 14, 85, 37, 17, 199, 92, 147, 162, 182, 142, 172, 207, 213, 228, 164, 49, 50, 164, 66, 119, 39, 217, 238, 195, 19, 95, 30, 168, 242, 130, 109, 213, 132, 99, 228, 143, 64, 95, 254, 246, 44, 159, 41, 50, 213, 190, 67, 71, 57, 22, 179, 85, 210, 124, 152, 63, 96, 18, 169, 194, 74, 186, 236, 240}, { 121, 181, 187, 29, 62, 135, 149, 69, 147, 131, 108, 180, 180, 76, 40, 8, 51, 19, 14, 224, 68, 170, 130, 178, 253, 244, 133, 191, 66, 218, 98, 114, 108, 100, 60, 150, 213, 52, 48, 146, 251, 219, 21, 222, 89, 194, 42, 85, 35, 121, 191, 19, 227, 2, 47, 188, 99, 81, 230, 188, 95, 160, 142, 9, 168, 186, 104, 249, 222, 164, 77, 178}, { 250, 125, 240, 67, 174, 42, 102, 22, 191, 108, 236, 177, 213, 112, 169, 50, 114, 190, 61, 10, 126, 244, 70, 216, 17, 232, 224, 76, 118, 173, 192, 170, 243, 187, 112, 33, 186, 1, 95, 239, 63, 176, 57, 28, 178, 151, 20, 151, 219, 224, 174, 156, 71, 141, 62, 171, 32, 148, 152, 137, 254, 169, 7, 227, 87, 94, 13, 206, 99, 110, 99, 83}, { 48, 2, 210, 55, 188, 44, 251, 151, 241, 7, 63, 175, 12, 80, 234, 202, 86, 63, 5, 235, 35, 253, 188, 25, 200, 234, 143, 4, 130, 185, 102, 241, 2, 150, 24, 138, 159, 186, 2, 128, 124, 221, 145, 159, 105, 139, 152, 211, 36, 89, 84, 132, 143, 183, 47, 38, 57, 60, 146, 214, 73, 194, 214, 119, 197, 206, 71, 30, 150, 72, 66, 166}, { 139, 248, 48, 201, 142, 61, 253, 230, 14, 130, 86, 249, 173, 37, 141, 211, 117, 145, 115, 249, 201, 203, 236, 156, 191, 243, 135, 41, 32, 211, 81, 232, 242, 201, 188, 126, 147, 176, 151, 48, 178, 63, 173, 21, 206, 167, 255, 180, 89, 167, 58, 143, 255, 83, 42, 113, 178, 61, 244, 88, 92, 138, 149, 102, 92, 192, 66, 231, 151, 34, 44, 161}, { 159, 60, 4, 56, 116, 240, 31, 94, 41, 3, 126, 115, 223, 88, 49, 126, 128, 200, 128, 167, 192, 160, 56, 174, 13, 211, 92, 212, 170, 8, 201, 228, 230, 22, 187, 139, 207, 175, 107, 112, 81, 186, 61, 98, 201, 10, 46, 106, 204, 199, 226, 70, 125, 239, 22, 114, 43, 37, 162, 119, 44, 84, 152, 62, 156, 196, 237, 65, 131, 135, 34, 228}, { 53, 167, 106, 13, 136, 84, 218, 100, 140, 60, 246, 198, 91, 206, 173, 129, 226, 49, 37, 74, 223, 254, 127, 138, 134, 103, 85, 199, 75, 88, 55, 238, 33, 109, 135, 86, 201, 92, 10, 161, 0, 37, 157, 79, 180, 4, 208, 60, 231, 125, 11, 76, 154, 53, 157, 222, 126, 54, 23, 216, 148, 144, 242, 116, 15, 112, 128, 82, 116, 52, 128, 41}, { 254, 226, 142, 137, 190, 186, 148, 203, 239, 85, 67, 19, 111, 114, 109, 213, 69, 215, 227, 156, 233, 43, 138, 42, 86, 2, 54, 231, 106, 202, 146, 59, 42, 164, 45, 124, 62, 82, 162, 73, 101, 58, 211, 57, 32, 132, 163, 84, 35, 120, 191, 146, 142, 248, 194, 137, 8, 191, 198, 182, 58, 132, 21, 234, 215, 50, 149, 135, 120, 86, 128, 199}, { 198, 12, 8, 62, 70, 213, 47, 107, 252, 103, 90, 69, 175, 148, 210, 251, 222, 138, 170, 248, 237, 212, 67, 194, 1, 110, 51, 137, 125, 12, 182, 110, 239, 224, 80, 138, 58, 43, 69, 5, 127, 196, 112, 82, 232, 49, 45, 228, 216, 227, 233, 22, 240, 183, 126, 160, 34, 100, 3, 37, 60, 131, 193, 242, 170, 61, 63, 40, 95, 16, 96, 118}, { 38, 45, 198, 135, 107, 117, 232, 238, 78, 66, 215, 5, 154, 61, 142, 40, 1, 124, 196, 65, 46, 48, 115, 2, 9, 234, 130, 168, 17, 33, 220, 234, 201, 148, 185, 250, 197, 137, 250, 39, 229, 159, 162, 212, 146, 58, 101, 104, 156, 108, 179, 21, 1, 121, 9, 153, 233, 233, 35, 44, 95, 190, 218, 94, 145, 127, 22, 188, 85, 116, 170, 31}, { 186, 7, 46, 22, 2, 53, 150, 192, 198, 102, 75, 98, 111, 203, 136, 98, 214, 74, 157, 47, 70, 115, 33, 139, 245, 174, 13, 253, 64, 223, 128, 225, 202, 0, 0, 240, 196, 21, 2, 253, 93, 218, 155, 230, 211, 242, 161, 178, 29, 112, 212, 142, 135, 136, 127, 121, 74, 116, 121, 241, 238, 157, 80, 196, 219, 142, 235, 161, 60, 1, 242, 33}, { 69, 185, 214, 150, 80, 255, 242, 175, 228, 179, 20, 51, 195, 97, 253, 41, 5, 102, 151, 45, 129, 61, 192, 19, 94, 85, 63, 236, 199, 54, 158, 189, 115, 120, 150, 188, 168, 169, 243, 222, 202, 199, 179, 244, 96, 243, 224, 218, 133, 230, 45, 240, 11, 109, 7, 102, 220, 160, 198, 92, 180, 52, 152, 62, 164, 195, 163, 255, 35, 35, 129, 149}, { 25, 245, 90, 195, 117, 157, 207, 185, 106, 229, 73, 9, 4, 95, 183, 67, 106, 255, 181, 39, 93, 87, 87, 174, 194, 45, 148, 51, 81, 144, 178, 25, 52, 135, 209, 153, 157, 114, 40, 184, 202, 14, 246, 227, 19, 215, 126, 165, 20, 47, 10, 153, 227, 39, 213, 80, 231, 120, 110, 11, 76, 183, 76, 69, 13, 142, 118, 196, 62, 238, 51, 239}, { 112, 145, 14, 243, 206, 244, 255, 40, 153, 103, 75, 98, 52, 199, 166, 142, 75, 214, 107, 36, 241, 125, 129, 168, 250, 178, 15, 12, 74, 164, 21, 1, 252, 1, 105, 68, 243, 200, 78, 143, 22, 19, 130, 179, 195, 2, 168, 203, 162, 202, 166, 82, 176, 209, 118, 239, 196, 45, 43, 27, 108, 216, 72, 111, 115, 227, 202, 102, 60, 123, 217, 50}, { 123, 181, 28, 48, 78, 59, 190, 29, 106, 70, 193, 92, 166, 22, 48, 229, 135, 94, 130, 212, 60, 202, 247, 38, 42, 211, 52, 141, 180, 160, 30, 137, 161, 34, 147, 44, 183, 28, 160, 228, 12, 104, 242, 225, 99, 157, 0, 154, 217, 37, 110, 192, 153, 144, 140, 209, 101, 86, 204, 109, 112, 161, 109, 92, 172, 2, 240, 183, 128, 110, 172, 235}, { 113, 20, 14, 167, 24, 226, 110, 223, 15, 104, 235, 202, 196, 72, 237, 119, 224, 168, 41, 199, 119, 75, 26, 142, 113, 48, 75, 46, 173, 205, 70, 210, 200, 211, 64, 244, 254, 227, 71, 136, 179, 225, 30, 247, 137, 78, 3, 119, 242, 3, 9, 74, 100, 86, 185, 131, 75, 13, 70, 255, 128, 148, 15, 127, 248, 168, 217, 234, 100, 67, 182, 91}, { 240, 230, 198, 45, 158, 105, 44, 194, 103, 160, 127, 137, 86, 166, 173, 36, 249, 5, 89, 15, 61, 55, 141, 197, 153, 44, 206, 57, 84, 62, 122, 243, 77, 144, 230, 101, 27, 5, 104, 164, 220, 197, 152, 66, 85, 88, 230, 247, 95, 243, 43, 232, 124, 19, 255, 208, 147, 174, 220, 71, 4, 142, 85, 61, 172, 125, 108, 64, 174, 150, 129, 76}, { 100, 204, 113, 79, 155, 57, 162, 208, 220, 1, 61, 86, 56, 156, 167, 209, 144, 25, 243, 251, 165, 240, 228, 62, 44, 31, 90, 181, 14, 192, 208, 15, 32, 207, 156, 150, 38, 59, 250, 138, 135, 197, 222, 67, 224, 104, 233, 102, 3, 180, 246, 112, 191, 59, 216, 117, 242, 91, 48, 153, 140, 248, 222, 186, 92, 152, 55, 5, 105, 48, 139, 11}, { 130, 7, 7, 154, 225, 30, 218, 206, 126, 91, 49, 209, 97, 252, 149, 91, 101, 17, 236, 241, 98, 53, 109, 186, 226, 115, 9, 25, 212, 73, 75, 63, 106, 113, 233, 127, 118, 30, 34, 80, 103, 130, 81, 165, 105, 37, 182, 59, 99, 123, 214, 228, 216, 15, 123, 25, 52, 84, 21, 22, 150, 98, 2, 92, 21, 44, 95, 182, 50, 150, 192, 101}, { 195, 157, 41, 136, 22, 178, 76, 191, 255, 3, 222, 243, 37, 66, 218, 135, 39, 64, 250, 238, 125, 73, 224, 222, 187, 89, 184, 25, 245, 29, 239, 111, 113, 35, 204, 35, 228, 235, 224, 90, 64, 66, 110, 133, 29, 93, 28, 253, 86, 111, 92, 154, 240, 104, 41, 233, 242, 42, 20, 54, 70, 241, 199, 208, 255, 78, 60, 148, 37, 124, 53, 253}, { 59, 174, 97, 98, 210, 232, 32, 11, 180, 155, 117, 198, 127, 61, 139, 184, 142, 42, 38, 162, 67, 106, 121, 206, 67, 121, 230, 224, 40, 199, 185, 90, 71, 54, 148, 118, 160, 61, 78, 108, 154, 58, 70, 43, 42, 114, 74, 73, 243, 157, 138, 78, 187, 185, 100, 63, 179, 95, 0, 108, 132, 249, 34, 195, 83, 19, 243, 171, 16, 146, 190, 126}, { 79, 238, 143, 66, 74, 51, 114, 92, 20, 63, 133, 231, 170, 197, 184, 141, 185, 85, 76, 88, 250, 126, 147, 135, 13, 169, 158, 92, 136, 68, 208, 88, 12, 143, 41, 129, 11, 158, 213, 185, 243, 110, 1, 34, 93, 158, 77, 100, 12, 142, 125, 53, 152, 104, 196, 26, 94, 215, 135, 101, 237, 25, 166, 174, 226, 9, 99, 124, 207, 77, 78, 198}, { 1, 193, 25, 150, 231, 156, 194, 106, 196, 16, 212, 62, 148, 210, 175, 131, 186, 5, 243, 165, 70, 52, 131, 7, 68, 210, 32, 109, 234, 151, 193, 11, 212, 223, 86, 167, 122, 108, 168, 0, 250, 20, 87, 76, 22, 2, 227, 28, 142, 35, 192, 196, 75, 131, 26, 187, 173, 234, 201, 139, 89, 34, 92, 34, 217, 239, 254, 34, 157, 209, 110, 251}, { 29, 13, 68, 241, 208, 22, 241, 228, 142, 135, 18, 204, 73, 5, 246, 81, 186, 35, 26, 211, 145, 48, 38, 160, 173, 116, 24, 211, 123, 46, 240, 62, 6, 221, 193, 228, 160, 220, 241, 151, 232, 88, 239, 226, 139, 253, 15, 247, 129, 192, 78, 95, 107, 242, 76, 124, 107, 27, 235, 45, 189, 53, 97, 61, 128, 132, 220, 137, 4, 172, 113, 238}, { 148, 83, 17, 76, 103, 96, 9, 195, 82, 245, 155, 3, 62, 51, 62, 65, 149, 137, 76, 45, 194, 95, 194, 81, 182, 121, 208, 93, 249, 20, 125, 69, 179, 4, 139, 66, 40, 122, 140, 179, 107, 223, 19, 26, 90, 45, 230, 48, 126, 166, 52, 98, 86, 214, 135, 243, 142, 159, 83, 219, 53, 108, 251, 116, 236, 223, 16, 47, 124, 218, 10, 158}, { 236, 198, 136, 25, 239, 206, 88, 184, 205, 138, 247, 110, 245, 27, 249, 19, 116, 146, 155, 96, 76, 239, 57, 252, 205, 138, 22, 115, 167, 109, 252, 206, 82, 244, 17, 201, 184, 236, 118, 170, 70, 40, 210, 161, 251, 26, 18, 136, 88, 22, 184, 144, 67, 254, 225, 72, 113, 148, 169, 197, 23, 190, 42, 197, 177, 255, 189, 143, 164, 207, 145, 65}, { 17, 136, 254, 193, 86, 232, 65, 0, 5, 57, 15, 40, 245, 43, 116, 97, 108, 193, 97, 110, 115, 174, 124, 215, 190, 144, 162, 252, 126, 228, 15, 237, 154, 14, 88, 248, 24, 42, 92, 126, 63, 237, 190, 152, 164, 17, 19, 169, 19, 201, 30, 58, 40, 204, 91, 148, 203, 243, 83, 160, 212, 168, 96, 78, 9, 15, 64, 21, 248, 94, 117, 144}, { 246, 74, 156, 226, 31, 114, 223, 49, 197, 114, 192, 123, 248, 232, 117, 152, 251, 159, 66, 229, 122, 250, 199, 143, 120, 46, 215, 123, 218, 146, 223, 7, 114, 225, 187, 36, 164, 2, 140, 208, 195, 86, 99, 64, 255, 141, 55, 134, 216, 154, 243, 226, 94, 151, 97, 70, 16, 159, 30, 119, 13, 127, 206, 228, 102, 193, 121, 117, 159, 106, 158, 22}, { 28, 231, 130, 91, 228, 216, 125, 163, 45, 29, 150, 248, 21, 138, 225, 205, 160, 238, 228, 161, 218, 146, 118, 14, 120, 71, 37, 208, 122, 177, 5, 8, 130, 253, 158, 214, 25, 45, 78, 126, 152, 47, 154, 86, 19, 38, 54, 51, 52, 125, 206, 191, 85, 135, 101, 36, 68, 173, 49, 49, 145, 4, 202, 209, 50, 101, 189, 176, 24, 180, 78, 175}, { 126, 241, 61, 126, 88, 254, 68, 131, 203, 154, 44, 212, 119, 88, 219, 254, 89, 65, 50, 11, 8, 187, 243, 76, 187, 52, 184, 66, 219, 151, 134, 14, 25, 206, 2, 127, 205, 216, 146, 199, 149, 155, 37, 90, 165, 47, 210, 232, 231, 233, 89, 161, 168, 56, 255, 165, 97, 95, 195, 2, 84, 3, 114, 100, 98, 48, 226, 177, 52, 143, 10, 123}, { 173, 39, 122, 122, 165, 143, 104, 227, 217, 157, 192, 83, 227, 120, 214, 126, 75, 233, 5, 244, 195, 240, 215, 11, 140, 45, 19, 77, 188, 57, 9, 219, 150, 125, 121, 181, 203, 247, 84, 62, 146, 68, 118, 125, 62, 196, 241, 30, 225, 143, 53, 247, 203, 12, 39, 131, 21, 57, 188, 252, 123, 112, 199, 120, 4, 251, 136, 104, 86, 63, 7, 7}};
                    int array_flip_vertical[82][72] = {{ 158, 215, 148, 188, 115, 160, 214, 241, 22, 212, 88, 249, 69, 96, 133, 200, 55, 133, 110, 95, 121, 162, 109, 248, 129, 248, 217, 130, 242, 127, 27, 220, 246, 109, 60, 36, 84, 196, 157, 241, 111, 114, 16, 111, 163, 202, 247, 146, 76, 75, 235, 5, 96, 62, 123, 139, 93, 105, 226, 32, 212, 91, 203, 254, 148, 170, 141, 93, 252, 180, 217, 73}, { 76, 151, 178, 133, 195, 130, 14, 31, 157, 135, 143, 148, 99, 155, 34, 211, 96, 222, 248, 96, 90, 250, 198, 68, 201, 154, 215, 18, 237, 88, 15, 25, 105, 9, 5, 230, 179, 246, 169, 89, 243, 19, 62, 56, 147, 108, 77, 121, 8, 78, 70, 194, 43, 113, 73, 5, 26, 222, 10, 140, 233, 237, 143, 246, 121, 229, 169, 153, 32, 165, 86, 219}, { 182, 111, 145, 41, 29, 19, 164, 217, 203, 208, 250, 182, 154, 54, 60, 60, 1, 44, 31, 84, 93, 95, 50, 65, 77, 255, 105, 15, 73, 231, 184, 194, 245, 133, 198, 110, 6, 193, 46, 201, 132, 42, 201, 215, 59, 240, 97, 41, 178, 106, 122, 241, 6, 13, 191, 127, 141, 30, 153, 71, 133, 114, 19, 240, 112, 171, 198, 234, 202, 246, 211, 98}, { 189, 246, 52, 100, 243, 174, 31, 71, 115, 133, 239, 227, 152, 36, 114, 154, 145, 146, 215, 41, 124, 26, 182, 173, 164, 67, 47, 164, 20, 254, 113, 195, 160, 204, 9, 196, 32, 33, 120, 158, 173, 61, 115, 85, 184, 179, 179, 106, 2, 242, 207, 68, 228, 247, 205, 137, 185, 132, 141, 104, 121, 33, 158, 247, 36, 245, 8, 74, 19, 252, 239, 69}, { 112, 46, 123, 232, 83, 117, 103, 35, 14, 225, 31, 26, 153, 190, 120, 149, 240, 179, 132, 91, 134, 111, 135, 25, 166, 138, 115, 246, 13, 88, 190, 204, 140, 171, 63, 167, 231, 166, 33, 14, 121, 217, 133, 71, 37, 104, 40, 97, 171, 58, 166, 177, 201, 218, 115, 60, 83, 186, 239, 9, 249, 8, 235, 50, 219, 127, 38, 187, 243, 76, 34, 17}, { 70, 133, 99, 192, 193, 153, 172, 254, 200, 206, 114, 43, 234, 18, 91, 91, 132, 121, 77, 222, 63, 172, 91, 232, 47, 203, 98, 127, 186, 20, 252, 87, 144, 13, 10, 87, 186, 79, 161, 57, 85, 0, 192, 75, 107, 120, 197, 216, 230, 202, 220, 21, 158, 138, 220, 96, 146, 160, 164, 41, 152, 182, 221, 223, 198, 165, 147, 11, 58, 123, 92, 116}, { 152, 63, 19, 202, 202, 210, 36, 163, 106, 19, 200, 128, 51, 140, 74, 188, 175, 189, 75, 13, 87, 60, 181, 100, 5, 49, 165, 9, 212, 72, 189, 172, 67, 175, 170, 239, 124, 40, 213, 38, 147, 254, 242, 27, 29, 71, 166, 2, 97, 255, 77, 77, 99, 208, 79, 109, 77, 124, 0, 253, 191, 154, 22, 235, 44, 205, 246, 46, 12, 201, 94, 94}, { 10, 74, 121, 104, 101, 220, 255, 165, 164, 92, 109, 114, 22, 13, 207, 119, 252, 22, 187, 202, 21, 112, 102, 161, 83, 208, 232, 26, 104, 169, 117, 211, 108, 152, 236, 185, 173, 95, 163, 114, 52, 191, 81, 51, 95, 249, 80, 30, 101, 223, 208, 52, 96, 229, 241, 25, 94, 81, 72, 19, 18, 41, 107, 193, 192, 166, 132, 57, 43, 255, 13, 7}, { 185, 246, 93, 251, 171, 255, 46, 91, 126, 82, 142, 30, 165, 253, 40, 192, 31, 87, 149, 62, 126, 86, 147, 206, 56, 162, 171, 18, 177, 90, 15, 105, 14, 42, 172, 249, 20, 97, 58, 94, 59, 125, 64, 57, 118, 125, 46, 108, 197, 106, 136, 221, 201, 89, 74, 187, 78, 93, 183, 169, 241, 231, 141, 139, 60, 14, 168, 153, 162, 236, 109, 102}, { 138, 107, 195, 21, 24, 199, 119, 58, 144, 58, 205, 19, 184, 67, 199, 176, 87, 176, 241, 230, 99, 172, 74, 11, 182, 73, 13, 20, 113, 170, 210, 76, 158, 36, 247, 78, 93, 67, 208, 219, 89, 109, 33, 219, 35, 76, 62, 128, 247, 132, 123, 231, 44, 206, 222, 196, 129, 88, 79, 196, 188, 215, 48, 91, 31, 25, 25, 189, 164, 28, 29, 97}, { 242, 44, 213, 193, 85, 158, 247, 223, 32, 88, 119, 0, 94, 108, 194, 69, 170, 135, 246, 45, 187, 195, 86, 48, 234, 211, 156, 205, 238, 31, 195, 243, 137, 121, 17, 184, 26, 114, 39, 174, 167, 27, 29, 155, 196, 150, 41, 245, 97, 120, 78, 137, 131, 230, 64, 108, 86, 9, 95, 108, 203, 87, 4, 208, 43, 236, 238, 0, 210, 202, 232, 175}, { 91, 162, 156, 140, 220, 183, 63, 57, 41, 197, 48, 91, 98, 64, 49, 141, 101, 209, 196, 244, 195, 159, 147, 215, 9, 45, 28, 159, 0, 218, 47, 115, 6, 35, 157, 153, 253, 140, 93, 163, 10, 137, 190, 216, 243, 68, 133, 52, 232, 2, 38, 21, 75, 235, 26, 182, 135, 176, 110, 60, 26, 28, 216, 29, 13, 48, 242, 67, 135, 116, 84, 87}, { 152, 215, 113, 140, 39, 115, 196, 156, 158, 80, 173, 144, 219, 182, 155, 255, 94, 209, 110, 103, 7, 128, 87, 170, 87, 32, 131, 16, 65, 88, 114, 250, 20, 196, 27, 239, 144, 74, 92, 164, 207, 10, 183, 255, 37, 235, 239, 116, 54, 198, 14, 31, 12, 82, 6, 38, 196, 107, 16, 178, 172, 134, 163, 65, 250, 162, 181, 194, 240, 66, 181, 29}, { 70, 165, 31, 231, 243, 228, 210, 221, 74, 167, 61, 241, 18, 174, 64, 200, 102, 169, 49, 156, 41, 67, 89, 171, 144, 169, 15, 79, 217, 7, 154, 3, 131, 85, 130, 112, 131, 220, 163, 186, 6, 28, 244, 23, 168, 180, 36, 162, 194, 166, 64, 133, 126, 98, 144, 249, 139, 43, 96, 121, 40, 111, 6, 64, 177, 183, 227, 178, 157, 49, 57, 107}, { 223, 40, 95, 147, 163, 185, 20, 166, 248, 47, 131, 194, 202, 31, 8, 175, 84, 15, 251, 230, 15, 128, 164, 78, 183, 112, 9, 65, 120, 26, 175, 104, 45, 131, 169, 197, 252, 142, 198, 121, 49, 42, 91, 75, 114, 62, 201, 33, 78, 156, 231, 154, 138, 94, 211, 171, 198, 129, 35, 147, 24, 94, 241, 169, 128, 120, 156, 83, 94, 219, 161, 166}, { 4, 59, 44, 50, 240, 243, 197, 81, 154, 23, 247, 44, 28, 161, 211, 140, 51, 9, 25, 144, 233, 255, 129, 46, 102, 96, 58, 37, 126, 65, 240, 220, 216, 23, 12, 8, 96, 236, 54, 190, 33, 117, 119, 52, 7, 188, 130, 64, 118, 253, 255, 118, 101, 35, 45, 187, 10, 169, 5, 46, 53, 71, 66, 38, 9, 70, 84, 41, 171, 74, 124, 3}, { 253, 190, 51, 23, 254, 6, 63, 85, 77, 33, 86, 175, 13, 15, 167, 60, 121, 40, 212, 97, 176, 172, 111, 156, 146, 171, 55, 222, 63, 146, 16, 107, 36, 80, 24, 24, 55, 144, 212, 79, 122, 167, 17, 42, 105, 234, 146, 142, 89, 36, 103, 48, 28, 220, 42, 236, 168, 145, 231, 232, 229, 143, 161, 36, 33, 27, 240, 195, 23, 206, 26, 78}, { 103, 69, 224, 13, 17, 146, 203, 7, 208, 166, 254, 85, 84, 132, 216, 245, 241, 17, 135, 169, 84, 29, 187, 232, 28, 191, 52, 0, 20, 172, 145, 249, 230, 120, 36, 157, 110, 12, 225, 158, 186, 81, 30, 153, 95, 150, 207, 62, 226, 142, 82, 150, 97, 153, 104, 27, 63, 201, 3, 44, 241, 233, 61, 154, 76, 89, 39, 199, 150, 32, 229, 225}, { 216, 105, 219, 137, 232, 23, 100, 209, 198, 231, 28, 55, 97, 183, 58, 145, 173, 103, 237, 97, 224, 111, 102, 219, 139, 92, 72, 203, 252, 101, 172, 2, 164, 21, 50, 238, 138, 188, 241, 156, 98, 175, 101, 243, 88, 80, 227, 11, 253, 197, 19, 244, 161, 148, 152, 223, 110, 213, 133, 16, 114, 0, 170, 169, 152, 1, 247, 111, 66, 89, 233, 0}, { 224, 140, 197, 131, 137, 203, 74, 195, 9, 95, 141, 86, 49, 98, 239, 15, 30, 97, 187, 94, 241, 34, 213, 222, 139, 239, 11, 139, 97, 144, 19, 127, 165, 248, 236, 136, 249, 16, 146, 238, 152, 182, 188, 106, 65, 174, 92, 141, 73, 5, 207, 3, 46, 167, 85, 208, 82, 21, 140, 58, 23, 209, 247, 60, 85, 50, 223, 184, 64, 249, 59, 77}, { 249, 118, 45, 21, 169, 83, 48, 145, 80, 173, 57, 25, 176, 55, 142, 26, 108, 207, 146, 79, 67, 170, 242, 147, 207, 158, 196, 113, 131, 118, 61, 17, 187, 101, 191, 143, 52, 188, 208, 91, 219, 25, 110, 55, 219, 233, 69, 74, 94, 238, 106, 75, 103, 117, 135, 74, 0, 12, 72, 128, 122, 53, 240, 222, 81, 255, 86, 143, 31, 163, 20, 211}, { 115, 194, 115, 32, 53, 75, 8, 117, 134, 123, 133, 252, 155, 78, 38, 220, 1, 65, 80, 226, 4, 188, 119, 134, 151, 173, 239, 248, 29, 1, 185, 193, 241, 87, 47, 206, 20, 86, 2, 128, 134, 238, 33, 244, 9, 87, 236, 95, 212, 235, 109, 149, 235, 94, 82, 94, 45, 254, 115, 201, 216, 67, 165, 204, 11, 63, 59, 212, 114, 164, 71, 152}, { 143, 19, 133, 133, 163, 7, 183, 212, 129, 182, 5, 132, 6, 12, 153, 157, 25, 144, 186, 119, 101, 157, 225, 44, 95, 233, 25, 29, 161, 105, 125, 57, 69, 61, 137, 29, 68, 128, 147, 66, 242, 21, 82, 88, 42, 214, 145, 142, 148, 84, 23, 225, 116, 223, 244, 199, 251, 55, 157, 157, 225, 62, 145, 76, 18, 238, 17, 249, 73, 225, 36, 240}, { 59, 18, 229, 53, 135, 17, 166, 204, 14, 55, 69, 2, 84, 44, 49, 220, 87, 89, 130, 204, 53, 57, 228, 179, 225, 71, 124, 115, 199, 51, 152, 195, 76, 199, 58, 14, 226, 151, 73, 72, 144, 58, 244, 39, 42, 80, 98, 150, 126, 47, 81, 130, 27, 111, 158, 178, 17, 128, 46, 27, 238, 230, 254, 53, 69, 72, 144, 155, 139, 228, 22, 106}, { 77, 190, 219, 227, 118, 157, 252, 226, 110, 170, 130, 175, 244, 160, 181, 166, 209, 93, 35, 229, 228, 80, 38, 24, 248, 189, 51, 243, 119, 152, 206, 204, 80, 89, 228, 229, 42, 184, 205, 211, 3, 85, 2, 145, 211, 163, 49, 193, 182, 73, 113, 30, 203, 141, 73, 216, 19, 185, 164, 253, 83, 90, 4, 225, 203, 245, 181, 5, 105, 55, 196, 244}, { 30, 117, 208, 132, 61, 122, 96, 155, 101, 99, 202, 116, 178, 121, 77, 23, 68, 191, 117, 212, 20, 142, 222, 40, 162, 105, 173, 202, 223, 197, 240, 239, 253, 63, 43, 192, 188, 17, 214, 153, 141, 29, 131, 18, 131, 113, 184, 209, 31, 177, 133, 244, 145, 43, 121, 159, 130, 156, 54, 226, 159, 196, 156, 13, 11, 160, 194, 8, 49, 97, 22, 94}, { 36, 158, 16, 112, 94, 211, 169, 197, 182, 191, 5, 71, 102, 47, 211, 184, 66, 7, 245, 96, 181, 12, 115, 221, 186, 53, 95, 112, 210, 184, 143, 196, 57, 175, 242, 180, 53, 120, 66, 237, 151, 63, 182, 112, 9, 128, 85, 253, 9, 22, 172, 135, 3, 79, 202, 123, 234, 147, 51, 49, 208, 106, 143, 184, 124, 203, 153, 167, 206, 101, 141, 239}, { 43, 46, 42, 213, 226, 159, 58, 159, 226, 73, 253, 22, 188, 50, 84, 33, 142, 182, 210, 115, 194, 103, 131, 221, 171, 236, 253, 94, 160, 249, 153, 63, 176, 59, 30, 196, 150, 104, 222, 113, 205, 43, 239, 255, 240, 108, 4, 42, 172, 11, 165, 31, 96, 134, 163, 79, 124, 134, 83, 72, 142, 127, 155, 166, 32, 53, 192, 238, 238, 75, 119, 106}, { 217, 150, 225, 168, 158, 120, 40, 126, 42, 19, 176, 104, 225, 91, 152, 244, 166, 24, 20, 111, 143, 200, 141, 213, 52, 233, 251, 203, 221, 85, 14, 131, 13, 77, 56, 138, 55, 106, 188, 47, 3, 212, 86, 50, 117, 251, 137, 92, 124, 170, 77, 73, 254, 26, 128, 32, 100, 55, 237, 55, 91, 235, 112, 195, 81, 39, 47, 67, 234, 231, 203, 71}, { 34, 13, 209, 53, 34, 48, 240, 220, 233, 68, 77, 43, 115, 18, 109, 245, 32, 191, 156, 87, 115, 213, 37, 15, 20, 190, 36, 120, 204, 59, 151, 10, 203, 39, 156, 47, 102, 138, 94, 85, 254, 212, 15, 129, 196, 89, 123, 33, 81, 227, 29, 104, 12, 127, 215, 197, 188, 90, 74, 122, 240, 48, 121, 84, 79, 108, 35, 169, 51, 146, 129, 93}, { 122, 146, 50, 39, 161, 31, 107, 80, 91, 43, 193, 238, 44, 29, 160, 84, 184, 143, 230, 101, 231, 56, 115, 110, 201, 215, 167, 74, 237, 1, 96, 142, 83, 91, 255, 92, 87, 61, 75, 32, 157, 189, 181, 168, 148, 81, 191, 81, 204, 185, 42, 191, 183, 233, 237, 233, 127, 233, 250, 47, 11, 186, 88, 220, 116, 121, 125, 44, 221, 134, 22, 242}, { 146, 130, 95, 222, 34, 84, 113, 250, 59, 162, 91, 117, 80, 187, 240, 107, 165, 146, 91, 79, 5, 159, 60, 111, 121, 30, 78, 92, 171, 33, 237, 214, 71, 138, 222, 0, 40, 42, 2, 83, 93, 188, 233, 123, 245, 34, 248, 151, 194, 107, 135, 148, 118, 231, 242, 90, 173, 97, 76, 146, 137, 169, 78, 52, 204, 74, 233, 220, 212, 26, 245, 203}, { 72, 202, 162, 141, 200, 88, 108, 24, 221, 122, 214, 114, 53, 115, 119, 67, 77, 145, 62, 115, 158, 136, 29, 10, 192, 29, 233, 128, 248, 147, 54, 36, 162, 138, 83, 178, 135, 120, 153, 104, 224, 128, 70, 182, 223, 52, 103, 85, 194, 42, 155, 233, 253, 78, 211, 115, 82, 100, 29, 190, 63, 43, 104, 232, 145, 38, 80, 195, 141, 123, 231, 8}, { 81, 84, 105, 158, 249, 54, 38, 168, 211, 167, 244, 25, 51, 226, 21, 34, 194, 76, 242, 66, 114, 97, 199, 235, 220, 243, 168, 40, 110, 31, 70, 249, 126, 59, 45, 135, 89, 4, 7, 117, 246, 250, 7, 144, 124, 128, 178, 226, 134, 152, 165, 88, 97, 96, 78, 0, 49, 72, 13, 185, 13, 52, 92, 55, 146, 210, 80, 142, 72, 145, 141, 139}, { 237, 74, 7, 230, 61, 35, 116, 162, 222, 156, 96, 230, 81, 94, 4, 129, 237, 201, 81, 3, 162, 222, 72, 88, 37, 137, 1, 250, 17, 173, 79, 218, 138, 215, 139, 90, 145, 215, 79, 122, 183, 160, 135, 149, 69, 244, 173, 105, 102, 85, 236, 93, 111, 167, 95, 59, 103, 116, 7, 144, 251, 72, 230, 219, 87, 12, 237, 68, 55, 77, 155, 225}, { 91, 180, 67, 38, 172, 27, 244, 74, 69, 163, 41, 68, 97, 245, 97, 49, 37, 57, 192, 169, 49, 108, 132, 28, 71, 73, 30, 56, 233, 107, 23, 30, 236, 57, 225, 218, 109, 91, 150, 12, 92, 174, 218, 173, 70, 105, 31, 205, 198, 155, 142, 181, 209, 30, 216, 254, 134, 217, 246, 109, 48, 180, 43, 235, 64, 125, 34, 241, 64, 22, 19, 55}, { 175, 223, 136, 171, 244, 50, 152, 207, 164, 143, 160, 73, 206, 12, 203, 74, 127, 103, 169, 5, 38, 172, 56, 125, 173, 34, 40, 234, 250, 18, 119, 56, 119, 239, 56, 28, 9, 40, 185, 43, 235, 163, 159, 224, 73, 92, 192, 219, 190, 3, 157, 78, 138, 163, 92, 115, 165, 46, 101, 76, 65, 227, 182, 44, 193, 224, 116, 125, 80, 243, 120, 2}, { 70, 70, 129, 173, 32, 168, 203, 78, 28, 150, 96, 9, 85, 133, 180, 126, 77, 113, 207, 133, 120, 34, 62, 43, 61, 150, 241, 119, 183, 231, 100, 118, 40, 103, 67, 170, 241, 228, 253, 70, 21, 69, 247, 24, 205, 43, 154, 4, 45, 224, 108, 158, 18, 120, 89, 230, 220, 246, 74, 219, 119, 137, 146, 206, 25, 142, 76, 25, 132, 126, 129, 82}, { 191, 164, 148, 67, 37, 13, 190, 179, 56, 240, 41, 215, 91, 17, 123, 212, 77, 55, 15, 37, 2, 223, 115, 230, 209, 27, 103, 231, 174, 156, 186, 48, 254, 137, 251, 73, 82, 172, 68, 203, 193, 142, 61, 84, 14, 77, 2, 218, 156, 237, 123, 54, 171, 111, 126, 96, 135, 82, 149, 57, 6, 40, 155, 189, 111, 202, 136, 7, 230, 213, 108, 212}, { 99, 127, 82, 21, 146, 179, 201, 201, 232, 150, 35, 162, 115, 130, 147, 147, 207, 129, 145, 86, 176, 183, 202, 188, 80, 92, 142, 74, 219, 112, 201, 4, 4, 6, 49, 38, 206, 91, 83, 178, 136, 61, 46, 245, 50, 117, 100, 154, 80, 216, 102, 156, 29, 161, 205, 124, 59, 228, 75, 195, 135, 86, 44, 226, 242, 17, 122, 98, 173, 246, 57, 0}, { 140, 101, 212, 27, 184, 162, 111, 33, 248, 99, 55, 39, 87, 41, 98, 230, 243, 255, 146, 128, 221, 201, 151, 237, 1, 141, 56, 191, 167, 52, 231, 27, 214, 198, 43, 6, 58, 227, 126, 168, 217, 75, 232, 51, 149, 192, 253, 5, 252, 251, 80, 154, 42, 241, 246, 214, 198, 246, 64, 238, 106, 113, 242, 209, 239, 101, 55, 235, 127, 249, 111, 130}, { 228, 202, 220, 169, 76, 243, 168, 72, 186, 28, 228, 76, 86, 141, 156, 133, 147, 78, 9, 206, 70, 22, 236, 183, 105, 148, 79, 56, 16, 31, 52, 137, 122, 188, 219, 114, 66, 10, 236, 203, 162, 160, 19, 43, 237, 87, 55, 155, 202, 203, 117, 191, 41, 2, 128, 200, 30, 87, 52, 120, 179, 128, 227, 55, 131, 167, 173, 101, 68, 215, 128, 6}, { 237, 105, 233, 62, 70, 27, 27, 20, 102, 167, 238, 7, 15, 62, 126, 185, 116, 102, 138, 77, 112, 253, 120, 95, 106, 86, 37, 42, 197, 106, 251, 156, 103, 105, 77, 29, 69, 154, 29, 215, 236, 146, 216, 79, 251, 249, 35, 107, 183, 230, 199, 247, 144, 65, 98, 176, 71, 188, 145, 115, 101, 196, 160, 37, 130, 56, 248, 247, 91, 202, 45, 250}, { 147, 89, 29, 251, 106, 175, 133, 222, 28, 182, 180, 224, 153, 110, 253, 60, 18, 166, 54, 124, 63, 251, 255, 27, 102, 86, 97, 7, 21, 220, 150, 63, 182, 245, 223, 185, 169, 165, 116, 184, 88, 27, 112, 56, 6, 97, 240, 18, 159, 187, 143, 35, 171, 229, 79, 199, 155, 75, 179, 69, 201, 30, 14, 186, 14, 193, 121, 47, 112, 148, 77, 206}, { 69, 149, 228, 19, 146, 243, 166, 113, 162, 159, 196, 19, 200, 113, 246, 113, 149, 124, 130, 2, 67, 175, 244, 208, 253, 152, 25, 43, 49, 88, 92, 98, 110, 103, 12, 243, 189, 111, 236, 251, 2, 62, 184, 111, 54, 60, 25, 9, 95, 240, 34, 218, 115, 129, 36, 235, 131, 62, 227, 174, 158, 105, 107, 232, 69, 57, 209, 171, 161, 57, 65, 124}, { 139, 147, 189, 17, 9, 203, 249, 18, 201, 247, 92, 215, 232, 226, 176, 188, 82, 219, 242, 236, 132, 142, 61, 238, 221, 20, 136, 177, 22, 20, 86, 213, 204, 174, 67, 81, 125, 73, 161, 6, 218, 198, 238, 245, 211, 94, 16, 116, 7, 188, 56, 192, 104, 171, 186, 21, 198, 51, 220, 189, 55, 196, 217, 100, 151, 200, 4, 13, 197, 248, 42, 250}, { 121, 189, 49, 79, 109, 233, 240, 136, 14, 82, 38, 4, 242, 9, 250, 19, 120, 43, 165, 130, 157, 59, 68, 19, 128, 144, 139, 21, 168, 27, 92, 69, 15, 186, 235, 9, 51, 12, 161, 64, 188, 138, 171, 104, 15, 143, 116, 227, 158, 161, 45, 67, 173, 115, 172, 178, 122, 174, 191, 61, 14, 141, 224, 31, 244, 247, 198, 30, 0, 35, 1, 229}, { 183, 39, 195, 192, 176, 111, 198, 19, 44, 36, 183, 164, 11, 21, 169, 179, 170, 31, 66, 33, 244, 253, 208, 204, 121, 35, 30, 242, 18, 98, 19, 7, 231, 178, 142, 215, 223, 216, 102, 128, 217, 178, 101, 26, 37, 236, 107, 123, 79, 114, 111, 65, 112, 132, 30, 168, 159, 164, 126, 51, 252, 219, 222, 32, 49, 81, 76, 177, 95, 5, 2, 148}, { 136, 192, 207, 168, 1, 158, 234, 8, 221, 122, 83, 187, 189, 220, 245, 167, 170, 103, 34, 157, 60, 111, 45, 172, 99, 228, 82, 77, 63, 44, 44, 96, 247, 4, 110, 238, 227, 62, 206, 64, 128, 153, 62, 18, 250, 141, 163, 233, 42, 20, 125, 201, 140, 84, 187, 166, 99, 229, 53, 29, 130, 253, 248, 114, 88, 122, 248, 41, 94, 72, 105, 189}, { 123, 78, 209, 35, 153, 178, 251, 110, 248, 110, 136, 201, 74, 102, 95, 85, 133, 21, 40, 214, 205, 77, 121, 105, 91, 254, 113, 168, 123, 105, 184, 11, 214, 19, 244, 12, 46, 211, 29, 199, 226, 72, 24, 246, 26, 209, 91, 177, 160, 4, 240, 137, 181, 177, 8, 158, 95, 118, 57, 148, 140, 209, 122, 183, 249, 24, 113, 137, 19, 92, 94, 32}, { 10, 243, 19, 139, 77, 27, 92, 91, 32, 234, 146, 192, 86, 87, 120, 148, 104, 50, 207, 11, 17, 121, 48, 226, 29, 153, 86, 238, 119, 42, 246, 170, 65, 218, 122, 161, 214, 106, 140, 98, 52, 218, 162, 89, 90, 203, 234, 229, 77, 185, 60, 213, 82, 35, 0, 148, 93, 117, 133, 73, 139, 4, 141, 244, 81, 194, 130, 204, 94, 100, 213, 142}, { 240, 236, 186, 74, 194, 169, 18, 96, 63, 152, 124, 210, 85, 179, 22, 57, 71, 67, 190, 213, 50, 41, 159, 44, 246, 254, 95, 64, 143, 228, 99, 132, 213, 109, 130, 242, 168, 30, 95, 19, 195, 238, 217, 39, 119, 66, 164, 50, 49, 164, 228, 213, 207, 172, 142, 182, 162, 147, 92, 199, 17, 37, 85, 14, 243, 17, 215, 166, 195, 222, 29, 182}, { 178, 77, 164, 222, 249, 104, 186, 168, 9, 142, 160, 95, 188, 230, 81, 99, 188, 47, 2, 227, 19, 191, 121, 35, 85, 42, 194, 89, 222, 21, 219, 251, 146, 48, 52, 213, 150, 60, 100, 108, 114, 98, 218, 66, 191, 133, 244, 253, 178, 130, 170, 68, 224, 14, 19, 51, 8, 40, 76, 180, 180, 108, 131, 147, 69, 149, 135, 62, 29, 187, 181, 121}, { 83, 99, 110, 99, 206, 13, 94, 87, 227, 7, 169, 254, 137, 152, 148, 32, 171, 62, 141, 71, 156, 174, 224, 219, 151, 20, 151, 178, 28, 57, 176, 63, 239, 95, 1, 186, 33, 112, 187, 243, 170, 192, 173, 118, 76, 224, 232, 17, 216, 70, 244, 126, 10, 61, 190, 114, 50, 169, 112, 213, 177, 236, 108, 191, 22, 102, 42, 174, 67, 240, 125, 250}, { 166, 66, 72, 150, 30, 71, 206, 197, 119, 214, 194, 73, 214, 146, 60, 57, 38, 47, 183, 143, 132, 84, 89, 36, 211, 152, 139, 105, 159, 145, 221, 124, 128, 2, 186, 159, 138, 24, 150, 2, 241, 102, 185, 130, 4, 143, 234, 200, 25, 188, 253, 35, 235, 5, 63, 86, 202, 234, 80, 12, 175, 63, 7, 241, 151, 251, 44, 188, 55, 210, 2, 48}, { 161, 44, 34, 151, 231, 66, 192, 92, 102, 149, 138, 92, 88, 244, 61, 178, 113, 42, 83, 255, 143, 58, 167, 89, 180, 255, 167, 206, 21, 173, 63, 178, 48, 151, 176, 147, 126, 188, 201, 242, 232, 81, 211, 32, 41, 135, 243, 191, 156, 236, 203, 201, 249, 115, 145, 117, 211, 141, 37, 173, 249, 86, 130, 14, 230, 253, 61, 142, 201, 48, 248, 139}, { 228, 34, 135, 131, 65, 237, 196, 156, 62, 152, 84, 44, 119, 162, 37, 43, 114, 22, 239, 125, 70, 226, 199, 204, 106, 46, 10, 201, 98, 61, 186, 81, 112, 107, 175, 207, 139, 187, 22, 230, 228, 201, 8, 170, 212, 92, 211, 13, 174, 56, 160, 192, 167, 128, 200, 128, 126, 49, 88, 223, 115, 126, 3, 41, 94, 31, 240, 116, 56, 4, 60, 159}, { 41, 128, 52, 116, 82, 128, 112, 15, 116, 242, 144, 148, 216, 23, 54, 126, 222, 157, 53, 154, 76, 11, 125, 231, 60, 208, 4, 180, 79, 157, 37, 0, 161, 10, 92, 201, 86, 135, 109, 33, 238, 55, 88, 75, 199, 85, 103, 134, 138, 127, 254, 223, 74, 37, 49, 226, 129, 173, 206, 91, 198, 246, 60, 140, 100, 218, 84, 136, 13, 106, 167, 53}, { 199, 128, 86, 120, 135, 149, 50, 215, 234, 21, 132, 58, 182, 198, 191, 8, 137, 194, 248, 142, 146, 191, 120, 35, 84, 163, 132, 32, 57, 211, 58, 101, 73, 162, 82, 62, 124, 45, 164, 42, 59, 146, 202, 106, 231, 54, 2, 86, 42, 138, 43, 233, 156, 227, 215, 69, 213, 109, 114, 111, 19, 67, 85, 239, 203, 148, 186, 190, 137, 142, 226, 254}, { 118, 96, 16, 95, 40, 63, 61, 170, 242, 193, 131, 60, 37, 3, 100, 34, 160, 126, 183, 240, 22, 233, 227, 216, 228, 45, 49, 232, 82, 112, 196, 127, 5, 69, 43, 58, 138, 80, 224, 239, 110, 182, 12, 125, 137, 51, 110, 1, 194, 67, 212, 237, 248, 170, 138, 222, 251, 210, 148, 175, 69, 90, 103, 252, 107, 47, 213, 70, 62, 8, 12, 198}, { 31, 170, 116, 85, 188, 22, 127, 145, 94, 218, 190, 95, 44, 35, 233, 233, 153, 9, 121, 1, 21, 179, 108, 156, 104, 101, 58, 146, 212, 162, 159, 229, 39, 250, 137, 197, 250, 185, 148, 201, 234, 220, 33, 17, 168, 130, 234, 9, 2, 115, 48, 46, 65, 196, 124, 1, 40, 142, 61, 154, 5, 215, 66, 78, 238, 232, 117, 107, 135, 198, 45, 38}, { 33, 242, 1, 60, 161, 235, 142, 219, 196, 80, 157, 238, 241, 121, 116, 74, 121, 127, 136, 135, 142, 212, 112, 29, 178, 161, 242, 211, 230, 155, 218, 93, 253, 2, 21, 196, 240, 0, 0, 202, 225, 128, 223, 64, 253, 13, 174, 245, 139, 33, 115, 70, 47, 157, 74, 214, 98, 136, 203, 111, 98, 75, 102, 198, 192, 150, 53, 2, 22, 46, 7, 186}, { 149, 129, 35, 35, 255, 163, 195, 164, 62, 152, 52, 180, 92, 198, 160, 220, 102, 7, 109, 11, 240, 45, 230, 133, 218, 224, 243, 96, 244, 179, 199, 202, 222, 243, 169, 168, 188, 150, 120, 115, 189, 158, 54, 199, 236, 63, 85, 94, 19, 192, 61, 129, 45, 151, 102, 5, 41, 253, 97, 195, 51, 20, 179, 228, 175, 242, 255, 80, 150, 214, 185, 69}, { 239, 51, 238, 62, 196, 118, 142, 13, 69, 76, 183, 76, 11, 110, 120, 231, 80, 213, 39, 227, 153, 10, 47, 20, 165, 126, 215, 19, 227, 246, 14, 202, 184, 40, 114, 157, 153, 209, 135, 52, 25, 178, 144, 81, 51, 148, 45, 194, 174, 87, 87, 93, 39, 181, 255, 106, 67, 183, 95, 4, 9, 73, 229, 106, 185, 207, 157, 117, 195, 90, 245, 25}, { 50, 217, 123, 60, 102, 202, 227, 115, 111, 72, 216, 108, 27, 43, 45, 196, 239, 118, 209, 176, 82, 166, 202, 162, 203, 168, 2, 195, 179, 130, 19, 22, 143, 78, 200, 243, 68, 105, 1, 252, 1, 21, 164, 74, 12, 15, 178, 250, 168, 129, 125, 241, 36, 107, 214, 75, 142, 166, 199, 52, 98, 75, 103, 153, 40, 255, 244, 206, 243, 14, 145, 112}, { 235, 172, 110, 128, 183, 240, 2, 172, 92, 109, 161, 112, 109, 204, 86, 101, 209, 140, 144, 153, 192, 110, 37, 217, 154, 0, 157, 99, 225, 242, 104, 12, 228, 160, 28, 183, 44, 147, 34, 161, 137, 30, 160, 180, 141, 52, 211, 42, 38, 247, 202, 60, 212, 130, 94, 135, 229, 48, 22, 166, 92, 193, 70, 106, 29, 190, 59, 78, 48, 28, 181, 123}, { 91, 182, 67, 100, 234, 217, 168, 248, 127, 15, 148, 128, 255, 70, 13, 75, 131, 185, 86, 100, 74, 9, 3, 242, 119, 3, 78, 137, 247, 30, 225, 179, 136, 71, 227, 254, 244, 64, 211, 200, 210, 70, 205, 173, 46, 75, 48, 113, 142, 26, 75, 119, 199, 41, 168, 224, 119, 237, 72, 196, 202, 235, 104, 15, 223, 110, 226, 24, 167, 14, 20, 113}, { 76, 129, 150, 174, 64, 108, 125, 172, 61, 85, 142, 4, 71, 220, 174, 147, 208, 255, 19, 124, 232, 43, 243, 95, 247, 230, 88, 85, 66, 152, 197, 220, 164, 104, 5, 27, 101, 230, 144, 77, 243, 122, 62, 84, 57, 206, 44, 153, 197, 141, 55, 61, 15, 89, 5, 249, 36, 173, 166, 86, 137, 127, 160, 103, 194, 44, 105, 158, 45, 198, 230, 240}, { 11, 139, 48, 105, 5, 55, 152, 92, 186, 222, 248, 140, 153, 48, 91, 242, 117, 216, 59, 191, 112, 246, 180, 3, 102, 233, 104, 224, 67, 222, 197, 135, 138, 250, 59, 38, 150, 156, 207, 32, 15, 208, 192, 14, 181, 90, 31, 44, 62, 228, 240, 165, 251, 243, 25, 144, 209, 167, 156, 56, 86, 61, 1, 220, 208, 162, 57, 155, 79, 113, 204, 100}, { 101, 192, 150, 50, 182, 95, 44, 21, 92, 2, 98, 150, 22, 21, 84, 52, 25, 123, 15, 216, 228, 214, 123, 99, 59, 182, 37, 105, 165, 81, 130, 103, 80, 34, 30, 118, 127, 233, 113, 106, 63, 75, 73, 212, 25, 9, 115, 226, 186, 109, 53, 98, 241, 236, 17, 101, 91, 149, 252, 97, 209, 49, 91, 126, 206, 218, 30, 225, 154, 7, 7, 130}, { 253, 53, 124, 37, 148, 60, 78, 255, 208, 199, 241, 70, 54, 20, 42, 242, 233, 41, 104, 240, 154, 92, 111, 86, 253, 28, 93, 29, 133, 110, 66, 64, 90, 224, 235, 228, 35, 204, 35, 113, 111, 239, 29, 245, 25, 184, 89, 187, 222, 224, 73, 125, 238, 250, 64, 39, 135, 218, 66, 37, 243, 222, 3, 255, 191, 76, 178, 22, 136, 41, 157, 195}, { 126, 190, 146, 16, 171, 243, 19, 83, 195, 34, 249, 132, 108, 0, 95, 179, 63, 100, 185, 187, 78, 138, 157, 243, 73, 74, 114, 42, 43, 70, 58, 154, 108, 78, 61, 160, 118, 148, 54, 71, 90, 185, 199, 40, 224, 230, 121, 67, 206, 121, 106, 67, 162, 38, 42, 142, 184, 139, 61, 127, 198, 117, 155, 180, 11, 32, 232, 210, 98, 97, 174, 59}, { 198, 78, 77, 207, 124, 99, 9, 226, 174, 166, 25, 237, 101, 135, 215, 94, 26, 196, 104, 152, 53, 125, 142, 12, 100, 77, 158, 93, 34, 1, 110, 243, 185, 213, 158, 11, 129, 41, 143, 12, 88, 208, 68, 136, 92, 158, 169, 13, 135, 147, 126, 250, 88, 76, 85, 185, 141, 184, 197, 170, 231, 133, 63, 20, 92, 114, 51, 74, 66, 143, 238, 79}, { 251, 110, 209, 157, 34, 254, 239, 217, 34, 92, 34, 89, 139, 201, 234, 173, 187, 26, 131, 75, 196, 192, 35, 142, 28, 227, 2, 22, 76, 87, 20, 250, 0, 168, 108, 122, 167, 86, 223, 212, 11, 193, 151, 234, 109, 32, 210, 68, 7, 131, 52, 70, 165, 243, 5, 186, 131, 175, 210, 148, 62, 212, 16, 196, 106, 194, 156, 231, 150, 25, 193, 1}, { 238, 113, 172, 4, 137, 220, 132, 128, 61, 97, 53, 189, 45, 235, 27, 107, 124, 76, 242, 107, 95, 78, 192, 129, 247, 15, 253, 139, 226, 239, 88, 232, 151, 241, 220, 160, 228, 193, 221, 6, 62, 240, 46, 123, 211, 24, 116, 173, 160, 38, 48, 145, 211, 26, 35, 186, 81, 246, 5, 73, 204, 18, 135, 142, 228, 241, 22, 208, 241, 68, 13, 29}, { 158, 10, 218, 124, 47, 16, 223, 236, 116, 251, 108, 53, 219, 83, 159, 142, 243, 135, 214, 86, 98, 52, 166, 126, 48, 230, 45, 90, 26, 19, 223, 107, 179, 140, 122, 40, 66, 139, 4, 179, 69, 125, 20, 249, 93, 208, 121, 182, 81, 194, 95, 194, 45, 76, 137, 149, 65, 62, 51, 62, 3, 155, 245, 82, 195, 9, 96, 103, 76, 17, 83, 148}, { 65, 145, 207, 164, 143, 189, 255, 177, 197, 42, 190, 23, 197, 169, 148, 113, 72, 225, 254, 67, 144, 184, 22, 88, 136, 18, 26, 251, 161, 210, 40, 70, 170, 118, 236, 184, 201, 17, 244, 82, 206, 252, 109, 167, 115, 22, 138, 205, 252, 57, 239, 76, 96, 155, 146, 116, 19, 249, 27, 245, 110, 247, 138, 205, 184, 88, 206, 239, 25, 136, 198, 236}, { 144, 117, 94, 248, 21, 64, 15, 9, 78, 96, 168, 212, 160, 83, 243, 203, 148, 91, 204, 40, 58, 30, 201, 19, 169, 19, 17, 164, 152, 190, 237, 63, 126, 92, 42, 24, 248, 88, 14, 154, 237, 15, 228, 126, 252, 162, 144, 190, 215, 124, 174, 115, 110, 97, 193, 108, 97, 116, 43, 245, 40, 15, 57, 5, 0, 65, 232, 86, 193, 254, 136, 17}, { 22, 158, 106, 159, 117, 121, 193, 102, 228, 206, 127, 13, 119, 30, 159, 16, 70, 97, 151, 94, 226, 243, 154, 216, 134, 55, 141, 255, 64, 99, 86, 195, 208, 140, 2, 164, 36, 187, 225, 114, 7, 223, 146, 218, 123, 215, 46, 120, 143, 199, 250, 122, 229, 66, 159, 251, 152, 117, 232, 248, 123, 192, 114, 197, 49, 223, 114, 31, 226, 156, 74, 246}, { 175, 78, 180, 24, 176, 189, 101, 50, 209, 202, 4, 145, 49, 49, 173, 68, 36, 101, 135, 85, 191, 206, 125, 52, 51, 54, 38, 19, 86, 154, 47, 152, 126, 78, 45, 25, 214, 158, 253, 130, 8, 5, 177, 122, 208, 37, 71, 120, 14, 118, 146, 218, 161, 228, 238, 160, 205, 225, 138, 21, 248, 150, 29, 45, 163, 125, 216, 228, 91, 130, 231, 28}, { 123, 10, 143, 52, 177, 226, 48, 98, 100, 114, 3, 84, 2, 195, 95, 97, 165, 255, 56, 168, 161, 89, 233, 231, 232, 210, 47, 165, 90, 37, 155, 149, 199, 146, 216, 205, 127, 2, 206, 25, 14, 134, 151, 219, 66, 184, 52, 187, 76, 243, 187, 8, 11, 50, 65, 89, 254, 219, 88, 119, 212, 44, 154, 203, 131, 68, 254, 88, 126, 61, 241, 126}, { 7, 7, 63, 86, 104, 136, 251, 4, 120, 199, 112, 123, 252, 188, 57, 21, 131, 39, 12, 203, 247, 53, 143, 225, 30, 241, 196, 62, 125, 118, 68, 146, 62, 84, 247, 203, 181, 121, 125, 150, 219, 9, 57, 188, 77, 19, 45, 140, 11, 215, 240, 195, 244, 5, 233, 75, 126, 214, 120, 227, 83, 192, 157, 217, 227, 104, 143, 165, 122, 122, 39, 173}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("collect.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 72, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 72, a ustawiła na %d", arr->width);
                    test_error(arr->height == 82, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 82, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 82; ++i)
                        for (int j = 0; j < 72; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    for (int i = 0; i < 82; ++i)
                        for (int j = 0; j < 72; ++j)
                            test_error(arr_flip_vertical->ptr[i][j] == array_flip_vertical[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_vertical[i][j], arr_flip_vertical->ptr[i][j]);


                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&arr_flip_vertical);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 96: Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 246 bajtów)
//
void UTEST96(void)
{
    // informacje o teście
    test_start(96, "Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 246 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(246);
    
    //
    // -----------
    //
    

                int array[3][6] = {{ 206, 252, 186, 24, 120, 10}, { 210, 119, 118, 72, 79, 56}, { 72, 225, 159, 168, 118, 187}};
                int array_flip_vertical[3][6] = {{ 10, 120, 24, 186, 252, 206}, { 56, 79, 72, 118, 119, 210}, { 187, 118, 168, 159, 225, 72}};

                int err_code = 4;

                printf("#####START#####");                            
                struct image_t *arr = load_image_t("son.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                test_error(arr->height == 3, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 3, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                    for (int j = 0; j < 6; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                printf("#####START#####");                            
                struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                printf("#####END#####");

                for (int i = 0; i < 3; ++i)
                    for (int j = 0; j < 6; ++j)
                        test_error(arr_flip_vertical->ptr[i][j] == array_flip_vertical[i][j], "Funkcja image_flip_vertical() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_flip_vertical[i][j], arr_flip_vertical->ptr[i][j]);


                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                printf("#####START#####");
                destroy_image(&arr_flip_vertical);
                printf("#####END#####");

                test_error(arr_flip_vertical == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 97: Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 123 bajtów)
//
void UTEST97(void)
{
    // informacje o teście
    test_start(97, "Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 123 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(123);
    
    //
    // -----------
    //
    

                    int array[3][6] = {{ 206, 252, 186, 24, 120, 10}, { 210, 119, 118, 72, 79, 56}, { 72, 225, 159, 168, 118, 187}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("son.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 3, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 3, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 3; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 98: Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 147 bajtów)
//
void UTEST98(void)
{
    // informacje o teście
    test_start(98, "Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 147 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(147);
    
    //
    // -----------
    //
    

                    int array[3][6] = {{ 206, 252, 186, 24, 120, 10}, { 210, 119, 118, 72, 79, 56}, { 72, 225, 159, 168, 118, 187}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("son.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 3, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 3, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 3; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 99: Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 171 bajtów)
//
void UTEST99(void)
{
    // informacje o teście
    test_start(99, "Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 171 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(171);
    
    //
    // -----------
    //
    

                    int array[3][6] = {{ 206, 252, 186, 24, 120, 10}, { 210, 119, 118, 72, 79, 56}, { 72, 225, 159, 168, 118, 187}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("son.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 3, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 3, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 3; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 100: Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 195 bajtów)
//
void UTEST100(void)
{
    // informacje o teście
    test_start(100, "Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 195 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(195);
    
    //
    // -----------
    //
    

                    int array[3][6] = {{ 206, 252, 186, 24, 120, 10}, { 210, 119, 118, 72, 79, 56}, { 72, 225, 159, 168, 118, 187}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("son.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 3, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 3, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 3; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 101: Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 219 bajtów)
//
void UTEST101(void)
{
    // informacje o teście
    test_start(101, "Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 219 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(219);
    
    //
    // -----------
    //
    

                    int array[3][6] = {{ 206, 252, 186, 24, 120, 10}, { 210, 119, 118, 72, 79, 56}, { 72, 225, 159, 168, 118, 187}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("son.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 3, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 3, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 3; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 102: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST102(void)
{
    // informacje o teście
    test_start(102, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");                            
                struct image_t *arr_flip_vertical = image_flip_vertical(NULL);
                printf("#####END#####");

                test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 103: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST103(void)
{
    // informacje o teście
    test_start(103, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 153, 166, 90, 145, 15, 33}, { 218, 129, 30, 41, 183, 174}, { 96, 144, 30, 209, 51, 223}, { 255, 25, 60, 136, 118, 187}, { 221, 184, 156, 121, 138, 48}, { 37, 122, 171, 224, 13, 72}, { 42, 25, 251, 161, 132, 14}, { 42, 231, 232, 158, 200, 84}, { 54, 91, 78, 246, 167, 51}, { 66, 111, 22, 33, 15, 132}, { 236, 23, 119, 103, 135, 114}, { 95, 188, 83, 106, 54, 165}, { 151, 166, 246, 120, 241, 62}, { 12, 99, 204, 142, 1, 176}, { 206, 152, 136, 243, 71, 51}, { 127, 208, 11, 70, 236, 62}, { 197, 18, 141, 141, 222, 10}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("it.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 6;
                    arr->height = -17;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 6;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 104: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST104(void)
{
    // informacje o teście
    test_start(104, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 153, 166, 90, 145, 15, 33}, { 218, 129, 30, 41, 183, 174}, { 96, 144, 30, 209, 51, 223}, { 255, 25, 60, 136, 118, 187}, { 221, 184, 156, 121, 138, 48}, { 37, 122, 171, 224, 13, 72}, { 42, 25, 251, 161, 132, 14}, { 42, 231, 232, 158, 200, 84}, { 54, 91, 78, 246, 167, 51}, { 66, 111, 22, 33, 15, 132}, { 236, 23, 119, 103, 135, 114}, { 95, 188, 83, 106, 54, 165}, { 151, 166, 246, 120, 241, 62}, { 12, 99, 204, 142, 1, 176}, { 206, 152, 136, 243, 71, 51}, { 127, 208, 11, 70, 236, 62}, { 197, 18, 141, 141, 222, 10}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("it.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -6;
                    arr->height = -17;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 6;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 105: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST105(void)
{
    // informacje o teście
    test_start(105, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 153, 166, 90, 145, 15, 33}, { 218, 129, 30, 41, 183, 174}, { 96, 144, 30, 209, 51, 223}, { 255, 25, 60, 136, 118, 187}, { 221, 184, 156, 121, 138, 48}, { 37, 122, 171, 224, 13, 72}, { 42, 25, 251, 161, 132, 14}, { 42, 231, 232, 158, 200, 84}, { 54, 91, 78, 246, 167, 51}, { 66, 111, 22, 33, 15, 132}, { 236, 23, 119, 103, 135, 114}, { 95, 188, 83, 106, 54, 165}, { 151, 166, 246, 120, 241, 62}, { 12, 99, 204, 142, 1, 176}, { 206, 152, 136, 243, 71, 51}, { 127, 208, 11, 70, 236, 62}, { 197, 18, 141, 141, 222, 10}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("it.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -6;
                    arr->height = 17;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 6;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 106: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST106(void)
{
    // informacje o teście
    test_start(106, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 153, 166, 90, 145, 15, 33}, { 218, 129, 30, 41, 183, 174}, { 96, 144, 30, 209, 51, 223}, { 255, 25, 60, 136, 118, 187}, { 221, 184, 156, 121, 138, 48}, { 37, 122, 171, 224, 13, 72}, { 42, 25, 251, 161, 132, 14}, { 42, 231, 232, 158, 200, 84}, { 54, 91, 78, 246, 167, 51}, { 66, 111, 22, 33, 15, 132}, { 236, 23, 119, 103, 135, 114}, { 95, 188, 83, 106, 54, 165}, { 151, 166, 246, 120, 241, 62}, { 12, 99, 204, 142, 1, 176}, { 206, 152, 136, 243, 71, 51}, { 127, 208, 11, 70, 236, 62}, { 197, 18, 141, 141, 222, 10}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("it.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 6;
                    arr->height = 0;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 6;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 107: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST107(void)
{
    // informacje o teście
    test_start(107, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 153, 166, 90, 145, 15, 33}, { 218, 129, 30, 41, 183, 174}, { 96, 144, 30, 209, 51, 223}, { 255, 25, 60, 136, 118, 187}, { 221, 184, 156, 121, 138, 48}, { 37, 122, 171, 224, 13, 72}, { 42, 25, 251, 161, 132, 14}, { 42, 231, 232, 158, 200, 84}, { 54, 91, 78, 246, 167, 51}, { 66, 111, 22, 33, 15, 132}, { 236, 23, 119, 103, 135, 114}, { 95, 188, 83, 106, 54, 165}, { 151, 166, 246, 120, 241, 62}, { 12, 99, 204, 142, 1, 176}, { 206, 152, 136, 243, 71, 51}, { 127, 208, 11, 70, 236, 62}, { 197, 18, 141, 141, 222, 10}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("it.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 17;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 6;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 108: Sprawdzanie poprawności działania funkcji image_flip_vertical
//
void UTEST108(void)
{
    // informacje o teście
    test_start(108, "Sprawdzanie poprawności działania funkcji image_flip_vertical", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 153, 166, 90, 145, 15, 33}, { 218, 129, 30, 41, 183, 174}, { 96, 144, 30, 209, 51, 223}, { 255, 25, 60, 136, 118, 187}, { 221, 184, 156, 121, 138, 48}, { 37, 122, 171, 224, 13, 72}, { 42, 25, 251, 161, 132, 14}, { 42, 231, 232, 158, 200, 84}, { 54, 91, 78, 246, 167, 51}, { 66, 111, 22, 33, 15, 132}, { 236, 23, 119, 103, 135, 114}, { 95, 188, 83, 106, 54, 165}, { 151, 166, 246, 120, 241, 62}, { 12, 99, 204, 142, 1, 176}, { 206, 152, 136, 243, 71, 51}, { 127, 208, 11, 70, 236, 62}, { 197, 18, 141, 141, 222, 10}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("it.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");                            
                    struct image_t *arr_flip_vertical = image_flip_vertical(arr);
                    printf("#####END#####");

                    test_error(arr_flip_vertical == NULL, "Funkcja image_flip_vertical() powinna przypisać NULL pod wskaźnik przekazany w parametrze w przypadku niepowodzenia alokacji pamięci");

                    arr->width = 6;
                    arr->height = 17;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 109: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST109(void)
{
    // informacje o teście
    test_start(109, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][9] = {{ 19, 32, 137, 49, 139, 220, 140, 60, 146}, { 201, 163, 60, 52, 112, 119, 30, 51, 185}, { 177, 65, 45, 221, 174, 191, 125, 177, 175}, { 100, 11, 98, 79, 184, 43, 238, 12, 58}, { 152, 50, 124, 64, 157, 82, 210, 181, 233}, { 88, 191, 145, 253, 23, 205, 45, 61, 16}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("team.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 6; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("noon.bin", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 110: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST110(void)
{
    // informacje o teście
    test_start(110, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[18][8] = {{ 11, 191, 105, 164, 177, 153, 124, 51}, { 141, 213, 101, 249, 205, 73, 217, 107}, { 77, 106, 12, 193, 49, 42, 69, 85}, { 137, 229, 218, 120, 53, 252, 235, 68}, { 171, 126, 238, 54, 1, 79, 134, 65}, { 65, 53, 212, 204, 33, 154, 92, 92}, { 77, 72, 174, 63, 11, 181, 225, 13}, { 151, 122, 84, 230, 195, 0, 162, 225}, { 241, 163, 49, 16, 21, 173, 138, 48}, { 57, 246, 236, 169, 225, 208, 133, 92}, { 89, 86, 175, 78, 214, 134, 216, 114}, { 154, 132, 169, 58, 148, 255, 0, 218}, { 214, 250, 222, 19, 200, 92, 243, 80}, { 100, 79, 136, 60, 224, 182, 233, 60}, { 61, 6, 202, 3, 16, 150, 84, 180}, { 57, 238, 241, 17, 244, 10, 150, 207}, { 230, 176, 203, 19, 187, 88, 103, 28}, { 10, 8, 180, 234, 20, 182, 196, 96}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("allow.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("spell.txt", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 111: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST111(void)
{
    // informacje o teście
    test_start(111, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][1] = {{ 156}, { 30}, { 78}, { 118}, { 89}, { 136}, { 202}, { 249}, { 124}, { 43}, { 72}, { 214}, { 47}, { 21}, { 94}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("side.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("dotxt", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 112: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST112(void)
{
    // informacje o teście
    test_start(112, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][10] = {{ 24, 172, 216, 25, 82, 129, 163, 193, 57, 41}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("silver.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("part", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 113: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST113(void)
{
    // informacje o teście
    test_start(113, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 111}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("silent.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("materialdesignthattellofwholebegindropseparateflat", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 114: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST114(void)
{
    // informacje o teście
    test_start(114, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[18][5] = {{ 17, 225, 223, 243, 161}, { 115, 245, 99, 228, 157}, { 13, 77, 166, 47, 95}, { 16, 171, 105, 231, 236}, { 181, 64, 104, 0, 36}, { 134, 1, 210, 135, 84}, { 203, 231, 54, 252, 159}, { 240, 19, 100, 55, 44}, { 125, 21, 195, 170, 9}, { 53, 123, 147, 57, 14}, { 75, 189, 147, 43, 252}, { 243, 8, 3, 229, 146}, { 49, 69, 163, 133, 28}, { 54, 163, 52, 141, 76}, { 199, 56, 255, 111, 142}, { 241, 243, 206, 57, 94}, { 10, 99, 77, 44, 189}, { 72, 97, 252, 244, 128}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 5;
                    arr->height = -18;

                    printf("#####START#####");                            
                    int res = save_image_t("silent.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 18;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 115: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST115(void)
{
    // informacje o teście
    test_start(115, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[18][5] = {{ 17, 225, 223, 243, 161}, { 115, 245, 99, 228, 157}, { 13, 77, 166, 47, 95}, { 16, 171, 105, 231, 236}, { 181, 64, 104, 0, 36}, { 134, 1, 210, 135, 84}, { 203, 231, 54, 252, 159}, { 240, 19, 100, 55, 44}, { 125, 21, 195, 170, 9}, { 53, 123, 147, 57, 14}, { 75, 189, 147, 43, 252}, { 243, 8, 3, 229, 146}, { 49, 69, 163, 133, 28}, { 54, 163, 52, 141, 76}, { 199, 56, 255, 111, 142}, { 241, 243, 206, 57, 94}, { 10, 99, 77, 44, 189}, { 72, 97, 252, 244, 128}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -5;
                    arr->height = -18;

                    printf("#####START#####");                            
                    int res = save_image_t("silent.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 18;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 116: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST116(void)
{
    // informacje o teście
    test_start(116, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[18][5] = {{ 17, 225, 223, 243, 161}, { 115, 245, 99, 228, 157}, { 13, 77, 166, 47, 95}, { 16, 171, 105, 231, 236}, { 181, 64, 104, 0, 36}, { 134, 1, 210, 135, 84}, { 203, 231, 54, 252, 159}, { 240, 19, 100, 55, 44}, { 125, 21, 195, 170, 9}, { 53, 123, 147, 57, 14}, { 75, 189, 147, 43, 252}, { 243, 8, 3, 229, 146}, { 49, 69, 163, 133, 28}, { 54, 163, 52, 141, 76}, { 199, 56, 255, 111, 142}, { 241, 243, 206, 57, 94}, { 10, 99, 77, 44, 189}, { 72, 97, 252, 244, 128}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -5;
                    arr->height = 18;

                    printf("#####START#####");                            
                    int res = save_image_t("silent.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 18;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 117: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST117(void)
{
    // informacje o teście
    test_start(117, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[18][5] = {{ 17, 225, 223, 243, 161}, { 115, 245, 99, 228, 157}, { 13, 77, 166, 47, 95}, { 16, 171, 105, 231, 236}, { 181, 64, 104, 0, 36}, { 134, 1, 210, 135, 84}, { 203, 231, 54, 252, 159}, { 240, 19, 100, 55, 44}, { 125, 21, 195, 170, 9}, { 53, 123, 147, 57, 14}, { 75, 189, 147, 43, 252}, { 243, 8, 3, 229, 146}, { 49, 69, 163, 133, 28}, { 54, 163, 52, 141, 76}, { 199, 56, 255, 111, 142}, { 241, 243, 206, 57, 94}, { 10, 99, 77, 44, 189}, { 72, 97, 252, 244, 128}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 5;
                    arr->height = 0;

                    printf("#####START#####");                            
                    int res = save_image_t("silent.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 18;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 118: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST118(void)
{
    // informacje o teście
    test_start(118, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[18][5] = {{ 17, 225, 223, 243, 161}, { 115, 245, 99, 228, 157}, { 13, 77, 166, 47, 95}, { 16, 171, 105, 231, 236}, { 181, 64, 104, 0, 36}, { 134, 1, 210, 135, 84}, { 203, 231, 54, 252, 159}, { 240, 19, 100, 55, 44}, { 125, 21, 195, 170, 9}, { 53, 123, 147, 57, 14}, { 75, 189, 147, 43, 252}, { 243, 8, 3, 229, 146}, { 49, 69, 163, 133, 28}, { 54, 163, 52, 141, 76}, { 199, 56, 255, 111, 142}, { 241, 243, 206, 57, 94}, { 10, 99, 77, 44, 189}, { 72, 97, 252, 244, 128}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 18;

                    printf("#####START#####");                            
                    int res = save_image_t("silent.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 18;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 119: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST119(void)
{
    // informacje o teście
    test_start(119, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[18][5] = {{ 17, 225, 223, 243, 161}, { 115, 245, 99, 228, 157}, { 13, 77, 166, 47, 95}, { 16, 171, 105, 231, 236}, { 181, 64, 104, 0, 36}, { 134, 1, 210, 135, 84}, { 203, 231, 54, 252, 159}, { 240, 19, 100, 55, 44}, { 125, 21, 195, 170, 9}, { 53, 123, 147, 57, 14}, { 75, 189, 147, 43, 252}, { 243, 8, 3, 229, 146}, { 49, 69, 163, 133, 28}, { 54, 163, 52, 141, 76}, { 199, 56, 255, 111, 142}, { 241, 243, 206, 57, 94}, { 10, 99, 77, 44, 189}, { 72, 97, 252, 244, 128}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");                            
                    int res = save_image_t("silent.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 18;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 120: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST120(void)
{
    // informacje o teście
    test_start(120, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[18][5] = {{ 17, 225, 223, 243, 161}, { 115, 245, 99, 228, 157}, { 13, 77, 166, 47, 95}, { 16, 171, 105, 231, 236}, { 181, 64, 104, 0, 36}, { 134, 1, 210, 135, 84}, { 203, 231, 54, 252, 159}, { 240, 19, 100, 55, 44}, { 125, 21, 195, 170, 9}, { 53, 123, 147, 57, 14}, { 75, 189, 147, 43, 252}, { 243, 8, 3, 229, 146}, { 49, 69, 163, 133, 28}, { 54, 163, 52, 141, 76}, { 199, 56, 255, 111, 142}, { 241, 243, 206, 57, 94}, { 10, 99, 77, 44, 189}, { 72, 97, 252, 244, 128}};

                int err_code = 1;

                printf("#####START#####");                            
                struct image_t *arr = load_image_t("hard.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 18; ++i)
                    for (int j = 0; j < 5; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                arr->width = 0;
                arr->height = 0;

                printf("#####START#####");                            
                int res = save_image_t(NULL, arr);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                arr->width = 5;
                arr->height = 18;            

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 121: Reakcja funkcji save_image_t na brak możliwości utworzenia pliku (fopen zwróci NULL przy drugim wywołaniu)
//
void UTEST121(void)
{
    // informacje o teście
    test_start(121, "Reakcja funkcji save_image_t na brak możliwości utworzenia pliku (fopen zwróci NULL przy drugim wywołaniu)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 1);
    
    //
    // -----------
    //
    

                int array[18][5] = {{ 17, 225, 223, 243, 161}, { 115, 245, 99, 228, 157}, { 13, 77, 166, 47, 95}, { 16, 171, 105, 231, 236}, { 181, 64, 104, 0, 36}, { 134, 1, 210, 135, 84}, { 203, 231, 54, 252, 159}, { 240, 19, 100, 55, 44}, { 125, 21, 195, 170, 9}, { 53, 123, 147, 57, 14}, { 75, 189, 147, 43, 252}, { 243, 8, 3, 229, 146}, { 49, 69, 163, 133, 28}, { 54, 163, 52, 141, 76}, { 199, 56, 255, 111, 142}, { 241, 243, 206, 57, 94}, { 10, 99, 77, 44, 189}, { 72, 97, 252, 244, 128}};

                int err_code = 4;

                printf("#####START#####");                            
                struct image_t *arr = load_image_t("hard.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 18; ++i)
                    for (int j = 0; j < 5; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                printf("#####START#####");                            
                int res = save_image_t("silent.bin", arr);
                printf("#####END#####");

                test_error(res == 2, "Funkcja save_image_t() powinna zwrócić kod błędu 2, a zwróciła %d", res);

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 122: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST122(void)
{
    // informacje o teście
    test_start(122, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct image_t arr = {.ptr = NULL, .width = 6, .height = 4, .type = "P2" };

                printf("#####START#####");
                int res = save_image_t("hard.bin", &arr);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 123: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST123(void)
{
    // informacje o teście
    test_start(123, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = save_image_t("hard.bin", NULL);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 124: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST124(void)
{
    // informacje o teście
    test_start(124, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = save_image_t(NULL, NULL);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja bład funkcji fopen (dozwolone 1-krotne wywołanie fopen)
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja bład funkcji fopen (dozwolone 1-krotne wywołanie fopen)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 1);
    
    //
    // -----------
    //
    
                printf("Kolejny test pamięci");
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 0, "Funkcja main zakończyła się kodem %d a powinna 0", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja bład funkcji fopen (dozwolone 2-krotne wywołanie fopen)
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja bład funkcji fopen (dozwolone 2-krotne wywołanie fopen)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 2);
    
    //
    // -----------
    //
    
                printf("Kolejny test pamięci");
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 0, "Funkcja main zakończyła się kodem %d a powinna 0", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja bład funkcji fopen (dozwolone 3-krotne wywołanie fopen)
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja bład funkcji fopen (dozwolone 3-krotne wywołanie fopen)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 3);
    
    //
    // -----------
    //
    
                printf("Kolejny test pamięci");
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 0, "Funkcja main zakończyła się kodem %d a powinna 0", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na brak pamięci - limit ustawiony na 0 bajtów
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na brak pamięci - limit ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Reakcja na brak pamięci - limit ustawiony na 40 bajtów
//
void MTEST5(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(5, "Reakcja na brak pamięci - limit ustawiony na 40 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(40);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Reakcja na brak pamięci - limit ustawiony na 200 bajtów
//
void MTEST6(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(6, "Reakcja na brak pamięci - limit ustawiony na 200 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(200);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Reakcja na brak pamięci - limit ustawiony na 360 bajtów
//
void MTEST7(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(7, "Reakcja na brak pamięci - limit ustawiony na 360 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(360);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST2, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST3, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST4, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST5, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST6, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST7, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST8, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST9, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST10, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST11, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST12, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST13, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST14, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST15, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST16, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST17, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST18, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST19, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST20, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST21, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST22, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST23, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST24, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST25, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST26, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST27, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST28, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST29, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST30, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST31, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST32, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST33, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST34, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST35, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 187 bajtów)
            UTEST36, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
            UTEST37, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
            UTEST38, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
            UTEST39, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 59 bajtów)
            UTEST40, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 91 bajtów)
            UTEST41, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 123 bajtów)
            UTEST42, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 155 bajtów)
            UTEST43, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
            UTEST44, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
            UTEST45, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
            UTEST46, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 59 bajtów)
            UTEST47, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 91 bajtów)
            UTEST48, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 123 bajtów)
            UTEST49, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 155 bajtów)
            UTEST50, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST51, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST52, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST53, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST54, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST55, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST56, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST57, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST58, // Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 246 bajtów)
            UTEST59, // Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 123 bajtów)
            UTEST60, // Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 147 bajtów)
            UTEST61, // Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 163 bajtów)
            UTEST62, // Sprawdzanie reakcji funkcji image_negate na limit pamięci (limit sterty ustawiono na 203 bajtów)
            UTEST63, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST64, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST65, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST66, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST67, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST68, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST69, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST70, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST71, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST72, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST73, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST74, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST75, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST76, // Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 438 bajtów)
            UTEST77, // Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 219 bajtów)
            UTEST78, // Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 243 bajtów)
            UTEST79, // Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 275 bajtów)
            UTEST80, // Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 315 bajtów)
            UTEST81, // Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 355 bajtów)
            UTEST82, // Sprawdzanie reakcji funkcji image_flip_horizontal na limit pamięci (limit sterty ustawiono na 395 bajtów)
            UTEST83, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST84, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST85, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST86, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST87, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST88, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST89, // Sprawdzanie poprawności działania funkcji image_flip_horizontal
            UTEST90, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST91, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST92, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST93, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST94, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST95, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST96, // Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 246 bajtów)
            UTEST97, // Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 123 bajtów)
            UTEST98, // Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 147 bajtów)
            UTEST99, // Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 171 bajtów)
            UTEST100, // Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 195 bajtów)
            UTEST101, // Sprawdzanie reakcji funkcji image_flip_vertical na limit pamięci (limit sterty ustawiono na 219 bajtów)
            UTEST102, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST103, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST104, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST105, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST106, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST107, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST108, // Sprawdzanie poprawności działania funkcji image_flip_vertical
            UTEST109, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST110, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST111, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST112, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST113, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST114, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST115, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST116, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST117, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST118, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST119, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST120, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST121, // Reakcja funkcji save_image_t na brak możliwości utworzenia pliku (fopen zwróci NULL przy drugim wywołaniu)
            UTEST122, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST123, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST124, // Sprawdzanie poprawności działania funkcji save_image_t
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(124); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja bład funkcji fopen (dozwolone 1-krotne wywołanie fopen)
            MTEST2, // Reakcja bład funkcji fopen (dozwolone 2-krotne wywołanie fopen)
            MTEST3, // Reakcja bład funkcji fopen (dozwolone 3-krotne wywołanie fopen)
            MTEST4, // Reakcja na brak pamięci - limit ustawiony na 0 bajtów
            MTEST5, // Reakcja na brak pamięci - limit ustawiony na 40 bajtów
            MTEST6, // Reakcja na brak pamięci - limit ustawiony na 200 bajtów
            MTEST7, // Reakcja na brak pamięci - limit ustawiony na 360 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(7); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}