#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "image_utils.h"
#include "tested_declarations.h"
#include "rdebug.h"

enum errors {
    SUCCES = 0,
    INCORECT_INPUT = 1,
    INCORECT_INPUT_DATA = 2,
    COULDNT_OPEN_FILE = 4,
    COULDNT_CREATE_FILE = 5,
    FILE_CORRUPTED = 6,
    FAILED_TO_ALLOCATE_MEMORY = 8
};

int main()
{
    int kod_wyjascia;
    int czy_zaladowano;
    char *sciezka = malloc(40 * sizeof(char));
    if(sciezka == NULL)
    {
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }

    
    printf("Enter destination image file name: ");
    scanf("%39s", sciezka);

    
    getchar();

    struct image_t *obrazek = load_image_t(sciezka, &kod_wyjascia);
    if (kod_wyjascia == 2)
    {
        free(sciezka);
        printf("Couldn't open file\n");
        return COULDNT_OPEN_FILE;
    }
    if (kod_wyjascia == 3)
    {
        free(sciezka);
        printf("File corrupted\n");
        return FILE_CORRUPTED;
    }
    if (kod_wyjascia == 4)
    {
        free(sciezka);
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }

    
    printf("How many subimages you want to draw: ");
    if (scanf("%d", &czy_zaladowano) != 1)
    {
        printf("Incorrect input\n");
        free(sciezka);
        destroy_image(&obrazek);
        return INCORECT_INPUT;
    }

    
    if (czy_zaladowano < 1)
    {
        printf("Incorrect input data\n");
        free(sciezka);
        destroy_image(&obrazek);
        return INCORECT_INPUT_DATA;
    }

    
    for (int i = 0; i < czy_zaladowano; ++i)
    {
        char *imgFilename = malloc(40 * sizeof(char));
        if(imgFilename == NULL)
        {
            printf("Failed to allocate memory\n");
            free(sciezka);
            destroy_image(&obrazek);
            return FAILED_TO_ALLOCATE_MEMORY;
        }

        printf("Enter a name of a subimage: ");
        scanf("%39s", imgFilename);

        struct image_t *image = load_image_t(imgFilename, &kod_wyjascia);
        if (kod_wyjascia == 2)
        {
            free(imgFilename);
            printf("Couldn't open file\n");
            continue;
        }
        if (kod_wyjascia == 3)
        {
            free(imgFilename);
            printf("File corrupted\n");
            continue;
        }
        if (kod_wyjascia == 4)
        {
            free(sciezka);
            free(imgFilename);
            destroy_image(&obrazek);
            printf("Failed to allocate memory\n");
            return FAILED_TO_ALLOCATE_MEMORY;
        }

        int x,y;
        printf("Enter coordinates (x, y): ");
        if(scanf("%d %d", &x, &y) != 2)
        {
            free(sciezka);
            free(imgFilename);
            destroy_image(&image);
            destroy_image(&obrazek);
            printf("Incorrect input\n");
            return INCORECT_INPUT;
        }
        if(x < 0 || y < 0 || x + image->width - 1 > obrazek->width || y + image->height - 1 > obrazek->height)
        {
            printf("Incorrect input data\n");
            free(imgFilename);
            destroy_image(&image);
            continue;
        }

        draw_image(obrazek, image, x, y);
        free(imgFilename);
        destroy_image(&image);
    }
    char *newFilename = malloc(40 + 9/*_modified*/ * sizeof(char));

    int howMany = 0;
    for (int i = 0; i < (int)strlen(sciezka); ++i)
    {
        if(*(sciezka + i) == 46) howMany++;
    }

    char *schowek = strtok(sciezka, ".");
    int flag = 0;
    while( schowek != NULL )
    {
        if(flag == 0)
        {
            strcpy(newFilename, schowek);
            flag++;
            schowek = strtok( NULL, ".");
            continue;
        }
        if(flag == howMany)
        {
            strcat(newFilename, "_modified");
            strcat(newFilename, ".");
            strcat(newFilename, schowek);
            schowek = strtok( NULL, ".");
            continue;
        }
        strcat(newFilename, ".");
        strcat(newFilename, schowek);
        schowek = strtok( NULL, ".");
        flag++;
    }

    kod_wyjascia = save_image_t(newFilename, obrazek);
    if(kod_wyjascia == 0)
    {
        free(sciezka);
        free(newFilename);
        destroy_image(&obrazek);
        printf("File saved\n");
    }
    else
    {
        free(sciezka);
        free(newFilename);
        destroy_image(&obrazek);
        printf("Couldn't create file");
        return COULDNT_CREATE_FILE;
    }
    return 0;
}
