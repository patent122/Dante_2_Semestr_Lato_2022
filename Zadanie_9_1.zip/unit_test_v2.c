/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Porównanie bez znaku równości
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 12:16:29.123647
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzenie funkcji is_equal()
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzenie funkcji is_equal()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int result;
            
                result = is_equal(0, 0);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(1, 1);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-1, -1);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(0, 1);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(0, -1);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1, 0);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(1, 0);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(2147483647, 2147483647);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-1666558362, 641987243);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1562526031, -848304781);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(1441490995, -986500685);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(1588023528, -991407565);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1327928136, -181293191);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1439011768, -525122038);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(1772937765, 1989356208);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-530835980, 402842757);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(1697839257, -1513882363);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(868810207, 1633689615);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1648906459, 1384583598);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1240026133, 844588359);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1467010974, -753554115);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1425691625, 424790062);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(1918415212, 165666726);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-13307930, 1974042971);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(1700653921, -1982783980);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1383938524, 158200947);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-1831479535, -1949604600);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(1565961153, -1047943259);
                test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
            
                result = is_equal(-533591845, -533591845);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(916652866, 916652866);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-803881174, -803881174);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-137461349, -137461349);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(1246944480, 1246944480);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(1415800328, 1415800328);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-2141926859, -2141926859);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-578361802, -578361802);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(1638961677, 1638961677);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-1312273278, -1312273278);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(281699052, 281699052);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-2109924301, -2109924301);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-1997573, -1997573);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(48827847, 48827847);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-2031558509, -2031558509);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(306712423, 306712423);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-1870662190, -1870662190);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-864461197, -864461197);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(4746407, 4746407);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
                result = is_equal(-518886115, -518886115);
                test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
            
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzenie funkcji is_negative()
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzenie funkcji is_negative()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
             int result;
             
                 result = is_negative(0);
                 test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
             
                 result = is_negative(1);
                 test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
             
                 result = is_negative(-1);
                 test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
             
                 result = is_negative(-1670273608);
                 test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
             
                 result = is_negative(-84146005);
                 test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
             
                 result = is_negative(-1373421662);
                 test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
             
                 result = is_negative(-961757764);
                 test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
             
                 result = is_negative(669506800);
                 test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
             
                 result = is_negative(-1294417144);
                 test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
             
                 result = is_negative(-91022468);
                 test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
             
                 result = is_negative(1862575743);
                 test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
             
                 result = is_negative(-509828969);
                 test_error(result == 1, "Oczekiwano wartości 1 a otrzymano %d", result);
             
                 result = is_negative(504958389);
                 test_error(result == 0, "Oczekiwano wartości 0 a otrzymano %d", result);
             
         
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}




enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzenie funkcji is_equal()
            UTEST2, // Sprawdzenie funkcji is_negative()
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(2); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(0); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}