#include <stdio.h>
#include "tested_declarations.h"
#include "rdebug.h"

int is_equal(int aa, int bb);
int is_negative(int wartosc);

int main()
{
    int aa;
    int bb;
    printf("Podaj dwie liczby: ");
    if (scanf("%d %d", &aa, &bb) ^ 2)
    {
        printf("Incorrect input\n");
        return 1;
    }
    

    if (is_equal(aa, bb) ^ 0)
        printf("rowne\n");
    else
        printf("nierowne\n");

    if (is_negative(aa) & 1)
        printf("ujemna ");
    else
        printf("nieujemna ");

    if (is_negative(bb) & 1)
        printf("ujemna ");
    else
        printf("nieujemna ");



    return 0;
}

int is_equal(int aa, int bb)
{
    if (aa ^ bb)
        return 0;
    else
        return 1;
}
int is_negative(int wartosc)
{
    if (!(wartosc ^ 0))
        return 0;
    else if ((!(wartosc & (1 << (31)) | (!wartosc))) ^ 0)
        return 0;
    else
        return 1;
}
