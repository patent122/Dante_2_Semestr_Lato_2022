/*
 * Test dla zadania Porównanie bez znaku równości
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 12:16:29.125624
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta

int is_equal(int a, int b);
int is_negative(int a);

#endif // _TESTED_DECLARATIONS_H_