#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int validateNumber(char *bcd) {
    if (*bcd == '-') {
        bcd++;
    }
    if (strlen(bcd) == 0) {
        return 0;
    }
    while (*bcd != '\0') {
        if (*bcd < '0' || *bcd > '9') {
            return 0;
        }
        bcd++;
    }
    return 1;
}

int main(int argc, char **argv) {
    int wyniczek = 0;
    int i;
    if (argc < 2) {
        printf("Not enough arguments");
        return 9;
    }
    for (i = 1; i < argc; i++) {
        char *num = *(argv + i);
        if (!validateNumber(num)) {
            printf("Incorrect input");
            return 1;
        }
        wyniczek += atoi(num);
    }
    printf("%d\n", wyniczek);
    return 0;
}