#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

float* create_array(int N)
{
    float *tablica = NULL;
    if(N < 1)
    {
        return NULL;
    }
    tablica = malloc(N * sizeof(float));
    if(tablica ==  NULL)
    {
        return NULL;
    }

    return tablica;
}

int main()
{
    int rozmiar;
    float *tablica = NULL;
    printf("Podaj rozmiar tablicy: ");
    if(scanf("%d", &rozmiar) != 1)
    {
        printf("Incorrect input\n");
        return 1;
    }
    if(rozmiar < 1)
    {
        printf("Incorrect input data\n");
        return 2;
    }

    tablica = create_array(rozmiar);

    if(tablica == NULL)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }

    int x = 0;
    printf("Podaj liczby: ");
    while(x < rozmiar)
    {
        int error = scanf("%f", tablica + x);
        if(error != 1)
        {
            printf("incorrect input\n");
            free(tablica);
            return 1;
        }

        x++;
    }

    for (int i = 0; i < x; ++i)
    {
        printf("%f ", *(tablica + x - i - 1));
    }

    free(tablica);

    return 0;
}
