/*
 * Test dla zadania Zapis double do pliku
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-21 22:31:51.543829
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta


        union double_to_char_t;
        
        int load_double(union double_to_char_t *dtc, const char *filename);
        int save_double(const union double_to_char_t *dtc, const char *filename);
        

#endif // _TESTED_DECLARATIONS_H_