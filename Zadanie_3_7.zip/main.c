#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

union double_to_char_t 
{
    double d;
    char tab[8];
};

int save_double(const union double_to_char_t *dtc, const char *filename);
int load_double(union double_to_char_t *dtc, const char *filename);

void
clear (void)
{    
  while ( getchar() != '\n' );
}

int main()
{
    union double_to_char_t dtc;
    char filename[40];
    printf("Podaj liczbe: ");
    if (!scanf("%lf", &dtc.d))
    {
        printf("Incorrect input");
        return 1;
    }
    printf("Podaj nazwe pliku: ");
    scanf("%39s", filename);
    int result = save_double(&dtc, filename);
    if (result == 2)
    {
        printf("couldn't create file");
        return 5;
    }
    else if (result == 3)
    {
        printf("couldn't create file");
        return 5;
    }
    printf("File saved\n");
    clear();
    printf("Podaj nazwe pliku: ");
    scanf("%39s", filename);
    result = load_double(&dtc, filename);
    if (result == 2)
    {
        printf("Couldn't open file");
        return 4;
    }
    else if (result == 3)
    {
        printf("File corrupted");
        return 6;
    }
    printf("%lf", dtc.d);
    return 0;
}

int save_double(const union double_to_char_t *dtc, const char *filename)
{
    if (dtc == NULL || filename == NULL)
    {
        return 1;
    }
    FILE* file = fopen(filename, "wb");
    if (file == NULL)
    {
        return 2;
    }
    if (fwrite(dtc->tab, 8, 1, file) != 1)
    {
        fclose(file);
        return 3;
    }
    fclose(file);
    return 0;
}

int load_double(union double_to_char_t *dtc, const char *filename)
{
    if (dtc == NULL || filename == NULL)
    {
        return 1;
    }
    FILE* file = fopen(filename, "rb");
    if (file == NULL)
    {
        return 2;
    }
    if (fread(dtc->tab, 8, 1, file) != 1)
    {
        fclose(file);
        return 3;
    }
    fclose(file);
    return 0;
}
