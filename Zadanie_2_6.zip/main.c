#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "tested_declarations.h"
#include "rdebug.h"

struct point_t 
{
    int x;
    int y;
};

struct point_t* set(struct point_t* p, int x, int y);
void show(const struct point_t* p);
struct point_t* read(struct point_t* p);
float distance(const struct point_t* p1, const struct point_t* p2, int* err_code);

struct segment_t 
{
    struct point_t start;
    struct point_t end;
};

struct segment_t* read_segment(struct segment_t* p);
void show_segment(const struct segment_t* p);
float length(const struct segment_t* s, int *err_code);

int main()
{
    struct segment_t s;
    if (!read_segment(&s))
    {
        printf("Incorrect input");
        return 1;
    }
    show_segment(&s);
    printf("%.2f", length(&s, NULL));
    return 0;
}

struct segment_t* read_segment(struct segment_t* p)
{
    if (p == NULL)
    {
        return NULL;
    }
    printf("Enter coordinates of the first point:\n");
    if (!read(&p->start))
    {
        return NULL;
    }
    printf("Enter coordinates of the second point:\n");
    if (!read(&p->end))
    {
        return NULL;
    }
    return p;
}

void show_segment(const struct segment_t* p)
{
    if (p == NULL)
    {
        return;
    }
    printf("Line start coords: ");
    show(&p->start);
    printf("Line end coords: ");
    show(&p->end);
}

float length(const struct segment_t* s, int *err_code)
{
    if (s == NULL)
    {
        if (err_code != NULL)
        {
            *err_code = 1;
        }
        return -1;
    }
    float dx = s->start.x - s->end.x;
    float dy = s->start.y - s->end.y;
    if (err_code != NULL)
    {
        *err_code = 0;
    }
    return sqrt(dx * dx + dy * dy);
}

struct point_t* set(struct point_t* p, int x, int y)
{
    if (p == NULL)
    {
        return NULL;
    }
    p->x = x;
    p->y = y;
    return p;
}

void show(const struct point_t* p)
{
    if (p == NULL)
    {
        return;
    }

    printf("x = %d; y = %d\n", p->x, p->y);
}

struct point_t* read(struct point_t* p)
{
    if (p == NULL)
    {
        return NULL;
    }
    printf("Podaj wspolrzedna x: ");
    if (scanf("%d", &p->x) != 1)
    {
        return NULL;
    }
    printf("Podaj wspolrzedna y: ");
    if (scanf("%d", &p->y) != 1)
    {
        return NULL;
    }
    return p;
}

float distance(const struct point_t* p1, const struct point_t* p2, int* err_code)
{
    if (p1 == NULL || p2 == NULL)
    {
        if (err_code != NULL)
        {
            *err_code = 1;
        }
        return -1.0f;
    }

    if (err_code != NULL)
    {
        *err_code = 0;
    }

    float dx = p1->x - p2->x;
    float dy = p1->y - p2->y;

    return sqrt(dx * dx + dy * dy);
}
