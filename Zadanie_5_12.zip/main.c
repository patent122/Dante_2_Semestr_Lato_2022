#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "format_type.h"
#include "tested_declarations.h"
#include "rdebug.h"

struct statistic_t
{
    int min;
    int max;
    float avg;
    float standard_deviation;
    int range;
};

float stdDev(int** wskaznik);
int statistics(int** wskaznik, struct statistic_t** statystyki);
void display(int** wskaznik);
int save(const char* sciezka, int** wskaznik, enum save_format_t format);
int load(const char* sciezka, int*** wskaznik, enum save_format_t format);
int statistics_row(int** wskaznik, struct statistic_t** statystyki);
void destroy(int*** wskaznik);

int main() 
{
    int** table, kod_bledu;
    struct statistic_t* statystyki;
    char* sciezka = malloc(40 * sizeof(char));
    if (sciezka == NULL)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }

    printf("Podaj nazwe pliku: ");
    scanf("%39s", sciezka);

    char* lastFourChar = sciezka + (int)strlen(sciezka) - 4;

    if (strcmp(lastFourChar, ".txt") == 0)
    {
        kod_bledu = load(sciezka, &table, fmt_text);
    }
    else if (strcmp(lastFourChar, ".bin") == 0)
    {
        kod_bledu = load(sciezka, &table, fmt_binary);
    }
    else
    {
        printf("Unsupported file format\n");
        free(sciezka);
        return 7;
    }
    
    switch (kod_bledu)
    {
    case 2:
        printf("Couldn't open file\n");
        free(sciezka);
        return 4;
    case 3:
        printf("File corrupted\n");
        free(sciezka);
        return 6;
    case 4:
        printf("Failed to allocate memory\n");
        free(sciezka);
        return 8;
    default:
        break;
    }

    int rozmiar = statistics_row(table, &statystyki);

    for (int i = 0; i < rozmiar; ++i)
    {
        printf("%d %d %d %.2f %.2f\n", (statystyki + i)->min, (statystyki + i)->max, (statystyki + i)->range, (statystyki + i)->avg, (statystyki + i)->standard_deviation);
    }

    free(sciezka);
    free(statystyki);
    destroy(&table);
    return 0;
}

int statistics(int** wskaznik, struct statistic_t** statystyki)
{
    if (wskaznik == NULL || statystyki == NULL)
        return 1;

    int suma = 0;
    int sum_numbers = 0;
    int px = 0;

    *statystyki = malloc(sizeof(struct statistic_t));
    if (*statystyki == NULL)
        return 2;

    while (*(wskaznik + px) != NULL)
    {
        int py = 0;
        while (*(*(wskaznik + px) + py) != -1)
        {
            
            suma += *(*(wskaznik + px) + py);
            
            sum_numbers++;
            py++;
        }
        px++;
    }

    
    if (sum_numbers == 0)
    {
        free(*statystyki);
        return 3;
    }


    (*statystyki)->min = *(*(wskaznik + 0) + 0);
    (*statystyki)->max = *(*(wskaznik + 0) + 0);

    px = 0;
    while (*(wskaznik + px) != NULL)
    {
        int py = 0;
        while (*(*(wskaznik + px) + py) != -1)
        {
            
            if (*(*(wskaznik + px) + py) < (*statystyki)->min)
            {
                (*statystyki)->min = *(*(wskaznik + px) + py);
            }
            
            if (*(*(wskaznik + px) + py) > (*statystyki)->max)
            {
                (*statystyki)->max = *(*(wskaznik + px) + py);
            }
            py++;
        }
        px++;
    }

    (*statystyki)->range = (*statystyki)->max - (*statystyki)->min;
    (*statystyki)->avg = (float)suma / (float)sum_numbers;
    (*statystyki)->standard_deviation = stdDev(wskaznik);
    return 0;
}

void display(int** wskaznik)
{
    if (wskaznik == NULL) return;
    int px = 0;
    while (*(wskaznik + px) != NULL)
    {
        int py = 0;
        while (*(*(wskaznik + px) + py) != -1)
        {
            printf("%d ", *(*(wskaznik + px) + py));
            py++;
        }
        printf("\n");
        px++;
    }
}

int save(const char* sciezka, int** wskaznik, enum save_format_t format)
{
    if (sciezka == NULL || wskaznik == NULL)
        return 1;
    if (format != fmt_text && format != fmt_binary)
        return 1;

    FILE* plik = NULL;
    int px = 0;
    switch (format)
    {
    case fmt_text:
        
        if ((plik = fopen(sciezka, "w")) == NULL)
        {
            return 2;
        }

        while (*(wskaznik + px) != NULL)
        {
            int py = 0;
            while (*(*(wskaznik + px) + py) != -1)
            {
                fprintf(plik, "%d ", *(*(wskaznik + px) + py));
                py++;
            }
            fprintf(plik, "-1");
            fprintf(plik, "\n");
            px++;
        }

        fclose(plik);
        break;
    case fmt_binary:
        
        if ((plik = fopen(sciezka, "wb")) == NULL)
        {
            return 2;
        }

        while (*(wskaznik + px) != NULL)
        {
            int py = 0;
            while (*(*(wskaznik + px) + py) != -1)
            {
                fwrite(*(wskaznik + px) + py, sizeof(int), 1, plik);
                py++;
            }
            fwrite(*(wskaznik + px) + py, sizeof(int), 1, plik);
            px++;
        }

        fclose(plik);
        break;
    default:
        break;
    }

    return 0;
}

float stdDev(int** wskaznik)
{
    int suma = 0;
    int rozmiar = 0;
    int px = 0;
    while (*(wskaznik + px) != NULL)
    {
        int py = 0;
        while (*(*(wskaznik + px) + py) != -1)
        {
            
            suma += *(*(wskaznik + px) + py);
            
            rozmiar++;
            py++;
        }
        px++;
    }
    float avg = (float)suma / (float)rozmiar;
    float licznik = 0;
    float mianownik = (float)rozmiar;

    px = 0;
    while (*(wskaznik + px) != NULL)
    {
        int py = 0;
        while (*(*(wskaznik + px) + py) != -1)
        {
            licznik += powf((float)(*(*(wskaznik + px) + py)) - avg, 2);
            py++;
        }
        px++;
    }
    return sqrtf(licznik / mianownik);
}

float stdDev_row(int** wskaznik)
{
    int suma = 0;
    int rozmiar = 0;
    int px = 0;
    while (*(*wskaznik + px) != -1)
    {
        
        suma += *(*wskaznik + px);
        
        rozmiar++;
        px++;
    }
    float avg = (float)suma / (float)rozmiar;
    float licznik = 0;
    float mianownik = (float)rozmiar;

    px = 0;
    while (*(*wskaznik + px) != -1)
    {
        licznik += powf((float)*(*wskaznik + px) - avg, 2);
        px++;
    }
    return sqrtf(licznik / mianownik);
}

int load(const char* sciezka, int*** wskaznik, enum save_format_t format)
{
    if (sciezka == NULL || wskaznik == NULL)
        return 1;
    if (format != fmt_text && format != fmt_binary)
        return 1;

    FILE* plik = NULL;
    int** tablica = NULL;
    int liczba;
    int wysokosc = 0;
    char znak;
    switch (format)
    {
        
    case fmt_text:
        
        if ((plik = fopen(sciezka, "r")) == NULL)
        {
            return 2;
        }

        int ile_liczb = 0;
        
        while (fscanf(plik, "%d", &liczba) == 1)
        {
            ile_liczb++;
        }
        
        if (ile_liczb == 0)
        {
            fclose(plik);
            return 3;
        }

        fseek(plik, 0L, SEEK_SET);
        while ((znak = fgetc(plik)) != EOF)
        {
            if (isdigit(znak) != 0 || isspace(znak) != 0 || znak == 45)
            {
                
            }
            else
            {
                fclose(plik);
                return 3;
            }
        }
        fseek(plik, 0L, SEEK_SET);

        
        while (fscanf(plik, "%d", &liczba) == 1)
        {
            if (liczba == -1)
                wysokosc++;
        }

        if (wysokosc == 0)
        {
            fclose(plik);
            return 3;
        }


        tablica = malloc((wysokosc + 1) * sizeof(int*));
        if (tablica == NULL)
        {
            fclose(plik);
            return 4;
        }

        *(tablica + wysokosc) = NULL;

        
        fseek(plik, 0L, SEEK_SET);

        for (int i = 0; i < wysokosc; ++i)
        {
            int rozmiar = 0;
            do {
                fscanf(plik, "%d", &liczba);
                rozmiar++;
            } while (liczba != -1);
            *(tablica + i) = malloc(rozmiar * sizeof(int));
            if (*(tablica + i) == NULL)
            {
                for (int j = 0; j < i; ++j)
                {
                    free(*(tablica + j));
                }
                free(tablica);
                fclose(plik);
                return 4;
            }
        }


        
        fseek(plik, 0L, SEEK_SET);

        for (int i = 0; i < wysokosc; ++i)
        {
            int rozmiar = 0;
            do {
                fscanf(plik, "%d", &liczba);
                *(*(tablica + i) + rozmiar) = liczba;
                rozmiar++;
            } while (liczba != -1);
        }

        *wskaznik = tablica;
        fclose(plik);
        break;
        
    case fmt_binary:
        
        if ((plik = fopen(sciezka, "rb")) == NULL)
        {
            return 2;
        }
        fseek(plik, 0L, SEEK_SET);
        while (fread(&liczba, sizeof(int), 1, plik) > 0)
        {
            if (ferror(plik))
            {
                fclose(plik);
                return 3;
            }
        }

        fseek(plik, 0L, SEEK_SET);

        
        while (fread(&liczba, sizeof(int), 1, plik) == 1)
        {
            if (liczba == -1)
                wysokosc++;
        }

        if (wysokosc == 0)
        {
            fclose(plik);
            return 3;
        }


        tablica = malloc((wysokosc + 1) * sizeof(int*));
        if (tablica == NULL)
        {
            fclose(plik);
            return 4;
        }

        *(tablica + wysokosc) = NULL;

        
        fseek(plik, 0L, SEEK_SET);

        for (int i = 0; i < wysokosc; ++i)
        {
            int rozmiar = 0;
            do {
                fread(&liczba, sizeof(int), 1, plik);
                rozmiar++;
            } while (liczba != -1);
            *(tablica + i) = malloc(rozmiar * sizeof(int));
            if (*(tablica + i) == NULL)
            {
                for (int j = 0; j < i; ++j)
                {
                    free(*(tablica + j));
                }
                free(tablica);
                fclose(plik);
                return 4;
            }
        }


        
        fseek(plik, 0L, SEEK_SET);

        for (int i = 0; i < wysokosc; ++i)
        {
            int rozmiar = 0;
            do {
                fread(&liczba, sizeof(int), 1, plik);
                *(*(tablica + i) + rozmiar) = liczba;
                rozmiar++;
            } while (liczba != -1);
        }

        *wskaznik = tablica;
        fclose(plik);
        break;
    default:
        break;
    }

    return 0;
}

int statistics_row(int** wskaznik, struct statistic_t** statystyki)
{
    if (wskaznik == NULL || statystyki == NULL)
        return -1;

    int wysokosc = 0;
    while (*(wskaznik + wysokosc) != NULL)
    {
        wysokosc++;
    }

    *statystyki = (struct statistic_t*)malloc(wysokosc * sizeof(struct statistic_t));
    if (*statystyki == NULL)
        return -2;

    for (int i = 0; i < wysokosc; ++i)
    {
        int suma = 0;
        int sum_numbers = 0;
        int px = 0;

        while (*(*(wskaznik + i) + px) != -1)
        {
            
            suma += *(*(wskaznik + i) + px);
            
            sum_numbers++;
            px++;
        }

        if (sum_numbers == 0)
        {
            (*statystyki + i)->min = -1;
            (*statystyki + i)->max = -1;
            (*statystyki + i)->avg = -1.0;
            (*statystyki + i)->standard_deviation = -1.0;
            (*statystyki + i)->range = -1;
            continue;
        }


        (*statystyki + i)->min = *(*(wskaznik + i) + 0);
        (*statystyki + i)->max = *(*(wskaznik + i) + 0);

        px = 0;
        while (*(*(wskaznik + i) + px) != -1)
        {
            
            if (*(*(wskaznik + i) + px) < (*statystyki + i)->min)
            {
                (*statystyki + i)->min = *(*(wskaznik + i) + px);
            }
            
            if (*(*(wskaznik + i) + px) > (*statystyki + i)->max)
            {
                (*statystyki + i)->max = *(*(wskaznik + i) + px);
            }
            px++;
        }

        (*statystyki + i)->range = (*statystyki + i)->max - (*statystyki + i)->min;
        (*statystyki + i)->avg = (float)suma / (float)sum_numbers;
        (*statystyki + i)->standard_deviation = stdDev_row(wskaznik + i);
    }

    return wysokosc;
}

void destroy(int*** wskaznik)
{
    if (wskaznik == NULL)
        return;

    int px = 0;
    while (*(*wskaznik + px) != NULL)
    {
        free(*(*wskaznik + px));
        px++;
    }
    free(*wskaznik);
    *wskaznik = NULL;
}

