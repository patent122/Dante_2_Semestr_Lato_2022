/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Zbiory liczb - statystyka szczegółowa
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-19 18:08:54.837112
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//


        struct statistic_t
        {
          int min;
          int max;
          float avg;
          float standard_deviation;
          int range;
        };    
    


//
//  Test 1: Sprawdzanie poprawności działania funkcji display
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji display", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("\n***TEST 1***\n\n");
            printf("***START***\n");
            display(NULL);
            printf("***END***\n");

            test_no_heap_leakage();
            onerror_terminate();
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji display
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji display", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int V[] = {857, 972, 41, 542, 888, 175, 160, -1};
    int A[] = {-381, -933, -455, -353, -671, -396, -1};
    int Z[] = {65, 632, -1};
    int G[] = {895, 38, -1};
    int R[] = {-1};
    int B[] = {-711, -574, -495, -905, -772, -719, -692, -254, -797, -1};
    int S[] = {-32, -524, -780, -4, -97, -781, -85, -1};
    int *X[] = {V, A, Z, G, R, B, S, NULL};
      

            printf("\n***TEST 1***\n\n");
            printf("***START***\n");
            display(X);
            printf("***END***\n");

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji statistics_row
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji statistics_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct statistic_t *stats;

                int V[] = {857, 972, 41, 542, 888, 175, 160, -1};
    int A[] = {-381, -933, -455, -353, -671, -396, -1};
    int Z[] = {65, 632, -1};
    int G[] = {895, 38, -1};
    int R[] = {-1};
    int B[] = {-711, -574, -495, -905, -772, -719, -692, -254, -797, -1};
    int S[] = {-32, -524, -780, -4, -97, -781, -85, -1};
    int *X[] = {V, A, Z, G, R, B, S, NULL};
      

                int err_code = statistics_row(X, &stats);
                test_error(err_code == 7, "Funkcja statistics_row() powinna zwrócić  7, a zwróciła %d", err_code);

                test_error(stats != NULL, "Funkcja statistics_row() powinna zaalokować pamięć na strukturę stats, a przypisała NULL");

                onerror_terminate();

                           
                 
                    test_error((stats + 0)->min == 41, "Funkcja statistics_row() powinna ustawić minimum na 41, a ustawiła na %d", (stats + 0)->min);
                    test_error((stats + 0)->max == 972, "Funkcja statistics_row() powinna ustawić maximum na 972, a ustawiła na %d", (stats + 0)->max);
                    test_error((stats + 0)->range == 931, "Funkcja statistics_row() powinna ustawić zakres na 931, a ustawiła na %d", (stats + 0)->range);
                    test_error(((stats + 0)->avg > 519.2857142857143 - 0.01) && ((stats + 0)->avg < 519.2857142857143 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 519.2857142857143, a ustawiła na %f", (stats + 0)->avg);
                    test_error(((stats + 0)->standard_deviation > 364.85680724897855 - 0.01) && ((stats + 0)->standard_deviation < 364.85680724897855 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 364.85680724897855, a ustawiła na %f", (stats + 0)->standard_deviation);
                           
                 
                    test_error((stats + 1)->min == -933, "Funkcja statistics_row() powinna ustawić minimum na -933, a ustawiła na %d", (stats + 1)->min);
                    test_error((stats + 1)->max == -353, "Funkcja statistics_row() powinna ustawić maximum na -353, a ustawiła na %d", (stats + 1)->max);
                    test_error((stats + 1)->range == 580, "Funkcja statistics_row() powinna ustawić zakres na 580, a ustawiła na %d", (stats + 1)->range);
                    test_error(((stats + 1)->avg > -531.5 - 0.01) && ((stats + 1)->avg < -531.5 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -531.5, a ustawiła na %f", (stats + 1)->avg);
                    test_error(((stats + 1)->standard_deviation > 207.92125913431747 - 0.01) && ((stats + 1)->standard_deviation < 207.92125913431747 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 207.92125913431747, a ustawiła na %f", (stats + 1)->standard_deviation);
                           
                 
                    test_error((stats + 2)->min == 65, "Funkcja statistics_row() powinna ustawić minimum na 65, a ustawiła na %d", (stats + 2)->min);
                    test_error((stats + 2)->max == 632, "Funkcja statistics_row() powinna ustawić maximum na 632, a ustawiła na %d", (stats + 2)->max);
                    test_error((stats + 2)->range == 567, "Funkcja statistics_row() powinna ustawić zakres na 567, a ustawiła na %d", (stats + 2)->range);
                    test_error(((stats + 2)->avg > 348.5 - 0.01) && ((stats + 2)->avg < 348.5 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 348.5, a ustawiła na %f", (stats + 2)->avg);
                    test_error(((stats + 2)->standard_deviation > 283.5 - 0.01) && ((stats + 2)->standard_deviation < 283.5 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 283.5, a ustawiła na %f", (stats + 2)->standard_deviation);
                           
                 
                    test_error((stats + 3)->min == 38, "Funkcja statistics_row() powinna ustawić minimum na 38, a ustawiła na %d", (stats + 3)->min);
                    test_error((stats + 3)->max == 895, "Funkcja statistics_row() powinna ustawić maximum na 895, a ustawiła na %d", (stats + 3)->max);
                    test_error((stats + 3)->range == 857, "Funkcja statistics_row() powinna ustawić zakres na 857, a ustawiła na %d", (stats + 3)->range);
                    test_error(((stats + 3)->avg > 466.5 - 0.01) && ((stats + 3)->avg < 466.5 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 466.5, a ustawiła na %f", (stats + 3)->avg);
                    test_error(((stats + 3)->standard_deviation > 428.5 - 0.01) && ((stats + 3)->standard_deviation < 428.5 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 428.5, a ustawiła na %f", (stats + 3)->standard_deviation);
                           
                 
                    test_error((stats + 4)->min == -1, "Funkcja statistics_row() powinna ustawić minimum na -1, a ustawiła na %d", (stats + 4)->min);
                    test_error((stats + 4)->max == -1, "Funkcja statistics_row() powinna ustawić maximum na -1, a ustawiła na %d", (stats + 4)->max);
                    test_error((stats + 4)->range == -1, "Funkcja statistics_row() powinna ustawić zakres na -1, a ustawiła na %d", (stats + 4)->range);
                    test_error(((stats + 4)->avg > -1 - 0.01) && ((stats + 4)->avg < -1 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -1, a ustawiła na %f", (stats + 4)->avg);
                    test_error(((stats + 4)->standard_deviation > -1 - 0.01) && ((stats + 4)->standard_deviation < -1 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na -1, a ustawiła na %f", (stats + 4)->standard_deviation);
                           
                 
                    test_error((stats + 5)->min == -905, "Funkcja statistics_row() powinna ustawić minimum na -905, a ustawiła na %d", (stats + 5)->min);
                    test_error((stats + 5)->max == -254, "Funkcja statistics_row() powinna ustawić maximum na -254, a ustawiła na %d", (stats + 5)->max);
                    test_error((stats + 5)->range == 651, "Funkcja statistics_row() powinna ustawić zakres na 651, a ustawiła na %d", (stats + 5)->range);
                    test_error(((stats + 5)->avg > -657.6666666666666 - 0.01) && ((stats + 5)->avg < -657.6666666666666 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -657.6666666666666, a ustawiła na %f", (stats + 5)->avg);
                    test_error(((stats + 5)->standard_deviation > 181.91939607053104 - 0.01) && ((stats + 5)->standard_deviation < 181.91939607053104 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 181.91939607053104, a ustawiła na %f", (stats + 5)->standard_deviation);
                           
                 
                    test_error((stats + 6)->min == -781, "Funkcja statistics_row() powinna ustawić minimum na -781, a ustawiła na %d", (stats + 6)->min);
                    test_error((stats + 6)->max == -4, "Funkcja statistics_row() powinna ustawić maximum na -4, a ustawiła na %d", (stats + 6)->max);
                    test_error((stats + 6)->range == 777, "Funkcja statistics_row() powinna ustawić zakres na 777, a ustawiła na %d", (stats + 6)->range);
                    test_error(((stats + 6)->avg > -329.0 - 0.01) && ((stats + 6)->avg < -329.0 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -329.0, a ustawiła na %f", (stats + 6)->avg);
                    test_error(((stats + 6)->standard_deviation > 327.9642837696986 - 0.01) && ((stats + 6)->standard_deviation < 327.9642837696986 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 327.9642837696986, a ustawiła na %f", (stats + 6)->standard_deviation);
                

                free(stats);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji statistics_row
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji statistics_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct statistic_t *stats;

                int V[] = {841, 781, 311, 992, 497, 427, 794, 686, -1};
    int A[] = {643, 463, 4, 66, 65, 441, 950, 660, 692, -1};
    int Z[] = {722, 850, 98, 557, 789, 1, -1};
    int G[] = {722, 850, 98, 557, 789, 1, -1};
    int *R[] = {V, A, Z, G, NULL};
      

                int err_code = statistics_row(R, &stats);
                test_error(err_code == 4, "Funkcja statistics_row() powinna zwrócić  4, a zwróciła %d", err_code);

                test_error(stats != NULL, "Funkcja statistics_row() powinna zaalokować pamięć na strukturę stats, a przypisała NULL");

                onerror_terminate();

                           
                 
                    test_error((stats + 0)->min == 311, "Funkcja statistics_row() powinna ustawić minimum na 311, a ustawiła na %d", (stats + 0)->min);
                    test_error((stats + 0)->max == 992, "Funkcja statistics_row() powinna ustawić maximum na 992, a ustawiła na %d", (stats + 0)->max);
                    test_error((stats + 0)->range == 681, "Funkcja statistics_row() powinna ustawić zakres na 681, a ustawiła na %d", (stats + 0)->range);
                    test_error(((stats + 0)->avg > 666.125 - 0.01) && ((stats + 0)->avg < 666.125 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 666.125, a ustawiła na %f", (stats + 0)->avg);
                    test_error(((stats + 0)->standard_deviation > 217.54794730127884 - 0.01) && ((stats + 0)->standard_deviation < 217.54794730127884 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 217.54794730127884, a ustawiła na %f", (stats + 0)->standard_deviation);
                           
                 
                    test_error((stats + 1)->min == 4, "Funkcja statistics_row() powinna ustawić minimum na 4, a ustawiła na %d", (stats + 1)->min);
                    test_error((stats + 1)->max == 950, "Funkcja statistics_row() powinna ustawić maximum na 950, a ustawiła na %d", (stats + 1)->max);
                    test_error((stats + 1)->range == 946, "Funkcja statistics_row() powinna ustawić zakres na 946, a ustawiła na %d", (stats + 1)->range);
                    test_error(((stats + 1)->avg > 442.6666666666667 - 0.01) && ((stats + 1)->avg < 442.6666666666667 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 442.6666666666667, a ustawiła na %f", (stats + 1)->avg);
                    test_error(((stats + 1)->standard_deviation > 313.4531685736944 - 0.01) && ((stats + 1)->standard_deviation < 313.4531685736944 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 313.4531685736944, a ustawiła na %f", (stats + 1)->standard_deviation);
                           
                 
                    test_error((stats + 2)->min == 1, "Funkcja statistics_row() powinna ustawić minimum na 1, a ustawiła na %d", (stats + 2)->min);
                    test_error((stats + 2)->max == 850, "Funkcja statistics_row() powinna ustawić maximum na 850, a ustawiła na %d", (stats + 2)->max);
                    test_error((stats + 2)->range == 849, "Funkcja statistics_row() powinna ustawić zakres na 849, a ustawiła na %d", (stats + 2)->range);
                    test_error(((stats + 2)->avg > 502.8333333333333 - 0.01) && ((stats + 2)->avg < 502.8333333333333 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 502.8333333333333, a ustawiła na %f", (stats + 2)->avg);
                    test_error(((stats + 2)->standard_deviation > 333.943815966432 - 0.01) && ((stats + 2)->standard_deviation < 333.943815966432 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 333.943815966432, a ustawiła na %f", (stats + 2)->standard_deviation);
                           
                 
                    test_error((stats + 3)->min == 1, "Funkcja statistics_row() powinna ustawić minimum na 1, a ustawiła na %d", (stats + 3)->min);
                    test_error((stats + 3)->max == 850, "Funkcja statistics_row() powinna ustawić maximum na 850, a ustawiła na %d", (stats + 3)->max);
                    test_error((stats + 3)->range == 849, "Funkcja statistics_row() powinna ustawić zakres na 849, a ustawiła na %d", (stats + 3)->range);
                    test_error(((stats + 3)->avg > 502.8333333333333 - 0.01) && ((stats + 3)->avg < 502.8333333333333 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 502.8333333333333, a ustawiła na %f", (stats + 3)->avg);
                    test_error(((stats + 3)->standard_deviation > 333.943815966432 - 0.01) && ((stats + 3)->standard_deviation < 333.943815966432 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 333.943815966432, a ustawiła na %f", (stats + 3)->standard_deviation);
                

                free(stats);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji statistics_row
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji statistics_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct statistic_t *stats;

                int V[] = {-30, -62, -1};
    int A[] = {-54, -69, -34, -31, -75, -34, -7, -65, -2, -1};
    int Z[] = {-53, -29, -1};
    int G[] = {-90, -80, -89, -28, -62, -18, -53, -18, -70, -38, -1};
    int R[] = {-90, -80, -89, -28, -62, -18, -53, -18, -70, -38, -1};
    int *B[] = {V, A, Z, G, R, NULL};
      

                int err_code = statistics_row(B, &stats);
                test_error(err_code == 5, "Funkcja statistics_row() powinna zwrócić  5, a zwróciła %d", err_code);

                test_error(stats != NULL, "Funkcja statistics_row() powinna zaalokować pamięć na strukturę stats, a przypisała NULL");

                onerror_terminate();

                           
                 
                    test_error((stats + 0)->min == -62, "Funkcja statistics_row() powinna ustawić minimum na -62, a ustawiła na %d", (stats + 0)->min);
                    test_error((stats + 0)->max == -30, "Funkcja statistics_row() powinna ustawić maximum na -30, a ustawiła na %d", (stats + 0)->max);
                    test_error((stats + 0)->range == 32, "Funkcja statistics_row() powinna ustawić zakres na 32, a ustawiła na %d", (stats + 0)->range);
                    test_error(((stats + 0)->avg > -46.0 - 0.01) && ((stats + 0)->avg < -46.0 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -46.0, a ustawiła na %f", (stats + 0)->avg);
                    test_error(((stats + 0)->standard_deviation > 16.0 - 0.01) && ((stats + 0)->standard_deviation < 16.0 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 16.0, a ustawiła na %f", (stats + 0)->standard_deviation);
                           
                 
                    test_error((stats + 1)->min == -75, "Funkcja statistics_row() powinna ustawić minimum na -75, a ustawiła na %d", (stats + 1)->min);
                    test_error((stats + 1)->max == -2, "Funkcja statistics_row() powinna ustawić maximum na -2, a ustawiła na %d", (stats + 1)->max);
                    test_error((stats + 1)->range == 73, "Funkcja statistics_row() powinna ustawić zakres na 73, a ustawiła na %d", (stats + 1)->range);
                    test_error(((stats + 1)->avg > -41.22222222222222 - 0.01) && ((stats + 1)->avg < -41.22222222222222 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -41.22222222222222, a ustawiła na %f", (stats + 1)->avg);
                    test_error(((stats + 1)->standard_deviation > 24.854142412518048 - 0.01) && ((stats + 1)->standard_deviation < 24.854142412518048 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 24.854142412518048, a ustawiła na %f", (stats + 1)->standard_deviation);
                           
                 
                    test_error((stats + 2)->min == -53, "Funkcja statistics_row() powinna ustawić minimum na -53, a ustawiła na %d", (stats + 2)->min);
                    test_error((stats + 2)->max == -29, "Funkcja statistics_row() powinna ustawić maximum na -29, a ustawiła na %d", (stats + 2)->max);
                    test_error((stats + 2)->range == 24, "Funkcja statistics_row() powinna ustawić zakres na 24, a ustawiła na %d", (stats + 2)->range);
                    test_error(((stats + 2)->avg > -41.0 - 0.01) && ((stats + 2)->avg < -41.0 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -41.0, a ustawiła na %f", (stats + 2)->avg);
                    test_error(((stats + 2)->standard_deviation > 12.0 - 0.01) && ((stats + 2)->standard_deviation < 12.0 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 12.0, a ustawiła na %f", (stats + 2)->standard_deviation);
                           
                 
                    test_error((stats + 3)->min == -90, "Funkcja statistics_row() powinna ustawić minimum na -90, a ustawiła na %d", (stats + 3)->min);
                    test_error((stats + 3)->max == -18, "Funkcja statistics_row() powinna ustawić maximum na -18, a ustawiła na %d", (stats + 3)->max);
                    test_error((stats + 3)->range == 72, "Funkcja statistics_row() powinna ustawić zakres na 72, a ustawiła na %d", (stats + 3)->range);
                    test_error(((stats + 3)->avg > -54.6 - 0.01) && ((stats + 3)->avg < -54.6 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -54.6, a ustawiła na %f", (stats + 3)->avg);
                    test_error(((stats + 3)->standard_deviation > 26.52998303806468 - 0.01) && ((stats + 3)->standard_deviation < 26.52998303806468 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 26.52998303806468, a ustawiła na %f", (stats + 3)->standard_deviation);
                           
                 
                    test_error((stats + 4)->min == -90, "Funkcja statistics_row() powinna ustawić minimum na -90, a ustawiła na %d", (stats + 4)->min);
                    test_error((stats + 4)->max == -18, "Funkcja statistics_row() powinna ustawić maximum na -18, a ustawiła na %d", (stats + 4)->max);
                    test_error((stats + 4)->range == 72, "Funkcja statistics_row() powinna ustawić zakres na 72, a ustawiła na %d", (stats + 4)->range);
                    test_error(((stats + 4)->avg > -54.6 - 0.01) && ((stats + 4)->avg < -54.6 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -54.6, a ustawiła na %f", (stats + 4)->avg);
                    test_error(((stats + 4)->standard_deviation > 26.52998303806468 - 0.01) && ((stats + 4)->standard_deviation < 26.52998303806468 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 26.52998303806468, a ustawiła na %f", (stats + 4)->standard_deviation);
                

                free(stats);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji statistics_row
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji statistics_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct statistic_t *stats;

                int V[] = {34, -91, 74, -66, -67, 33, 17, -36, -51, 61, -1};
    int A[] = {-52, 71, 71, -80, -1};
    int Z[] = {-58, 70, -96, 92, 41, -1};
    int G[] = {81, 99, 9, -33, -3, 96, -1};
    int R[] = {53, 72, 40, 47, -16, -91, -34, -94, -91, -1};
    int B[] = {53, 43, -1};
    int S[] = {-61, 56, -47, 55, 26, 25, -1};
    int X[] = {-61, 56, -47, 55, 26, 25, -1};
    int *P[] = {V, A, Z, G, R, B, S, X, NULL};
      

                int err_code = statistics_row(P, &stats);
                test_error(err_code == 8, "Funkcja statistics_row() powinna zwrócić  8, a zwróciła %d", err_code);

                test_error(stats != NULL, "Funkcja statistics_row() powinna zaalokować pamięć na strukturę stats, a przypisała NULL");

                onerror_terminate();

                           
                 
                    test_error((stats + 0)->min == -91, "Funkcja statistics_row() powinna ustawić minimum na -91, a ustawiła na %d", (stats + 0)->min);
                    test_error((stats + 0)->max == 74, "Funkcja statistics_row() powinna ustawić maximum na 74, a ustawiła na %d", (stats + 0)->max);
                    test_error((stats + 0)->range == 165, "Funkcja statistics_row() powinna ustawić zakres na 165, a ustawiła na %d", (stats + 0)->range);
                    test_error(((stats + 0)->avg > -9.2 - 0.01) && ((stats + 0)->avg < -9.2 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -9.2, a ustawiła na %f", (stats + 0)->avg);
                    test_error(((stats + 0)->standard_deviation > 56.486812620292184 - 0.01) && ((stats + 0)->standard_deviation < 56.486812620292184 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 56.486812620292184, a ustawiła na %f", (stats + 0)->standard_deviation);
                           
                 
                    test_error((stats + 1)->min == -80, "Funkcja statistics_row() powinna ustawić minimum na -80, a ustawiła na %d", (stats + 1)->min);
                    test_error((stats + 1)->max == 71, "Funkcja statistics_row() powinna ustawić maximum na 71, a ustawiła na %d", (stats + 1)->max);
                    test_error((stats + 1)->range == 151, "Funkcja statistics_row() powinna ustawić zakres na 151, a ustawiła na %d", (stats + 1)->range);
                    test_error(((stats + 1)->avg > 2.5 - 0.01) && ((stats + 1)->avg < 2.5 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 2.5, a ustawiła na %f", (stats + 1)->avg);
                    test_error(((stats + 1)->standard_deviation > 69.21163197035597 - 0.01) && ((stats + 1)->standard_deviation < 69.21163197035597 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 69.21163197035597, a ustawiła na %f", (stats + 1)->standard_deviation);
                           
                 
                    test_error((stats + 2)->min == -96, "Funkcja statistics_row() powinna ustawić minimum na -96, a ustawiła na %d", (stats + 2)->min);
                    test_error((stats + 2)->max == 92, "Funkcja statistics_row() powinna ustawić maximum na 92, a ustawiła na %d", (stats + 2)->max);
                    test_error((stats + 2)->range == 188, "Funkcja statistics_row() powinna ustawić zakres na 188, a ustawiła na %d", (stats + 2)->range);
                    test_error(((stats + 2)->avg > 9.8 - 0.01) && ((stats + 2)->avg < 9.8 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 9.8, a ustawiła na %f", (stats + 2)->avg);
                    test_error(((stats + 2)->standard_deviation > 73.68147664101203 - 0.01) && ((stats + 2)->standard_deviation < 73.68147664101203 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 73.68147664101203, a ustawiła na %f", (stats + 2)->standard_deviation);
                           
                 
                    test_error((stats + 3)->min == -33, "Funkcja statistics_row() powinna ustawić minimum na -33, a ustawiła na %d", (stats + 3)->min);
                    test_error((stats + 3)->max == 99, "Funkcja statistics_row() powinna ustawić maximum na 99, a ustawiła na %d", (stats + 3)->max);
                    test_error((stats + 3)->range == 132, "Funkcja statistics_row() powinna ustawić zakres na 132, a ustawiła na %d", (stats + 3)->range);
                    test_error(((stats + 3)->avg > 41.5 - 0.01) && ((stats + 3)->avg < 41.5 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 41.5, a ustawiła na %f", (stats + 3)->avg);
                    test_error(((stats + 3)->standard_deviation > 52.31873469418006 - 0.01) && ((stats + 3)->standard_deviation < 52.31873469418006 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 52.31873469418006, a ustawiła na %f", (stats + 3)->standard_deviation);
                           
                 
                    test_error((stats + 4)->min == -94, "Funkcja statistics_row() powinna ustawić minimum na -94, a ustawiła na %d", (stats + 4)->min);
                    test_error((stats + 4)->max == 72, "Funkcja statistics_row() powinna ustawić maximum na 72, a ustawiła na %d", (stats + 4)->max);
                    test_error((stats + 4)->range == 166, "Funkcja statistics_row() powinna ustawić zakres na 166, a ustawiła na %d", (stats + 4)->range);
                    test_error(((stats + 4)->avg > -12.666666666666666 - 0.01) && ((stats + 4)->avg < -12.666666666666666 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na -12.666666666666666, a ustawiła na %f", (stats + 4)->avg);
                    test_error(((stats + 4)->standard_deviation > 64.26334707885809 - 0.01) && ((stats + 4)->standard_deviation < 64.26334707885809 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 64.26334707885809, a ustawiła na %f", (stats + 4)->standard_deviation);
                           
                 
                    test_error((stats + 5)->min == 43, "Funkcja statistics_row() powinna ustawić minimum na 43, a ustawiła na %d", (stats + 5)->min);
                    test_error((stats + 5)->max == 53, "Funkcja statistics_row() powinna ustawić maximum na 53, a ustawiła na %d", (stats + 5)->max);
                    test_error((stats + 5)->range == 10, "Funkcja statistics_row() powinna ustawić zakres na 10, a ustawiła na %d", (stats + 5)->range);
                    test_error(((stats + 5)->avg > 48.0 - 0.01) && ((stats + 5)->avg < 48.0 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 48.0, a ustawiła na %f", (stats + 5)->avg);
                    test_error(((stats + 5)->standard_deviation > 5.0 - 0.01) && ((stats + 5)->standard_deviation < 5.0 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 5.0, a ustawiła na %f", (stats + 5)->standard_deviation);
                           
                 
                    test_error((stats + 6)->min == -61, "Funkcja statistics_row() powinna ustawić minimum na -61, a ustawiła na %d", (stats + 6)->min);
                    test_error((stats + 6)->max == 56, "Funkcja statistics_row() powinna ustawić maximum na 56, a ustawiła na %d", (stats + 6)->max);
                    test_error((stats + 6)->range == 117, "Funkcja statistics_row() powinna ustawić zakres na 117, a ustawiła na %d", (stats + 6)->range);
                    test_error(((stats + 6)->avg > 9.0 - 0.01) && ((stats + 6)->avg < 9.0 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 9.0, a ustawiła na %f", (stats + 6)->avg);
                    test_error(((stats + 6)->standard_deviation > 46.37887450122092 - 0.01) && ((stats + 6)->standard_deviation < 46.37887450122092 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 46.37887450122092, a ustawiła na %f", (stats + 6)->standard_deviation);
                           
                 
                    test_error((stats + 7)->min == -61, "Funkcja statistics_row() powinna ustawić minimum na -61, a ustawiła na %d", (stats + 7)->min);
                    test_error((stats + 7)->max == 56, "Funkcja statistics_row() powinna ustawić maximum na 56, a ustawiła na %d", (stats + 7)->max);
                    test_error((stats + 7)->range == 117, "Funkcja statistics_row() powinna ustawić zakres na 117, a ustawiła na %d", (stats + 7)->range);
                    test_error(((stats + 7)->avg > 9.0 - 0.01) && ((stats + 7)->avg < 9.0 + 0.01), "Funkcja statistics_row() powinna ustawić średnią na 9.0, a ustawiła na %f", (stats + 7)->avg);
                    test_error(((stats + 7)->standard_deviation > 46.37887450122092 - 0.01) && ((stats + 7)->standard_deviation < 46.37887450122092 + 0.01), "Funkcja statistics_row() powinna ustawić odchylenie standardowe na 46.37887450122092, a ustawiła na %f", (stats + 7)->standard_deviation);
                

                free(stats);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji statistics_row
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji statistics_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int V[] = {34, -91, 74, -66, -67, 33, 17, -36, -51, 61, -1};
    int A[] = {-52, 71, 71, -80, -1};
    int Z[] = {-58, 70, -96, 92, 41, -1};
    int G[] = {81, 99, 9, -33, -3, 96, -1};
    int R[] = {53, 72, 40, 47, -16, -91, -34, -94, -91, -1};
    int B[] = {53, 43, -1};
    int S[] = {-61, 56, -47, 55, 26, 25, -1};
    int X[] = {-61, 56, -47, 55, 26, 25, -1};
    int *P[] = {V, A, Z, G, R, B, S, X, NULL};
      

            int err_code = statistics_row(P, NULL);
            test_error(err_code == -1, "Funkcja statistics_row() powinna zwrócić -1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji statistics_row
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji statistics_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = statistics_row(NULL, NULL);
            test_error(err_code == -1, "Funkcja statistics_row() powinna zwrócić -1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji statistics_row
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji statistics_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct statistic_t *stats;

            int err_code = statistics_row(NULL, &stats);
            test_error(err_code == -1, "Funkcja statistics_row() powinna zwrócić -1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji statistics_row (limit sterty ustawiono na 0 bajtów)
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji statistics_row (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

            struct statistic_t *stats;

            int V[] = {34, -91, 74, -66, -67, 33, 17, -36, -51, 61, -1};
    int A[] = {-52, 71, 71, -80, -1};
    int Z[] = {-58, 70, -96, 92, 41, -1};
    int G[] = {81, 99, 9, -33, -3, 96, -1};
    int R[] = {53, 72, 40, 47, -16, -91, -34, -94, -91, -1};
    int B[] = {53, 43, -1};
    int S[] = {-61, 56, -47, 55, 26, 25, -1};
    int X[] = {-61, 56, -47, 55, 26, 25, -1};
    int *P[] = {V, A, Z, G, R, B, S, X, NULL};
      

            int err_code = statistics_row(P, &stats);
            test_error(err_code == -2, "Funkcja statistics_row() powinna zwrócić -2, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 224 bajtów)
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 224 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(224);
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load("similar.txt", &ptr, fmt_binary);
            test_error(err_code == 0, "Funkcja load() powinna zwrócić 0, a zwróciła %d", err_code);

            onerror_terminate();

            printf("\n***TEST 3***\n\n");
            printf("***START***\n");
            display(ptr);
            printf("***END***\n");

            destroy(&ptr);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 172 bajtów)
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 172 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(172);
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load("student.bin", &ptr, fmt_text);
            test_error(err_code == 0, "Funkcja load() powinna zwrócić 0, a zwróciła %d", err_code);

            printf("\n***TEST 4***\n\n");
            printf("***START***\n");
            display(ptr);
            printf("***END***\n");


            destroy(&ptr);
            
            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji load
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load("degree.bin", &ptr, fmt_binary);
            test_error(err_code == 3, "Funkcja load() powinna zwrócić 3, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji load
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load("bird.txt", &ptr, fmt_text);
            test_error(err_code == 3, "Funkcja load() powinna zwrócić 3, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji load
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load("season.txt", &ptr, fmt_text);
            test_error(err_code == 3, "Funkcja load() powinna zwrócić 3, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji load
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load("gentle", &ptr, fmt_text);
            test_error(err_code == 2, "Funkcja load() powinna zwrócić 2, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji load
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load("gentle", &ptr, fmt_binary);
            test_error(err_code == 2, "Funkcja load() powinna zwrócić 2, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji load
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = load("similar.txt", NULL, fmt_binary);
            test_error(err_code == 1, "Funkcja load() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji load
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = load("student.bin", NULL, fmt_text);
            test_error(err_code == 1, "Funkcja load() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji load
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load(NULL, &ptr, fmt_binary);
            test_error(err_code == 1, "Funkcja load() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji load
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load(NULL, &ptr, fmt_text);
            test_error(err_code == 1, "Funkcja load() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji load
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = load(NULL, NULL, fmt_binary);
            test_error(err_code == 1, "Funkcja load() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji load
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = load(NULL, NULL, fmt_text);
            test_error(err_code == 1, "Funkcja load() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji load
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji load", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr;

            int err_code = load("student.bin", &ptr, 4);
            test_error(err_code == 1, "Funkcja load() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 0 bajtów)
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("student.bin", &ptr, fmt_text);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 40 bajtów)
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 40 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(40);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("student.bin", &ptr, fmt_text);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 76 bajtów)
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 76 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(76);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("student.bin", &ptr, fmt_text);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 116 bajtów)
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 116 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(116);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("student.bin", &ptr, fmt_text);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 144 bajtów)
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 144 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(144);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("student.bin", &ptr, fmt_text);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 0 bajtów)
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("similar.txt", &ptr, fmt_binary);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 64 bajtów)
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 64 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(64);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("similar.txt", &ptr, fmt_binary);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 96 bajtów)
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 96 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(96);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("similar.txt", &ptr, fmt_binary);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 124 bajtów)
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 124 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(124);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("similar.txt", &ptr, fmt_binary);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 136 bajtów)
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 136 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(136);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("similar.txt", &ptr, fmt_binary);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 148 bajtów)
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 148 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(148);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("similar.txt", &ptr, fmt_binary);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 152 bajtów)
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 152 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(152);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("similar.txt", &ptr, fmt_binary);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 192 bajtów)
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 192 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(192);
    
    //
    // -----------
    //
    
        
                int **ptr;
        
                int err_code = load("similar.txt", &ptr, fmt_binary);
                test_error(err_code == 4, "Funkcja load() powinna zwrócić 4, a zwróciła %d", err_code);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci - limit ustawiony na 0 bajtów
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci - limit ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci - limit ustawiony na 40 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci - limit ustawiony na 40 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(40);
    
    //
    // -----------
    //
    
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci - limit ustawiony na 40 bajtów
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci - limit ustawiony na 40 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(40);
    
    //
    // -----------
    //
    
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na brak pamięci - limit ustawiony na 96 bajtów
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na brak pamięci - limit ustawiony na 96 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(96);
    
    //
    // -----------
    //
    
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Reakcja na brak pamięci - limit ustawiony na 96 bajtów
//
void MTEST5(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(5, "Reakcja na brak pamięci - limit ustawiony na 96 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(96);
    
    //
    // -----------
    //
    
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji display
            UTEST2, // Sprawdzanie poprawności działania funkcji display
            UTEST3, // Sprawdzanie poprawności działania funkcji statistics_row
            UTEST4, // Sprawdzanie poprawności działania funkcji statistics_row
            UTEST5, // Sprawdzanie poprawności działania funkcji statistics_row
            UTEST6, // Sprawdzanie poprawności działania funkcji statistics_row
            UTEST7, // Sprawdzanie poprawności działania funkcji statistics_row
            UTEST8, // Sprawdzanie poprawności działania funkcji statistics_row
            UTEST9, // Sprawdzanie poprawności działania funkcji statistics_row
            UTEST10, // Sprawdzanie poprawności działania funkcji statistics_row (limit sterty ustawiono na 0 bajtów)
            UTEST11, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 224 bajtów)
            UTEST12, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 172 bajtów)
            UTEST13, // Sprawdzanie poprawności działania funkcji load
            UTEST14, // Sprawdzanie poprawności działania funkcji load
            UTEST15, // Sprawdzanie poprawności działania funkcji load
            UTEST16, // Sprawdzanie poprawności działania funkcji load
            UTEST17, // Sprawdzanie poprawności działania funkcji load
            UTEST18, // Sprawdzanie poprawności działania funkcji load
            UTEST19, // Sprawdzanie poprawności działania funkcji load
            UTEST20, // Sprawdzanie poprawności działania funkcji load
            UTEST21, // Sprawdzanie poprawności działania funkcji load
            UTEST22, // Sprawdzanie poprawności działania funkcji load
            UTEST23, // Sprawdzanie poprawności działania funkcji load
            UTEST24, // Sprawdzanie poprawności działania funkcji load
            UTEST25, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 0 bajtów)
            UTEST26, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 40 bajtów)
            UTEST27, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 76 bajtów)
            UTEST28, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 116 bajtów)
            UTEST29, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 144 bajtów)
            UTEST30, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 0 bajtów)
            UTEST31, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 64 bajtów)
            UTEST32, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 96 bajtów)
            UTEST33, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 124 bajtów)
            UTEST34, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 136 bajtów)
            UTEST35, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 148 bajtów)
            UTEST36, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 152 bajtów)
            UTEST37, // Sprawdzanie poprawności działania funkcji load (limit sterty ustawiono na 192 bajtów)
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(37); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci - limit ustawiony na 0 bajtów
            MTEST2, // Reakcja na brak pamięci - limit ustawiony na 40 bajtów
            MTEST3, // Reakcja na brak pamięci - limit ustawiony na 40 bajtów
            MTEST4, // Reakcja na brak pamięci - limit ustawiony na 96 bajtów
            MTEST5, // Reakcja na brak pamięci - limit ustawiony na 96 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(5); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}