#pragma once
enum save_format_t
{
    fmt_binary = 0,
    fmt_text = 1
};
