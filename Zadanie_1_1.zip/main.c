#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
	char path[31];

	printf("path: ");
	scanf("%30s", path);

	FILE* file = fopen(path, "rb");

	if (file == NULL)
	{
		printf("Couldn't open file\n");
		return 4;
	}

	int c;
	int any = 0;

	while ((c = fgetc(file)) != -1)
	{
		printf("%c", (char)c);
		any = 1;
	}

	if (!any)
	{
		printf("Nothing to show\n");
	}

	fclose(file);

	return 0;
}

