#include <stdio.h>
#include <stdlib.h>
#include "array.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
    int rozmiar;
    int ile;
    struct array_t tablica;

    printf("Podaj wielkosc tablicy: ");
    if(scanf("%d", &rozmiar) != 1)
    {
        printf("Incorrect input\n");
        return 1;
    }

    if(rozmiar < 1)
    {
        printf("Incorrect input data\n");
        return 2;
    }


    int error = array_create(&tablica, rozmiar);

    if (error == 2)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }

    printf("Podaj liczby do tablicy: ");
    do {
        if(scanf("%d", &ile) != 1)
        {
            printf("Incorrect input\n");
            array_destroy(&tablica);
            return 1;
        }

        if(ile == 0) break;

        array_push_back(&tablica, ile);
        if(tablica.size == tablica.capacity)
        {
            printf("Buffer is full\n");
            break;
        }
    }while(1);

    if(tablica.size == 0)
    {
        printf("Buffer is empty\n");
        array_destroy(&tablica);
        return 0;
    }

    array_display(&tablica);
    array_destroy(&tablica);
    return 0;
}

