/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Bezpieczna tablica
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 20:09:42.043790
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = 7, .capacity = -2 };

                printf("#####START#####");
                int res = array_create(&ptr, -75);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!1)
                {           
            
                    test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == -75, "Funkcja array_create() powinna ustawić wartość capacity size w strukturze na -75, a ustawiła na %d", ptr.capacity);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = 4, .capacity = -6 };

                printf("#####START#####");
                int res = array_create(&ptr, 0);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!1)
                {           
            
                    test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == 0, "Funkcja array_create() powinna ustawić wartość capacity size w strukturze na 0, a ustawiła na %d", ptr.capacity);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = 10, .capacity = 0 };

                printf("#####START#####");
                int res = array_create(&ptr, 82);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!0)
                {           
            
                    test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == 82, "Funkcja array_create() powinna ustawić wartość capacity size w strukturze na 82, a ustawiła na %d", ptr.capacity);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = -10, .capacity = -1 };

                printf("#####START#####");
                int res = array_create(&ptr, 2107);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!0)
                {           
            
                    test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == 2107, "Funkcja array_create() powinna ustawić wartość capacity size w strukturze na 2107, a ustawiła na %d", ptr.capacity);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 380 bajtów)
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 380 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(380);
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = 10, .capacity = -6 };

                printf("#####START#####");
                int res = array_create(&ptr, 95);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 95, "Funkcja array_create() powinna ustawić wartość pola capacity w strukturze na 95, a ustawiła na %d", ptr.capacity);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 87 bajtów)
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 87 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(87);
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = -3, .capacity = -2 };

                printf("#####START#####");
                int res = array_create(&ptr, 95);
                printf("#####END#####");

                test_error(res == 2, "Funkcja array_create() powinna zwrócić wartość 2, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = array_create(NULL, 95);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int array[] = {72, 92, 46, -72, 28, 45, -28, -65, 8, 89, 11, -100, 18, 79, -34, 38, 52, 67, -80};
        
                struct array_t ptr = { .size = 10, .capacity = 1 };

                printf("#####START#####");
                int res = array_create(&ptr, 19);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 19, "Funkcja array_create() powinna ustawić wartość pola capacity w strukturze na 19, a ustawiła na %d", ptr.capacity);

                for (int i = 0; i < 19; ++i)
                {
                        printf("#####START#####");
                        res = array_push_back(&ptr, array[i]);
                        printf("#####END#####");
                        
                        test_error(res == 0, "Funkcja array_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 19, "Funkcja array_push_back() powinna ustawić wartość pola capacity w strukturze na 19, a ustawiła na %d", ptr.capacity);
                        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr.ptr[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                printf("#####START#####");
                res = array_push_back(&ptr, 67);
                printf("#####END#####");

                test_error(res == 2, "Funkcja array_push_back() powinna zwrócić wartość 2, a zwróciła %d", res);
                test_error(ptr.size == 19, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na 19, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 19, "Funkcja array_push_back() powinna ustawić wartość pola capacity w strukturze na 19, a ustawiła na %d", ptr.capacity);
                
                for (int j = 0; j < 19; ++j)
                    test_error(ptr.ptr[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr.ptr[j]);
                
                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int array[] = {51, 16, -34, -31, 41, 27, 15, -98, -79, -85, -21, -24, 49, -62, -96, -81, 15, 0, 93, -19, -62, -40, 13, -91, 37, -46, -90, -20, 9, -34, -76, 57, -91, 72, -38, 20, -28, 85, -15, 75, -31, 42, -32, -26, -79, 27, -23, 85, -39, 93, -6, -59, 71, 63, -76, -59, -8, 72, -80, -36, -63, -36, -54, 39, -46, 31, -2, -73, 8, 29, -26, 65, 42, 42, 60, -69, -88, 70, -60, -28, -66};
        
                struct array_t ptr = { .size = -10, .capacity = -10 };

                printf("#####START#####");
                int res = array_create(&ptr, 81);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 81, "Funkcja array_create() powinna ustawić wartość pola capacity w strukturze na 81, a ustawiła na %d", ptr.capacity);

                for (int i = 0; i < 81; ++i)
                {
                        printf("#####START#####");
                        res = array_push_back(&ptr, array[i]);
                        printf("#####END#####");
                        
                        test_error(res == 0, "Funkcja array_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 81, "Funkcja array_push_back() powinna ustawić wartość pola capacity w strukturze na 81, a ustawiła na %d", ptr.capacity);
                        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr.ptr[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                printf("#####START#####");
                res = array_push_back(&ptr, 68);
                printf("#####END#####");

                test_error(res == 2, "Funkcja array_push_back() powinna zwrócić wartość 2, a zwróciła %d", res);
                test_error(ptr.size == 81, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na 81, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 81, "Funkcja array_push_back() powinna ustawić wartość pola capacity w strukturze na 81, a ustawiła na %d", ptr.capacity);
                
                for (int j = 0; j < 81; ++j)
                    test_error(ptr.ptr[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr.ptr[j]);
                
                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {27, -80, -15, -45, -93, 21, -40, 2, -61, 41, -30, -53, -83, 93};
                struct array_t ptr = { .ptr = array, .size = -4, .capacity = 5 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, -35);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {27, -80, -15, -45, -93, 21, -40, 2, -61, 41, -30, -53, -83, 93};
                struct array_t ptr = { .ptr = array, .size = 0, .capacity = -3 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, 6);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {27, -80, -15, -45, -93, 21, -40, 2, -61, 41, -30, -53, -83, 93};
                struct array_t ptr = { .ptr = array, .size = 15, .capacity = 6 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, 72);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {27, -80, -15, -45, -93, 21, -40, 2, -61, 41, -30, -53, -83, 93};
                struct array_t ptr = { .ptr = array, .size = 0, .capacity = 0 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, 10);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {27, -80, -15, -45, -93, 21, -40, 2, -61, 41, -30, -53, -83, 93};
                struct array_t ptr = { .ptr = array, .size = 12, .capacity = -8 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, 84);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {27, -80, -15, -45, -93, 21, -40, 2, -61, 41, -30, -53, -83, 93};
                struct array_t ptr = { .ptr = array, .size = -11, .capacity = -4 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, -41);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            int res = array_push_back(NULL, 41);
            printf("#####END#####");

            test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji array_destroy
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji array_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = -9, .capacity = 3 };

                printf("#####START#####");
                int res = array_create(&ptr, 30);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 30, "Funkcja array_create() powinna ustawić wartość pola capacity w strukturze na 30, a ustawiła na %d", ptr.capacity);

                printf("#####START#####");
                array_destroy(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji array_destroy
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji array_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = 1, .capacity = 2 };

                printf("#####START#####");
                int res = array_create(&ptr, 1233);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 1233, "Funkcja array_create() powinna ustawić wartość pola capacity w strukturze na 1233, a ustawiła na %d", ptr.capacity);

                printf("#####START#####");
                array_destroy(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji array_destroy
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji array_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


            printf("#####START#####");
            array_destroy(NULL);
            printf("#####END#####");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji array_destroy
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji array_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct array_t ptr = { .ptr = NULL, .size = 10, .capacity = 14 };

            printf("#####START#####");
            array_destroy(&ptr);
            printf("#####END#####");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji array_display
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji array_display", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int array[] = {27, -80, -15, -45, -93, 21, -40, 2, -61, 41, -30, -53, -83, 93};

            struct array_t arr;
            arr.ptr = array;

    //-------------1-----------------------

            printf("Test 1: ***START***\n");
            array_display(NULL);
            printf("***END***\n");


    //-------------2-----------------------

            arr.capacity = 13;
            arr.size = 14;

            printf("Test 2: ***START***\n");
            array_display(&arr);
            printf("***END***\n");


    //-------------3-----------------------

            arr.capacity = 14;
            arr.size = -14;

            printf("Test 3: ***START***\n");
            array_display(&arr);
            printf("***END***\n");


    //-------------4-----------------------

            arr.capacity = 14;
            arr.size = 0;

            printf("Test 4: ***START***\n");
            array_display(&arr);
            printf("***END***\n");

    //-------------5-----------------------

            arr.capacity = 14;
            arr.size = 14;
            arr.ptr = NULL;

            printf("Test 5: ***START***\n");
            array_display(&arr);
            printf("***END***\n");

    //-------------6-----------------------

            arr.capacity = 14;
            arr.size = 14;
            arr.ptr = array;

            printf("Test 6: ***START***\n");
            array_display(&arr);
            printf("***END***\n");

    //-------------7-----------------------

            arr.capacity = 14;
            arr.size = 14 - 1;

            printf("Test 7: ***START***\n");
            array_display(&arr);
            printf("***END***\n");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci (limit sterty ustawiono na 21 bajtów)
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci (limit sterty ustawiono na 21 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(21);
    
    //
    // -----------
    //
    
            printf("***START***\n");
            int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
            printf("\n***END***\n");
            test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji array_create
            UTEST2, // Sprawdzanie poprawności działania funkcji array_create
            UTEST3, // Sprawdzanie poprawności działania funkcji array_create
            UTEST4, // Sprawdzanie poprawności działania funkcji array_create
            UTEST5, // Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 380 bajtów)
            UTEST6, // Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 87 bajtów)
            UTEST7, // Sprawdzanie poprawności działania funkcji array_create
            UTEST8, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST9, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST10, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST11, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST12, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST13, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST14, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST15, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST16, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST17, // Sprawdzanie poprawności działania funkcji array_destroy
            UTEST18, // Sprawdzanie poprawności działania funkcji array_destroy
            UTEST19, // Sprawdzanie poprawności działania funkcji array_destroy
            UTEST20, // Sprawdzanie poprawności działania funkcji array_destroy
            UTEST21, // Sprawdzanie poprawności działania funkcji array_display
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(21); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci (limit sterty ustawiono na 21 bajtów)
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(1); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}