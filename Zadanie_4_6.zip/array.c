#include "array.h"
#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int array_create(struct array_t *tablica, int N)
{
    if(tablica == NULL || N < 1) return 1;

    tablica->ptr = malloc(N * sizeof(int));
    tablica->size = 0;
    tablica->capacity = N;

    if(tablica->ptr == NULL) return 2;

    return 0;
}
int array_push_back(struct array_t *tablica, int value)
{
    if(tablica == NULL || tablica->size < 0 || tablica->capacity < 1 || tablica->size > tablica->capacity) return 1;

    if(tablica->size == tablica->capacity) return 2;

    *(tablica->ptr + tablica->size) = value;
    tablica->size += 1;

    return 0;
}
void array_display(const struct array_t *tablica)
{
    if(tablica == NULL || tablica->size > tablica->capacity || tablica->size < 1 || tablica->ptr == NULL) return;

    for (int i = 0; i < tablica->size; ++i)
    {
        printf("%d ", *(tablica->ptr + i));
    }
}
void array_destroy(struct array_t *tablica)
{
    if(tablica == NULL || tablica->ptr == NULL) return;

    free(tablica->ptr);
}
