#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "stack.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main() {
    struct stack_t* stos;
    unsigned long long liczba;
    if (stack_init(&stos)) {
        printf("Failed to allocate memory");
        return 8;
    }   
    printf("Enter number: ");
    if (!scanf("%llu", &liczba))
    {
        stack_destroy(&stos);
        printf("Incorrect input");
        return 1;
    }
    unsigned long long limit;
    if (liczba == 0)
    {
        limit = 1;
    }
    else
    {
        limit = (int)ceil(log2(liczba));
    }
    for (unsigned long long i = 0; i < limit; i++)
    {
        if ((liczba & (1ul << i)) != 0)
        {
            if (stack_push(stos, 1) == 2)
            {
                stack_destroy(&stos);
                printf("Failed to allocate memory");
                return 8;
            }
        }
        else
        {
            stack_push(stos, 0);
        }
    }
    while (!stack_empty(stos))
    {
        printf("%d ", stack_pop(stos, NULL));
    }
    stack_destroy(&stos);
    return 0;
}
