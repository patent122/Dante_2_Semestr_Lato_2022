#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int **create_array_2d(int szerokosc, int wysokosc);
void display_array_2d(int **ptr, int szerokosc, int wysokosc);
void destroy_array_2d(int **ptr, int wysokosc);

int main()
{
    int szerokosc, wysokosc;
    int **dane = NULL;
    printf("Podaj szerokość i wysokość: ");
    if(scanf("%d %d", &szerokosc, &wysokosc) != 2)
    {
        printf("Incorrect input\n");
        return 1;
    }
    if(szerokosc < 1 || wysokosc < 1)
    {
        printf("Incorrect input data\n");
        return 2;
    }

    dane = create_array_2d(szerokosc, wysokosc);

    if(dane == NULL)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }

    printf("Podaj tablice: ");
    for (int i = 0; i < wysokosc; ++i)
    {
        for (int j = 0; j < szerokosc; ++j)
        {
            if(scanf("%d", *(dane+i)+j) != 1)
            {
                printf("Incorrect input\n");
                destroy_array_2d(dane, wysokosc);
                return 1;
            }
        }
    }

    display_array_2d(dane, szerokosc, wysokosc);
    destroy_array_2d(dane, wysokosc);

    return 0;
}

int **create_array_2d(int szerokosc, int wysokosc)
{
    if(wysokosc < 1 || szerokosc < 1) return NULL;

    int **dane = malloc(wysokosc * sizeof(int*));
    if(dane == NULL)
    {
        return NULL;
    }

    for (int i = 0; i < wysokosc; ++i)
    {
        *(dane + i) = malloc(szerokosc * sizeof(int));
        if(*(dane+i) == NULL)
        {
            for (int j = 0; j < i ; ++j)
            {
                free(*(dane + j));
            }
            free(dane);
            return NULL;
        }
    }

    return dane;
}

void display_array_2d(int **ptr, int szerokosc, int wysokosc)
{
    if(ptr == NULL || wysokosc < 1 || szerokosc < 1) return;

    for (int i = 0; i < wysokosc; ++i)
    {
        for (int j = 0; j < szerokosc; ++j)
        {
            printf("%3d ", *(*(ptr + i) + j));
        }
        printf("\n");
    }
}
void destroy_array_2d(int **ptr, int wysokosc)
{
    if(ptr == NULL || wysokosc < 1) return;

    for (int i = 0; i < wysokosc; ++i) {
        free(*(ptr+i));
    }
    free(ptr);
}
