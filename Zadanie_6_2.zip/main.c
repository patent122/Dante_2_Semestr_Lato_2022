#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tested_declarations.h"
#include "rdebug.h"

#define SET_PTR_SAFE(d, s) if (d) *d = s

struct student_t 
{
    char *name;
    char *surname;
    int index;
    char* internal;
};

struct student_t* read(int *err_code);
void destroy(struct student_t **p);
void show(const struct student_t* p);
char* parse_until_comma(char** destination, char* source);

int main()
{
    struct student_t *p;
    int exit_code;
    p = read(&exit_code);
    if (exit_code == 4)
    {
        printf("Failed to allocate memory");
        return 8;
    }
    else if (exit_code != 0)
    {
        printf("Incorrect input");
    }
    else
    {
        show(p);
    }
    destroy(&p);
    return exit_code;
}

struct student_t* read(int *err_code)
{
    struct student_t *p = malloc(sizeof(struct student_t));
    if (p == NULL)
    {
        SET_PTR_SAFE(err_code, 4);
        return NULL;
    }
    char *buffer = malloc(101);
    if (buffer == NULL)
    {
        free(p);
        SET_PTR_SAFE(err_code, 4);
        return NULL;
    }
    memset(p, 0, sizeof(struct student_t));
    char* internal = buffer;
    printf("Podaj dane: ");
    scanf("%99[^\n]", buffer);
    if (!(buffer = parse_until_comma(&p->name, buffer)))
    {
        SET_PTR_SAFE(err_code, 1);
        free(p);
        free(internal);
        return NULL;
    }
    if (!(buffer = parse_until_comma(&p->surname, buffer)))
    {
        SET_PTR_SAFE(err_code, 2);
        free(p);
        free(internal);
        return NULL;
    }
    if (!sscanf(buffer, "%d", &p->index))
    {
        SET_PTR_SAFE(err_code, 3);
        free(p);
        free(internal);
        return NULL;
    }
    SET_PTR_SAFE(err_code, 0);
    p->internal = internal;
    return p;
    
}

void show(const struct student_t* p)
{
    if (p == NULL)
    {
        return;
    }
    printf("%s %s, %d", p->name, p->surname, p->index);
}

void destroy(struct student_t **p)
{
    if (p != NULL && *p != NULL)
    {
        if ((*p)->internal != NULL)
        {
            free((*p)->internal);
        }
        free(*p);
        *p = NULL;
    }
}

char* parse_until_comma(char** destination, char* source)
{
    int c, index = 0, result = 0, in_state = 0;
    char *begin = NULL;
    while ((c = *(source + index++)) != 0)
    {
        if (c == ',')
        {
            result = 1;
            break;
        }
        else if (c == ' ' && !in_state)
        {
            continue;
        }
        if (begin == NULL) 
        {
            begin = source + index - 1;
        }
        in_state = 1;
    }
    if (result == 1 && begin != NULL)
    {
        int last_space = index - 1;
        while (*(source + last_space) == ' ' || *(source + last_space) == ',') 
        {
            last_space--;
        }
        *destination = begin;
        *(source + last_space + 1) = '\0';
        return source + index;
    }
    return NULL;
}

