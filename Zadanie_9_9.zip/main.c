#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "tested_declarations.h"
#include "rdebug.h"

int is_sparse(uint64_t liczba) {
    unsigned int czy_jeden = 0;
    for (unsigned int i = 0; i < sizeof(uint64_t) * 8; i++) 
    {
        if ((liczba >> i) % 2 == 1) 
        {
            if (czy_jeden) 
            {
                return 0;
            }
            czy_jeden = 1;
        }
        else 
        {
            czy_jeden = 0;
        }
    }
    return 1;
}

int main() 
{
    printf("Podaj wartosc: ");
    unsigned long long liczba;
    if (scanf("%llu", &liczba) != 1) 
    {
        printf("Incorrect input");
        return 1;
    }
    printf("Liczba: %.16llx, Wynik: %d", liczba, is_sparse(liczba));
    return 0;
}
