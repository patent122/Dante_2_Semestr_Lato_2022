#include "comparators.h"
#include "comparators.h"
#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int sort_int(int* tablica, int rozmiar, int(*comparator)(int, int)) {
    if (tablica == NULL || rozmiar <= 0 || comparator == NULL) {
        return 1;
    }
    int change = 1;
    while (change == 1) {
        change = 0;
        for (int i = 0; i < rozmiar - 1; i++) {
            if (comparator(*(tablica + i), *(tablica + i + 1)) == 1) {
                change = 1;
                int tt = *(tablica + i);
                *(tablica + i) = *(tablica + i + 1);
                *(tablica + i + 1) = tt;
            }
        }
    }
    return 0;
}

int comp_int(int aa, int bb) {
    if (aa < bb) {
        return -1;
    }
    if (aa > bb) {
        return 1;
    }
    return 0;
}

int comp_int_abs(int aa, int bb) {
    if (aa < 0) {
        aa = -aa;
    }
    if (bb < 0) {
        bb = -bb;
    }
    if (aa < bb) {
        return -1;
    }
    if (aa > bb) {
        return 1;
    }
    return 0;
}

int digit_sum(int n) {
    if (n < 0) {
        n = -n;
    }
    if (n == 0) {
        return 0;
    }
    return n % 10 + digit_sum(n / 10);
}

int length(int n) {
    if (n < 0) {
        n = -n;
    }
    if (n < 10 && n > -10) {
        return 1;
    }
    return 1 + length(n / 10);
}

int comp_int_length(int aa, int bb) {
    if (length(aa) < length(bb)) {
        return -1;
    }
    if (length(aa) > length(bb)) {
        return 1;
    }
    return 0;

}

int comp_int_digits_sum(int aa, int bb) {
    if (digit_sum(aa) < digit_sum(bb)) {
        return -1;
    }
    if (digit_sum(aa) > digit_sum(bb)) {
        return 1;
    }
    return 0;
}
