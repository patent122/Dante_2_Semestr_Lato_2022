/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Sortowanie liczb 1D
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-19 19:44:41.435255
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji comp_int
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji comp_int", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int res = comp_int(68, 6);
        
                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int() jest niewłaściwa, powinna być liczba dodatnia", res);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji comp_int
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji comp_int", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int res = comp_int(-2, -15);
        
                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int() jest niewłaściwa, powinna być liczba dodatnia", res);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji comp_int
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji comp_int", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int res = comp_int(6, -2);
        
                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int() jest niewłaściwa, powinna być liczba dodatnia", res);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji comp_int
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji comp_int", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int res = comp_int(-10, 36);
        
                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int() jest niewłaściwa, powinna być liczba ujemna", res);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji comp_int
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji comp_int", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int res = comp_int(-50, -15);
        
                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int() jest niewłaściwa, powinna być liczba ujemna", res);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji comp_int
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji comp_int", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int res = comp_int(9, 34);
        
                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int() jest niewłaściwa, powinna być liczba ujemna", res);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji comp_int
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji comp_int", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int res = comp_int(-32, -32);
        
                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int() jest niewłaściwa, powinna być liczba równa 0", res);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji comp_int
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji comp_int", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int res = comp_int(95, 95);
        
                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int() jest niewłaściwa, powinna być liczba równa 0", res);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji comp_int
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji comp_int", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int res = comp_int(4, 4);
        
                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int() jest niewłaściwa, powinna być liczba równa 0", res);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji comp_int_abs
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji comp_int_abs", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_abs(84, 7);
                printf("%d ", res);

                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int_abs() jest niewłaściwa, powinna być liczba dodatnia", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji comp_int_abs
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji comp_int_abs", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_abs(-4, -12);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_abs() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji comp_int_abs
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji comp_int_abs", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_abs(9, -16);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_abs() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji comp_int_abs
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji comp_int_abs", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_abs(-72, 6);
                printf("%d ", res);

                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int_abs() jest niewłaściwa, powinna być liczba dodatnia", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji comp_int_abs
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji comp_int_abs", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_abs(-87, -11);
                printf("%d ", res);

                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int_abs() jest niewłaściwa, powinna być liczba dodatnia", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji comp_int_abs
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji comp_int_abs", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_abs(6, 86);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_abs() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji comp_int_abs
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji comp_int_abs", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_abs(-100, 100);
                printf("%d ", res);

                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int_abs() jest niewłaściwa, powinna być liczba równa 0", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji comp_int_abs
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji comp_int_abs", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_abs(-95, 95);
                printf("%d ", res);

                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int_abs() jest niewłaściwa, powinna być liczba równa 0", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji comp_int_abs
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji comp_int_abs", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_abs(0, 0);
                printf("%d ", res);

                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int_abs() jest niewłaściwa, powinna być liczba równa 0", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji comp_int_length
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji comp_int_length", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_length(8085, -819);
                printf("%d ", res);

                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int_length() jest niewłaściwa, powinna być liczba dodatnia", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji comp_int_length
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji comp_int_length", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_length(-6698, -360);
                printf("%d ", res);

                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int_length() jest niewłaściwa, powinna być liczba dodatnia", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji comp_int_length
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji comp_int_length", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_length(-1157, -319);
                printf("%d ", res);

                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int_length() jest niewłaściwa, powinna być liczba dodatnia", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji comp_int_length
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji comp_int_length", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_length(-489, 7662);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_length() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji comp_int_length
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji comp_int_length", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_length(-8265, -11292);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_length() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji comp_int_length
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji comp_int_length", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_length(9404, 321978);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_length() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji comp_int_length
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji comp_int_length", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_length(-42207, 88611);
                printf("%d ", res);

                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int_length() jest niewłaściwa, powinna być liczba równa 0", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji comp_int_length
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji comp_int_length", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_length(225469, -916492);
                printf("%d ", res);

                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int_length() jest niewłaściwa, powinna być liczba równa 0", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji comp_int_length
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji comp_int_length", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_length(68090, 15573);
                printf("%d ", res);

                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int_length() jest niewłaściwa, powinna być liczba równa 0", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(5199, -593);
                printf("%d ", res);

                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba dodatnia", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(-8110, -347);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(-6214, -684);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(-728, 2758);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(-8457, -85786);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(8414, 597931);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(-93700, 83871);
                printf("%d ", res);

                test_error(res < 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba ujemna", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(709969, -521832);
                printf("%d ", res);

                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba dodatnia", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(85757, 30244);
                printf("%d ", res);

                test_error(res > 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba dodatnia", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(1001, 11);
                printf("%d ", res);

                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba równa 0", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji comp_int_digits_sum
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji comp_int_digits_sum", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = comp_int_digits_sum(1001, -101);
                printf("%d ", res);

                test_error(res == 0, "Wartość %d zwrócona przez funkcję comp_int_digits_sum() jest niewłaściwa, powinna być liczba równa 0", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji sort_int(comp_int)
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji sort_int(comp_int)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int tab[] = {81, -77, 54, -93, 87, 79, -11, 77, 26, -90, 83, -56, 45};
            int tab_sorted[] = {-93, -90, -77, -56, -11, 26, 45, 54, 77, 79, 81, 83, 87};

            int res = sort_int(tab, 13, comp_int);

            printf("Oczekiwany wynik sortowania: ");
            for (int i = 0; i < 13; ++i)
                printf("%d ", tab_sorted[i]);        

            printf("\n");
                
            printf("Otrzymany wynik sortowania: ");
            for (int i = 0; i < 13; ++i)
                printf("%d ", tab[i]);        

            printf("\n");
                
            test_error(res == 0, "Wartość %d zwrócona przez funkcję sort_int() jest niewłaściwa, powinno być 0", res);

            for (int i = 0; i < 13; ++i)
                test_error(tab[i] == tab_sorted[i], "Wartość pod indeksem %d jest niewłaściwa, powinno być %d, a jest %d", i, tab_sorted[i], tab[i]);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji sort_int(comp_int_abs)
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji sort_int(comp_int_abs)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int tab[] = {81, -77, 54, -93, 87, 79, -11, 77, 26, -90, 83, -56, 45};
            int tab_sorted[] = {-11, 26, 45, 54, -56, -77, 77, 79, 81, 83, 87, -90, -93};

            int res = sort_int(tab, 13, comp_int_abs);

            printf("Oczekiwany wynik sortowania: ");
            for (int i = 0; i < 13; ++i)
                printf("%d ", tab_sorted[i]);        
            
            printf("\n");
                
            printf("Otrzymany wynik sortowania: ");
            for (int i = 0; i < 13; ++i)
                printf("%d ", tab[i]);        

            printf("\n");

            test_error(res == 0, "Wartość %d zwrócona przez funkcję sort_int() jest niewłaściwa, powinno być 0", res);

            for (int i = 0; i < 13; ++i)
                test_error(tab[i] == tab_sorted[i] || tab[i] == -tab_sorted[i], "Wartość pod indeksem %d jest niewłaściwa, powinno być %d, a jest %d", i, tab_sorted[i], tab[i]);
        
            for (int i = 0; i < 13; ++i)
                for (int j = 0; j < 13; ++j)
                    if (tab[i] == tab_sorted[j])
                    {
                            tab_sorted[j] = 0;
                            break;
                    }

            int sum = 0;
                    
            for (int i = 0; i < 13; ++i)
                sum += tab_sorted[i];
                
            test_error(sum == 0, "Wartości w tablicy po sortowaniu funkcją sort_int() są różne od tych podanych na wejściu");
                        
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji sort_int(comp_int_length)
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji sort_int(comp_int_length)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int tab[] = {9, -86, 9542376, 537, -26492, 1, -12317, -5860, -1, 617159, 211, -10, 78122, 1, 497676};
            int tab_sorted[] = {9, 1, -1, 1, -86, -10, 537, 211, -5860, -26492, -12317, 78122, 617159, 497676, 9542376};

            int res = sort_int(tab, 15, comp_int_length);

            printf("Oczekiwany wynik sortowania: ");
            for (int i = 0; i < 15; ++i)
                printf("%d ", tab_sorted[i]);        

            printf("\n");

            printf("Otrzymany wynik sortowania: ");
            for (int i = 0; i < 15; ++i)
                printf("%d ", tab[i]);        

            printf("\n");

            test_error(res == 0, "Wartość %d zwrócona przez funkcję sort_int() jest niewłaściwa, powinno być 0", res);

            for (int i = 0; i < 15; ++i)
                test_error(comp_int_length(tab[i], tab_sorted[i]) >= 0, "Wartość pod indeksem %d jest niewłaściwa", i);

            for (int i = 0; i < 15; ++i)
                for (int j = 0; j < 15; ++j)
                    if (tab[i] == tab_sorted[j])
                    {
                            tab_sorted[j] = 0;
                            break;
                    }

            int sum = 0;

            for (int i = 0; i < 15; ++i)
                sum += tab_sorted[i];

            test_error(sum == 0, "Wartości w tablicy po sortowaniu funkcją sort_int() są różne od tych podanych na wejściu");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji sort_int(comp_int_digits_sum)
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji sort_int(comp_int_digits_sum)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int tab[] = {54856, -49207, -1, -75, 85, 39363, 86, -55145, -511, -22844, -78985, -435, -1, -3428, -261182};
            int tab_sorted[] = {-1, -1, -511, -75, -435, 85, 86, -3428, -55145, -22844, -261182, -49207, 39363, 54856, -78985};

            int res = sort_int(tab, 15, comp_int_digits_sum);

            printf("Oczekiwany wynik sortowania: ");
            for (int i = 0; i < 15; ++i)
                printf("%d ", tab_sorted[i]);        

            printf("\n");

            printf("Otrzymany wynik sortowania: ");
            for (int i = 0; i < 15; ++i)
                printf("%d ", tab[i]);        

            printf("\n");

            test_error(res == 0, "Wartość %d zwrócona przez funkcję sort_int() jest niewłaściwa, powinno być 0", res);

            for (int i = 0; i < 15; ++i)
                test_error(comp_int_length(tab[i], tab_sorted[i]) >= 0, "Wartość pod indeksem %d jest niewłaściwa", i);

            for (int i = 0; i < 15; ++i)
                for (int j = 0; j < 15; ++j)
                    if (tab[i] == tab_sorted[j])
                    {
                            tab_sorted[j] = 0;
                            break;
                    }

            int sum = 0;

            for (int i = 0; i < 15; ++i)
                sum += tab_sorted[i];

            test_error(sum == 0, "Wartości w tablicy po sortowaniu funkcją sort_int() są różne od tych podanych na wejściu");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji sort_int(comp_int_digits_sum)
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji sort_int(comp_int_digits_sum)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int tab[] = {-1, -1, -511, -75, -435, 85, 86, -3428, -55145, -22844, -261182, -49207, 39363, 54856, -78985};
            int tab_sorted[] = {-1, -1, -511, -75, -435, 85, 86, -3428, -55145, -22844, -261182, -49207, 39363, 54856, -78985};
            
            int res = sort_int(tab, 15, NULL);
            test_error(res == 1, "Wartość %d zwrócona przez funkcję sort_int(tab, 15, NULL) jest niewłaściwa, powinno być 1 a jest %d", res);

            res = sort_int(tab, -15, comp_int);
            test_error(res == 1, "Wartość %d zwrócona przez funkcję sort_int(tab, -15, comp_int) jest niewłaściwa, powinno być 1 a jest %d", res);

            res = sort_int(tab, 0, comp_int);
            test_error(res == 1, "Wartość %d zwrócona przez funkcję sort_int(sort_int(tab, 0, comp_int)) jest niewłaściwa, powinno być 1 a jest %d", res);

            res = sort_int(NULL, 15, comp_int);
            test_error(res == 1, "Wartość %d zwrócona przez funkcję sort_int(sort_int(NULL, 15, comp_int)) jest niewłaściwa, powinno być 1 a jest %d", res);

            res = sort_int(NULL, -15, comp_int);
            test_error(res == 1, "Wartość %d zwrócona przez funkcję sort_int(sort_int(NULL, -15, comp_int)) jest niewłaściwa, powinno być 1 a jest %d", res);

            res = sort_int(tab, -15, NULL);
            test_error(res == 1, "Wartość %d zwrócona przez funkcję sort_int(sort_int(tab, -15, NULL)) jest niewłaściwa, powinno być 1 a jest %d", res);

            res = sort_int(NULL, 15, NULL);
            test_error(res == 1, "Wartość %d zwrócona przez funkcję sort_int(sort_int(NULL, 15, NULL)) jest niewłaściwa, powinno być 1 a jest %d", res);

            res = sort_int(tab, 1, comp_int);
            test_error(res == 0, "Wartość %d zwrócona przez funkcję sort_int(sort_int(tab, 1, comp_int)) jest niewłaściwa, powinno być 0 a jest %d", res);

            res = sort_int(tab, 1, comp_int);
            test_error(tab[0] == tab_sorted[0], "Wartość ustawiona na pozycji %d przez funkcję sort_int(sort_int(tab, 1, comp_int)) jest niewłaściwa, powinno być %d, a jest %d", 0, tab_sorted[0], tab[0]);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci - limit ustawiony na 0 bajtów
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci - limit ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci - limit ustawiony na 40 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci - limit ustawiony na 40 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(40);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji comp_int
            UTEST2, // Sprawdzanie poprawności działania funkcji comp_int
            UTEST3, // Sprawdzanie poprawności działania funkcji comp_int
            UTEST4, // Sprawdzanie poprawności działania funkcji comp_int
            UTEST5, // Sprawdzanie poprawności działania funkcji comp_int
            UTEST6, // Sprawdzanie poprawności działania funkcji comp_int
            UTEST7, // Sprawdzanie poprawności działania funkcji comp_int
            UTEST8, // Sprawdzanie poprawności działania funkcji comp_int
            UTEST9, // Sprawdzanie poprawności działania funkcji comp_int
            UTEST10, // Sprawdzanie poprawności działania funkcji comp_int_abs
            UTEST11, // Sprawdzanie poprawności działania funkcji comp_int_abs
            UTEST12, // Sprawdzanie poprawności działania funkcji comp_int_abs
            UTEST13, // Sprawdzanie poprawności działania funkcji comp_int_abs
            UTEST14, // Sprawdzanie poprawności działania funkcji comp_int_abs
            UTEST15, // Sprawdzanie poprawności działania funkcji comp_int_abs
            UTEST16, // Sprawdzanie poprawności działania funkcji comp_int_abs
            UTEST17, // Sprawdzanie poprawności działania funkcji comp_int_abs
            UTEST18, // Sprawdzanie poprawności działania funkcji comp_int_abs
            UTEST19, // Sprawdzanie poprawności działania funkcji comp_int_length
            UTEST20, // Sprawdzanie poprawności działania funkcji comp_int_length
            UTEST21, // Sprawdzanie poprawności działania funkcji comp_int_length
            UTEST22, // Sprawdzanie poprawności działania funkcji comp_int_length
            UTEST23, // Sprawdzanie poprawności działania funkcji comp_int_length
            UTEST24, // Sprawdzanie poprawności działania funkcji comp_int_length
            UTEST25, // Sprawdzanie poprawności działania funkcji comp_int_length
            UTEST26, // Sprawdzanie poprawności działania funkcji comp_int_length
            UTEST27, // Sprawdzanie poprawności działania funkcji comp_int_length
            UTEST28, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST29, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST30, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST31, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST32, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST33, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST34, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST35, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST36, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST37, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST38, // Sprawdzanie poprawności działania funkcji comp_int_digits_sum
            UTEST39, // Sprawdzanie poprawności działania funkcji sort_int(comp_int)
            UTEST40, // Sprawdzanie poprawności działania funkcji sort_int(comp_int_abs)
            UTEST41, // Sprawdzanie poprawności działania funkcji sort_int(comp_int_length)
            UTEST42, // Sprawdzanie poprawności działania funkcji sort_int(comp_int_digits_sum)
            UTEST43, // Sprawdzanie poprawności działania funkcji sort_int(comp_int_digits_sum)
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(43); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci - limit ustawiony na 0 bajtów
            MTEST2, // Reakcja na brak pamięci - limit ustawiony na 40 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(2); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}