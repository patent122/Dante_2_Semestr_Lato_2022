#include <stdio.h>

#include "comparators.h"
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int main() {
    int (**funkcje)(int, int);
    funkcje = malloc(sizeof(int (*)(int, int)) * 4);
    if (funkcje == NULL) {
        printf("Failed to allocate memory");
        return 8;
    }
    *(funkcje) = comp_int;
    *(funkcje + 1) = comp_int_abs;
    *(funkcje + 2) = comp_int_length;
    *(funkcje + 3) = comp_int_digits_sum;
    int dlugosc;
    printf("Podaj dlugosc tablicy: ");
    if (scanf("%d", &dlugosc) != 1) {
        printf("Incorrect input");
        free(funkcje);
        return 1;
    }
    if (dlugosc < 1) {
        printf("Incorrect input data");
        free(funkcje);
        return 2;
    }
    int* tablica = malloc(sizeof(int) * dlugosc);
    if (tablica == NULL) {
        free(funkcje);
        printf("Failed to allocate memory");
        return 8;
    }
    printf("Podaj liczby: ");
    for (int i = 0; i < dlugosc; i++) {
        if (scanf("%d", tablica + i) != 1) {
            printf("Incorrect input");
            free(tablica);
            free(funkcje);
            return 1;
        }
    }
    printf("Podaj rodzaj");
    int op;
    if (scanf("%d", &op) != 1) {
        printf("Incorrect input");
        free(tablica);
        free(funkcje);
        return 1;
    }
    if (op < 0 || op > 3) {
        printf("Incorrect input data");
        free(tablica);
        free(funkcje);
        return 2;
    }
    sort_int(tablica, dlugosc, *(funkcje + op));
    for (int i = 0; i < dlugosc; i++) {
        printf("%d ", *(tablica + i));
    }
    free(tablica);
    free(funkcje);
    return 0;
}

