#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
    float *liczba = NULL;
    liczba = (float*)malloc(sizeof(float));
    if(liczba == NULL)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }
    *(liczba) = (float)3.141593;

    printf("%f %p", *liczba, (void*)&liczba);

    free(liczba);

    return 0;
}

