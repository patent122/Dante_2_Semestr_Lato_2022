/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Zbiory liczb - statystyka ogólna
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 21:25:45.848336
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//


        struct statistic_t
        {
          int min;
          int max;
          float avg;
          float standard_deviation;
          int range;
        };    
    


//
//  Test 1: Sprawdzanie poprawności działania funkcji display
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji display", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("\n***TEST 1***\n\n");
            printf("***START***\n");
            display(NULL);
            printf("***END***\n");

            test_no_heap_leakage();
            onerror_terminate();
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji display
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji display", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int O[] = {986, 536, 640, 759, 111, 636, -1};
    int A[] = {-339, -197, -662, -46, -452, -794, -464, -313, -1};
    int S[] = {-759, -44, -642, -166, -944, -1};
    int J[] = {507, 667, 64, 862, 923, 154, 506, 805, 208, 512, -1};
    int L[] = {239, 878, 647, 245, 305, 319, 151, 502, 258, -1};
    int G[] = {-449, -552, -950, -95, -164, -556, -388, -1};
    int Y[] = {-1};
    int P[] = {-666, -603, -51, -704, -1};
    int H[] = {-286, -626, -156, -954, -993, -299, -726, -1};
    int U[] = {-880, -777, -882, -1};
    int *B[] = {O, A, S, J, L, G, Y, P, H, U, NULL};
      

            printf("\n***TEST 1***\n\n");
            printf("***START***\n");
            display(B);
            printf("***END***\n");

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji statistics
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji statistics", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                struct statistic_t *stats;
        
                int O[] = {986, 536, 640, 759, 111, 636, -1};
    int A[] = {-339, -197, -662, -46, -452, -794, -464, -313, -1};
    int S[] = {-759, -44, -642, -166, -944, -1};
    int J[] = {507, 667, 64, 862, 923, 154, 506, 805, 208, 512, -1};
    int L[] = {239, 878, 647, 245, 305, 319, 151, 502, 258, -1};
    int G[] = {-449, -552, -950, -95, -164, -556, -388, -1};
    int Y[] = {-1};
    int P[] = {-666, -603, -51, -704, -1};
    int H[] = {-286, -626, -156, -954, -993, -299, -726, -1};
    int U[] = {-880, -777, -882, -1};
    int *B[] = {O, A, S, J, L, G, Y, P, H, U, NULL};
      
        
                int err_code = statistics(B, &stats);
                test_error(err_code == 0, "Funkcja statistics() powinna zwrócić 0, a zwróciła %d", err_code);

                test_error(stats != NULL, "Funkcja statistics() powinna zaalokować pamięć na strukturę stats, a przypisała NULL");
        
                onerror_terminate();
        
                test_error(stats->min == -993, "Funkcja statistics() powinna ustawić minimum na -993, a ustawiła na %d", stats->min);
                test_error(stats->max == 986, "Funkcja statistics() powinna ustawić maximum na 986, a ustawiła na %d", stats->max);
                test_error(stats->range == 1979, "Funkcja statistics() powinna ustawić zakres na 1979, a ustawiła na %d", stats->range);
                test_error((stats->avg > -87.4506779661017) && (stats->avg < -87.43067796610168), "Funkcja statistics() powinna ustawić średnią na -87.44067796610169, a ustawiła na %f", stats->avg);
                test_error((stats->standard_deviation > 576.5862154172005) && (stats->standard_deviation < 576.6062154172005), "Funkcja statistics() powinna ustawić odchylenie standardowe na 576.5962154172005, a ustawiła na %f", stats->standard_deviation);
        
                free(stats);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji statistics
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji statistics", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                struct statistic_t *stats;
        
                int O[] = {71, 731, 879, 11, 422, 389, 711, 175, 124, -1};
    int A[] = {690, -1};
    int S[] = {707, 433, 36, 391, 990, 481, 87, 846, 786, -1};
    int J[] = {707, 433, 36, 391, 990, 481, 87, 846, 786, -1};
    int *L[] = {O, A, S, J, NULL};
      
        
                int err_code = statistics(L, &stats);
                test_error(err_code == 0, "Funkcja statistics() powinna zwrócić 0, a zwróciła %d", err_code);

                test_error(stats != NULL, "Funkcja statistics() powinna zaalokować pamięć na strukturę stats, a przypisała NULL");
        
                onerror_terminate();
        
                test_error(stats->min == 11, "Funkcja statistics() powinna ustawić minimum na 11, a ustawiła na %d", stats->min);
                test_error(stats->max == 990, "Funkcja statistics() powinna ustawić maximum na 990, a ustawiła na %d", stats->max);
                test_error(stats->range == 979, "Funkcja statistics() powinna ustawić zakres na 979, a ustawiła na %d", stats->range);
                test_error((stats->avg > 489.8828571428572) && (stats->avg < 489.90285714285716), "Funkcja statistics() powinna ustawić średnią na 489.89285714285717, a ustawiła na %f", stats->avg);
                test_error((stats->standard_deviation > 312.6653610017121) && (stats->standard_deviation < 312.68536100171207), "Funkcja statistics() powinna ustawić odchylenie standardowe na 312.6753610017121, a ustawiła na %f", stats->standard_deviation);
        
                free(stats);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji statistics
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji statistics", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                struct statistic_t *stats;
        
                int O[] = {-54, -23, -97, -70, -70, -86, -84, -81, -36, -1};
    int A[] = {-35, -45, -46, -40, -1};
    int S[] = {-69, -26, -73, -99, -35, -15, -71, -53, -44, -1};
    int J[] = {-87, -27, -15, -21, -7, -64, -35, -87, -34, -28, -1};
    int L[] = {-78, -8, -72, -41, -15, -11, -57, -27, -81, -1};
    int G[] = {-31, -82, -48, -69, -59, -11, -76, -84, -75, -1};
    int Y[] = {-31, -82, -48, -69, -59, -11, -76, -84, -75, -1};
    int *P[] = {O, A, S, J, L, G, Y, NULL};
      
        
                int err_code = statistics(P, &stats);
                test_error(err_code == 0, "Funkcja statistics() powinna zwrócić 0, a zwróciła %d", err_code);

                test_error(stats != NULL, "Funkcja statistics() powinna zaalokować pamięć na strukturę stats, a przypisała NULL");
        
                onerror_terminate();
        
                test_error(stats->min == -99, "Funkcja statistics() powinna ustawić minimum na -99, a ustawiła na %d", stats->min);
                test_error(stats->max == -7, "Funkcja statistics() powinna ustawić maximum na -7, a ustawiła na %d", stats->max);
                test_error(stats->range == 92, "Funkcja statistics() powinna ustawić zakres na 92, a ustawiła na %d", stats->range);
                test_error((stats->avg > -52.84050847457627) && (stats->avg < -52.82050847457627), "Funkcja statistics() powinna ustawić średnią na -52.83050847457627, a ustawiła na %f", stats->avg);
                test_error((stats->standard_deviation > 26.16357481097149) && (stats->standard_deviation < 26.183574810971493), "Funkcja statistics() powinna ustawić odchylenie standardowe na 26.17357481097149, a ustawiła na %f", stats->standard_deviation);
        
                free(stats);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji statistics
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji statistics", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                struct statistic_t *stats;
        
                int O[] = {55, -78, -79, 79, 10, 23, -1};
    int A[] = {27, -63, -21, 70, 54, 23, -14, -29, -1};
    int S[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int J[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int *L[] = {O, A, S, J, NULL};
      
        
                int err_code = statistics(L, &stats);
                test_error(err_code == 0, "Funkcja statistics() powinna zwrócić 0, a zwróciła %d", err_code);

                test_error(stats != NULL, "Funkcja statistics() powinna zaalokować pamięć na strukturę stats, a przypisała NULL");
        
                onerror_terminate();
        
                test_error(stats->min == -91, "Funkcja statistics() powinna ustawić minimum na -91, a ustawiła na %d", stats->min);
                test_error(stats->max == 79, "Funkcja statistics() powinna ustawić maximum na 79, a ustawiła na %d", stats->max);
                test_error(stats->range == 170, "Funkcja statistics() powinna ustawić zakres na 170, a ustawiła na %d", stats->range);
                test_error((stats->avg > -14.862941176470589) && (stats->avg < -14.842941176470589), "Funkcja statistics() powinna ustawić średnią na -14.852941176470589, a ustawiła na %f", stats->avg);
                test_error((stats->standard_deviation > 54.364048931745316) && (stats->standard_deviation < 54.38404893174531), "Funkcja statistics() powinna ustawić odchylenie standardowe na 54.374048931745314, a ustawiła na %f", stats->standard_deviation);
        
                free(stats);
        
                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji statistics
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji statistics", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int O[] = {55, -78, -79, 79, 10, 23, -1};
    int A[] = {27, -63, -21, 70, 54, 23, -14, -29, -1};
    int S[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int J[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int *L[] = {O, A, S, J, NULL};
      

            int err_code = statistics(L, NULL);
            test_error(err_code == 1, "Funkcja statistics() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji statistics
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji statistics", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = statistics(NULL, NULL);
            test_error(err_code == 1, "Funkcja statistics() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji statistics
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji statistics", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct statistic_t *stats;

            int err_code = statistics(NULL, &stats);
            test_error(err_code == 1, "Funkcja statistics() powinna zwrócić 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji statistics (limit sterty ustawiono na 0 bajtów)
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji statistics (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
            
            struct statistic_t *stats;

            int O[] = {55, -78, -79, 79, 10, 23, -1};
    int A[] = {27, -63, -21, 70, 54, 23, -14, -29, -1};
    int S[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int J[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int *L[] = {O, A, S, J, NULL};
      
        
            int err_code = statistics(L, &stats);
            test_error(err_code == 2, "Funkcja statistics() powinna zwrócić 2, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji statistics
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji statistics", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct statistic_t *stats;

            int O[] = {-1};
    int A[] = {-1};
    int S[] = {-1};
    int *J[] = {O, A, S, NULL};
      

            int err_code = statistics(J, &stats);
            test_error(err_code == 3, "Funkcja statistics() powinna zwrócić 3, a zwróciła %d", err_code);
        
            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji statistics
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji statistics", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int *a[] = {NULL};

            struct statistic_t *stats;

            int err_code = statistics(a, &stats);
            test_error(err_code == 3, "Funkcja statistics() powinna zwrócić 3, a zwróciła %d", err_code);


            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji save
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
          
                int O[] = {986, 536, 640, 759, 111, 636, -1};
    int A[] = {-339, -197, -662, -46, -452, -794, -464, -313, -1};
    int S[] = {-759, -44, -642, -166, -944, -1};
    int J[] = {507, 667, 64, 862, 923, 154, 506, 805, 208, 512, -1};
    int L[] = {239, 878, 647, 245, 305, 319, 151, 502, 258, -1};
    int G[] = {-449, -552, -950, -95, -164, -556, -388, -1};
    int Y[] = {-1};
    int P[] = {-666, -603, -51, -704, -1};
    int H[] = {-286, -626, -156, -954, -993, -299, -726, -1};
    int U[] = {-880, -777, -882, -1};
    int *B[] = {O, A, S, J, L, G, Y, P, H, U, NULL};
      

                int err_code = save("big.bin", B, fmt_binary);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji save
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
          
                int O[] = {71, 731, 879, 11, 422, 389, 711, 175, 124, -1};
    int A[] = {690, -1};
    int S[] = {707, 433, 36, 391, 990, 481, 87, 846, 786, -1};
    int J[] = {707, 433, 36, 391, 990, 481, 87, 846, 786, -1};
    int *L[] = {O, A, S, J, NULL};
      

                int err_code = save("long.txt.bin", L, fmt_binary);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji save
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
          
                int O[] = {-54, -23, -97, -70, -70, -86, -84, -81, -36, -1};
    int A[] = {-35, -45, -46, -40, -1};
    int S[] = {-69, -26, -73, -99, -35, -15, -71, -53, -44, -1};
    int J[] = {-87, -27, -15, -21, -7, -64, -35, -87, -34, -28, -1};
    int L[] = {-78, -8, -72, -41, -15, -11, -57, -27, -81, -1};
    int G[] = {-31, -82, -48, -69, -59, -11, -76, -84, -75, -1};
    int Y[] = {-31, -82, -48, -69, -59, -11, -76, -84, -75, -1};
    int *P[] = {O, A, S, J, L, G, Y, NULL};
      

                int err_code = save("draw.txt", P, fmt_binary);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji save
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
          
                int O[] = {55, -78, -79, 79, 10, 23, -1};
    int A[] = {27, -63, -21, 70, 54, 23, -14, -29, -1};
    int S[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int J[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int *L[] = {O, A, S, J, NULL};
      

                int err_code = save("party.bin.txt", L, fmt_binary);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji save
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
          
                int O[] = {-1};
    int A[] = {-1};
    int S[] = {-1};
    int *J[] = {O, A, S, NULL};
      

                int err_code = save("remember", J, fmt_binary);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji save
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int O[] = {986, 536, 640, 759, 111, 636, -1};
    int A[] = {-339, -197, -662, -46, -452, -794, -464, -313, -1};
    int S[] = {-759, -44, -642, -166, -944, -1};
    int J[] = {507, 667, 64, 862, 923, 154, 506, 805, 208, 512, -1};
    int L[] = {239, 878, 647, 245, 305, 319, 151, 502, 258, -1};
    int G[] = {-449, -552, -950, -95, -164, -556, -388, -1};
    int Y[] = {-1};
    int P[] = {-666, -603, -51, -704, -1};
    int H[] = {-286, -626, -156, -954, -993, -299, -726, -1};
    int U[] = {-880, -777, -882, -1};
    int *B[] = {O, A, S, J, L, G, Y, P, H, U, NULL};
      

                int err_code = save("master.bin", B, fmt_text);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji save
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int O[] = {71, 731, 879, 11, 422, 389, 711, 175, 124, -1};
    int A[] = {690, -1};
    int S[] = {707, 433, 36, 391, 990, 481, 87, 846, 786, -1};
    int J[] = {707, 433, 36, 391, 990, 481, 87, 846, 786, -1};
    int *L[] = {O, A, S, J, NULL};
      

                int err_code = save("about.txt.bin", L, fmt_text);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji save
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int O[] = {-54, -23, -97, -70, -70, -86, -84, -81, -36, -1};
    int A[] = {-35, -45, -46, -40, -1};
    int S[] = {-69, -26, -73, -99, -35, -15, -71, -53, -44, -1};
    int J[] = {-87, -27, -15, -21, -7, -64, -35, -87, -34, -28, -1};
    int L[] = {-78, -8, -72, -41, -15, -11, -57, -27, -81, -1};
    int G[] = {-31, -82, -48, -69, -59, -11, -76, -84, -75, -1};
    int Y[] = {-31, -82, -48, -69, -59, -11, -76, -84, -75, -1};
    int *P[] = {O, A, S, J, L, G, Y, NULL};
      

                int err_code = save("why.txt", P, fmt_text);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji save
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int O[] = {55, -78, -79, 79, 10, 23, -1};
    int A[] = {27, -63, -21, 70, 54, 23, -14, -29, -1};
    int S[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int J[] = {21, -80, -56, -91, -81, -33, -47, -28, 46, 68, -1};
    int *L[] = {O, A, S, J, NULL};
      

                int err_code = save("cloud.bin.txt", L, fmt_text);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji save
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int O[] = {-1};
    int A[] = {-1};
    int S[] = {-1};
    int *J[] = {O, A, S, NULL};
      

                int err_code = save("hole", J, fmt_text);
                test_error(err_code == 0, "Funkcja save() powinna zwrócić 0, a zwróciła %d", err_code);

                test_no_heap_leakage();
                onerror_terminate();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji save
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = save("made.bin", NULL, fmt_text);
            test_error(err_code == 1, "Funkcja save() powinna zwrócić 1, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji save
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = save("fire.txt", NULL, fmt_binary);
            test_error(err_code == 1, "Funkcja save() powinna zwrócić 1, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji save
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int O[] = {986, 536, 640, 759, 111, 636, -1};
    int A[] = {-339, -197, -662, -46, -452, -794, -464, -313, -1};
    int S[] = {-759, -44, -642, -166, -944, -1};
    int J[] = {507, 667, 64, 862, 923, 154, 506, 805, 208, 512, -1};
    int L[] = {239, 878, 647, 245, 305, 319, 151, 502, 258, -1};
    int G[] = {-449, -552, -950, -95, -164, -556, -388, -1};
    int Y[] = {-1};
    int P[] = {-666, -603, -51, -704, -1};
    int H[] = {-286, -626, -156, -954, -993, -299, -726, -1};
    int U[] = {-880, -777, -882, -1};
    int *B[] = {O, A, S, J, L, G, Y, P, H, U, NULL};
      

            int err_code = save(NULL, B, fmt_text);
            test_error(err_code == 1, "Funkcja save() powinna zwrócić 1, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji save
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int O[] = {986, 536, 640, 759, 111, 636, -1};
    int A[] = {-339, -197, -662, -46, -452, -794, -464, -313, -1};
    int S[] = {-759, -44, -642, -166, -944, -1};
    int J[] = {507, 667, 64, 862, 923, 154, 506, 805, 208, 512, -1};
    int L[] = {239, 878, 647, 245, 305, 319, 151, 502, 258, -1};
    int G[] = {-449, -552, -950, -95, -164, -556, -388, -1};
    int Y[] = {-1};
    int P[] = {-666, -603, -51, -704, -1};
    int H[] = {-286, -626, -156, -954, -993, -299, -726, -1};
    int U[] = {-880, -777, -882, -1};
    int *B[] = {O, A, S, J, L, G, Y, P, H, U, NULL};
      

            int err_code = save(NULL, B, fmt_binary);
            test_error(err_code == 1, "Funkcja save() powinna zwrócić 1, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji save
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = save(NULL, NULL, fmt_text);
            test_error(err_code == 1, "Funkcja save() powinna zwrócić 1, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji save
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = save(NULL, NULL, fmt_binary);
            test_error(err_code == 1, "Funkcja save() powinna zwrócić 1, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji save
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji save", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int O[] = {986, 536, 640, 759, 111, 636, -1};
    int A[] = {-339, -197, -662, -46, -452, -794, -464, -313, -1};
    int S[] = {-759, -44, -642, -166, -944, -1};
    int J[] = {507, 667, 64, 862, 923, 154, 506, 805, 208, 512, -1};
    int L[] = {239, 878, 647, 245, 305, 319, 151, 502, 258, -1};
    int G[] = {-449, -552, -950, -95, -164, -556, -388, -1};
    int Y[] = {-1};
    int P[] = {-666, -603, -51, -704, -1};
    int H[] = {-286, -626, -156, -954, -993, -299, -726, -1};
    int U[] = {-880, -777, -882, -1};
    int *B[] = {O, A, S, J, L, G, Y, P, H, U, NULL};
      

            int err_code = save("fire.txt", B, 78);
            test_error(err_code == 1, "Funkcja save() powinna zwrócić 1, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Reakcja funkcji save na brak możliwości utworzenia pliku (fopen zwróci NULL przy pierwszym wywołaniu)
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Reakcja funkcji save na brak możliwości utworzenia pliku (fopen zwróci NULL przy pierwszym wywołaniu)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 0);
    
    //
    // -----------
    //
    

            int O[] = {986, 536, 640, 759, 111, 636, -1};
    int A[] = {-339, -197, -662, -46, -452, -794, -464, -313, -1};
    int S[] = {-759, -44, -642, -166, -944, -1};
    int J[] = {507, 667, 64, 862, 923, 154, 506, 805, 208, 512, -1};
    int L[] = {239, 878, 647, 245, 305, 319, 151, 502, 258, -1};
    int G[] = {-449, -552, -950, -95, -164, -556, -388, -1};
    int Y[] = {-1};
    int P[] = {-666, -603, -51, -704, -1};
    int H[] = {-286, -626, -156, -954, -993, -299, -726, -1};
    int U[] = {-880, -777, -882, -1};
    int *B[] = {O, A, S, J, L, G, Y, P, H, U, NULL};
      

            int err_code = save("fire.txt", B, fmt_text);
            test_error(err_code == 2, "Funkcja save() powinna zwrócić 2, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Reakcja funkcji save na brak możliwości utworzenia pliku (fopen zwróci NULL przy pierwszym wywołaniu)
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Reakcja funkcji save na brak możliwości utworzenia pliku (fopen zwróci NULL przy pierwszym wywołaniu)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 0);
    
    //
    // -----------
    //
    

            int O[] = {986, 536, 640, 759, 111, 636, -1};
    int A[] = {-339, -197, -662, -46, -452, -794, -464, -313, -1};
    int S[] = {-759, -44, -642, -166, -944, -1};
    int J[] = {507, 667, 64, 862, 923, 154, 506, 805, 208, 512, -1};
    int L[] = {239, 878, 647, 245, 305, 319, 151, 502, 258, -1};
    int G[] = {-449, -552, -950, -95, -164, -556, -388, -1};
    int Y[] = {-1};
    int P[] = {-666, -603, -51, -704, -1};
    int H[] = {-286, -626, -156, -954, -993, -299, -726, -1};
    int U[] = {-880, -777, -882, -1};
    int *B[] = {O, A, S, J, L, G, Y, P, H, U, NULL};
      

            int err_code = save("fire.txt", B, fmt_binary);
            test_error(err_code == 2, "Funkcja save() powinna zwrócić 2, a zwróciła %d", err_code);

            test_no_heap_leakage();
            onerror_terminate();
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci - limit ustawiony na 0 bajtów
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci - limit ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci - limit ustawiony na 40 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci - limit ustawiony na 40 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(40);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na błąd operacji wejścia/wyjścia; fopen zwróci NULL przy 0 wywołaniu
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na błąd operacji wejścia/wyjścia; fopen zwróci NULL przy 0 wywołaniu", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 0, "Funkcja main zakończyła się kodem %d a powinna 0", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na błąd operacji wejścia/wyjścia; fopen zwróci NULL przy 1 wywołaniu
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na błąd operacji wejścia/wyjścia; fopen zwróci NULL przy 1 wywołaniu", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 1);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 0, "Funkcja main zakończyła się kodem %d a powinna 0", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji display
            UTEST2, // Sprawdzanie poprawności działania funkcji display
            UTEST3, // Sprawdzanie poprawności działania funkcji statistics
            UTEST4, // Sprawdzanie poprawności działania funkcji statistics
            UTEST5, // Sprawdzanie poprawności działania funkcji statistics
            UTEST6, // Sprawdzanie poprawności działania funkcji statistics
            UTEST7, // Sprawdzanie poprawności działania funkcji statistics
            UTEST8, // Sprawdzanie poprawności działania funkcji statistics
            UTEST9, // Sprawdzanie poprawności działania funkcji statistics
            UTEST10, // Sprawdzanie poprawności działania funkcji statistics (limit sterty ustawiono na 0 bajtów)
            UTEST11, // Sprawdzanie poprawności działania funkcji statistics
            UTEST12, // Sprawdzanie poprawności działania funkcji statistics
            UTEST13, // Sprawdzanie poprawności działania funkcji save
            UTEST14, // Sprawdzanie poprawności działania funkcji save
            UTEST15, // Sprawdzanie poprawności działania funkcji save
            UTEST16, // Sprawdzanie poprawności działania funkcji save
            UTEST17, // Sprawdzanie poprawności działania funkcji save
            UTEST18, // Sprawdzanie poprawności działania funkcji save
            UTEST19, // Sprawdzanie poprawności działania funkcji save
            UTEST20, // Sprawdzanie poprawności działania funkcji save
            UTEST21, // Sprawdzanie poprawności działania funkcji save
            UTEST22, // Sprawdzanie poprawności działania funkcji save
            UTEST23, // Sprawdzanie poprawności działania funkcji save
            UTEST24, // Sprawdzanie poprawności działania funkcji save
            UTEST25, // Sprawdzanie poprawności działania funkcji save
            UTEST26, // Sprawdzanie poprawności działania funkcji save
            UTEST27, // Sprawdzanie poprawności działania funkcji save
            UTEST28, // Sprawdzanie poprawności działania funkcji save
            UTEST29, // Sprawdzanie poprawności działania funkcji save
            UTEST30, // Reakcja funkcji save na brak możliwości utworzenia pliku (fopen zwróci NULL przy pierwszym wywołaniu)
            UTEST31, // Reakcja funkcji save na brak możliwości utworzenia pliku (fopen zwróci NULL przy pierwszym wywołaniu)
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(31); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci - limit ustawiony na 0 bajtów
            MTEST2, // Reakcja na brak pamięci - limit ustawiony na 40 bajtów
            MTEST3, // Reakcja na błąd operacji wejścia/wyjścia; fopen zwróci NULL przy 0 wywołaniu
            MTEST4, // Reakcja na błąd operacji wejścia/wyjścia; fopen zwróci NULL przy 1 wywołaniu
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(4); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}