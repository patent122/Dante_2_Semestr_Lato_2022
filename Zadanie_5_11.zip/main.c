#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "format_type.h"
#include "tested_declarations.h"
#include "rdebug.h"

enum errors {
    SUCCES = 0,
    INCORECT_INPUT = 1,
    INCORECT_INPUT_DATA = 2,
    COULDNT_OPEN_FILE = 4,
    COULDNT_CREATE_FILE = 5,
    FILE_CORRUPTED = 6,
    FAILED_TO_ALLOCATE_MEMORY = 8
};


struct statistic_t
{
    int min;
    int max;
    float avg;
    float standard_deviation;
    int range;
};

float stdDev(int **wskaznik);
int statistics(int **wskaznik, struct statistic_t **statystyki);
void display(int **wskaznik);
int save(const char *sciezka, int **wskaznik, enum save_format_t format);

int main()
{
    struct statistic_t *statystyki;

    int A[] = {10, 20, 30, 40, 50, 60, 70, -1};
    int B[] = {100, 200, 300, 400, 500, 600, 700, 800, -1};
    int C[] = {1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, -1};
    int* D[] = {A, B, C, NULL};

    display(D);
    
    char *sciezka = malloc(40 * sizeof(char));
    if (sciezka == NULL)
    {
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }
    printf("File name: ");
    scanf("%39s", sciezka);

    
    while(getchar()!='\n'){}

    
    char *filenameTxt = malloc((40 + 4) * sizeof(char));
    if (filenameTxt == NULL)
    {
        free(sciezka);
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }

    strcpy(filenameTxt, sciezka);
    strcat(filenameTxt, ".txt");

    
    char *filenameBin = malloc((40 + 4) * sizeof(char));
    if (filenameBin == NULL)
    {
        free(sciezka);
        free(filenameTxt);
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }

    strcpy(filenameBin, sciezka);
    strcat(filenameBin, ".bin");

    
    if(save(filenameTxt, D, fmt_text) != 2)
        printf("File saved\n");
    else
        printf("Couldn't create file\n");

    
    if(save(filenameBin, D, fmt_binary) != 2)
        printf("File saved\n");
    else
        printf("Couldn't create file\n");

    
    if(statistics(D,&statystyki) == 2)
    {
        free(sciezka);
        free(filenameTxt);
        free(filenameBin);
        printf("Failed to allocate memory\n");
    }
    printf("%d\n%d\n%d\n%f\n%f", statystyki->min, statystyki->max, statystyki->range, statystyki->avg, statystyki->standard_deviation);


    free(statystyki);
    free(sciezka);
    free(filenameTxt);
    free(filenameBin);
    return 0;
}

int statistics(int **wskaznik, struct statistic_t **statystyki)
{
    if (wskaznik == NULL || statystyki == NULL)
        return 1;

    int sum = 0;
    int sum_numbers = 0;
    int x = 0;

    *statystyki = malloc(sizeof(struct statistic_t));
    if(*statystyki == NULL)
        return 2;

    while (*(wskaznik + x) != NULL)
    {
        int y = 0;
        while(*(*(wskaznik + x) + y) != -1)
        {
            
            sum += *(*(wskaznik + x) + y);
            
            sum_numbers++;
            y++;
        }
        x++;
    }

    
    

    
    if(sum_numbers == 0)
    {
        free(*statystyki);
        return 3;
    }


    (*statystyki)->min = *(*(wskaznik + 0) + 0);
    (*statystyki)->max = *(*(wskaznik + 0) + 0);

    x = 0;
    while (*(wskaznik + x) != NULL)
    {
        int y = 0;
        while(*(*(wskaznik + x) + y) != -1)
        {
            
            if(*(*(wskaznik + x) + y) < (*statystyki)->min)
            {
                (*statystyki)->min = *(*(wskaznik + x) + y);
            }
            
            if(*(*(wskaznik + x) + y) > (*statystyki)->max)
            {
                (*statystyki)->max = *(*(wskaznik + x) + y);
            }
            y++;
        }
        x++;
    }

    (*statystyki)->range = (*statystyki)->max - (*statystyki)->min;
    (*statystyki)->avg = (float)sum / (float)sum_numbers;
    (*statystyki)->standard_deviation = stdDev(wskaznik);
    return 0;
}

void display(int **wskaznik)
{
    if(wskaznik == NULL) return;
    int x = 0;
    while (*(wskaznik + x) != NULL)
    {
        int y = 0;
        while(*(*(wskaznik + x) + y) != -1)
        {
            printf("%d ", *(*(wskaznik + x) + y));
            y++;
        }
        printf("\n");
        x++;
    }
}

int save(const char *sciezka, int **wskaznik, enum save_format_t format)
{
    if (sciezka == NULL || wskaznik == NULL)
        return 1;
    if (format != fmt_text && format != fmt_binary)
        return 1;

    FILE *file = NULL;
    int x = 0;
    switch (format)
    {
        case fmt_text:
            
            if((file = fopen(sciezka, "w")) == NULL)
            {
                return 2;
            }

            while (*(wskaznik + x) != NULL)
            {
                int y = 0;
                while(*(*(wskaznik + x) + y) != -1)
                {
                    fprintf(file, "%d ", *(*(wskaznik + x) + y));
                    y++;
                }
                fprintf(file, "-1");
                fprintf(file, "\n");
                x++;
            }

            fclose(file);
            break;
        case fmt_binary:
            
            if((file = fopen(sciezka, "wb")) == NULL)
            {
                return 2;
            }

            while (*(wskaznik + x) != NULL)
            {
                int y = 0;
                while(*(*(wskaznik + x) + y) != -1)
                {
                    fwrite(*(wskaznik + x) + y, sizeof(int), 1, file);
                    y++;
                }
                fwrite(*(wskaznik + x) + y, sizeof(int), 1, file);
                x++;
            }

            fclose(file);
            break;
    }

    return 0;
}

float stdDev(int **wskaznik)
{
    int sum = 0;
    int size = 0;
    int x = 0;
    while (*(wskaznik + x) != NULL)
    {
        int y = 0;
        while(*(*(wskaznik + x) + y) != -1)
        {
            
            sum += *(*(wskaznik + x) + y);
            
            size++;
            y++;
        }
        x++;
    }
    float avg = (float)sum/(float)size;
    float licznik = 0;
    float mianownik = (float)size;

    x = 0;
    while (*(wskaznik + x) != NULL)
    {
        int y = 0;
        while(*(*(wskaznik + x) + y) != -1)
        {
            licznik += powf((float)(*(*(wskaznik + x) + y)) - avg, 2);
            y++;
        }
        x++;
    }
    return sqrtf(licznik/mianownik);
}
