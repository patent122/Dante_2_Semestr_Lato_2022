/*
 * Test dla zadania Zbiory liczb - statystyka ogólna
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 21:25:45.851369
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta



        #include "format_type.h"

        struct statistic_t;
        
        void display(int  **ptr);
        int save(const char *filename, int **ptr, enum save_format_t format);
        int statistics(int **ptr, struct statistic_t **stats);

    

#endif // _TESTED_DECLARATIONS_H_