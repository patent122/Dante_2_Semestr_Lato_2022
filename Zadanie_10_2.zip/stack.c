#include <stdio.h>
#include <stdlib.h>

#include "stack.h"
#include "tested_declarations.h"
#include "rdebug.h"

int stack_init(struct stack_t** stos) {
    if (stos == NULL) {
        return 1;
    }
    *stos = malloc(sizeof(struct stack_t));
    if (*stos == NULL) {
        return 2;
    }
    (*stos)->head = NULL;
    return 0;
}

int stack_push(struct stack_t* stos, int value) {
    if (stos == NULL) {
        return 1;
    }
    struct node_t* node = malloc(sizeof(struct node_t));
    if (node == NULL) {
        return 2;
    }
    node->data = value;
    node->next = stos->head;
    stos->head = node;
    return 0;
}

void stack_display(const struct stack_t* stos) {
    if (stos == NULL) {
        return;
    }
    struct node_t* node = stos->head;
    while (node != NULL) {
        printf("%d ", node->data);
        node = node->next;
    }
}

int stack_pop(struct stack_t* stos, int* kod_wyjscia) {
    if (stos == NULL || stos->head == NULL) {
        if (kod_wyjscia)*kod_wyjscia = 1;
        return 0;
    }
    if (kod_wyjscia)*kod_wyjscia = 0;
    struct node_t* node = stos->head;
    stos->head = node->next;
    int val = node->data;
    free(node);
    return val;
}

void stack_destroy(struct stack_t** stos) {
    if (stos == NULL) {
        return;
    }
    struct node_t* node = (*stos)->head;
    while (node != NULL) {
        struct node_t* del = node;
        node = node->next;
        free(del);
    }
    free(*stos);
}

int stack_empty(const struct stack_t* stos) {
    if (stos == NULL) {
        return 2;
    }
    if (stos->head == NULL) {
        return 1;
    }
    return 0;
}
