#include <stdio.h>
#include <stdlib.h>

#include "stack.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main() {
    struct stack_t* stos;
    if (stack_init(&stos)) {
        printf("Failed to allocate memory");
        return 8;
    }   
    while (1) {
        printf("Co chcesz zrobic? ");
        int litera;
        if (scanf("%d", &litera) != 1) {
            printf("Incorrect input");
            stack_destroy(&stos);
            return 1;
        }
        int aa;
        switch (litera) {
        case 0:
            stack_destroy(&stos);
            return 0;
        case 1:
            printf("Podaj liczbe: ");
            if (scanf("%d", &aa) != 1) {
                printf("Incorrect input");
                stack_destroy(&stos);
                return 1;
            }
            if (stack_push(stos, aa)) {
                stack_destroy(&stos);
                printf("Failed to allocate memory");
                return 8;
            }
            break;
        case 2:
            if (stack_empty(stos)) {
                printf("Stack is empty\n");
                continue;
            }
            aa = stack_pop(stos, NULL);
            printf("%d\n", aa);
            break;
        case 3:
            if (stack_empty(stos)) {
                printf("1\n");
            }
            else {
                printf("0\n");
            }
            break;
        case 4:
            if (stack_empty(stos)) {
                printf("Stack is empty\n");
                continue;
            }
            stack_display(stos);
            printf("\n");
            break;
        default:
            printf("Incorrect input data\n");
        }
    }
    return 0;
}
