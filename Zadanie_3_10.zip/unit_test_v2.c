/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Figury geometryczne
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-16 20:17:36.677031
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//


        enum figure_types{
          TRIANGLE = 1,
          RECTANGLE,
          CIRCLE
        };
        
        struct point_t
        {
          int x;
          int y;
        };
        
        struct rectangle_t
        {
          struct point_t p;
          int width;
          int height;
        };
        
        struct circle_t
        {
          struct point_t c;
          float r;
        };
        
        struct triangle_t
        {
          struct point_t p1;
          struct point_t p2;
          struct point_t p3;
        };
        
        struct figure_t{
          union
          {
            struct rectangle_t rect;
            struct triangle_t triangle;
            struct circle_t circ;
          };
          enum figure_types type;
        };
    


//
//  Test 1: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 4, 7 }, .p2 = { 3, 6 }, .p3 = { 5, 4 }  };
        
                float area = area_triangle(&tr);
                test_error(2.0 + 0.05 > area && 2.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 2.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -3, 10 }, .p2 = { 6, 1 }, .p3 = { 5, 9 }  };
        
                float area = area_triangle(&tr);
                test_error(31.5 + 0.05 > area && 31.5 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 31.5000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 4, -3 }, .p2 = { 1, 8 }, .p3 = { 4, 3 }  };
        
                float area = area_triangle(&tr);
                test_error(9.0 + 0.05 > area && 9.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 9.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 8, 3 }, .p2 = { -1, 7 }, .p3 = { 7, 8 }  };
        
                float area = area_triangle(&tr);
                test_error(20.5 + 0.05 > area && 20.5 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 20.5000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 7, 9 }, .p2 = { 7, -10 }, .p3 = { 9, 5 }  };
        
                float area = area_triangle(&tr);
                test_error(19.0 + 0.05 > area && 19.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 19.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 2, 5 }, .p2 = { 2, 2 }, .p3 = { -5, 2 }  };
        
                float area = area_triangle(&tr);
                test_error(10.5 + 0.05 > area && 10.5 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 10.5000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 2, 4 }, .p2 = { 4, 10 }, .p3 = { 10, -10 }  };
        
                float area = area_triangle(&tr);
                test_error(38.0 + 0.05 > area && 38.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 38.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -9, -6 }, .p2 = { 1, 9 }, .p3 = { 2, 5 }  };
        
                float area = area_triangle(&tr);
                test_error(27.5 + 0.05 > area && 27.5 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 27.5000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -10, 10 }, .p2 = { -6, 9 }, .p3 = { 2, 10 }  };
        
                float area = area_triangle(&tr);
                test_error(6.0 + 0.05 > area && 6.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 6.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -8, 4 }, .p2 = { 2, -6 }, .p3 = { 6, 2 }  };
        
                float area = area_triangle(&tr);
                test_error(60.0 + 0.05 > area && 60.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 60.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -5, 8 }, .p2 = { 9, 9 }, .p3 = { -8, 10 }  };
        
                float area = area_triangle(&tr);
                test_error(15.5 + 0.05 > area && 15.5 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 15.5000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -7, 5 }, .p2 = { 6, 3 }, .p3 = { 5, -8 }  };
        
                float area = area_triangle(&tr);
                test_error(72.5 + 0.05 > area && 72.5 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 72.5000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 1, 5 }, .p2 = { -8, -5 }, .p3 = { 9, 10 }  };
        
                float area = area_triangle(&tr);
                test_error(17.5 + 0.05 > area && 17.5 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 17.5000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 9, 4 }, .p2 = { 3, 4 }, .p3 = { -6, -8 }  };
        
                float area = area_triangle(&tr);
                test_error(36.0 + 0.05 > area && 36.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 36.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -8, -10 }, .p2 = { -4, -9 }, .p3 = { 6, 9 }  };
        
                float area = area_triangle(&tr);
                test_error(31.0 + 0.05 > area && 31.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 31.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 1, 8 }, .p2 = { -7, -6 }, .p3 = { -4, -10 }  };
        
                float area = area_triangle(&tr);
                test_error(37.0 + 0.05 > area && 37.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 37.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -3, -6 }, .p2 = { -3, -3 }, .p3 = { -4, -4 }  };
        
                float area = area_triangle(&tr);
                test_error(1.5 + 0.05 > area && 1.5 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 1.5000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 2, 4 }, .p2 = { 2, 10 }, .p3 = { 7, 4 }  };
        
                float area = area_triangle(&tr);
                test_error(15.0 + 0.05 > area && 15.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 15.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -4, -8 }, .p2 = { -4, -2 }, .p3 = { -9, -8 }  };
        
                float area = area_triangle(&tr);
                test_error(15.0 + 0.05 > area && 15.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 15.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 1, 5 }, .p2 = { 1, 15 }, .p3 = { 2, 5 }  };
        
                float area = area_triangle(&tr);
                test_error(5.0 + 0.05 > area && 5.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 5.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 9, 2 }, .p2 = { 9, 2 }, .p3 = { 11, 12 }  };
        
                float area = area_triangle(&tr);
                test_error(-1.0 + 0.05 > area && -1.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji area_triangle
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji area_triangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            float area = area_triangle(NULL);
            test_error(-1.0 + 0.05 > area && -1.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji area_rectangle
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji area_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { 9, 1 }, .width = 4, .height = 10 };

                float area = area_rectangle(&rect);
                test_error(40.0 + 0.05 > area && 40.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 40.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji area_rectangle
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji area_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { -8, 10 }, .width = 2, .height = 4 };

                float area = area_rectangle(&rect);
                test_error(8.0 + 0.05 > area && 8.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 8.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji area_rectangle
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji area_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { 10, -2 }, .width = 10, .height = 10 };

                float area = area_rectangle(&rect);
                test_error(100.0 + 0.05 > area && 100.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 100.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji area_rectangle
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji area_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { -7, -1 }, .width = 7, .height = 2 };

                float area = area_rectangle(&rect);
                test_error(14.0 + 0.05 > area && 14.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 14.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji area_rectangle
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji area_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { 0, 0 }, .width = 3, .height = 9 };

                float area = area_rectangle(&rect);
                test_error(27.0 + 0.05 > area && 27.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 27.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji area_rectangle
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji area_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { 3, 2 }, .width = 3, .height = -3 };

                float area = area_rectangle(&rect);
                test_error(-1.0 + 0.05 > area && -1.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji area_rectangle
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji area_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            float area = area_rectangle(NULL);
            test_error(-1.0 + 0.05 > area && -1.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_triangle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji area_circle
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji area_circle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { 6, 3 }, .r = 1.6994591338925091 };

                float area = area_circle(&circ);
                test_error(9.073426246643066 + 0.5 > area && 9.073426246643066 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_circle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 9.0734f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji area_circle
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji area_circle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { -9, 1 }, .r = 2.915975064324263 };

                float area = area_circle(&circ);
                test_error(26.71268081665039 + 0.5 > area && 26.71268081665039 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_circle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 26.7127f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji area_circle
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji area_circle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { 3, -10 }, .r = 9.158814721065703 };

                float area = area_circle(&circ);
                test_error(263.52899169921875 + 0.5 > area && 263.52899169921875 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_circle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 263.5290f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji area_circle
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji area_circle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { -3, -9 }, .r = 9.706848126115679 };

                float area = area_circle(&circ);
                test_error(296.0099792480469 + 0.5 > area && 296.0099792480469 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_circle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 296.0100f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji area_circle
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji area_circle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { 0, 0 }, .r = 2 };

                float area = area_circle(&circ);
                test_error(12.566370964050293 + 0.5 > area && 12.566370964050293 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_circle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 12.5664f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji area_circle
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji area_circle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { 9, 5 }, .r = -8.03333162860816 };

                float area = area_circle(&circ);
                test_error(-1.0 + 0.5 > area && -1.0 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_circle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji area_circle
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji area_circle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { 3, 3 }, .r = 0 };

                float area = area_circle(&circ);
                test_error(-1.0 + 0.5 > area && -1.0 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_circle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji area_circle
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji area_circle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            float area = area_circle(NULL);
            test_error(-1.0 + 0.1 > area && -1.0 - 0.1 < area, "Wartość %.4f zwrócona przez funkcję area_circle() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 1, 5 }, .p2 = { 1, 4 }, .p3 = { 3, 5 }  };

                struct figure_t figure = { .type = TRIANGLE, .triangle = tr };

                float area = area_figure(&figure);
                test_error(1.0 + 0.05 > area && 1.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 1.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { -8, -2 }, .p2 = { -8, -10 }, .p3 = { -9, -2 }  };

                struct figure_t figure = { .type = TRIANGLE, .triangle = tr };

                float area = area_figure(&figure);
                test_error(4.0 + 0.05 > area && 4.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 4.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 1, 7 }, .p2 = { 1, 11 }, .p3 = { 2, 7 }  };

                struct figure_t figure = { .type = TRIANGLE, .triangle = tr };

                float area = area_figure(&figure);
                test_error(2.0 + 0.05 > area && 2.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 2.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct triangle_t tr = { .p1 = { 7, 7 }, .p2 = { 7, 7 }, .p3 = { 14, 12 }  };

                struct figure_t figure = { .type = TRIANGLE, .triangle = tr };

                float area = area_figure(&figure);
                test_error(-1.0 + 0.05 > area && -1.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { 6, 2 }, .width = 6, .height = 3 };

                struct figure_t figure = { .type = RECTANGLE, .rect = rect };

                float area = area_figure(&figure);
                test_error(18.0 + 0.05 > area && 18.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 18.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { -5, -1 }, .width = -5, .height = -5 };

                struct figure_t figure = { .type = RECTANGLE, .rect = rect };

                float area = area_figure(&figure);
                test_error(-1.0 + 0.05 > area && -1.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { 3, 3 }, .width = 3, .height = 13 };

                struct figure_t figure = { .type = RECTANGLE, .rect = rect };

                float area = area_figure(&figure);
                test_error(39.0 + 0.05 > area && 39.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 39.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct rectangle_t rect = { .p = { 9, 9 }, .width = 9, .height = 9 };

                struct figure_t figure = { .type = RECTANGLE, .rect = rect };

                float area = area_figure(&figure);
                test_error(81.0 + 0.05 > area && 81.0 - 0.05 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 81.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { -5, -8 }, .r = 3.161738412851001 };

                struct figure_t figure = { .type = CIRCLE, .circ = circ };

                float area = area_figure(&figure);
                test_error(31.40521240234375 + 0.5 > area && 31.40521240234375 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 31.4052f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { 0, 0 }, .r = 7 };

                struct figure_t figure = { .type = CIRCLE, .circ = circ };

                float area = area_figure(&figure);
                test_error(153.9380340576172 + 0.5 > area && 153.9380340576172 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, 153.9380f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { 4, 4 }, .r = -3.213680970984056 };

                struct figure_t figure = { .type = CIRCLE, .circ = circ };

                float area = area_figure(&figure);
                test_error(-1.0 + 0.5 > area && -1.0 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
                struct circle_t circ = { .c = { 3, 5 }, .r = 0 };

                struct figure_t figure = { .type = CIRCLE, .circ = circ };

                float area = area_figure(&figure);
                test_error(-1.0 + 0.5 > area && -1.0 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 50: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST50(void)
{
    // informacje o teście
    test_start(50, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            struct circle_t circ = { .c = { 3, 5 }, .r = 0 };

            struct figure_t figure = { .type = CIRCLE + RECTANGLE * 2 + TRIANGLE * 3, .circ = circ };

            float area = area_figure(&figure);
            test_error(-1 + 0.5 > area && -1 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 51: Sprawdzanie poprawności działania funkcji area_figure
//
void UTEST51(void)
{
    // informacje o teście
    test_start(51, "Sprawdzanie poprawności działania funkcji area_figure", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            float area = area_figure(NULL);
            test_error(-1 + 0.5 > area && -1 - 0.5 < area, "Wartość %.4f zwrócona przez funkcję area_figure() nie mieści się w wymaganym przedziale dokładności, powinno być %.4f", area, -1.0000f);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 52: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST52(void)
{
    // informacje o teście
    test_start(52, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct figure_t figures[] = { { .type = CIRCLE, .circ = { .c = { 9, -3 }, .r = 1.9701184534490008 } }, { .type = RECTANGLE, .rect = { .p = { 4, 8 }, .width = 37, .height = 48 } }, { .type = TRIANGLE, .triangle = { .p1 = { 5, 17 }, .p2 = { 6, 12 }, .p3 = { 4, -12 } } } };
                struct figure_t *ptr[3];

                for (int i = 0; i < 3; ++i)
                    ptr[i] = &figures[i];

                printf("------------TABLICA FIGUR DO POSORTOWANIA-----------\n");

                for (int i = 0; i < 3; ++i)
                {
                    printf("%.4f ", area_figure(figures  + i));
                    display_figure(figures  + i);
                }
                
                printf("------------TABLICA FIGUR PO SORTOWANIU-----------\n");

                int res = sort_by_area(ptr, 3);
                test_error(res == 0, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 0, res);

                struct figure_t expected_figures[] = { { .type = RECTANGLE, .rect = { .p = { 4, 8 }, .width = 37, .height = 48 } }, { .type = TRIANGLE, .triangle = { .p1 = { 5, 17 }, .p2 = { 6, 12 }, .p3 = { 4, -12 } } }, { .type = CIRCLE, .circ = { .c = { 9, -3 }, .r = 1.9701184534490008 } } };

                for (int i = 0; i < 3; ++i)
                {
                    printf("%d %.4f ", i, area_figure(ptr[i]));
                    display_figure(ptr[i]);
                }
                
                printf("------------OCZEKIWANA TABLICA FIGUR-----------\n");
                
                for (int i = 0; i < 3; ++i)
                {
                    printf("%d %.4f ", i, area_figure(expected_figures + i));
                    display_figure(expected_figures  + i);
                }
                
                printf("------------\n");
                

                for (int i = 0; i < 3; ++i)
                {
                    test_error(ptr[i]->type == expected_figures[i].type, "Typ figury pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].type, ptr[i]->type);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (ptr[i]->type == TRIANGLE)
                    {
                        test_error(ptr[i]->triangle.p1.x == expected_figures[i].triangle.p1.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.x, ptr[i]->triangle.p1.x);
                        test_error(ptr[i]->triangle.p1.y == expected_figures[i].triangle.p1.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.y, ptr[i]->triangle.p1.y);
                        test_error(ptr[i]->triangle.p2.x == expected_figures[i].triangle.p2.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.x, ptr[i]->triangle.p2.x);
                        test_error(ptr[i]->triangle.p2.y == expected_figures[i].triangle.p2.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.y, ptr[i]->triangle.p2.y);
                        test_error(ptr[i]->triangle.p3.x == expected_figures[i].triangle.p3.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.x, ptr[i]->triangle.p3.x);
                        test_error(ptr[i]->triangle.p3.y == expected_figures[i].triangle.p3.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.y, ptr[i]->triangle.p3.y);
                    }            
                    else if (ptr[i]->type == RECTANGLE)
                    {
                        test_error(ptr[i]->rect.p.x == expected_figures[i].rect.p.x, "Współrzędna x prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.x, ptr[i]->rect.p.x);
                        test_error(ptr[i]->rect.p.y == expected_figures[i].rect.p.y, "Współrzędna y prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.y, ptr[i]->rect.p.y);
                        test_error(ptr[i]->rect.width == expected_figures[i].rect.width, "Szerokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.width, ptr[i]->rect.width);
                        test_error(ptr[i]->rect.height == expected_figures[i].rect.height, "Wysokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.height, ptr[i]->rect.height);
                    }
                    else if (ptr[i]->type == CIRCLE)
                    {
                        test_error(ptr[i]->circ.c.x == expected_figures[i].circ.c.x, "Współrzędna x okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.x, ptr[i]->circ.c.x);
                        test_error(ptr[i]->circ.c.y == expected_figures[i].circ.c.y, "Współrzędna y okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.y, ptr[i]->circ.c.y);
                        test_error(ptr[i]->circ.r == expected_figures[i].circ.r, "Promięć okręgu pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].circ.r, ptr[i]->circ.r);
                    }
                    
                }


            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 53: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST53(void)
{
    // informacje o teście
    test_start(53, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct figure_t figures[] = { { .type = RECTANGLE, .rect = { .p = { 4, 8 }, .width = 37, .height = 48 } }, { .type = TRIANGLE, .triangle = { .p1 = { 5, 17 }, .p2 = { 6, 12 }, .p3 = { 4, -12 } } }, { .type = CIRCLE, .circ = { .c = { 9, -3 }, .r = 1.9701184534490008 } } };
                struct figure_t *ptr[3];

                for (int i = 0; i < 3; ++i)
                    ptr[i] = &figures[i];

                printf("------------TABLICA FIGUR DO POSORTOWANIA-----------\n");

                for (int i = 0; i < 3; ++i)
                {
                    printf("%.4f ", area_figure(figures  + i));
                    display_figure(figures  + i);
                }
                
                printf("------------TABLICA FIGUR PO SORTOWANIU-----------\n");

                int res = sort_by_area(ptr, 3);
                test_error(res == 0, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 0, res);

                struct figure_t expected_figures[] = { { .type = RECTANGLE, .rect = { .p = { 4, 8 }, .width = 37, .height = 48 } }, { .type = TRIANGLE, .triangle = { .p1 = { 5, 17 }, .p2 = { 6, 12 }, .p3 = { 4, -12 } } }, { .type = CIRCLE, .circ = { .c = { 9, -3 }, .r = 1.9701184534490008 } } };

                for (int i = 0; i < 3; ++i)
                {
                    printf("%d %.4f ", i, area_figure(ptr[i]));
                    display_figure(ptr[i]);
                }
                
                printf("------------OCZEKIWANA TABLICA FIGUR-----------\n");
                
                for (int i = 0; i < 3; ++i)
                {
                    printf("%d %.4f ", i, area_figure(expected_figures + i));
                    display_figure(expected_figures  + i);
                }
                
                printf("------------\n");
                

                for (int i = 0; i < 3; ++i)
                {
                    test_error(ptr[i]->type == expected_figures[i].type, "Typ figury pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].type, ptr[i]->type);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (ptr[i]->type == TRIANGLE)
                    {
                        test_error(ptr[i]->triangle.p1.x == expected_figures[i].triangle.p1.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.x, ptr[i]->triangle.p1.x);
                        test_error(ptr[i]->triangle.p1.y == expected_figures[i].triangle.p1.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.y, ptr[i]->triangle.p1.y);
                        test_error(ptr[i]->triangle.p2.x == expected_figures[i].triangle.p2.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.x, ptr[i]->triangle.p2.x);
                        test_error(ptr[i]->triangle.p2.y == expected_figures[i].triangle.p2.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.y, ptr[i]->triangle.p2.y);
                        test_error(ptr[i]->triangle.p3.x == expected_figures[i].triangle.p3.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.x, ptr[i]->triangle.p3.x);
                        test_error(ptr[i]->triangle.p3.y == expected_figures[i].triangle.p3.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.y, ptr[i]->triangle.p3.y);
                    }            
                    else if (ptr[i]->type == RECTANGLE)
                    {
                        test_error(ptr[i]->rect.p.x == expected_figures[i].rect.p.x, "Współrzędna x prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.x, ptr[i]->rect.p.x);
                        test_error(ptr[i]->rect.p.y == expected_figures[i].rect.p.y, "Współrzędna y prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.y, ptr[i]->rect.p.y);
                        test_error(ptr[i]->rect.width == expected_figures[i].rect.width, "Szerokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.width, ptr[i]->rect.width);
                        test_error(ptr[i]->rect.height == expected_figures[i].rect.height, "Wysokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.height, ptr[i]->rect.height);
                    }
                    else if (ptr[i]->type == CIRCLE)
                    {
                        test_error(ptr[i]->circ.c.x == expected_figures[i].circ.c.x, "Współrzędna x okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.x, ptr[i]->circ.c.x);
                        test_error(ptr[i]->circ.c.y == expected_figures[i].circ.c.y, "Współrzędna y okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.y, ptr[i]->circ.c.y);
                        test_error(ptr[i]->circ.r == expected_figures[i].circ.r, "Promięć okręgu pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].circ.r, ptr[i]->circ.r);
                    }
                    
                }


            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 54: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST54(void)
{
    // informacje o teście
    test_start(54, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct figure_t figures[] = { { .type = TRIANGLE, .triangle = { .p1 = { 6, 1 }, .p2 = { -7, 1 }, .p3 = { 5, -8 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -13, 19 }, .p2 = { 0, -3 }, .p3 = { -19, 16 } } }, { .type = CIRCLE, .circ = { .c = { 7, 0 }, .r = 18.958244988612147 } }, { .type = RECTANGLE, .rect = { .p = { 7, 4 }, .width = 40, .height = 31 } }, { .type = RECTANGLE, .rect = { .p = { 9, 2 }, .width = 31, .height = 14 } }, { .type = TRIANGLE, .triangle = { .p1 = { -19, -8 }, .p2 = { 8, -3 }, .p3 = { -6, 17 } } }, { .type = RECTANGLE, .rect = { .p = { 4, -2 }, .width = 10, .height = 48 } }, { .type = CIRCLE, .circ = { .c = { 9, 4 }, .r = 13.8001362433548 } }, { .type = TRIANGLE, .triangle = { .p1 = { 4, 19 }, .p2 = { -19, 18 }, .p3 = { 4, -4 } } }, { .type = RECTANGLE, .rect = { .p = { 0, -4 }, .width = 36, .height = 37 } }, { .type = TRIANGLE, .triangle = { .p1 = { 20, 9 }, .p2 = { 9, 15 }, .p3 = { -9, 15 } } } };
                struct figure_t *ptr[11];

                for (int i = 0; i < 11; ++i)
                    ptr[i] = &figures[i];

                printf("------------TABLICA FIGUR DO POSORTOWANIA-----------\n");

                for (int i = 0; i < 11; ++i)
                {
                    printf("%.4f ", area_figure(figures  + i));
                    display_figure(figures  + i);
                }
                
                printf("------------TABLICA FIGUR PO SORTOWANIU-----------\n");

                int res = sort_by_area(ptr, 11);
                test_error(res == 0, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 0, res);

                struct figure_t expected_figures[] = { { .type = RECTANGLE, .rect = { .p = { 0, -4 }, .width = 36, .height = 37 } }, { .type = RECTANGLE, .rect = { .p = { 7, 4 }, .width = 40, .height = 31 } }, { .type = CIRCLE, .circ = { .c = { 7, 0 }, .r = 18.958244988612147 } }, { .type = CIRCLE, .circ = { .c = { 9, 4 }, .r = 13.8001362433548 } }, { .type = RECTANGLE, .rect = { .p = { 4, -2 }, .width = 10, .height = 48 } }, { .type = RECTANGLE, .rect = { .p = { 9, 2 }, .width = 31, .height = 14 } }, { .type = TRIANGLE, .triangle = { .p1 = { -19, -8 }, .p2 = { 8, -3 }, .p3 = { -6, 17 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 4, 19 }, .p2 = { -19, 18 }, .p3 = { 4, -4 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -13, 19 }, .p2 = { 0, -3 }, .p3 = { -19, 16 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 6, 1 }, .p2 = { -7, 1 }, .p3 = { 5, -8 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 20, 9 }, .p2 = { 9, 15 }, .p3 = { -9, 15 } } } };

                for (int i = 0; i < 11; ++i)
                {
                    printf("%d %.4f ", i, area_figure(ptr[i]));
                    display_figure(ptr[i]);
                }
                
                printf("------------OCZEKIWANA TABLICA FIGUR-----------\n");
                
                for (int i = 0; i < 11; ++i)
                {
                    printf("%d %.4f ", i, area_figure(expected_figures + i));
                    display_figure(expected_figures  + i);
                }
                
                printf("------------\n");
                

                for (int i = 0; i < 11; ++i)
                {
                    test_error(ptr[i]->type == expected_figures[i].type, "Typ figury pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].type, ptr[i]->type);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (ptr[i]->type == TRIANGLE)
                    {
                        test_error(ptr[i]->triangle.p1.x == expected_figures[i].triangle.p1.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.x, ptr[i]->triangle.p1.x);
                        test_error(ptr[i]->triangle.p1.y == expected_figures[i].triangle.p1.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.y, ptr[i]->triangle.p1.y);
                        test_error(ptr[i]->triangle.p2.x == expected_figures[i].triangle.p2.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.x, ptr[i]->triangle.p2.x);
                        test_error(ptr[i]->triangle.p2.y == expected_figures[i].triangle.p2.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.y, ptr[i]->triangle.p2.y);
                        test_error(ptr[i]->triangle.p3.x == expected_figures[i].triangle.p3.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.x, ptr[i]->triangle.p3.x);
                        test_error(ptr[i]->triangle.p3.y == expected_figures[i].triangle.p3.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.y, ptr[i]->triangle.p3.y);
                    }            
                    else if (ptr[i]->type == RECTANGLE)
                    {
                        test_error(ptr[i]->rect.p.x == expected_figures[i].rect.p.x, "Współrzędna x prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.x, ptr[i]->rect.p.x);
                        test_error(ptr[i]->rect.p.y == expected_figures[i].rect.p.y, "Współrzędna y prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.y, ptr[i]->rect.p.y);
                        test_error(ptr[i]->rect.width == expected_figures[i].rect.width, "Szerokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.width, ptr[i]->rect.width);
                        test_error(ptr[i]->rect.height == expected_figures[i].rect.height, "Wysokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.height, ptr[i]->rect.height);
                    }
                    else if (ptr[i]->type == CIRCLE)
                    {
                        test_error(ptr[i]->circ.c.x == expected_figures[i].circ.c.x, "Współrzędna x okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.x, ptr[i]->circ.c.x);
                        test_error(ptr[i]->circ.c.y == expected_figures[i].circ.c.y, "Współrzędna y okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.y, ptr[i]->circ.c.y);
                        test_error(ptr[i]->circ.r == expected_figures[i].circ.r, "Promięć okręgu pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].circ.r, ptr[i]->circ.r);
                    }
                    
                }


            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 55: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST55(void)
{
    // informacje o teście
    test_start(55, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct figure_t figures[] = { { .type = TRIANGLE, .triangle = { .p1 = { 20, 4 }, .p2 = { 14, 6 }, .p3 = { 0, 17 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -2, -11 }, .p2 = { 17, 5 }, .p3 = { 19, 1 } } }, { .type = RECTANGLE, .rect = { .p = { -4, -1 }, .width = 44, .height = 34 } }, { .type = CIRCLE, .circ = { .c = { -2, 8 }, .r = 9.513343417159714 } }, { .type = CIRCLE, .circ = { .c = { -1, -10 }, .r = 5.507564329625998 } }, { .type = RECTANGLE, .rect = { .p = { 9, 6 }, .width = 43, .height = 46 } }, { .type = RECTANGLE, .rect = { .p = { -6, 7 }, .width = 26, .height = 25 } }, { .type = CIRCLE, .circ = { .c = { 5, -2 }, .r = 5.144456601723737 } }, { .type = RECTANGLE, .rect = { .p = { 7, 5 }, .width = 41, .height = 49 } }, { .type = RECTANGLE, .rect = { .p = { -6, 4 }, .width = 24, .height = 46 } }, { .type = RECTANGLE, .rect = { .p = { 2, 0 }, .width = 47, .height = 15 } }, { .type = CIRCLE, .circ = { .c = { 7, 5 }, .r = 7.662044219214981 } }, { .type = CIRCLE, .circ = { .c = { 5, -7 }, .r = 11.354015501155242 } }, { .type = RECTANGLE, .rect = { .p = { 8, -6 }, .width = 22, .height = 47 } }, { .type = TRIANGLE, .triangle = { .p1 = { -4, 18 }, .p2 = { -5, 20 }, .p3 = { -5, 10 } } }, { .type = CIRCLE, .circ = { .c = { -10, -2 }, .r = 18.04523639622121 } }, { .type = CIRCLE, .circ = { .c = { 10, -3 }, .r = 36.22829510570455 } }, { .type = CIRCLE, .circ = { .c = { 6, 6 }, .r = 3.097411421187313 } }, { .type = RECTANGLE, .rect = { .p = { 1, -4 }, .width = 27, .height = 26 } }, { .type = RECTANGLE, .rect = { .p = { -2, 5 }, .width = 49, .height = 11 } }, { .type = TRIANGLE, .triangle = { .p1 = { -3, -16 }, .p2 = { -12, -3 }, .p3 = { 18, -11 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -1, -19 }, .p2 = { -17, 6 }, .p3 = { -14, 7 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 3, 14 }, .p2 = { 9, -9 }, .p3 = { 4, -6 } } }, { .type = RECTANGLE, .rect = { .p = { -4, -8 }, .width = 45, .height = 28 } }, { .type = TRIANGLE, .triangle = { .p1 = { -17, -5 }, .p2 = { 5, -17 }, .p3 = { 9, -13 } } }, { .type = RECTANGLE, .rect = { .p = { 9, -6 }, .width = 45, .height = 29 } }, { .type = CIRCLE, .circ = { .c = { 8, -3 }, .r = 8.25315675140515 } }, { .type = RECTANGLE, .rect = { .p = { 2, 1 }, .width = 28, .height = 42 } }, { .type = CIRCLE, .circ = { .c = { -8, 0 }, .r = 20.805846693981835 } }, { .type = CIRCLE, .circ = { .c = { 4, 7 }, .r = 26.280312917214214 } }, { .type = TRIANGLE, .triangle = { .p1 = { -9, 5 }, .p2 = { -19, -20 }, .p3 = { 6, 11 } } }, { .type = CIRCLE, .circ = { .c = { 3, 3 }, .r = 22.63538831903412 } }, { .type = CIRCLE, .circ = { .c = { -2, 5 }, .r = 32.774371562803466 } }, { .type = TRIANGLE, .triangle = { .p1 = { 5, 14 }, .p2 = { 15, 2 }, .p3 = { -18, -4 } } }, { .type = RECTANGLE, .rect = { .p = { -8, -4 }, .width = 32, .height = 21 } }, { .type = RECTANGLE, .rect = { .p = { -6, -4 }, .width = 50, .height = 17 } }, { .type = TRIANGLE, .triangle = { .p1 = { -13, -6 }, .p2 = { -14, -18 }, .p3 = { -7, 16 } } }, { .type = CIRCLE, .circ = { .c = { 4, 8 }, .r = 25.432902316789757 } }, { .type = TRIANGLE, .triangle = { .p1 = { -8, 7 }, .p2 = { -14, 20 }, .p3 = { 14, 7 } } }, { .type = CIRCLE, .circ = { .c = { -10, 1 }, .r = 33.36471016303736 } }, { .type = CIRCLE, .circ = { .c = { -8, -4 }, .r = 36.02284974824651 } }, { .type = CIRCLE, .circ = { .c = { 8, -4 }, .r = 29.42427866449936 } }, { .type = RECTANGLE, .rect = { .p = { 1, -8 }, .width = 39, .height = 33 } }, { .type = TRIANGLE, .triangle = { .p1 = { 4, 8 }, .p2 = { 20, 14 }, .p3 = { 8, 14 } } }, { .type = CIRCLE, .circ = { .c = { -4, 9 }, .r = 7.181899081630619 } }, { .type = RECTANGLE, .rect = { .p = { -6, -5 }, .width = 49, .height = 17 } }, { .type = RECTANGLE, .rect = { .p = { -3, -10 }, .width = 43, .height = 17 } }, { .type = CIRCLE, .circ = { .c = { -1, -8 }, .r = 29.907875248029605 } }, { .type = TRIANGLE, .triangle = { .p1 = { -6, 0 }, .p2 = { -11, 14 }, .p3 = { 4, -11 } } }, { .type = RECTANGLE, .rect = { .p = { 5, -7 }, .width = 16, .height = 28 } }, { .type = TRIANGLE, .triangle = { .p1 = { 15, -12 }, .p2 = { 3, -4 }, .p3 = { 19, 20 } } }, { .type = CIRCLE, .circ = { .c = { -3, -9 }, .r = 31.393670295761613 } }, { .type = TRIANGLE, .triangle = { .p1 = { 2, 13 }, .p2 = { -10, -7 }, .p3 = { -4, -13 } } }, { .type = RECTANGLE, .rect = { .p = { 3, 8 }, .width = 15, .height = 12 } }, { .type = RECTANGLE, .rect = { .p = { 9, -1 }, .width = 22, .height = 12 } } };
                struct figure_t *ptr[55];

                for (int i = 0; i < 55; ++i)
                    ptr[i] = &figures[i];

                printf("------------TABLICA FIGUR DO POSORTOWANIA-----------\n");

                for (int i = 0; i < 55; ++i)
                {
                    printf("%.4f ", area_figure(figures  + i));
                    display_figure(figures  + i);
                }
                
                printf("------------TABLICA FIGUR PO SORTOWANIU-----------\n");

                int res = sort_by_area(ptr, 55);
                test_error(res == 0, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 0, res);

                struct figure_t expected_figures[] = { { .type = CIRCLE, .circ = { .c = { 10, -3 }, .r = 36.22829510570455 } }, { .type = CIRCLE, .circ = { .c = { -8, -4 }, .r = 36.02284974824651 } }, { .type = CIRCLE, .circ = { .c = { -10, 1 }, .r = 33.36471016303736 } }, { .type = CIRCLE, .circ = { .c = { -2, 5 }, .r = 32.774371562803466 } }, { .type = CIRCLE, .circ = { .c = { -3, -9 }, .r = 31.393670295761613 } }, { .type = CIRCLE, .circ = { .c = { -1, -8 }, .r = 29.907875248029605 } }, { .type = CIRCLE, .circ = { .c = { 8, -4 }, .r = 29.42427866449936 } }, { .type = CIRCLE, .circ = { .c = { 4, 7 }, .r = 26.280312917214214 } }, { .type = CIRCLE, .circ = { .c = { 4, 8 }, .r = 25.432902316789757 } }, { .type = RECTANGLE, .rect = { .p = { 7, 5 }, .width = 41, .height = 49 } }, { .type = RECTANGLE, .rect = { .p = { 9, 6 }, .width = 43, .height = 46 } }, { .type = CIRCLE, .circ = { .c = { 3, 3 }, .r = 22.63538831903412 } }, { .type = RECTANGLE, .rect = { .p = { -4, -1 }, .width = 44, .height = 34 } }, { .type = CIRCLE, .circ = { .c = { -8, 0 }, .r = 20.805846693981835 } }, { .type = RECTANGLE, .rect = { .p = { 9, -6 }, .width = 45, .height = 29 } }, { .type = RECTANGLE, .rect = { .p = { 1, -8 }, .width = 39, .height = 33 } }, { .type = RECTANGLE, .rect = { .p = { -4, -8 }, .width = 45, .height = 28 } }, { .type = RECTANGLE, .rect = { .p = { 2, 1 }, .width = 28, .height = 42 } }, { .type = RECTANGLE, .rect = { .p = { -6, 4 }, .width = 24, .height = 46 } }, { .type = RECTANGLE, .rect = { .p = { 8, -6 }, .width = 22, .height = 47 } }, { .type = CIRCLE, .circ = { .c = { -10, -2 }, .r = 18.04523639622121 } }, { .type = RECTANGLE, .rect = { .p = { -6, -4 }, .width = 50, .height = 17 } }, { .type = RECTANGLE, .rect = { .p = { -6, -5 }, .width = 49, .height = 17 } }, { .type = RECTANGLE, .rect = { .p = { -3, -10 }, .width = 43, .height = 17 } }, { .type = RECTANGLE, .rect = { .p = { 2, 0 }, .width = 47, .height = 15 } }, { .type = RECTANGLE, .rect = { .p = { 1, -4 }, .width = 27, .height = 26 } }, { .type = RECTANGLE, .rect = { .p = { -8, -4 }, .width = 32, .height = 21 } }, { .type = RECTANGLE, .rect = { .p = { -6, 7 }, .width = 26, .height = 25 } }, { .type = RECTANGLE, .rect = { .p = { -2, 5 }, .width = 49, .height = 11 } }, { .type = RECTANGLE, .rect = { .p = { 5, -7 }, .width = 16, .height = 28 } }, { .type = CIRCLE, .circ = { .c = { 5, -7 }, .r = 11.354015501155242 } }, { .type = CIRCLE, .circ = { .c = { -2, 8 }, .r = 9.513343417159714 } }, { .type = RECTANGLE, .rect = { .p = { 9, -1 }, .width = 22, .height = 12 } }, { .type = TRIANGLE, .triangle = { .p1 = { 5, 14 }, .p2 = { 15, 2 }, .p3 = { -18, -4 } } }, { .type = CIRCLE, .circ = { .c = { 8, -3 }, .r = 8.25315675140515 } }, { .type = TRIANGLE, .triangle = { .p1 = { 15, -12 }, .p2 = { 3, -4 }, .p3 = { 19, 20 } } }, { .type = CIRCLE, .circ = { .c = { 7, 5 }, .r = 7.662044219214981 } }, { .type = RECTANGLE, .rect = { .p = { 3, 8 }, .width = 15, .height = 12 } }, { .type = CIRCLE, .circ = { .c = { -4, 9 }, .r = 7.181899081630619 } }, { .type = TRIANGLE, .triangle = { .p1 = { -3, -16 }, .p2 = { -12, -3 }, .p3 = { 18, -11 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -9, 5 }, .p2 = { -19, -20 }, .p3 = { 6, 11 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -8, 7 }, .p2 = { -14, 20 }, .p3 = { 14, 7 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 2, 13 }, .p2 = { -10, -7 }, .p3 = { -4, -13 } } }, { .type = CIRCLE, .circ = { .c = { -1, -10 }, .r = 5.507564329625998 } }, { .type = CIRCLE, .circ = { .c = { 5, -2 }, .r = 5.144456601723737 } }, { .type = TRIANGLE, .triangle = { .p1 = { -17, -5 }, .p2 = { 5, -17 }, .p3 = { 9, -13 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -2, -11 }, .p2 = { 17, 5 }, .p3 = { 19, 1 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 3, 14 }, .p2 = { 9, -9 }, .p3 = { 4, -6 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -1, -19 }, .p2 = { -17, 6 }, .p3 = { -14, 7 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -6, 0 }, .p2 = { -11, 14 }, .p3 = { 4, -11 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 4, 8 }, .p2 = { 20, 14 }, .p3 = { 8, 14 } } }, { .type = CIRCLE, .circ = { .c = { 6, 6 }, .r = 3.097411421187313 } }, { .type = TRIANGLE, .triangle = { .p1 = { -13, -6 }, .p2 = { -14, -18 }, .p3 = { -7, 16 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 20, 4 }, .p2 = { 14, 6 }, .p3 = { 0, 17 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -4, 18 }, .p2 = { -5, 20 }, .p3 = { -5, 10 } } } };

                for (int i = 0; i < 55; ++i)
                {
                    printf("%d %.4f ", i, area_figure(ptr[i]));
                    display_figure(ptr[i]);
                }
                
                printf("------------OCZEKIWANA TABLICA FIGUR-----------\n");
                
                for (int i = 0; i < 55; ++i)
                {
                    printf("%d %.4f ", i, area_figure(expected_figures + i));
                    display_figure(expected_figures  + i);
                }
                
                printf("------------\n");
                

                for (int i = 0; i < 55; ++i)
                {
                    test_error(ptr[i]->type == expected_figures[i].type, "Typ figury pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].type, ptr[i]->type);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (ptr[i]->type == TRIANGLE)
                    {
                        test_error(ptr[i]->triangle.p1.x == expected_figures[i].triangle.p1.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.x, ptr[i]->triangle.p1.x);
                        test_error(ptr[i]->triangle.p1.y == expected_figures[i].triangle.p1.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.y, ptr[i]->triangle.p1.y);
                        test_error(ptr[i]->triangle.p2.x == expected_figures[i].triangle.p2.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.x, ptr[i]->triangle.p2.x);
                        test_error(ptr[i]->triangle.p2.y == expected_figures[i].triangle.p2.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.y, ptr[i]->triangle.p2.y);
                        test_error(ptr[i]->triangle.p3.x == expected_figures[i].triangle.p3.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.x, ptr[i]->triangle.p3.x);
                        test_error(ptr[i]->triangle.p3.y == expected_figures[i].triangle.p3.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.y, ptr[i]->triangle.p3.y);
                    }            
                    else if (ptr[i]->type == RECTANGLE)
                    {
                        test_error(ptr[i]->rect.p.x == expected_figures[i].rect.p.x, "Współrzędna x prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.x, ptr[i]->rect.p.x);
                        test_error(ptr[i]->rect.p.y == expected_figures[i].rect.p.y, "Współrzędna y prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.y, ptr[i]->rect.p.y);
                        test_error(ptr[i]->rect.width == expected_figures[i].rect.width, "Szerokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.width, ptr[i]->rect.width);
                        test_error(ptr[i]->rect.height == expected_figures[i].rect.height, "Wysokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.height, ptr[i]->rect.height);
                    }
                    else if (ptr[i]->type == CIRCLE)
                    {
                        test_error(ptr[i]->circ.c.x == expected_figures[i].circ.c.x, "Współrzędna x okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.x, ptr[i]->circ.c.x);
                        test_error(ptr[i]->circ.c.y == expected_figures[i].circ.c.y, "Współrzędna y okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.y, ptr[i]->circ.c.y);
                        test_error(ptr[i]->circ.r == expected_figures[i].circ.r, "Promięć okręgu pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].circ.r, ptr[i]->circ.r);
                    }
                    
                }


            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 56: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST56(void)
{
    // informacje o teście
    test_start(56, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct figure_t figures[] = { { .type = RECTANGLE, .rect = { .p = { -1, -5 }, .width = 35, .height = 24 } }, { .type = TRIANGLE, .triangle = { .p1 = { 24, 34 }, .p2 = { 9, 37 }, .p3 = { -17, -22 } } }, { .type = CIRCLE, .circ = { .c = { -2, 0 }, .r = 31.5355779958928 } }, { .type = CIRCLE, .circ = { .c = { -6, -9 }, .r = 16.850248285536274 } }, { .type = TRIANGLE, .triangle = { .p1 = { 7, -7 }, .p2 = { 3, 40 }, .p3 = { 14, -6 } } }, { .type = RECTANGLE, .rect = { .p = { 0, -8 }, .width = 41, .height = 43 } }, { .type = TRIANGLE, .triangle = { .p1 = { -33, 16 }, .p2 = { -6, -9 }, .p3 = { 3, 39 } } }, { .type = RECTANGLE, .rect = { .p = { 7, -4 }, .width = 37, .height = 19 } }, { .type = TRIANGLE, .triangle = { .p1 = { 13, 3 }, .p2 = { -25, 32 }, .p3 = { 40, -13 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -13, -24 }, .p2 = { 37, 1 }, .p3 = { -18, -7 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -22, -14 }, .p2 = { 16, 31 }, .p3 = { 20, -32 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -7, -27 }, .p2 = { 39, -16 }, .p3 = { 9, 34 } } }, { .type = CIRCLE, .circ = { .c = { 7, 5 }, .r = 11.659960110339092 } }, { .type = CIRCLE, .circ = { .c = { -7, 1 }, .r = 9.16845474303259 } }, { .type = CIRCLE, .circ = { .c = { -10, -7 }, .r = 28.061949091778253 } }, { .type = RECTANGLE, .rect = { .p = { 4, 5 }, .width = 37, .height = 14 } }, { .type = TRIANGLE, .triangle = { .p1 = { 22, -17 }, .p2 = { -18, 12 }, .p3 = { 10, 16 } } }, { .type = CIRCLE, .circ = { .c = { -6, -4 }, .r = 33.32578871699465 } }, { .type = TRIANGLE, .triangle = { .p1 = { -40, 23 }, .p2 = { -15, -8 }, .p3 = { -2, -39 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 19, 36 }, .p2 = { 11, 13 }, .p3 = { -37, 30 } } }, { .type = CIRCLE, .circ = { .c = { 6, 6 }, .r = 19.776935101402984 } }, { .type = CIRCLE, .circ = { .c = { -5, 9 }, .r = 37.734274886913674 } }, { .type = TRIANGLE, .triangle = { .p1 = { 38, 29 }, .p2 = { 20, 5 }, .p3 = { 20, 33 } } }, { .type = RECTANGLE, .rect = { .p = { 6, -10 }, .width = 12, .height = 16 } }, { .type = TRIANGLE, .triangle = { .p1 = { -40, -5 }, .p2 = { -19, -9 }, .p3 = { -7, -7 } } }, { .type = RECTANGLE, .rect = { .p = { -8, -10 }, .width = 32, .height = 14 } }, { .type = RECTANGLE, .rect = { .p = { 6, 6 }, .width = 11, .height = 38 } }, { .type = CIRCLE, .circ = { .c = { 1, 5 }, .r = 23.784221173066474 } }, { .type = RECTANGLE, .rect = { .p = { -4, -3 }, .width = 34, .height = 39 } }, { .type = CIRCLE, .circ = { .c = { 9, -4 }, .r = 3.434872427280797 } }, { .type = CIRCLE, .circ = { .c = { -2, -3 }, .r = 12.750852572897069 } }, { .type = RECTANGLE, .rect = { .p = { -4, -2 }, .width = 34, .height = 15 } }, { .type = CIRCLE, .circ = { .c = { -4, 10 }, .r = 13.696910761746363 } }, { .type = CIRCLE, .circ = { .c = { 2, 5 }, .r = 29.059799024551808 } }, { .type = RECTANGLE, .rect = { .p = { 6, -6 }, .width = 37, .height = 31 } }, { .type = RECTANGLE, .rect = { .p = { -2, 2 }, .width = 45, .height = 46 } }, { .type = CIRCLE, .circ = { .c = { 6, -4 }, .r = 21.238874557261354 } }, { .type = CIRCLE, .circ = { .c = { 5, 10 }, .r = 30.626858053920945 } }, { .type = CIRCLE, .circ = { .c = { 9, 3 }, .r = 4.427473660894087 } }, { .type = CIRCLE, .circ = { .c = { -10, 0 }, .r = 36.75048692666157 } }, { .type = CIRCLE, .circ = { .c = { 5, -4 }, .r = 36.18610953122747 } }, { .type = RECTANGLE, .rect = { .p = { 0, 4 }, .width = 37, .height = 45 } }, { .type = RECTANGLE, .rect = { .p = { -9, -4 }, .width = 13, .height = 12 } }, { .type = TRIANGLE, .triangle = { .p1 = { 34, -37 }, .p2 = { -6, 5 }, .p3 = { 34, 31 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 34, 4 }, .p2 = { -9, -37 }, .p3 = { -37, -3 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 31, -38 }, .p2 = { 12, 5 }, .p3 = { 1, -36 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -32, -19 }, .p2 = { 9, 40 }, .p3 = { 3, 9 } } }, { .type = CIRCLE, .circ = { .c = { -1, -8 }, .r = 28.72375237681608 } }, { .type = CIRCLE, .circ = { .c = { -2, 3 }, .r = 12.192761747394785 } }, { .type = RECTANGLE, .rect = { .p = { -1, -10 }, .width = 38, .height = 27 } }, { .type = CIRCLE, .circ = { .c = { -9, 1 }, .r = 21.680856392163914 } }, { .type = CIRCLE, .circ = { .c = { 1, 7 }, .r = 33.19844017148416 } }, { .type = CIRCLE, .circ = { .c = { -4, 1 }, .r = 1.9736911967150585 } }, { .type = CIRCLE, .circ = { .c = { -10, 8 }, .r = 5.2190715979403635 } }, { .type = CIRCLE, .circ = { .c = { -10, -1 }, .r = 14.267758615402006 } }, { .type = RECTANGLE, .rect = { .p = { 5, 6 }, .width = 26, .height = 50 } }, { .type = TRIANGLE, .triangle = { .p1 = { 34, -14 }, .p2 = { 15, 33 }, .p3 = { 1, 25 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -28, -5 }, .p2 = { 8, 32 }, .p3 = { -38, 21 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -28, -17 }, .p2 = { -1, 4 }, .p3 = { -24, 22 } } }, { .type = RECTANGLE, .rect = { .p = { 10, 1 }, .width = 50, .height = 38 } }, { .type = CIRCLE, .circ = { .c = { -1, -2 }, .r = 19.925295732558638 } }, { .type = CIRCLE, .circ = { .c = { 4, 6 }, .r = 36.71464038820379 } }, { .type = CIRCLE, .circ = { .c = { -9, -3 }, .r = 30.027498060408593 } }, { .type = TRIANGLE, .triangle = { .p1 = { -2, 12 }, .p2 = { 9, 17 }, .p3 = { -12, 36 } } }, { .type = CIRCLE, .circ = { .c = { 4, -2 }, .r = 27.70834497568788 } }, { .type = CIRCLE, .circ = { .c = { -4, -9 }, .r = 9.513371518074143 } }, { .type = CIRCLE, .circ = { .c = { 7, 9 }, .r = 35.181473787802595 } }, { .type = TRIANGLE, .triangle = { .p1 = { 4, 22 }, .p2 = { 21, 18 }, .p3 = { 25, 14 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -18, -29 }, .p2 = { 33, -28 }, .p3 = { 16, 10 } } }, { .type = CIRCLE, .circ = { .c = { 3, -5 }, .r = 34.799866875031384 } }, { .type = RECTANGLE, .rect = { .p = { -1, 2 }, .width = 23, .height = 18 } }, { .type = TRIANGLE, .triangle = { .p1 = { -7, -14 }, .p2 = { -15, 32 }, .p3 = { -17, -22 } } }, { .type = CIRCLE, .circ = { .c = { 10, 6 }, .r = 32.27179543295192 } }, { .type = CIRCLE, .circ = { .c = { 1, -5 }, .r = 9.786860376927265 } }, { .type = CIRCLE, .circ = { .c = { 4, -9 }, .r = 3.002660420433876 } }, { .type = RECTANGLE, .rect = { .p = { 4, 1 }, .width = 24, .height = 41 } }, { .type = CIRCLE, .circ = { .c = { -7, 6 }, .r = 39.98567475107591 } }, { .type = CIRCLE, .circ = { .c = { -3, -10 }, .r = 15.264806384740771 } }, { .type = CIRCLE, .circ = { .c = { 3, -7 }, .r = 3.3234288954895006 } }, { .type = RECTANGLE, .rect = { .p = { 7, -2 }, .width = 27, .height = 27 } }, { .type = CIRCLE, .circ = { .c = { 5, 5 }, .r = 11.843032705700647 } }, { .type = RECTANGLE, .rect = { .p = { 3, 5 }, .width = 23, .height = 42 } }, { .type = CIRCLE, .circ = { .c = { 7, 9 }, .r = 30.98135750615086 } } };
                struct figure_t *ptr[83];

                for (int i = 0; i < 83; ++i)
                    ptr[i] = &figures[i];

                printf("------------TABLICA FIGUR DO POSORTOWANIA-----------\n");

                for (int i = 0; i < 83; ++i)
                {
                    printf("%.4f ", area_figure(figures  + i));
                    display_figure(figures  + i);
                }
                
                printf("------------TABLICA FIGUR PO SORTOWANIU-----------\n");

                int res = sort_by_area(ptr, 83);
                test_error(res == 0, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 0, res);

                struct figure_t expected_figures[] = { { .type = CIRCLE, .circ = { .c = { -7, 6 }, .r = 39.98567475107591 } }, { .type = CIRCLE, .circ = { .c = { -5, 9 }, .r = 37.734274886913674 } }, { .type = CIRCLE, .circ = { .c = { -10, 0 }, .r = 36.75048692666157 } }, { .type = CIRCLE, .circ = { .c = { 4, 6 }, .r = 36.71464038820379 } }, { .type = CIRCLE, .circ = { .c = { 5, -4 }, .r = 36.18610953122747 } }, { .type = CIRCLE, .circ = { .c = { 7, 9 }, .r = 35.181473787802595 } }, { .type = CIRCLE, .circ = { .c = { 3, -5 }, .r = 34.799866875031384 } }, { .type = CIRCLE, .circ = { .c = { -6, -4 }, .r = 33.32578871699465 } }, { .type = CIRCLE, .circ = { .c = { 1, 7 }, .r = 33.19844017148416 } }, { .type = CIRCLE, .circ = { .c = { 10, 6 }, .r = 32.27179543295192 } }, { .type = CIRCLE, .circ = { .c = { -2, 0 }, .r = 31.5355779958928 } }, { .type = CIRCLE, .circ = { .c = { 7, 9 }, .r = 30.98135750615086 } }, { .type = CIRCLE, .circ = { .c = { 5, 10 }, .r = 30.626858053920945 } }, { .type = CIRCLE, .circ = { .c = { -9, -3 }, .r = 30.027498060408593 } }, { .type = CIRCLE, .circ = { .c = { 2, 5 }, .r = 29.059799024551808 } }, { .type = CIRCLE, .circ = { .c = { -1, -8 }, .r = 28.72375237681608 } }, { .type = CIRCLE, .circ = { .c = { -10, -7 }, .r = 28.061949091778253 } }, { .type = CIRCLE, .circ = { .c = { 4, -2 }, .r = 27.70834497568788 } }, { .type = RECTANGLE, .rect = { .p = { -2, 2 }, .width = 45, .height = 46 } }, { .type = RECTANGLE, .rect = { .p = { 10, 1 }, .width = 50, .height = 38 } }, { .type = CIRCLE, .circ = { .c = { 1, 5 }, .r = 23.784221173066474 } }, { .type = RECTANGLE, .rect = { .p = { 0, -8 }, .width = 41, .height = 43 } }, { .type = RECTANGLE, .rect = { .p = { 0, 4 }, .width = 37, .height = 45 } }, { .type = CIRCLE, .circ = { .c = { -9, 1 }, .r = 21.680856392163914 } }, { .type = CIRCLE, .circ = { .c = { 6, -4 }, .r = 21.238874557261354 } }, { .type = TRIANGLE, .triangle = { .p1 = { 34, -37 }, .p2 = { -6, 5 }, .p3 = { 34, 31 } } }, { .type = RECTANGLE, .rect = { .p = { -4, -3 }, .width = 34, .height = 39 } }, { .type = TRIANGLE, .triangle = { .p1 = { -7, -27 }, .p2 = { 39, -16 }, .p3 = { 9, 34 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 34, 4 }, .p2 = { -9, -37 }, .p3 = { -37, -3 } } }, { .type = RECTANGLE, .rect = { .p = { 5, 6 }, .width = 26, .height = 50 } }, { .type = TRIANGLE, .triangle = { .p1 = { -22, -14 }, .p2 = { 16, 31 }, .p3 = { 20, -32 } } }, { .type = CIRCLE, .circ = { .c = { -1, -2 }, .r = 19.925295732558638 } }, { .type = CIRCLE, .circ = { .c = { 6, 6 }, .r = 19.776935101402984 } }, { .type = RECTANGLE, .rect = { .p = { 6, -6 }, .width = 37, .height = 31 } }, { .type = RECTANGLE, .rect = { .p = { -1, -10 }, .width = 38, .height = 27 } }, { .type = RECTANGLE, .rect = { .p = { 4, 1 }, .width = 24, .height = 41 } }, { .type = TRIANGLE, .triangle = { .p1 = { -18, -29 }, .p2 = { 33, -28 }, .p3 = { 16, 10 } } }, { .type = RECTANGLE, .rect = { .p = { 3, 5 }, .width = 23, .height = 42 } }, { .type = CIRCLE, .circ = { .c = { -6, -9 }, .r = 16.850248285536274 } }, { .type = RECTANGLE, .rect = { .p = { -1, -5 }, .width = 35, .height = 24 } }, { .type = TRIANGLE, .triangle = { .p1 = { -33, 16 }, .p2 = { -6, -9 }, .p3 = { 3, 39 } } }, { .type = CIRCLE, .circ = { .c = { -3, -10 }, .r = 15.264806384740771 } }, { .type = RECTANGLE, .rect = { .p = { 7, -2 }, .width = 27, .height = 27 } }, { .type = RECTANGLE, .rect = { .p = { 7, -4 }, .width = 37, .height = 19 } }, { .type = TRIANGLE, .triangle = { .p1 = { -28, -5 }, .p2 = { 8, 32 }, .p3 = { -38, 21 } } }, { .type = CIRCLE, .circ = { .c = { -10, -1 }, .r = 14.267758615402006 } }, { .type = TRIANGLE, .triangle = { .p1 = { 31, -38 }, .p2 = { 12, 5 }, .p3 = { 1, -36 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 19, 36 }, .p2 = { 11, 13 }, .p3 = { -37, 30 } } }, { .type = CIRCLE, .circ = { .c = { -4, 10 }, .r = 13.696910761746363 } }, { .type = RECTANGLE, .rect = { .p = { 4, 5 }, .width = 37, .height = 14 } }, { .type = CIRCLE, .circ = { .c = { -2, -3 }, .r = 12.750852572897069 } }, { .type = RECTANGLE, .rect = { .p = { -4, -2 }, .width = 34, .height = 15 } }, { .type = TRIANGLE, .triangle = { .p1 = { -13, -24 }, .p2 = { 37, 1 }, .p3 = { -18, -7 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 22, -17 }, .p2 = { -18, 12 }, .p3 = { 10, 16 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -28, -17 }, .p2 = { -1, 4 }, .p3 = { -24, 22 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 24, 34 }, .p2 = { 9, 37 }, .p3 = { -17, -22 } } }, { .type = CIRCLE, .circ = { .c = { -2, 3 }, .r = 12.192761747394785 } }, { .type = TRIANGLE, .triangle = { .p1 = { -32, -19 }, .p2 = { 9, 40 }, .p3 = { 3, 9 } } }, { .type = RECTANGLE, .rect = { .p = { -8, -10 }, .width = 32, .height = 14 } }, { .type = CIRCLE, .circ = { .c = { 5, 5 }, .r = 11.843032705700647 } }, { .type = CIRCLE, .circ = { .c = { 7, 5 }, .r = 11.659960110339092 } }, { .type = RECTANGLE, .rect = { .p = { 6, 6 }, .width = 11, .height = 38 } }, { .type = RECTANGLE, .rect = { .p = { -1, 2 }, .width = 23, .height = 18 } }, { .type = TRIANGLE, .triangle = { .p1 = { 34, -14 }, .p2 = { 15, 33 }, .p3 = { 1, 25 } } }, { .type = CIRCLE, .circ = { .c = { 1, -5 }, .r = 9.786860376927265 } }, { .type = CIRCLE, .circ = { .c = { -4, -9 }, .r = 9.513371518074143 } }, { .type = CIRCLE, .circ = { .c = { -7, 1 }, .r = 9.16845474303259 } }, { .type = TRIANGLE, .triangle = { .p1 = { -7, -14 }, .p2 = { -15, 32 }, .p3 = { -17, -22 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 38, 29 }, .p2 = { 20, 5 }, .p3 = { 20, 33 } } }, { .type = RECTANGLE, .rect = { .p = { 6, -10 }, .width = 12, .height = 16 } }, { .type = TRIANGLE, .triangle = { .p1 = { -40, 23 }, .p2 = { -15, -8 }, .p3 = { -2, -39 } } }, { .type = TRIANGLE, .triangle = { .p1 = { 7, -7 }, .p2 = { 3, 40 }, .p3 = { 14, -6 } } }, { .type = TRIANGLE, .triangle = { .p1 = { -2, 12 }, .p2 = { 9, 17 }, .p3 = { -12, 36 } } }, { .type = RECTANGLE, .rect = { .p = { -9, -4 }, .width = 13, .height = 12 } }, { .type = TRIANGLE, .triangle = { .p1 = { 13, 3 }, .p2 = { -25, 32 }, .p3 = { 40, -13 } } }, { .type = CIRCLE, .circ = { .c = { -10, 8 }, .r = 5.2190715979403635 } }, { .type = CIRCLE, .circ = { .c = { 9, 3 }, .r = 4.427473660894087 } }, { .type = TRIANGLE, .triangle = { .p1 = { -40, -5 }, .p2 = { -19, -9 }, .p3 = { -7, -7 } } }, { .type = CIRCLE, .circ = { .c = { 9, -4 }, .r = 3.434872427280797 } }, { .type = CIRCLE, .circ = { .c = { 3, -7 }, .r = 3.3234288954895006 } }, { .type = CIRCLE, .circ = { .c = { 4, -9 }, .r = 3.002660420433876 } }, { .type = TRIANGLE, .triangle = { .p1 = { 4, 22 }, .p2 = { 21, 18 }, .p3 = { 25, 14 } } }, { .type = CIRCLE, .circ = { .c = { -4, 1 }, .r = 1.9736911967150585 } } };

                for (int i = 0; i < 83; ++i)
                {
                    printf("%d %.4f ", i, area_figure(ptr[i]));
                    display_figure(ptr[i]);
                }
                
                printf("------------OCZEKIWANA TABLICA FIGUR-----------\n");
                
                for (int i = 0; i < 83; ++i)
                {
                    printf("%d %.4f ", i, area_figure(expected_figures + i));
                    display_figure(expected_figures  + i);
                }
                
                printf("------------\n");
                

                for (int i = 0; i < 83; ++i)
                {
                    test_error(ptr[i]->type == expected_figures[i].type, "Typ figury pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].type, ptr[i]->type);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (ptr[i]->type == TRIANGLE)
                    {
                        test_error(ptr[i]->triangle.p1.x == expected_figures[i].triangle.p1.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.x, ptr[i]->triangle.p1.x);
                        test_error(ptr[i]->triangle.p1.y == expected_figures[i].triangle.p1.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p1.y, ptr[i]->triangle.p1.y);
                        test_error(ptr[i]->triangle.p2.x == expected_figures[i].triangle.p2.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.x, ptr[i]->triangle.p2.x);
                        test_error(ptr[i]->triangle.p2.y == expected_figures[i].triangle.p2.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p2.y, ptr[i]->triangle.p2.y);
                        test_error(ptr[i]->triangle.p3.x == expected_figures[i].triangle.p3.x, "Współrzędna x punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.x, ptr[i]->triangle.p3.x);
                        test_error(ptr[i]->triangle.p3.y == expected_figures[i].triangle.p3.y, "Współrzędna y punktu 1 trójkąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].triangle.p3.y, ptr[i]->triangle.p3.y);
                    }            
                    else if (ptr[i]->type == RECTANGLE)
                    {
                        test_error(ptr[i]->rect.p.x == expected_figures[i].rect.p.x, "Współrzędna x prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.x, ptr[i]->rect.p.x);
                        test_error(ptr[i]->rect.p.y == expected_figures[i].rect.p.y, "Współrzędna y prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.p.y, ptr[i]->rect.p.y);
                        test_error(ptr[i]->rect.width == expected_figures[i].rect.width, "Szerokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.width, ptr[i]->rect.width);
                        test_error(ptr[i]->rect.height == expected_figures[i].rect.height, "Wysokość prostokąta pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].rect.height, ptr[i]->rect.height);
                    }
                    else if (ptr[i]->type == CIRCLE)
                    {
                        test_error(ptr[i]->circ.c.x == expected_figures[i].circ.c.x, "Współrzędna x okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.x, ptr[i]->circ.c.x);
                        test_error(ptr[i]->circ.c.y == expected_figures[i].circ.c.y, "Współrzędna y okręgu pod indeksem %d jest nieprawidłowa, powinno być %d, a jest %d", i, expected_figures[i].circ.c.y, ptr[i]->circ.c.y);
                        test_error(ptr[i]->circ.r == expected_figures[i].circ.r, "Promięć okręgu pod indeksem %d jest nieprawidłowy, powinno być %d, a jest %d", i, expected_figures[i].circ.r, ptr[i]->circ.r);
                    }
                    
                }


            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 57: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST57(void)
{
    // informacje o teście
    test_start(57, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct figure_t figures[] = { { .type = CIRCLE, .circ = { .c = { 10, 3 }, .r = -27.39669686977917 } }, { .type = RECTANGLE, .rect = { .p = { 5, 10 }, .width = 20, .height = 42 } }, { .type = TRIANGLE, .triangle = { .p1 = { 6, -6 }, .p2 = { -5, -5 }, .p3 = { 4, 6 } } } };
                struct figure_t *ptr[3];

                for (int i = 0; i < 3; ++i)
                    ptr[i] = &figures[i];

                printf("------------TABLICA FIGUR DO POSORTOWANIA-----------\n");

                for (int i = 0; i < 3; ++i)
                {
                    printf("%d %.4f ", i, area_figure(figures  + i));
                    display_figure(figures  + i);
                }

                int res = sort_by_area(ptr, 3);
                test_error(res == 1, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 1, res);


            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 58: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST58(void)
{
    // informacje o teście
    test_start(58, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct figure_t figures[] = { { .type = TRIANGLE, .triangle = { .p1 = { -3, -8 }, .p2 = { 2, 7 }, .p3 = { -8, 6 } } }, { .type = RECTANGLE, .rect = { .p = { 6, 7 }, .width = 38, .height = -16 } }, { .type = CIRCLE, .circ = { .c = { -8, -6 }, .r = 27.765513118905535 } } };
                struct figure_t *ptr[3];

                for (int i = 0; i < 3; ++i)
                    ptr[i] = &figures[i];

                printf("------------TABLICA FIGUR DO POSORTOWANIA-----------\n");

                for (int i = 0; i < 3; ++i)
                {
                    printf("%d %.4f ", i, area_figure(figures  + i));
                    display_figure(figures  + i);
                }

                int res = sort_by_area(ptr, 3);
                test_error(res == 1, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 1, res);


            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 59: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST59(void)
{
    // informacje o teście
    test_start(59, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct figure_t figures[] = { { .type = CIRCLE, .circ = { .c = { 10, -3 }, .r = 37.00596403507844 } }, { .type = RECTANGLE, .rect = { .p = { 0, -1 }, .width = -36, .height = 32 } }, { .type = TRIANGLE, .triangle = { .p1 = { 0, -9 }, .p2 = { -2, -2 }, .p3 = { 9, -2 } } } };
                struct figure_t *ptr[3];

                for (int i = 0; i < 3; ++i)
                    ptr[i] = &figures[i];

                printf("------------TABLICA FIGUR DO POSORTOWANIA-----------\n");

                for (int i = 0; i < 3; ++i)
                {
                    printf("%d %.4f ", i, area_figure(figures  + i));
                    display_figure(figures  + i);
                }

                int res = sort_by_area(ptr, 3);
                test_error(res == 1, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 1, res);


            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 60: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST60(void)
{
    // informacje o teście
    test_start(60, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct figure_t figures[] = { { .type = TRIANGLE, .triangle = { .p1 = { -1, 0 }, .p2 = { 7, 1 }, .p3 = { 7, 1 } } }, { .type = CIRCLE, .circ = { .c = { 5, -8 }, .r = -9.213865275647835 } }, { .type = RECTANGLE, .rect = { .p = { 0, 0 }, .width = 17, .height = 38 } } };
                struct figure_t *ptr[3];

                for (int i = 0; i < 3; ++i)
                    ptr[i] = &figures[i];

                printf("------------TABLICA FIGUR DO POSORTOWANIA-----------\n");

                for (int i = 0; i < 3; ++i)
                {
                    printf("%d %.4f ", i, area_figure(figures  + i));
                    display_figure(figures  + i);
                }

                int res = sort_by_area(ptr, 3);
                test_error(res == 1, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 1, res);


            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 61: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST61(void)
{
    // informacje o teście
    test_start(61, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct figure_t figures[] = { { .type = TRIANGLE, .triangle = { .p1 = { 6, -2 }, .p2 = { -5, 0 }, .p3 = { -5, 0 } } }, { .type = RECTANGLE, .rect = { .p = { 2, 1 }, .width = 20, .height = 44 } }, { .type = CIRCLE, .circ = { .c = { 6, -2 }, .r = 22.974156012524748 } } };
            struct figure_t *ptr[3];

            for (int i = 0; i < 3; ++i)
                ptr[i] = &figures[i];

            int res = sort_by_area(ptr, -3);
            test_error(res == 1, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 1, res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 62: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST62(void)
{
    // informacje o teście
    test_start(62, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct figure_t figures[] = { { .type = TRIANGLE, .triangle = { .p1 = { 6, -2 }, .p2 = { -5, 0 }, .p3 = { -5, 0 } } }, { .type = RECTANGLE, .rect = { .p = { 2, 1 }, .width = 20, .height = 44 } }, { .type = CIRCLE, .circ = { .c = { 6, -2 }, .r = 22.974156012524748 } } };
            struct figure_t *ptr[3];

            for (int i = 0; i < 3; ++i)
                ptr[i] = &figures[i];

            int res = sort_by_area(ptr, 0);
            test_error(res == 1, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 1, res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 63: Sprawdzanie poprawności działania funkcji sort_by_area
//
void UTEST63(void)
{
    // informacje o teście
    test_start(63, "Sprawdzanie poprawności działania funkcji sort_by_area", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int res = sort_by_area(NULL, 3);
            test_error(res == 1, "Funkcja sort_by_area powinna zwrócić %d, a zwróciła %d", 1, res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}




enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST2, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST3, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST4, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST5, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST6, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST7, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST8, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST9, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST10, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST11, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST12, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST13, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST14, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST15, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST16, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST17, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST18, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST19, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST20, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST21, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST22, // Sprawdzanie poprawności działania funkcji area_triangle
            UTEST23, // Sprawdzanie poprawności działania funkcji area_rectangle
            UTEST24, // Sprawdzanie poprawności działania funkcji area_rectangle
            UTEST25, // Sprawdzanie poprawności działania funkcji area_rectangle
            UTEST26, // Sprawdzanie poprawności działania funkcji area_rectangle
            UTEST27, // Sprawdzanie poprawności działania funkcji area_rectangle
            UTEST28, // Sprawdzanie poprawności działania funkcji area_rectangle
            UTEST29, // Sprawdzanie poprawności działania funkcji area_rectangle
            UTEST30, // Sprawdzanie poprawności działania funkcji area_circle
            UTEST31, // Sprawdzanie poprawności działania funkcji area_circle
            UTEST32, // Sprawdzanie poprawności działania funkcji area_circle
            UTEST33, // Sprawdzanie poprawności działania funkcji area_circle
            UTEST34, // Sprawdzanie poprawności działania funkcji area_circle
            UTEST35, // Sprawdzanie poprawności działania funkcji area_circle
            UTEST36, // Sprawdzanie poprawności działania funkcji area_circle
            UTEST37, // Sprawdzanie poprawności działania funkcji area_circle
            UTEST38, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST39, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST40, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST41, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST42, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST43, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST44, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST45, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST46, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST47, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST48, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST49, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST50, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST51, // Sprawdzanie poprawności działania funkcji area_figure
            UTEST52, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST53, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST54, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST55, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST56, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST57, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST58, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST59, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST60, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST61, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST62, // Sprawdzanie poprawności działania funkcji sort_by_area
            UTEST63, // Sprawdzanie poprawności działania funkcji sort_by_area
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(63); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(0); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}