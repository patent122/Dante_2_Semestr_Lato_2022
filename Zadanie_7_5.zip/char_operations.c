#include "char_operations.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"
char* letter_modifier(const char* litera, func funkcja)
{
    if (litera == NULL || funkcja == NULL) return NULL;

    int lenghtText = (int)strlen(litera);

    char* newText = malloc((lenghtText + 1) * sizeof(char));
    if (newText == NULL) return NULL;

    strcpy(newText, litera);

    for (int i = 0; i < lenghtText; ++i)
    {
        *(newText + i) = funkcja(*(newText + i));
    }

    return newText;
}
char lower_to_upper(char litera)
{
    if (litera >= 97 && litera <= 122)
    {
        litera -= 32;
    }

    return litera;
}
char upper_to_lower(char litera)
{
    if (litera >= 65 && litera <= 90)
    {
        litera += 32;
    }

    return litera;
}
char space_to_dash(char litera)
{
    if (litera == ' ')
    {
        return '_';
    }

    return litera;
}
char reverse_letter(char litera)
{
    if (litera >= 97 && litera <= 122)
    {
        return (char)(122 - (litera - 97));
    }

    if (litera >= 65 && litera <= 90)
    {
        return (char)(90 - (litera - 65));
    }

    return litera;
}
