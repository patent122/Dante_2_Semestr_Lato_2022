#include <stdio.h>
#include <stdlib.h>
#include "char_operations.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
    char(**funkcje)(char);
    funkcje = malloc(4 * sizeof(char (*)(char)));
    if (funkcje == NULL)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }

    *(funkcje + 0) = lower_to_upper;
    *(funkcje + 1) = upper_to_lower;
    *(funkcje + 2) = space_to_dash;
    *(funkcje + 3) = reverse_letter;

    int opcja;
    char* tekst = malloc(1001 * sizeof(char));
    if (tekst == NULL)
    {
        printf("Failed to allocate memory\n");
        free(funkcje);
        return 8;
    }

    printf("Podaj tekst: ");
    scanf("%1000[^\n]s", tekst);

    
    while (getchar() != '\n') {}

    printf("Podaj opcje do wyknania: ");
    if (scanf("%d", &opcja) != 1)
    {
        printf("Incorrect input\n");
        free(tekst);
        free(funkcje);
        return 1;
    }
    if (opcja < 0 || opcja > 3)
    {
        printf("Incorrect input data\n");
        free(tekst);
        free(funkcje);
        return 2;
    }

    char* nowy;

    switch (opcja)
    {
    case 0:
        nowy = letter_modifier(tekst, lower_to_upper);
        break;
    case 1:
        nowy = letter_modifier(tekst, upper_to_lower);
        break;
    case 2:
        nowy = letter_modifier(tekst, space_to_dash);
        break;
    case 3:
        nowy = letter_modifier(tekst, reverse_letter);
        break;
    default:
        break;
    }

    if (nowy == NULL)
    {
        printf("Failed to allocate memory\n");
        free(tekst);
        free(funkcje);
        return 8;
    }

    printf("%s", nowy);


    free(tekst);
    free(nowy);
    free(funkcje);
    return 0;
}

