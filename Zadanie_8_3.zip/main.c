#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "data_type.h"
#include "tested_declarations.h"
#include "rdebug.h"

#define DZIALAJ(RODZAJ, FORMAT_WEJSCIA, FORMAT_WYJSCIA) {\
            RODZAJ **tablica = malloc(ilosc_tablic * sizeof(RODZAJ *));\
if (tablica == NULL) {\
    printf("Failed to allocate memory");\
    return 8;\
}\
for (int i = 0; i < ilosc_tablic; i++) {\
    printf("Podaj liczbe elementow: ");\
    int n;\
    if (scanf("%d", &n) != 1) {\
        printf("Incorrect input");\
        for (int j = 0; j <= i; j++) {\
            free(*(tablica + j));\
        }\
        free(tablica);\
        return 1;\
    }                                             \
    if(n<1){                                      \
        printf("Incorrect input data");\
        for (int j = 0; j <= i; j++) {\
            free(*(tablica + j));\
        }\
        free(tablica);\
        return 2;\
    }\
    *(tablica + i) = malloc((1 + n) * sizeof(RODZAJ));\
    if (*(tablica + i) == NULL) {\
        printf("Failed to allocate memory");\
        for (int j = 0; j <= i; j++) {\
            free(*(tablica + j));\
        }\
        free(tablica);\
        return 8;\
    }\
\
    printf("Podaj liczby :");\
    for (int j = 0; j < n; j++) {\
    if (scanf(FORMAT_WEJSCIA, (*(tablica + i) + j)) != 1) {\
            printf("Incorrect input");\
            for (j = 0; j <= i; j++) {\
                free(*(tablica + j));\
            }\
            free(tablica);\
            return 1;\
        }\
    }\
    *(*(tablica + i) + n) = -1;                       \
}                                                 \
RODZAJ *aa = connect(type, ilosc_tablic, *(tablica + 0), *(tablica + 1), *(tablica + 2), *(tablica + 3));\
free_array((void **) tablica, ilosc_tablic);\
if (aa == NULL) {\
    printf("Failed to allocate memory");\
    return 8;\
}\
for (int i = 0;; i++) {\
    RODZAJ n = *(aa + i);\
    if (n == -1) {\
        break;\
    }\
    printf(FORMAT_WYJSCIA, n);\
}\
free(aa);\
break;\
}

#define POLACZ(RODZAJ) void *connect_##RODZAJ(int ile, va_list list){ \
    RODZAJ *array=malloc(1*sizeof(RODZAJ));                              \
    if(array==NULL){                                                 \
        return NULL;                                                     \
    }                                    \
    *array=-1;                                                       \
    int dlugosc=0;\
    for (int i=0;i<ile;i++){                                       \
        RODZAJ *nastepny= va_arg(list,RODZAJ*);                              \
        for(int i=0;*(nastepny+i)!=-1;i++){                              \
            RODZAJ *new_array = realloc(array,sizeof(*array)*(dlugosc+2));                  \
            if(new_array==NULL){                                     \
                free(array);                                         \
                return NULL;\
            }                                                        \
            array=new_array;                                         \
            *(array+dlugosc)=*(nastepny+i);                                  \
            dlugosc++;                                                   \
            *(array+dlugosc)=-1;                                         \
        }\
    }                                                                     \
    return array;                                                                     \
}

POLACZ(short)

POLACZ(int)

POLACZ(float)

POLACZ(double)

POLACZ(long)

void* connect(data_type_t type, int ile, ...) {
    if (ile < 1 || type > data_type_long || type < data_type_short)
        return NULL;
    va_list list;
    va_start(list, ile);
    void* kod_wyjscia;
    switch (type) {
    case data_type_short:
        kod_wyjscia = connect_short(ile, list);
        break;
    case data_type_int:
        kod_wyjscia = connect_int(ile, list);
        break;
    case data_type_float:
        kod_wyjscia = connect_float(ile, list);
        break;
    case data_type_double:
        kod_wyjscia = connect_double(ile, list);
        break;
    case data_type_long:
        kod_wyjscia = connect_long(ile, list);
        break;
    }
    va_end(list);
    return kod_wyjscia;
}

void free_array(void** wskaznik, int rozmiar) {
    for (int i = 0; i < rozmiar; i++)
        free(*(wskaznik + i));

    free(wskaznik);
}

int main() {
    data_type_t type;
    printf("Podaj typ danych do wprowadzenia: ");
    if (scanf("%u", &type) != 1) {
        printf("Incorrect input");
        return 1;
    }
    if (type > data_type_long || type < data_type_short) {
        printf("Incorrect input data");
        return 2;
    }
    printf("\nPodaj liczbe tablic do wprowadzenia: ");
    int ilosc_tablic = 0;
    if (scanf("%d", &ilosc_tablic) != 1) {
        printf("Incorrect Input");
        return 1;
    }
    if (ilosc_tablic < 2 || ilosc_tablic > 4) {
        printf("Incorrect input data");
        return 2;
    }

    switch (type) {
    case data_type_short: DZIALAJ(short, "%hd", "%hd ")
    case data_type_int: DZIALAJ(int, "%d", "%d ")
    case data_type_long: DZIALAJ(long, "%ld", "%ld ")
    case data_type_float: DZIALAJ(float, "%f", "%f ")
    case data_type_double: DZIALAJ(double, "%lf", "%lf ")

    }
    return 0;
}
