/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Łączenie tablic
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 11:40:07.289697
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji connect dla tablic typu float (limit sterty ustawiono na 92 bajtów)
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji connect dla tablic typu float (limit sterty ustawiono na 92 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(92);
    
    //
    // -----------
    //
    
            
                    float expected_result[] = {-14.875120, -10.520338, 16.652489, 5.541064, 8.739058, -5.947552, -16.937171, 5.608364, -11.413125, 3.651992, -1.508986, 5.168013, 3.982659, -6.370056, 9.882506, 8.011846, 5.673643, -5.183129, 13.318961, -9.841934, 5.760726, -16.024017, -0.206530, 6.845306, 11.608124, -14.341667, 18.491204, -3.715620, 12.610630, -11.813204, 9.015713, 5.887146, 13.658571, -10.131035, 9.081358, 4.468979, 2.777686, 2.379311, -16.499856, -1.000000};
            
                    float* result = connect(data_type_float, 9, (float []){-14.875120, -10.520338, 16.652489, 5.541064, -1.000000}, (float []){8.739058, -5.947552, -16.937171, 5.608364, -11.413125, -1.000000}, (float []){3.651992, -1.508986, 5.168013, 3.982659, -1.000000}, (float []){-6.370056, 9.882506, 8.011846, -1.000000}, (float []){5.673643, -5.183129, 13.318961, -1.000000}, (float []){-9.841934, 5.760726, -16.024017, -0.206530, 6.845306, -1.000000}, (float []){11.608124, -14.341667, 18.491204, -3.715620, 12.610630, -1.000000}, (float []){-11.813204, 9.015713, 5.887146, 13.658571, -10.131035, -1.000000}, (float []){9.081358, 4.468979, 2.777686, 2.379311, -16.499856, -1.000000});
            
                    test_error(result == NULL, "Funkcja connect() powinna zwrócić NULL");
            
                    onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    if (result != NULL)
                    {
                        int ok = 1;
                
                        for (int i = 0; i < 40; ++i) 
                            if (*(result + i) != *(expected_result + i))
                                ok = 0;
                
                        if (!ok)
                        {
                            printf("Oczekiwany wynik:\n");
                
                            for (int i = 0; i < 40; ++i) 
                                printf("%f", *(expected_result + i));
                
                            printf("Otrzymany wynik:\n");
                            for (int i = 0; i < 40; ++i) 
                                printf("%f", *(result + i));
                        }
                
                        test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");
                
                        free(result);
                    }
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
                 
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji connect dla tablic typu float (limit sterty ustawiono na 160 bajtów)
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji connect dla tablic typu float (limit sterty ustawiono na 160 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(160);
    
    //
    // -----------
    //
    
            
                    float expected_result[] = {-14.875120, -10.520338, 16.652489, 5.541064, 8.739058, -5.947552, -16.937171, 5.608364, -11.413125, 3.651992, -1.508986, 5.168013, 3.982659, -6.370056, 9.882506, 8.011846, 5.673643, -5.183129, 13.318961, -9.841934, 5.760726, -16.024017, -0.206530, 6.845306, 11.608124, -14.341667, 18.491204, -3.715620, 12.610630, -11.813204, 9.015713, 5.887146, 13.658571, -10.131035, 9.081358, 4.468979, 2.777686, 2.379311, -16.499856, -1.000000};
            
                    float* result = connect(data_type_float, 9, (float []){-14.875120, -10.520338, 16.652489, 5.541064, -1.000000}, (float []){8.739058, -5.947552, -16.937171, 5.608364, -11.413125, -1.000000}, (float []){3.651992, -1.508986, 5.168013, 3.982659, -1.000000}, (float []){-6.370056, 9.882506, 8.011846, -1.000000}, (float []){5.673643, -5.183129, 13.318961, -1.000000}, (float []){-9.841934, 5.760726, -16.024017, -0.206530, 6.845306, -1.000000}, (float []){11.608124, -14.341667, 18.491204, -3.715620, 12.610630, -1.000000}, (float []){-11.813204, 9.015713, 5.887146, 13.658571, -10.131035, -1.000000}, (float []){9.081358, 4.468979, 2.777686, 2.379311, -16.499856, -1.000000});
            
                    test_error(result != NULL, "Funkcja connect() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");
            
                    onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    if (result != NULL)
                    {
                        int ok = 1;
                
                        for (int i = 0; i < 40; ++i) 
                            if (*(result + i) != *(expected_result + i))
                                ok = 0;
                
                        if (!ok)
                        {
                            printf("Oczekiwany wynik:\n");
                
                            for (int i = 0; i < 40; ++i) 
                                printf("%f", *(expected_result + i));
                
                            printf("Otrzymany wynik:\n");
                            for (int i = 0; i < 40; ++i) 
                                printf("%f", *(result + i));
                        }
                
                        test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");
                
                        free(result);
                    }
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
                 
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji connect dla tablic typu double (limit sterty ustawiono na 63 bajtów)
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji connect dla tablic typu double (limit sterty ustawiono na 63 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(63);
    
    //
    // -----------
    //
    
            
                    double expected_result[] = {1.590065, -6.729470, 19.536226, -2.304822, 15.960776, 19.130311, 12.374667, -18.522383, -15.154778, 17.348940, 2.354352, 11.193533, -14.266227, 14.418926, -9.653746, 1.400628, 19.683014, 12.868624, 8.137639, 14.504478, 17.342117, 18.099137, -9.068854, -3.506391, 9.076774, 8.654778, -1.000000};
            
                    double* result = connect(data_type_double, 6, (double []){1.590065, -6.729470, 19.536226, -2.304822, -1.000000}, (double []){15.960776, 19.130311, 12.374667, -1.000000}, (double []){-18.522383, -15.154778, 17.348940, 2.354352, 11.193533, -1.000000}, (double []){-14.266227, 14.418926, -9.653746, 1.400628, -1.000000}, (double []){19.683014, 12.868624, 8.137639, 14.504478, 17.342117, -1.000000}, (double []){18.099137, -9.068854, -3.506391, 9.076774, 8.654778, -1.000000});
            
                    test_error(result == NULL, "Funkcja connect() powinna zwrócić NULL");
            
                    onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    if (result != NULL)
                    {
                        int ok = 1;
                
                        for (int i = 0; i < 27; ++i) 
                            if (*(result + i) != *(expected_result + i))
                                ok = 0;
                
                        if (!ok)
                        {
                            printf("Oczekiwany wynik:\n");
                
                            for (int i = 0; i < 27; ++i) 
                                printf("%lf", *(expected_result + i));
                
                            printf("Otrzymany wynik:\n");
                            for (int i = 0; i < 27; ++i) 
                                printf("%lf", *(result + i));
                        }
                
                        test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");
                
                        free(result);
                    }
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
                 
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji connect dla tablic typu double (limit sterty ustawiono na 216 bajtów)
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji connect dla tablic typu double (limit sterty ustawiono na 216 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(216);
    
    //
    // -----------
    //
    
            
                    double expected_result[] = {1.590065, -6.729470, 19.536226, -2.304822, 15.960776, 19.130311, 12.374667, -18.522383, -15.154778, 17.348940, 2.354352, 11.193533, -14.266227, 14.418926, -9.653746, 1.400628, 19.683014, 12.868624, 8.137639, 14.504478, 17.342117, 18.099137, -9.068854, -3.506391, 9.076774, 8.654778, -1.000000};
            
                    double* result = connect(data_type_double, 6, (double []){1.590065, -6.729470, 19.536226, -2.304822, -1.000000}, (double []){15.960776, 19.130311, 12.374667, -1.000000}, (double []){-18.522383, -15.154778, 17.348940, 2.354352, 11.193533, -1.000000}, (double []){-14.266227, 14.418926, -9.653746, 1.400628, -1.000000}, (double []){19.683014, 12.868624, 8.137639, 14.504478, 17.342117, -1.000000}, (double []){18.099137, -9.068854, -3.506391, 9.076774, 8.654778, -1.000000});
            
                    test_error(result != NULL, "Funkcja connect() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");
            
                    onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
                    if (result != NULL)
                    {
                        int ok = 1;
                
                        for (int i = 0; i < 27; ++i) 
                            if (*(result + i) != *(expected_result + i))
                                ok = 0;
                
                        if (!ok)
                        {
                            printf("Oczekiwany wynik:\n");
                
                            for (int i = 0; i < 27; ++i) 
                                printf("%lf", *(expected_result + i));
                
                            printf("Otrzymany wynik:\n");
                            for (int i = 0; i < 27; ++i) 
                                printf("%lf", *(result + i));
                        }
                
                        test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");
                
                        free(result);
                    }
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
                 
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji connect dla tablic typu short (limit sterty ustawiono na 28 bajtów)
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji connect dla tablic typu short (limit sterty ustawiono na 28 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(28);
    
    //
    // -----------
    //
    

                     short expected_result[] = {0, 0, -19, 0, 15, -4, -18, -10, 10, -20, 8, 20, 19, 6, 20, -5, 16, 3, -10, 18, 9, 5, 5, -16, -1};

                     short* result = connect(data_type_short, 6, (short []){0, 0, -19, -1}, (short []){0, 15, -4, -18, -1}, (short []){-10, 10, -20, 8, 20, -1}, (short []){19, 6, 20, -5, -1}, (short []){16, 3, -10, 18, 9, -1}, (short []){5, 5, -16, -1});

                     test_error(result == NULL, "Funkcja connect() powinna zwrócić NULL");

                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                     if (result != NULL)
                     {
                         int ok = 1;

                         for (int i = 0; i < 25; ++i) 
                             if (*(result + i) != *(expected_result + i))
                                 ok = 0;

                         if (!ok)
                         {
                             printf("Oczekiwany wynik:\n");

                             for (int i = 0; i < 25; ++i) 
                                 printf("%hd", *(expected_result + i));

                             printf("Otrzymany wynik:\n");
                             for (int i = 0; i < 25; ++i) 
                                 printf("%hd", *(result + i));
                         }

                         test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");

                         free(result);
                     }
                     test_no_heap_leakage();
                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                  
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji connect dla tablic typu short (limit sterty ustawiono na 50 bajtów)
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji connect dla tablic typu short (limit sterty ustawiono na 50 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(50);
    
    //
    // -----------
    //
    

                     short expected_result[] = {0, 0, -19, 0, 15, -4, -18, -10, 10, -20, 8, 20, 19, 6, 20, -5, 16, 3, -10, 18, 9, 5, 5, -16, -1};

                     short* result = connect(data_type_short, 6, (short []){0, 0, -19, -1}, (short []){0, 15, -4, -18, -1}, (short []){-10, 10, -20, 8, 20, -1}, (short []){19, 6, 20, -5, -1}, (short []){16, 3, -10, 18, 9, -1}, (short []){5, 5, -16, -1});

                     test_error(result != NULL, "Funkcja connect() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                     if (result != NULL)
                     {
                         int ok = 1;

                         for (int i = 0; i < 25; ++i) 
                             if (*(result + i) != *(expected_result + i))
                                 ok = 0;

                         if (!ok)
                         {
                             printf("Oczekiwany wynik:\n");

                             for (int i = 0; i < 25; ++i) 
                                 printf("%hd", *(expected_result + i));

                             printf("Otrzymany wynik:\n");
                             for (int i = 0; i < 25; ++i) 
                                 printf("%hd", *(result + i));
                         }

                         test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");

                         free(result);
                     }
                     test_no_heap_leakage();
                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                  
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji connect dla tablic typu int (limit sterty ustawiono na 0 bajtów)
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji connect dla tablic typu int (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                     int expected_result[] = {20, 17, -2, 8, -14, -8, 7, -7, -8, 19, 5, 17, -17, 1, -12, -20, 3, -10, 4, 15, -4, 11, 3, -20, -8, -20, -13, -1};

                     int* result = connect(data_type_int, 7, (int []){20, 17, -2, -1}, (int []){8, -14, -8, 7, -1}, (int []){-7, -8, 19, 5, 17, -1}, (int []){-17, 1, -12, -20, 3, -1}, (int []){-10, 4, 15, -1}, (int []){-4, 11, 3, -1}, (int []){-20, -8, -20, -13, -1});

                     test_error(result == NULL, "Funkcja connect() powinna zwrócić NULL");

                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                     if (result != NULL)
                     {
                         int ok = 1;

                         for (int i = 0; i < 28; ++i) 
                             if (*(result + i) != *(expected_result + i))
                                 ok = 0;

                         if (!ok)
                         {
                             printf("Oczekiwany wynik:\n");

                             for (int i = 0; i < 28; ++i) 
                                 printf("%d", *(expected_result + i));

                             printf("Otrzymany wynik:\n");
                             for (int i = 0; i < 28; ++i) 
                                 printf("%d", *(result + i));
                         }

                         test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");

                         free(result);
                     }
                     test_no_heap_leakage();
                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                  
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji connect dla tablic typu int (limit sterty ustawiono na 112 bajtów)
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji connect dla tablic typu int (limit sterty ustawiono na 112 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(112);
    
    //
    // -----------
    //
    

                     int expected_result[] = {20, 17, -2, 8, -14, -8, 7, -7, -8, 19, 5, 17, -17, 1, -12, -20, 3, -10, 4, 15, -4, 11, 3, -20, -8, -20, -13, -1};

                     int* result = connect(data_type_int, 7, (int []){20, 17, -2, -1}, (int []){8, -14, -8, 7, -1}, (int []){-7, -8, 19, 5, 17, -1}, (int []){-17, 1, -12, -20, 3, -1}, (int []){-10, 4, 15, -1}, (int []){-4, 11, 3, -1}, (int []){-20, -8, -20, -13, -1});

                     test_error(result != NULL, "Funkcja connect() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                     if (result != NULL)
                     {
                         int ok = 1;

                         for (int i = 0; i < 28; ++i) 
                             if (*(result + i) != *(expected_result + i))
                                 ok = 0;

                         if (!ok)
                         {
                             printf("Oczekiwany wynik:\n");

                             for (int i = 0; i < 28; ++i) 
                                 printf("%d", *(expected_result + i));

                             printf("Otrzymany wynik:\n");
                             for (int i = 0; i < 28; ++i) 
                                 printf("%d", *(result + i));
                         }

                         test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");

                         free(result);
                     }
                     test_no_heap_leakage();
                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                  
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji connect dla tablic typu long (limit sterty ustawiono na 103 bajtów)
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji connect dla tablic typu long (limit sterty ustawiono na 103 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(103);
    
    //
    // -----------
    //
    

                     long expected_result[] = {-3, -18, 15, 15, -14, -2, -6, 0, -16, 11, 20, 6, 11, -8, -14, -11, 7, 17, -16, -7, -20, 2, -9, -19, -8, 8, -17, -1};

                     long* result = connect(data_type_long, 7, (long []){-3, -18, 15, -1}, (long []){15, -14, -2, -1}, (long []){-6, 0, -16, 11, 20, -1}, (long []){6, 11, -8, -1}, (long []){-14, -11, 7, 17, -16, -1}, (long []){-7, -20, 2, -9, -19, -1}, (long []){-8, 8, -17, -1});

                     test_error(result == NULL, "Funkcja connect() powinna zwrócić NULL");

                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                     if (result != NULL)
                     {
                         int ok = 1;

                         for (int i = 0; i < 28; ++i) 
                             if (*(result + i) != *(expected_result + i))
                                 ok = 0;

                         if (!ok)
                         {
                             printf("Oczekiwany wynik:\n");

                             for (int i = 0; i < 28; ++i) 
                                 printf("%ld", *(expected_result + i));

                             printf("Otrzymany wynik:\n");
                             for (int i = 0; i < 28; ++i) 
                                 printf("%ld", *(result + i));
                         }

                         test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");

                         free(result);
                     }
                     test_no_heap_leakage();
                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                  
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji connect dla tablic typu long (limit sterty ustawiono na 224 bajtów)
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji connect dla tablic typu long (limit sterty ustawiono na 224 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(224);
    
    //
    // -----------
    //
    

                     long expected_result[] = {-3, -18, 15, 15, -14, -2, -6, 0, -16, 11, 20, 6, 11, -8, -14, -11, 7, 17, -16, -7, -20, 2, -9, -19, -8, 8, -17, -1};

                     long* result = connect(data_type_long, 7, (long []){-3, -18, 15, -1}, (long []){15, -14, -2, -1}, (long []){-6, 0, -16, 11, 20, -1}, (long []){6, 11, -8, -1}, (long []){-14, -11, 7, 17, -16, -1}, (long []){-7, -20, 2, -9, -19, -1}, (long []){-8, 8, -17, -1});

                     test_error(result != NULL, "Funkcja connect() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                     if (result != NULL)
                     {
                         int ok = 1;

                         for (int i = 0; i < 28; ++i) 
                             if (*(result + i) != *(expected_result + i))
                                 ok = 0;

                         if (!ok)
                         {
                             printf("Oczekiwany wynik:\n");

                             for (int i = 0; i < 28; ++i) 
                                 printf("%ld", *(expected_result + i));

                             printf("Otrzymany wynik:\n");
                             for (int i = 0; i < 28; ++i) 
                                 printf("%ld", *(result + i));
                         }

                         test_error(ok == 1, "Wartość zwrócona przez funkcję connect() jest nieprawidłowa");

                         free(result);
                     }
                     test_no_heap_leakage();
                     onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                  
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji connect
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji connect", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                

                void *res = connect(data_type_long, -7, (long []){-3, -18, 15, -1}, (long []){15, -14, -2, -1}, (long []){-6, 0, -16, 11, 20, -1}, (long []){6, 11, -8, -1}, (long []){-14, -11, 7, 17, -16, -1}, (long []){-7, -20, 2, -9, -19, -1}, (long []){-8, 8, -17, -1});
                test_error(res == NULL, "Funkcja connect() powinna zwrócić wartość NULL");
                
                int type = abs(data_type_short) + abs(data_type_int) + abs(data_type_float) + abs(data_type_double) + abs(data_type_long);            

                res = connect(type, 7, (long []){-3, -18, 15, -1}, (long []){15, -14, -2, -1}, (long []){-6, 0, -16, 11, 20, -1}, (long []){6, 11, -8, -1}, (long []){-14, -11, 7, 17, -16, -1}, (long []){-7, -20, 2, -9, -19, -1}, (long []){-8, 8, -17, -1});
                test_error(res == NULL, "Funkcja connect() powinna zwrócić wartość NULL");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
            printf("***START***\n");
            int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
            printf("\n***END***\n");
            test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
//
void MTEST5(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(5, "Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
//
void MTEST6(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(6, "Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Reakcja na brak pamięci (limit sterty ustawiono na 52 bajtów)
//
void MTEST7(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(7, "Reakcja na brak pamięci (limit sterty ustawiono na 52 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(52);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)
//
void MTEST8(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(8, "Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(72);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)
//
void MTEST9(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(9, "Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(72);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)
//
void MTEST10(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(10, "Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(112);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)
//
void MTEST11(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(11, "Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(112);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)
//
void MTEST12(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(12, "Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(72);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)
//
void MTEST13(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(13, "Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(112);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)
//
void MTEST14(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(14, "Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(112);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Reakcja na brak pamięci (limit sterty ustawiono na 192 bajtów)
//
void MTEST15(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(15, "Reakcja na brak pamięci (limit sterty ustawiono na 192 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(192);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Reakcja na brak pamięci (limit sterty ustawiono na 192 bajtów)
//
void MTEST16(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(16, "Reakcja na brak pamięci (limit sterty ustawiono na 192 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(192);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji connect dla tablic typu float (limit sterty ustawiono na 92 bajtów)
            UTEST2, // Sprawdzanie poprawności działania funkcji connect dla tablic typu float (limit sterty ustawiono na 160 bajtów)
            UTEST3, // Sprawdzanie poprawności działania funkcji connect dla tablic typu double (limit sterty ustawiono na 63 bajtów)
            UTEST4, // Sprawdzanie poprawności działania funkcji connect dla tablic typu double (limit sterty ustawiono na 216 bajtów)
            UTEST5, // Sprawdzanie poprawności działania funkcji connect dla tablic typu short (limit sterty ustawiono na 28 bajtów)
            UTEST6, // Sprawdzanie poprawności działania funkcji connect dla tablic typu short (limit sterty ustawiono na 50 bajtów)
            UTEST7, // Sprawdzanie poprawności działania funkcji connect dla tablic typu int (limit sterty ustawiono na 0 bajtów)
            UTEST8, // Sprawdzanie poprawności działania funkcji connect dla tablic typu int (limit sterty ustawiono na 112 bajtów)
            UTEST9, // Sprawdzanie poprawności działania funkcji connect dla tablic typu long (limit sterty ustawiono na 103 bajtów)
            UTEST10, // Sprawdzanie poprawności działania funkcji connect dla tablic typu long (limit sterty ustawiono na 224 bajtów)
            UTEST11, // Sprawdzanie poprawności działania funkcji connect
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(11); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)
            MTEST2, // Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
            MTEST3, // Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
            MTEST4, // Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
            MTEST5, // Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
            MTEST6, // Reakcja na brak pamięci (limit sterty ustawiono na 32 bajtów)
            MTEST7, // Reakcja na brak pamięci (limit sterty ustawiono na 52 bajtów)
            MTEST8, // Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)
            MTEST9, // Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)
            MTEST10, // Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)
            MTEST11, // Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)
            MTEST12, // Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)
            MTEST13, // Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)
            MTEST14, // Reakcja na brak pamięci (limit sterty ustawiono na 112 bajtów)
            MTEST15, // Reakcja na brak pamięci (limit sterty ustawiono na 192 bajtów)
            MTEST16, // Reakcja na brak pamięci (limit sterty ustawiono na 192 bajtów)
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(16); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}