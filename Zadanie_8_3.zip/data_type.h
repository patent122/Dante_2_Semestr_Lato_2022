#pragma once
typedef enum data_type_t 
{
    data_type_short,
    data_type_int,
    data_type_float,
    data_type_double,
    data_type_long
} data_type_t;
