﻿#include <stdio.h>
#include <stdint.h>
#include "tested_declarations.h"
#include "rdebug.h"
#include "tested_declarations.h"
#include "rdebug.h"

union uint32bits {
    struct {
        uint8_t b0: 1;
        uint8_t b1: 1;
        uint8_t b2: 1;
        uint8_t b3: 1;
        uint8_t b4: 1;
        uint8_t b5: 1;
        uint8_t b6: 1;
        uint8_t b7: 1;
        uint8_t b8: 1;
        uint8_t b9: 1;
        uint8_t b10: 1;
        uint8_t b11: 1;
        uint8_t b12: 1;
        uint8_t b13: 1;
        uint8_t b14: 1;
        uint8_t b15: 1;
        uint8_t b16: 1;
        uint8_t b17: 1;
        uint8_t b18: 1;
        uint8_t b19: 1;
        uint8_t b20: 1;
        uint8_t b21: 1;
        uint8_t b22: 1;
        uint8_t b23: 1;
        uint8_t b24: 1;
        uint8_t b25: 1;
        uint8_t b26: 1;
        uint8_t b27: 1;
        uint8_t b28: 1;
        uint8_t b29: 1;
        uint8_t b30: 1;
        uint8_t b31: 1;
    };
    uint32_t all_bits;
};

int toggle_bit(uint32_t* wartosc, int b) {
    if(wartosc == NULL || b < 0 || b > 31) {
        return -1;
    }
    union uint32bits bits;
    bits.all_bits = *wartosc;
    switch (b) {
        case 0: { bits.b0 = !bits.b0; break; }
        case 1: { bits.b1 = !bits.b1; break; }
        case 2: { bits.b2 = !bits.b2; break; }
        case 3: { bits.b3 = !bits.b3; break; }
        case 4: { bits.b4 = !bits.b4; break; }
        case 5: { bits.b5 = !bits.b5; break; }
        case 6: { bits.b6 = !bits.b6; break; }
        case 7: { bits.b7 = !bits.b7; break; }
        case 8: { bits.b8 = !bits.b8; break; }
        case 9: { bits.b9 = !bits.b9; break; }
        case 10: { bits.b10 = !bits.b10; break; }
        case 11: { bits.b11 = !bits.b11; break; }
        case 12: { bits.b12 = !bits.b12; break; }
        case 13: { bits.b13 = !bits.b13; break; }
        case 14: { bits.b14 = !bits.b14; break; }
        case 15: { bits.b15 = !bits.b15; break; }
        case 16: { bits.b16 = !bits.b16; break; }
        case 17: { bits.b17 = !bits.b17; break; }
        case 18: { bits.b18 = !bits.b18; break; }
        case 19: { bits.b19 = !bits.b19; break; }
        case 20: { bits.b20 = !bits.b20; break; }
        case 21: { bits.b21 = !bits.b21; break; }
        case 22: { bits.b22 = !bits.b22; break; }
        case 23: { bits.b23 = !bits.b23; break; }
        case 24: { bits.b24 = !bits.b24; break; }
        case 25: { bits.b25 = !bits.b25; break; }
        case 26: { bits.b26 = !bits.b26; break; }
        case 27: { bits.b27 = !bits.b27; break; }
        case 28: { bits.b28 = !bits.b28; break; }
        case 29: { bits.b29 = !bits.b29; break; }
        case 30: { bits.b30 = !bits.b30; break; }
        case 31: { bits.b31 = !bits.b31; break; }
        default: break;
    }
    *wartosc = bits.all_bits;

    return 0;
}

int set_bit(uint32_t* pwartosc, int b) {
    if(pwartosc == NULL || b < 0 || b > 31) {
        return -1;
    }
    union uint32bits bits;
    bits.all_bits = *pwartosc;
    switch (b) {
        case 0: { bits.b0 = 1; break; }
        case 1: { bits.b1 = 1; break; }
        case 2: { bits.b2 = 1; break; }
        case 3: { bits.b3 = 1; break; }
        case 4: { bits.b4 = 1; break; }
        case 5: { bits.b5 = 1; break; }
        case 6: { bits.b6 = 1; break; }
        case 7: { bits.b7 = 1; break; }
        case 8: { bits.b8 = 1; break; }
        case 9: { bits.b9 = 1; break; }
        case 10: { bits.b10 = 1; break; }
        case 11: { bits.b11 = 1; break; }
        case 12: { bits.b12 = 1; break; }
        case 13: { bits.b13 = 1; break; }
        case 14: { bits.b14 = 1; break; }
        case 15: { bits.b15 = 1; break; }
        case 16: { bits.b16 = 1; break; }
        case 17: { bits.b17 = 1; break; }
        case 18: { bits.b18 = 1; break; }
        case 19: { bits.b19 = 1; break; }
        case 20: { bits.b20 = 1; break; }
        case 21: { bits.b21 = 1; break; }
        case 22: { bits.b22 = 1; break; }
        case 23: { bits.b23 = 1; break; }
        case 24: { bits.b24 = 1; break; }
        case 25: { bits.b25 = 1; break; }
        case 26: { bits.b26 = 1; break; }
        case 27: { bits.b27 = 1; break; }
        case 28: { bits.b28 = 1; break; }
        case 29: { bits.b29 = 1; break; }
        case 30: { bits.b30 = 1; break; }
        case 31: { bits.b31 = 1; break; }
        default: break;
    }
    *pwartosc = bits.all_bits;
    return 0;
}

int clear_bit(uint32_t* pwartosc, int b) {
    if(pwartosc == NULL || b < 0 || b > 31) {
        return -1;
    }
    union uint32bits bits;
    bits.all_bits = *pwartosc;
    switch (b) {
        case 0: { bits.b0 = 0; break; }
        case 1: { bits.b1 = 0; break; }
        case 2: { bits.b2 = 0; break; }
        case 3: { bits.b3 = 0; break; }
        case 4: { bits.b4 = 0; break; }
        case 5: { bits.b5 = 0; break; }
        case 6: { bits.b6 = 0; break; }
        case 7: { bits.b7 = 0; break; }
        case 8: { bits.b8 = 0; break; }
        case 9: { bits.b9 = 0; break; }
        case 10: { bits.b10 = 0; break; }
        case 11: { bits.b11 = 0; break; }
        case 12: { bits.b12 = 0; break; }
        case 13: { bits.b13 = 0; break; }
        case 14: { bits.b14 = 0; break; }
        case 15: { bits.b15 = 0; break; }
        case 16: { bits.b16 = 0; break; }
        case 17: { bits.b17 = 0; break; }
        case 18: { bits.b18 = 0; break; }
        case 19: { bits.b19 = 0; break; }
        case 20: { bits.b20 = 0; break; }
        case 21: { bits.b21 = 0; break; }
        case 22: { bits.b22 = 0; break; }
        case 23: { bits.b23 = 0; break; }
        case 24: { bits.b24 = 0; break; }
        case 25: { bits.b25 = 0; break; }
        case 26: { bits.b26 = 0; break; }
        case 27: { bits.b27 = 0; break; }
        case 28: { bits.b28 = 0; break; }
        case 29: { bits.b29 = 0; break; }
        case 30: { bits.b30 = 0; break; }
        case 31: { bits.b31 = 0; break; }
        default: break;
    }
    *pwartosc = bits.all_bits;
    return 0;
}

int isset_bit(const uint32_t* pwartosc, int b) {
    if(pwartosc == NULL || b < 0 || b > 31) {
        return -1;
    }
    union uint32bits bits;
    bits.all_bits = *pwartosc;
    switch (b) {
        case 0: { return bits.b0; }
        case 1: { return bits.b1; }
        case 2: { return bits.b2; }
        case 3: { return bits.b3; }
        case 4: { return bits.b4; }
        case 5: { return bits.b5; }
        case 6: { return bits.b6; }
        case 7: { return bits.b7; }
        case 8: { return bits.b8; }
        case 9: { return bits.b9; }
        case 10: { return bits.b10; }
        case 11: { return bits.b11; }
        case 12: { return bits.b12; }
        case 13: { return bits.b13; }
        case 14: { return bits.b14; }
        case 15: { return bits.b15; }
        case 16: { return bits.b16; }
        case 17: { return bits.b17; }
        case 18: { return bits.b18; }
        case 19: { return bits.b19; }
        case 20: { return bits.b20; }
        case 21: { return bits.b21; }
        case 22: { return bits.b22; }
        case 23: { return bits.b23; }
        case 24: { return bits.b24; }
        case 25: { return bits.b25; }
        case 26: { return bits.b26; }
        case 27: { return bits.b27; }
        case 28: { return bits.b28; }
        case 29: { return bits.b29; }
        case 30: { return bits.b30; }
        case 31: { return bits.b31; }
        default: return -1;
    }
}

int main() {

    uint32_t num;

    int b;

    int pro;

    printf("Enter a value: ");
    if(scanf("%u", &num) != 1) {
        printf("Incorrect input");
        return 1;
    }

    printf("Enter an index of a bit: ");
    if(scanf("%d", &b) != 1) {
        printf("Incorrect input");
        return 1;
    }
    if(b < 0 || b > 31) {
        printf("Invalid bit index");
        return 2;
    }

    printf("Select operation (0-toggle, 1-set, 2-clear, 3-read): ");
    if(scanf("%d", &pro) != 1) {
        printf("Incorrect input");
        return 1;
    }
    if(pro < 0 || pro > 3) {
        printf("Invalid operation");
        return 2;
    }

    switch (pro) {
        case 0: {

            toggle_bit(&num, b);
            printf("%x", num);
            break;
        }
        case 1: {

            set_bit(&num, b);
            printf("%x", num);
            break;
        }
        case 2: {

            clear_bit(&num, b);
            printf("%x", num);
            break;
        }
        case 3: {

            printf("%d", isset_bit(&num, b));
        }

        default: break;
    }

    return 0;
}

