/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Włącz, wyłącz i przełącz
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-09 21:51:23.012502
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzenie funkcji set_bit()
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzenie funkcji set_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = set_bit(NULL, 0);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzenie funkcji set_bit()
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzenie funkcji set_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = set_bit(NULL, -1);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzenie funkcji set_bit()
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzenie funkcji set_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = set_bit(NULL, 32);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzenie funkcji set_bit()
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzenie funkcji set_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value = 0;
            int err = set_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1, "Oczekiwano wartości value 1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzenie funkcji set_bit()
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzenie funkcji set_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value = 0;
            int err = set_bit(&value, -1);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value 0 a otrzymano %u", value);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzenie funkcji set_bit()
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzenie funkcji set_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value = 0;
            int err = set_bit(&value, 32);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value 0 a otrzymano %u", value);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzenie funkcji set_bit() - bity
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzenie funkcji set_bit() - bity", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value;
            int err;
            
            value = 0;
            err = set_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1, "Oczekiwano wartości value=1 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 1);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2, "Oczekiwano wartości value=2 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 2);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 4, "Oczekiwano wartości value=4 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 3);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 8, "Oczekiwano wartości value=8 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 4);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 16, "Oczekiwano wartości value=16 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 5);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 32, "Oczekiwano wartości value=32 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 6);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 64, "Oczekiwano wartości value=64 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 7);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 128, "Oczekiwano wartości value=128 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 8);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 256, "Oczekiwano wartości value=256 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 9);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 512, "Oczekiwano wartości value=512 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 10);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1024, "Oczekiwano wartości value=1024 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 11);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2048, "Oczekiwano wartości value=2048 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 12);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 4096, "Oczekiwano wartości value=4096 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 13);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 8192, "Oczekiwano wartości value=8192 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 14);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 16384, "Oczekiwano wartości value=16384 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 15);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 32768, "Oczekiwano wartości value=32768 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 16);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 65536, "Oczekiwano wartości value=65536 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 17);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 131072, "Oczekiwano wartości value=131072 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 18);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 262144, "Oczekiwano wartości value=262144 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 19);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 524288, "Oczekiwano wartości value=524288 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 20);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1048576, "Oczekiwano wartości value=1048576 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 21);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2097152, "Oczekiwano wartości value=2097152 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 22);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 4194304, "Oczekiwano wartości value=4194304 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 23);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 8388608, "Oczekiwano wartości value=8388608 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 24);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 16777216, "Oczekiwano wartości value=16777216 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 25);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 33554432, "Oczekiwano wartości value=33554432 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 26);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 67108864, "Oczekiwano wartości value=67108864 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 27);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 134217728, "Oczekiwano wartości value=134217728 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 28);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 268435456, "Oczekiwano wartości value=268435456 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 29);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 536870912, "Oczekiwano wartości value=536870912 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 30);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1073741824, "Oczekiwano wartości value=1073741824 a otrzymano %u", value);
            
            value = 0;
            err = set_bit(&value, 31);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2147483648, "Oczekiwano wartości value=2147483648 a otrzymano %u", value);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzenie funkcji set_bit() - bity (losowanie)
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzenie funkcji set_bit() - bity (losowanie)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value;
            int err;
            
            value = 3715500161;
            err = set_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3715500161, "Oczekiwano wartości value=3715500161 a otrzymano %u", value);
            
            value = 1709115667;
            err = set_bit(&value, 3);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1709115675, "Oczekiwano wartości value=1709115675 a otrzymano %u", value);
            
            value = 2857594476;
            err = set_bit(&value, 5);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2857594476, "Oczekiwano wartości value=2857594476 a otrzymano %u", value);
            
            value = 2881467805;
            err = set_bit(&value, 1);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2881467807, "Oczekiwano wartości value=2881467807 a otrzymano %u", value);
            
            value = 1695897236;
            err = set_bit(&value, 6);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1695897300, "Oczekiwano wartości value=1695897300 a otrzymano %u", value);
            
            value = 2399505154;
            err = set_bit(&value, 13);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2399513346, "Oczekiwano wartości value=2399513346 a otrzymano %u", value);
            
            value = 2345488231;
            err = set_bit(&value, 18);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2345488231, "Oczekiwano wartości value=2345488231 a otrzymano %u", value);
            
            value = 635339649;
            err = set_bit(&value, 31);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2782823297, "Oczekiwano wartości value=2782823297 a otrzymano %u", value);
            
            value = 1544628402;
            err = set_bit(&value, 13);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1544628402, "Oczekiwano wartości value=1544628402 a otrzymano %u", value);
            
            value = 319720747;
            err = set_bit(&value, 22);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 323915051, "Oczekiwano wartości value=323915051 a otrzymano %u", value);
            
            value = 1785248070;
            err = set_bit(&value, 16);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1785313606, "Oczekiwano wartości value=1785313606 a otrzymano %u", value);
            
            value = 2186325118;
            err = set_bit(&value, 5);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2186325118, "Oczekiwano wartości value=2186325118 a otrzymano %u", value);
            
            value = 3114994376;
            err = set_bit(&value, 31);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3114994376, "Oczekiwano wartości value=3114994376 a otrzymano %u", value);
            
            value = 3691462621;
            err = set_bit(&value, 30);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3691462621, "Oczekiwano wartości value=3691462621 a otrzymano %u", value);
            
            value = 382249763;
            err = set_bit(&value, 16);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 382315299, "Oczekiwano wartości value=382315299 a otrzymano %u", value);
            
            value = 413833185;
            err = set_bit(&value, 12);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 413833185, "Oczekiwano wartości value=413833185 a otrzymano %u", value);
            
            value = 219313474;
            err = set_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 219313475, "Oczekiwano wartości value=219313475 a otrzymano %u", value);
            
            value = 442335172;
            err = set_bit(&value, 13);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 442335172, "Oczekiwano wartości value=442335172 a otrzymano %u", value);
            
            value = 2567598875;
            err = set_bit(&value, 5);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2567598907, "Oczekiwano wartości value=2567598907 a otrzymano %u", value);
            
            value = 2544460633;
            err = set_bit(&value, 28);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2544460633, "Oczekiwano wartości value=2544460633 a otrzymano %u", value);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzenie funkcji clear_bit()
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzenie funkcji clear_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = clear_bit(NULL, 0);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzenie funkcji clear_bit()
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzenie funkcji clear_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = clear_bit(NULL, -1);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzenie funkcji clear_bit()
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzenie funkcji clear_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = clear_bit(NULL, 32);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzenie funkcji clear_bit()
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzenie funkcji clear_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value = 1;
            int err = clear_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value 0 a otrzymano %u", value);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzenie funkcji clear_bit()
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzenie funkcji clear_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value = 0;
            int err = clear_bit(&value, -1);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value 0 a otrzymano %u", value);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzenie funkcji clear_bit()
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzenie funkcji clear_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value = 0;
            int err = clear_bit(&value, 32);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value 0 a otrzymano %u", value);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzenie funkcji clear_bit() - bity
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzenie funkcji clear_bit() - bity", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value;
            int err;
            
            value = 1;
            err = clear_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 2;
            err = clear_bit(&value, 1);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 4;
            err = clear_bit(&value, 2);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 8;
            err = clear_bit(&value, 3);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 16;
            err = clear_bit(&value, 4);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 32;
            err = clear_bit(&value, 5);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 64;
            err = clear_bit(&value, 6);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 128;
            err = clear_bit(&value, 7);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 256;
            err = clear_bit(&value, 8);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 512;
            err = clear_bit(&value, 9);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 1024;
            err = clear_bit(&value, 10);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 2048;
            err = clear_bit(&value, 11);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 4096;
            err = clear_bit(&value, 12);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 8192;
            err = clear_bit(&value, 13);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 16384;
            err = clear_bit(&value, 14);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 32768;
            err = clear_bit(&value, 15);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 65536;
            err = clear_bit(&value, 16);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 131072;
            err = clear_bit(&value, 17);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 262144;
            err = clear_bit(&value, 18);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 524288;
            err = clear_bit(&value, 19);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 1048576;
            err = clear_bit(&value, 20);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 2097152;
            err = clear_bit(&value, 21);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 4194304;
            err = clear_bit(&value, 22);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 8388608;
            err = clear_bit(&value, 23);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 16777216;
            err = clear_bit(&value, 24);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 33554432;
            err = clear_bit(&value, 25);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 67108864;
            err = clear_bit(&value, 26);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 134217728;
            err = clear_bit(&value, 27);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 268435456;
            err = clear_bit(&value, 28);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 536870912;
            err = clear_bit(&value, 29);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 1073741824;
            err = clear_bit(&value, 30);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            value = 2147483648;
            err = clear_bit(&value, 31);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value=0 a otrzymano %u", value);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzenie funkcji clear_bit() - bity (losowanie)
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzenie funkcji clear_bit() - bity (losowanie)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value;
            int err;
            
            value = 69307315;
            err = clear_bit(&value, 24);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 69307315, "Oczekiwano wartości value=69307315 a otrzymano %u", value);
            
            value = 1553459732;
            err = clear_bit(&value, 12);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1553459732, "Oczekiwano wartości value=1553459732 a otrzymano %u", value);
            
            value = 3430022228;
            err = clear_bit(&value, 19);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3430022228, "Oczekiwano wartości value=3430022228 a otrzymano %u", value);
            
            value = 3045220341;
            err = clear_bit(&value, 28);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2776784885, "Oczekiwano wartości value=2776784885 a otrzymano %u", value);
            
            value = 2643971680;
            err = clear_bit(&value, 24);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2627194464, "Oczekiwano wartości value=2627194464 a otrzymano %u", value);
            
            value = 2803492413;
            err = clear_bit(&value, 22);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2803492413, "Oczekiwano wartości value=2803492413 a otrzymano %u", value);
            
            value = 3339763415;
            err = clear_bit(&value, 24);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3322986199, "Oczekiwano wartości value=3322986199 a otrzymano %u", value);
            
            value = 642937821;
            err = clear_bit(&value, 16);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 642937821, "Oczekiwano wartości value=642937821 a otrzymano %u", value);
            
            value = 2171352150;
            err = clear_bit(&value, 1);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2171352148, "Oczekiwano wartości value=2171352148 a otrzymano %u", value);
            
            value = 3858633305;
            err = clear_bit(&value, 30);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2784891481, "Oczekiwano wartości value=2784891481 a otrzymano %u", value);
            
            value = 2309537454;
            err = clear_bit(&value, 20);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2309537454, "Oczekiwano wartości value=2309537454 a otrzymano %u", value);
            
            value = 2657632168;
            err = clear_bit(&value, 28);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2389196712, "Oczekiwano wartości value=2389196712 a otrzymano %u", value);
            
            value = 441666743;
            err = clear_bit(&value, 9);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 441666743, "Oczekiwano wartości value=441666743 a otrzymano %u", value);
            
            value = 427081596;
            err = clear_bit(&value, 3);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 427081588, "Oczekiwano wartości value=427081588 a otrzymano %u", value);
            
            value = 3436843905;
            err = clear_bit(&value, 7);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3436843777, "Oczekiwano wartości value=3436843777 a otrzymano %u", value);
            
            value = 4053211552;
            err = clear_bit(&value, 3);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 4053211552, "Oczekiwano wartości value=4053211552 a otrzymano %u", value);
            
            value = 3417937172;
            err = clear_bit(&value, 19);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3417412884, "Oczekiwano wartości value=3417412884 a otrzymano %u", value);
            
            value = 3036435047;
            err = clear_bit(&value, 22);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3032240743, "Oczekiwano wartości value=3032240743 a otrzymano %u", value);
            
            value = 2910301229;
            err = clear_bit(&value, 9);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2910301229, "Oczekiwano wartości value=2910301229 a otrzymano %u", value);
            
            value = 2554323094;
            err = clear_bit(&value, 31);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 406839446, "Oczekiwano wartości value=406839446 a otrzymano %u", value);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzenie funkcji toggle_bit()
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzenie funkcji toggle_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = toggle_bit(NULL, 0);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzenie funkcji toggle_bit()
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzenie funkcji toggle_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = toggle_bit(NULL, -1);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzenie funkcji toggle_bit()
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzenie funkcji toggle_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = toggle_bit(NULL, 32);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzenie funkcji toggle_bit()
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzenie funkcji toggle_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value = 1;
            int err = toggle_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value 0 a otrzymano %u", value);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzenie funkcji toggle_bit()
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzenie funkcji toggle_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value = 0;
            int err = toggle_bit(&value, -1);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value 0 a otrzymano %u", value);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzenie funkcji toggle_bit()
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzenie funkcji toggle_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value = 0;
            int err = toggle_bit(&value, 32);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
            test_error(value == 0, "Oczekiwano wartości value 0 a otrzymano %u", value);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzenie funkcji toggle_bit() - bity (losowanie)
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzenie funkcji toggle_bit() - bity (losowanie)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value;
            int err;
            
            value = 4282653468;
            err = toggle_bit(&value, 26);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 4215544604, "Oczekiwano wartości value=4215544604 a otrzymano %u", value);
            
            value = 317492704;
            err = toggle_bit(&value, 11);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 317490656, "Oczekiwano wartości value=317490656 a otrzymano %u", value);
            
            value = 3472228240;
            err = toggle_bit(&value, 5);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3472228272, "Oczekiwano wartości value=3472228272 a otrzymano %u", value);
            
            value = 2639044188;
            err = toggle_bit(&value, 15);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2639011420, "Oczekiwano wartości value=2639011420 a otrzymano %u", value);
            
            value = 3758536001;
            err = toggle_bit(&value, 23);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3766924609, "Oczekiwano wartości value=3766924609 a otrzymano %u", value);
            
            value = 268037070;
            err = toggle_bit(&value, 24);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 251259854, "Oczekiwano wartości value=251259854 a otrzymano %u", value);
            
            value = 3877483088;
            err = toggle_bit(&value, 28);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 4145918544, "Oczekiwano wartości value=4145918544 a otrzymano %u", value);
            
            value = 3216717873;
            err = toggle_bit(&value, 17);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3216586801, "Oczekiwano wartości value=3216586801 a otrzymano %u", value);
            
            value = 3836298113;
            err = toggle_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3836298112, "Oczekiwano wartości value=3836298112 a otrzymano %u", value);
            
            value = 4101521769;
            err = toggle_bit(&value, 7);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 4101521897, "Oczekiwano wartości value=4101521897 a otrzymano %u", value);
            
            value = 657668753;
            err = toggle_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 657668752, "Oczekiwano wartości value=657668752 a otrzymano %u", value);
            
            value = 3396653712;
            err = toggle_bit(&value, 28);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3665089168, "Oczekiwano wartości value=3665089168 a otrzymano %u", value);
            
            value = 1979309164;
            err = toggle_bit(&value, 8);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1979309420, "Oczekiwano wartości value=1979309420 a otrzymano %u", value);
            
            value = 2517626527;
            err = toggle_bit(&value, 17);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2517495455, "Oczekiwano wartości value=2517495455 a otrzymano %u", value);
            
            value = 3305716649;
            err = toggle_bit(&value, 5);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3305716617, "Oczekiwano wartości value=3305716617 a otrzymano %u", value);
            
            value = 3530784474;
            err = toggle_bit(&value, 9);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 3530783962, "Oczekiwano wartości value=3530783962 a otrzymano %u", value);
            
            value = 256713730;
            err = toggle_bit(&value, 28);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 525149186, "Oczekiwano wartości value=525149186 a otrzymano %u", value);
            
            value = 1290451868;
            err = toggle_bit(&value, 3);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 1290451860, "Oczekiwano wartości value=1290451860 a otrzymano %u", value);
            
            value = 2212206408;
            err = toggle_bit(&value, 0);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2212206409, "Oczekiwano wartości value=2212206409 a otrzymano %u", value);
            
            value = 2551690350;
            err = toggle_bit(&value, 23);
            test_error(err == 0, "Oczekiwano kodu błędu 0 a otrzymano %d", err);
            test_error(value == 2560078958, "Oczekiwano wartości value=2560078958 a otrzymano %u", value);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzenie funkcji isset_bit()
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzenie funkcji isset_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = isset_bit(NULL, 0);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzenie funkcji isset_bit()
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzenie funkcji isset_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = isset_bit(NULL, -1);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzenie funkcji isset_bit()
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzenie funkcji isset_bit()", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            int err = isset_bit(NULL, 32);
            test_error(err == -1, "Oczekiwano kodu błędu -1 a otrzymano %d", err);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzenie funkcji isset_bit() - bity (losowanie)
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzenie funkcji isset_bit() - bity (losowanie)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
            uint32_t value, state;
            
            value = 2749067153;
            state = isset_bit(&value, 0);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 1917661470;
            state = isset_bit(&value, 24);
            test_error(state == 0, "Oczekiwano wartości state=0 a otrzymano %u", state);
            
            value = 189754945;
            state = isset_bit(&value, 10);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 2626058194;
            state = isset_bit(&value, 8);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 1821887351;
            state = isset_bit(&value, 29);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 2878346650;
            state = isset_bit(&value, 20);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 3100953171;
            state = isset_bit(&value, 27);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 1065763205;
            state = isset_bit(&value, 13);
            test_error(state == 0, "Oczekiwano wartości state=0 a otrzymano %u", state);
            
            value = 2310521485;
            state = isset_bit(&value, 26);
            test_error(state == 0, "Oczekiwano wartości state=0 a otrzymano %u", state);
            
            value = 3492825182;
            state = isset_bit(&value, 6);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 3358832644;
            state = isset_bit(&value, 0);
            test_error(state == 0, "Oczekiwano wartości state=0 a otrzymano %u", state);
            
            value = 251081940;
            state = isset_bit(&value, 18);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 4144294125;
            state = isset_bit(&value, 8);
            test_error(state == 0, "Oczekiwano wartości state=0 a otrzymano %u", state);
            
            value = 125316513;
            state = isset_bit(&value, 10);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 1888694589;
            state = isset_bit(&value, 9);
            test_error(state == 0, "Oczekiwano wartości state=0 a otrzymano %u", state);
            
            value = 2931638787;
            state = isset_bit(&value, 0);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 1246433923;
            state = isset_bit(&value, 17);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 4149600546;
            state = isset_bit(&value, 30);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            value = 1438187625;
            state = isset_bit(&value, 22);
            test_error(state == 0, "Oczekiwano wartości state=0 a otrzymano %u", state);
            
            value = 1556668527;
            state = isset_bit(&value, 5);
            test_error(state == 1, "Oczekiwano wartości state=1 a otrzymano %u", state);
            
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}




enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzenie funkcji set_bit()
            UTEST2, // Sprawdzenie funkcji set_bit()
            UTEST3, // Sprawdzenie funkcji set_bit()
            UTEST4, // Sprawdzenie funkcji set_bit()
            UTEST5, // Sprawdzenie funkcji set_bit()
            UTEST6, // Sprawdzenie funkcji set_bit()
            UTEST7, // Sprawdzenie funkcji set_bit() - bity
            UTEST8, // Sprawdzenie funkcji set_bit() - bity (losowanie)
            UTEST9, // Sprawdzenie funkcji clear_bit()
            UTEST10, // Sprawdzenie funkcji clear_bit()
            UTEST11, // Sprawdzenie funkcji clear_bit()
            UTEST12, // Sprawdzenie funkcji clear_bit()
            UTEST13, // Sprawdzenie funkcji clear_bit()
            UTEST14, // Sprawdzenie funkcji clear_bit()
            UTEST15, // Sprawdzenie funkcji clear_bit() - bity
            UTEST16, // Sprawdzenie funkcji clear_bit() - bity (losowanie)
            UTEST17, // Sprawdzenie funkcji toggle_bit()
            UTEST18, // Sprawdzenie funkcji toggle_bit()
            UTEST19, // Sprawdzenie funkcji toggle_bit()
            UTEST20, // Sprawdzenie funkcji toggle_bit()
            UTEST21, // Sprawdzenie funkcji toggle_bit()
            UTEST22, // Sprawdzenie funkcji toggle_bit()
            UTEST23, // Sprawdzenie funkcji toggle_bit() - bity (losowanie)
            UTEST24, // Sprawdzenie funkcji isset_bit()
            UTEST25, // Sprawdzenie funkcji isset_bit()
            UTEST26, // Sprawdzenie funkcji isset_bit()
            UTEST27, // Sprawdzenie funkcji isset_bit() - bity (losowanie)
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(27); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(0); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}