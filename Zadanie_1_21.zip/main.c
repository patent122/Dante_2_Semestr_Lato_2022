#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

#define CLOSE_RESOURCES() fclose(index_cursor); fclose(text_cursor)
#define CORRUPTED() CLOSE_RESOURCES(); printf("file corrupted"); return 6

int main()
{
	FILE* index_cursor, * text_cursor;
	char path[31];
	int index, c, has_first_line = 0, file_size;

	printf("Podaj sciezke do pliku: ");
	scanf("%30s", path);

	index_cursor = fopen(path, "rb");

	if (index_cursor == NULL)
	{
		printf("couldn't open file");
		return 4;
	}

	fseek(index_cursor, 0, SEEK_END);
	file_size = ftell(index_cursor);
	fseek(index_cursor, 0, SEEK_SET);

	text_cursor = fopen(path, "rb");

	while ((c = fgetc(text_cursor)) != -1)
	{
		if (c == '\n')
		{
			has_first_line = 1;
			break;
		}
	}

	if (!has_first_line)
	{
		CORRUPTED();
	}

	while (fscanf(index_cursor, "%d", &index) == 1)
	{
		fseek(text_cursor, index, SEEK_SET);

		if (index >= file_size)
		{
			CORRUPTED();
		}
	}

	fseek(index_cursor, -1, SEEK_CUR);

	if ((c = fgetc(index_cursor)) != '\n')
	{
		CORRUPTED();
	}

	fseek(index_cursor, 0, SEEK_SET);

	while (fscanf(index_cursor, "%d", &index) == 1)
	{
		if (fseek(text_cursor, index, SEEK_SET) != 0)
		{
			CORRUPTED();
		}

		if ((c = fgetc(text_cursor)) != -1)
		{
			printf("%c", c);
		}
		else
		{
			CORRUPTED();
		}
	}

	CLOSE_RESOURCES();

	return 0;
}

