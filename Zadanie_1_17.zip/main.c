#include <stdio.h>
#include <string.h>
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
    char plik_zrod[51], plik_cel[51] = "copy_";
    FILE *zrod, *cel;

    printf("Input file directory:\n");
    scanf("%30[^\n]s", plik_zrod);
    if (strcmp(plik_zrod + (strlen(plik_zrod) - 4), ".bmp")) {
        printf("Unsupported File Format");
        return 7;
    }
    zrod = fopen(plik_zrod, "rb");

    if (zrod == NULL)
    {
        printf("Couldn't open file\n");
        return 4;
    }
    strcpy((plik_cel + 5), plik_zrod);
    cel = fopen(plik_cel, "wb");

    if (cel == NULL)
    {
        fclose(zrod);
        printf("Couldn't create file\n");
        return 5;
    }
    char buf[51] = { 0 };
    long lSize;
    fseek(zrod, 0, SEEK_END);
    lSize = ftell(zrod);
    rewind(zrod);

    for (int i = 0; i < lSize; i++) {
        fread(buf, 1, 1, zrod);
        fwrite(buf, 1, 1, cel);
    }
    printf("File saved\n");
    fclose(zrod);
    fclose(cel);

    return 0;
}
