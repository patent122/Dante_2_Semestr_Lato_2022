﻿#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include "tested_declarations.h"
#include "rdebug.h"
#include "tested_declarations.h"
#include "rdebug.h"


struct point_t
{
    int a;
    int b;
};

struct point_t* set(struct point_t* c, int a, int b)
{
    if (c == NULL) return NULL;
    c->b = b;

    c->a = a;

    return c;
}
void show(const struct point_t* p)
{
    if (p == NULL) return;
    printf("x=%d , y=%d\n", p->a, p->b);
}
int save_point_t(const char* filename, const struct point_t* c)
{
    if (filename == NULL || c == NULL) return 1;

    FILE* file;

    file = fopen(filename, "w");

    if (file == NULL) return 2;

    fprintf(file, "%d", c->a);

    fprintf(file, "%c", ' ');

    fprintf(file, "%d", c->b);

    fclose(file);

    return 0;
}
int load_point_t(const char* filename, struct point_t* p)
{
    if (filename == NULL || p == NULL) return 1;
    FILE* file;
    file = fopen(filename, "r");
    if (file == NULL) return 2;
    if (fscanf(file, "%d", &p->a) != 1)
    {
        fclose(file);
        return 3;
    }
    if (fscanf(file, "%d", &p->b) != 1)
    {
        fclose(file);
        return 3;
    }
    fclose(file);
    return 0;
}
int save_point_b(const char* filename, const struct point_t* p)
{
    if (filename == NULL || p == NULL) return 1;
    FILE* file;
    file = fopen(filename, "wb");
    if (file == NULL) return 2;
    fwrite(&p->a, sizeof(int), 1, file);
    fwrite(&p->b, sizeof(int), 1, file);
    fclose(file);
    return 0;
}
int load_point_b(const char* filename, struct point_t* p)
{
    if (filename == NULL || p == NULL) return 1;
    FILE* file;
    file = fopen(filename, "rb");
    if (file == NULL) return 2;
    if (fread(p, sizeof(struct point_t), 1, file) != 1)
    {
        fclose(file);
        return 3;
    }

    fclose(file);
    return 0;
}


int main()
{
    srand(time(NULL));
    struct point_t point;
    char path[31];
    int a = rand() % 10;
    int b = rand() % 10;
    set(&point, a, b);
    show(&point);
    printf("Enter path:\n");
    scanf("%30[^\n]", path);
    while (getchar() != '\n');
    int len = strlen(path);
    int check = 0;
    if (*(path + (len-1)) == 't')
    {
        if (*(path + (len-2)) == 'x')
        {
            if (*(path+(len-3)) == 't')
            {
                if (*(path + (len - 4)) == '.')
                {
                    check = 1;
                }
            }
        }
    }
    if (*(path + (len - 1)) == 'n')
    {
        if (*(path + (len - 2)) == 'i')
        {
            if (*(path + (len - 3)) == 'b')
            {
                if (*(path + (len - 4)) == '.')
                {
                    check = 2;
                }
            }
        }
    }
    switch (check) {
        case 0:
            printf("Unsupported file format\n");
            return 7;
        case 1:
            if (save_point_t(path, &point) == 2)
            {
                printf("Couldn't create file\n");
                return 5;
            }
            break;
        case 2:
            if (save_point_b(path, &point) == 2)
            {
                printf("Couldn't create file\n");
                return 5;
            }
            break;
    }
    printf("File saved\n");
    printf("Do you want to read file(Y/N)?");
    int result = 0;
    char d;
    scanf("%c", &d);
    while (getchar() != '\n');
    if (d == 'y' || d == 'Y')
    {
        switch (check) {
            case 1:
                result = load_point_t(path, &point);
                if (result == 2)
                {
                    printf("Couldn't open file\n");
                    return 4;
                }
                if (result != 0)
                {
                    printf("File corrupted");
                    return 6;
                }
                show(&point);
                break;
            case 2:
                result = load_point_b(path, &point);
                if (result == 2)
                {
                    printf("Couldn't open file\n");
                    return 4;
                }
                if (result != 0)
                {
                    printf("File corrupted");
                    return 6;
                }
                show(&point);
        }
    }
    else if (d == 'n' || d == 'N') return 0;

    else {
        printf("Incorrect input\n");
        return 1;
    }
}


