#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned int n;
    int ones = 0;
    printf("Podaj wartosc: ");
    if (!scanf("%u", &n))
    {
        printf("Incorrect input");
        return 1;
    }
    while (n > 0)
    {
        if ((n % 2) == 1)
        {
            ones++;
        }
        n /= 2;
    }
    if (ones % 2 == 0)
    {
        printf("YES");
    }
    else
    {
        printf("NO");
    }
    return 0;
}
