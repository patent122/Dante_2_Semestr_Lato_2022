#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int main() {
    int **tabliczka = NULL;
    tabliczka = malloc(10 * sizeof(int*));

    if(tabliczka == NULL)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }
    for (int i = 0; i < 10; ++i)
    {
        *(tabliczka + i) = malloc(10 * sizeof(int));
        if(*(tabliczka + i) == NULL)
        {
            printf("Failed to allocate memory\n");
            for (int j = 0; j < i; ++j)
            {
                free(*(tabliczka+j));
            }
            free(tabliczka);
            return 8;
        }
    }

    for (int i = 0; i < 10; ++i)
    {
        for (int j = 0; j < 10; ++j)
        {
            *(*(tabliczka + i) + j) = (i+1) * (j+1);
        }
    }

    for (int i = 0; i < 10; ++i)
    {
        for (int j = 0; j < 10; ++j)
        {
            printf("%3d ", *(*(tabliczka + i) + j));
        }
        printf("\n");
    }

    for (int i = 0; i < 10; ++i) {
        free(*(tabliczka+i));
    }
    free(tabliczka);
    return 0;
}
