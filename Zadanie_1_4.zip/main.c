#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
	char input_path[31], output_path[31];
	FILE* input, * output;
	int c;

	printf("Podaj sciezke do pliku wejsciowego: ");
	scanf("%30s", input_path);
	input = fopen(input_path, "rb");

	if (input == NULL)
	{
		printf("couldn't open file");
		return 4;
	}

	if (strlen(input_path) == 30)
	{
		while ((c = fgetc(stdin)) != -1)
		{
			if (c == '\n')
			{
				break;
			}
		}
	}

	printf("Podaj sciezke do pliku wyjsciowego: ");
	scanf("%30s", output_path);

	output = fopen(output_path, "wb");

	if (output == NULL)
	{
		fclose(input);
		printf("couldn't create file");
		return 5;
	}

	fseek(input, 0, SEEK_END);
	long current = ftell(input);
	current--;

	while (current >= 0)
	{
		fseek(input, current, SEEK_SET);
		c = fgetc(input);
		// i tutaj te�
		fputc(c, output);
		current--;
	}

	fclose(output);
	fclose(input);

	printf("File copied");

	return 0;
}

