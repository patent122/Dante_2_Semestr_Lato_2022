#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int read_file(const char* filename)
{
	FILE* current_file;
	char current_filename[31];
	int n;

	if (filename == NULL)
	{
		return -1;
	}

	current_file = fopen(filename, "rb");

	if (current_file != NULL)
	{
		n = 1;
		while (fscanf(current_file, "%30s", current_filename) == 1)
		{
			printf("%s\n", current_filename);
			n += read_file(current_filename);
		}

		fclose(current_file);
		return n;
	}

	return 0;
}

int main()
{
	char filename[31];
	int n;

	printf("Podaj sciezke do pliku: ");
	scanf("%30s", filename);
	n = read_file(filename);

	if (n == 0)
	{
		printf("couldn't open file");
		return 4;
	}

	printf("%d", n);

	return 0;
}

