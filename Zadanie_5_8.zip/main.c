#include <stdio.h>
#include <stdlib.h>
#include "image_utils.h"
#include "tested_declarations.h"
#include "rdebug.h"

enum errors {
    SUCCES = 0,
    INCORECT_INPUT = 1,
    INCORECT_INPUT_DATA = 2,
    COULDNT_OPEN_FILE = 4,
    COULDNT_CREATE_FILE = 5,
    FILE_CORRUPTED = 6,
    FAILED_TO_ALLOCATE_MEMORY = 8
};

int main()
{
    int px,py,kolorek,wysokosc,szerokosc,kod_wyjscia;
    struct image_t *obrazek;
    char *sciezka = malloc(40 * sizeof(char));
    if(sciezka == NULL)
    {
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }

    printf("Filename to open: ");
    scanf("%39s", sciezka);

    while(getchar()!='\n'){}

    obrazek = load_image_t(sciezka, &kod_wyjscia);
    if (kod_wyjscia == 2)
    {
        free(sciezka);
        printf("Couldn't open file\n");
        return COULDNT_OPEN_FILE;
    }
    if (kod_wyjscia == 3)
    {
        free(sciezka);
        printf("File corrupted\n");
        return FILE_CORRUPTED;
    }
    if (kod_wyjscia == 4)
    {
        free(sciezka);
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }

    printf("Give (X Y WIDTH HEIGHT): ");
    if(scanf("%d %d %d %d", &px, &py, &szerokosc, &wysokosc) != 4)
    {
        free(sciezka);
        destroy_image(&obrazek);
        printf("Incorrect input\n");
        return INCORECT_INPUT;
    }

    printf("Give kolorek: ");
    if(scanf("%d", &kolorek) != 1)
    {
        free(sciezka);
        destroy_image(&obrazek);
        printf("Incorrect input\n");
        return INCORECT_INPUT;
    }

    if(kolorek < 0 || kolorek > 255 || px < 0 || py < 0 || szerokosc < 0 || wysokosc < 0)
    {
        free(sciezka);
        destroy_image(&obrazek);
        printf("Incorrect input data\n");
        return INCORECT_INPUT_DATA;
    }

    kod_wyjscia = image_draw_rectangle(obrazek, &(struct rectangle_t){ .p = {px,py}, .width = szerokosc, .height = wysokosc}, kolorek);
    if(kod_wyjscia == 1)
    {
        free(sciezka);
        destroy_image(&obrazek);
        printf("Incorrect input data\n");
        return INCORECT_INPUT_DATA;
    }

    kod_wyjscia = save_image_t(sciezka, obrazek);
    if(kod_wyjscia == 0)
    {
        printf("File saved\n");
    }
    else
    {
        free(sciezka);
        destroy_image(&obrazek);
        printf("Couldn't create file");
        return COULDNT_CREATE_FILE;
    }

    free(sciezka);
    destroy_image(&obrazek);
    return SUCCES;
}
