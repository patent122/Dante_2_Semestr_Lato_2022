#include "image_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tested_declarations.h"
#include "rdebug.h"

enum error {
    SUCCES = 0,
    IN_ERROR = 1,
    FILE_OPEN_ERROR = 2,
    FILE_CORRUPTED = 3,
    MEMORY_ERROR = 4
};

struct image_t* load_image_t(const char *sciezka, int *kod_wyjscia)
{
    if(sciezka == NULL)
    {
        if(kod_wyjscia != NULL) *kod_wyjscia = IN_ERROR;
        return NULL;
    }

    
    FILE *plik;
    struct image_t *obrazek = malloc(sizeof(struct image_t));
    if(obrazek == NULL)
    {
        if (kod_wyjscia != NULL) *kod_wyjscia = MEMORY_ERROR;
        return NULL;
    }
    
    if((plik = fopen(sciezka, "r")) == NULL)
    {
        free(obrazek);
        if (kod_wyjscia != NULL) *kod_wyjscia = FILE_OPEN_ERROR;
        return NULL;
    }
    
    char *code = malloc(3 * sizeof(char));
    
    fscanf(plik, "%2s", code);

    if (strcmp(code, "P2") != 0)
    {
        if (kod_wyjscia != NULL) *kod_wyjscia = FILE_CORRUPTED;
        free(obrazek);
        free(code);
        fclose(plik);
        return NULL;
    }

    strcpy(obrazek->type, code);
    free(code);
    
    if (fscanf(plik, "%d %d", &obrazek->width, &obrazek->height) != 2)
    {
        if (kod_wyjscia != NULL) *kod_wyjscia = FILE_CORRUPTED;
        free(obrazek);
        fclose(plik);
        return NULL;
    }

    if(obrazek->width < 1 || obrazek->height < 1)
    {
        if (kod_wyjscia != NULL) *kod_wyjscia = FILE_CORRUPTED;
        free(obrazek);
        fclose(plik);
        return NULL;
    }

    
    int max;

    if (fscanf(plik, "%d", &max) != 1)
    {
        if (kod_wyjscia != NULL) *kod_wyjscia = FILE_CORRUPTED;
        free(obrazek);
        fclose(plik);
        return NULL;
    }

    if(max > 255)
    {
        if (kod_wyjscia != NULL) *kod_wyjscia = FILE_CORRUPTED;
        free(obrazek);
        fclose(plik);
        return NULL;
    }

    
    obrazek->ptr = malloc(obrazek->height * sizeof(int*));
    if(obrazek->ptr == NULL)
    {
        if (kod_wyjscia != NULL) *kod_wyjscia = MEMORY_ERROR;
        free(obrazek);
        fclose(plik);
        return NULL;
    }

    for (int i = 0; i < obrazek->height; ++i)
    {
        *(obrazek->ptr + i) = malloc(obrazek->width * sizeof(int));
        if(*(obrazek->ptr + i) == NULL)
        {
            for (int j = 0; j < i ; ++j)
            {
                free(*(obrazek->ptr + j));
            }
            if (kod_wyjscia != NULL) *kod_wyjscia = MEMORY_ERROR;
            free(obrazek->ptr);
            free(obrazek);
            fclose(plik);
            return NULL;
        }
    }

    for (int i = 0; i < obrazek->height; ++i)
    {
        for (int j = 0; j < obrazek->width; ++j)
        {
            if(fscanf(plik, "%d", *(obrazek->ptr + i) +j) != 1)
            {
                if (kod_wyjscia != NULL) *kod_wyjscia = FILE_CORRUPTED;
                for (int k = 0; k < obrazek->height; ++k)
                {
                    free(*(obrazek->ptr + k));
                }
                free(obrazek->ptr);
                free(obrazek);
                fclose(plik);
                return NULL;
            }
            if(*(*(obrazek->ptr + i) +j) < 0)
            {
                if (kod_wyjscia != NULL) *kod_wyjscia = FILE_CORRUPTED;
                for (int k = 0; k < obrazek->height; ++k)
                {
                    free(*(obrazek->ptr + k));
                }
                free(obrazek->ptr);
                free(obrazek);
                fclose(plik);
                return NULL;
            }
        }
    }

    fclose(plik);
    if (kod_wyjscia != NULL) *kod_wyjscia = SUCCES;
    return obrazek;
}

int save_image_t(const char * sciezka, const struct image_t *m1)
{
    if(sciezka == NULL || m1 == NULL || m1->width < 1 || m1->height < 1 || m1->ptr == NULL) return IN_ERROR;

    FILE *plik;
    int _height;
    int _width;

    if((plik = fopen(sciezka, "w")) == NULL) return FILE_OPEN_ERROR;

    _height = m1->height;
    _width = m1->width;

    fprintf(plik, "%s\n", m1->type);
    fprintf(plik, "%d %d\n", m1->width, m1->height);
    fprintf(plik, "255\n");

    for (int i = 0; i < _height; ++i)
    {
        for (int j = 0; j < _width; ++j)
        {
            if(fprintf(plik, "%d ", *(*(m1->ptr+i)+j)) < 0)
            {
                fclose(plik);
                return FILE_CORRUPTED;
            }
        }
        if(fprintf(plik, "\n") < 0)
        {
            fclose(plik);
            return FILE_CORRUPTED;
        }
    }

    fclose(plik);
    return SUCCES;
}

void destroy_image(struct image_t **m)
{
    if(*m == NULL || (*m)->ptr == NULL || (*m)->height < 1) return;

    for (int i = 0; i < (*m)->height; ++i)
    {
        free(*((*m)->ptr + i));
    }
    free((*m)->ptr);
    free(*m);
    *m = NULL;
}

struct image_t* image_flip_horizontal(const struct image_t *m1)
{
    if(m1 == NULL || m1->ptr == NULL || m1->width < 1|| m1->height < 1) return NULL;

    struct image_t *obrazek = malloc(sizeof(struct image_t));

    if(obrazek == NULL)
    {
        return NULL;
    }

    obrazek->height = m1->height;
    obrazek->width = m1->width;
    strcpy(obrazek->type, m1->type);

    
    obrazek->ptr = malloc(obrazek->height * sizeof(int*));
    if(obrazek->ptr == NULL)
    {
        free(obrazek);
        return NULL;
    }

    for (int i = 0; i < obrazek->height; ++i)
    {
        *(obrazek->ptr + i) = malloc(obrazek->width * sizeof(int));
        if(*(obrazek->ptr + i) == NULL)
        {
            for (int j = 0; j < i ; ++j)
            {
                free(*(obrazek->ptr + j));
            }
            free(obrazek->ptr);
            free(obrazek);
            return NULL;
        }
    }

    
    for (int i = 0; i < m1->height; ++i)
    {
        for (int j = 0; j < m1->width; ++j)
        {
            *(*(obrazek->ptr + i) + j) = *(*(m1->ptr + m1->height - i - 1) + j);
        }
    }

    return obrazek;
}

struct image_t* image_flip_vertical(const struct image_t *m1)
{
    if(m1 == NULL || m1->ptr == NULL || m1->width < 1|| m1->height < 1) return NULL;

    struct image_t *obrazek = malloc(sizeof(struct image_t));

    if(obrazek == NULL)
    {
        return NULL;
    }

    obrazek->height = m1->height;
    obrazek->width = m1->width;
    strcpy(obrazek->type, m1->type);

    
    obrazek->ptr = malloc(obrazek->height * sizeof(int*));
    if(obrazek->ptr == NULL)
    {
        free(obrazek);
        return NULL;
    }

    for (int i = 0; i < obrazek->height; ++i)
    {
        *(obrazek->ptr + i) = malloc(obrazek->width * sizeof(int));
        if(*(obrazek->ptr + i) == NULL)
        {
            for (int j = 0; j < i ; ++j)
            {
                free(*(obrazek->ptr + j));
            }
            free(obrazek->ptr);
            free(obrazek);
            return NULL;
        }
    }

    
    for (int i = 0; i < m1->height; ++i)
    {
        for (int j = 0; j < m1->width; ++j)
        {
            *(*(obrazek->ptr + i) + j) = *(*(m1->ptr + i) + m1->width - j - 1);
        }
    }

    return obrazek;
}

struct image_t* image_negate(const struct image_t *m1)
{
    if(m1 == NULL || m1->ptr == NULL || m1->width < 1|| m1->height < 1) return NULL;

    struct image_t *obrazek = malloc(sizeof(struct image_t));

    if(obrazek == NULL)
    {
        return NULL;
    }

    obrazek->height = m1->height;
    obrazek->width = m1->width;
    strcpy(obrazek->type, m1->type);

    
    obrazek->ptr = malloc(obrazek->height * sizeof(int*));
    if(obrazek->ptr == NULL)
    {
        free(obrazek);
        return NULL;
    }

    for (int i = 0; i < obrazek->height; ++i)
    {
        *(obrazek->ptr + i) = malloc(obrazek->width * sizeof(int));
        if(*(obrazek->ptr + i) == NULL)
        {
            for (int j = 0; j < i ; ++j)
            {
                free(*(obrazek->ptr + j));
            }
            free(obrazek->ptr);
            free(obrazek);
            return NULL;
        }
    }

    
    for (int i = 0; i < m1->height; ++i)
    {
        for (int j = 0; j < m1->width; ++j)
        {
            *(*(obrazek->ptr + i) + j) = 255 - *(*(m1->ptr + i) + j);
        }
    }

    return obrazek;
}

const int* image_get_pixel(const struct image_t *img, int x, int y)
{
    if (img == NULL ||
        img->ptr == NULL ||
        img->width < 1 ||
        img->height < 1 ||
        x < 0 ||
        y < 0 ||
        x > img->width - 1 ||
        y > img->height - 1)
        return NULL;

    return *(img->ptr + y) + x;
}

int* image_set_pixel(struct image_t *img, int x, int y)
{
    if (img == NULL ||
        img->ptr == NULL ||
        img->width < 1 ||
        img->height < 1 ||
        x < 0 ||
        y < 0 ||
        x > img->width - 1 ||
        y > img->height - 1)
        return NULL;

    return *(img->ptr + y) + x;
}

int image_draw_rectangle(struct image_t *img, const struct rectangle_t *rect, int value)
{
    
    if (img == NULL ||
        img->ptr == NULL ||
        img->height < 1 ||
        img->width < 1 ||
        rect == NULL ||
        rect->width < 1 ||
        rect->height < 1 ||
        value < 0 ||
        value > 255)
        return 1;

    
    if (rect->p.x + rect->width> img->width ||
        rect->p.y + rect->height > img->height ||
        rect->p.x >= img->width ||
        rect->p.x < 0 ||
        rect->p.y >= img->height ||
        rect->p.y < 0)
        return 1;

    
    for (int i = 0; i < rect->width; ++i)
    {
        int *pixel = image_set_pixel(img, rect->p.x + i, rect->p.y);

        if(pixel != NULL)
            *pixel = value;
    }

    
    for (int i = 0; i < rect->width; ++i)
    {
        int *pixel = image_set_pixel(img, rect->p.x + i, rect->p.y + rect->height - 1);

        if(pixel != NULL)
            *pixel = value;
    }

    
    for (int i = 0; i < rect->height; ++i)
    {
        int *pixel = image_set_pixel(img, rect->p.x, rect->p.y + i);

        if(pixel != NULL)
            *pixel = value;
    }

    
    for (int i = 0; i < rect->height; ++i)
    {
        int *pixel = image_set_pixel(img, rect->p.x + rect->width - 1, rect->p.y + i);

        if(pixel != NULL)
            *pixel = value;
    }

    return 0;
}
