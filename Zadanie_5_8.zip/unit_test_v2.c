/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Rysujemy prostokąt
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 21:06:34.272102
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][5] = {{ 1, 10, 9, -9, 5}, { 2, 4, -10, -8, -3}, { -10, 10, -42, -5, 7}, { -4, 3, -1, -6, 8}, { 5, 5, 2, 2, -6}, { 3, 8, 6, -10, -10}, { 9, -7, -1, -6, -2}, { -3, 9, 0, 3, -1}, { 7, -6, -5, -8, 1}, { -3, 8, -8, 4, -7}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("son.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 5; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][7] = {{ -10, -2, 8, -3, 8, 7, -6}, { 10, -3, -4, -9, -8, -4, 7}, { 7, 10, -42, -8, -4, 4, -5}, { 7, 7, -1, 8, -4, -4, -5}, { -4, 9, -1, -2, 6, -1, 2}, { 5, 5, 9, -5, 9, 4, 9}, { -6, -9, -5, -6, -9, 8, 3}, { -5, -3, 2, -7, 6, -3, -9}, { -5, -8, 0, -4, -5, 7, -5}, { -2, -2, 9, 1, 4, 1, 8}, { 7, -9, -3, 4, -1, 2, 2}, { 7, 10, -5, -8, 8, 8, -1}, { -1, 3, -9, -4, 5, 2, -6}, { 3, -2, -3, -9, -8, -2, -2}, { 2, -6, -8, -1, -1, -7, 10}, { 1, 9, 6, 2, 4, -8, -10}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("string.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                        test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 7; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][1] = {{ 4}, { 2}, { 5}, { 10}, { 5}, { 8}, { 7}, { 0}, { 0}, { 10}, { 8}, { 9}, { 10}, { 1}, { 3}, { 4}, { 5}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("valley.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][8] = {{ 0, 4, 0, 0, 6, 0, 7, 2}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("design.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 9}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("an.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("shoe.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("read.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("cow.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("look.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bought.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("substance.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("book.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("dollar.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("board.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("music.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("chief.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("wish.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 2, "Funkcja load_image_t() powinna zwrócić kod błędu 2, a zwróciła %d", err_code);
                    if (!2)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[10][5] = {{ 1, 10, 9, -9, 5}, { 2, 4, -10, -8, -3}, { -10, 10, -42, -5, 7}, { -4, 3, -1, -6, 8}, { 5, 5, 2, 2, -6}, { 3, 8, 6, -10, -10}, { 9, -7, -1, -6, -2}, { -3, 9, 0, 3, -1}, { 7, -6, -5, -8, 1}, { -3, 8, -8, 4, -7}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("son.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                        test_error(arr->height == 10, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 10, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 10; ++i)
                            for (int j = 0; j < 5; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][7] = {{ -10, -2, 8, -3, 8, 7, -6}, { 10, -3, -4, -9, -8, -4, 7}, { 7, 10, -42, -8, -4, 4, -5}, { 7, 7, -1, 8, -4, -4, -5}, { -4, 9, -1, -2, 6, -1, 2}, { 5, 5, 9, -5, 9, 4, 9}, { -6, -9, -5, -6, -9, 8, 3}, { -5, -3, 2, -7, 6, -3, -9}, { -5, -8, 0, -4, -5, 7, -5}, { -2, -2, 9, 1, 4, 1, 8}, { 7, -9, -3, 4, -1, 2, 2}, { 7, 10, -5, -8, 8, 8, -1}, { -1, 3, -9, -4, 5, 2, -6}, { 3, -2, -3, -9, -8, -2, -2}, { 2, -6, -8, -1, -1, -7, 10}, { 1, 9, 6, 2, 4, -8, -10}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("string.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                        test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 7; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][1] = {{ 4}, { 2}, { 5}, { 10}, { 5}, { 8}, { 7}, { 0}, { 0}, { 10}, { 8}, { 9}, { 10}, { 1}, { 3}, { 4}, { 5}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("valley.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][8] = {{ 0, 4, 0, 0, 6, 0, 7, 2}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("design.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("an.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("shoe.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("read.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("cow.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("look.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bought.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("substance.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("book.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("dollar.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("board.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("music.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("chief.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji matrix_load_t
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji matrix_load_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][8] = {{ -6, 1, 10, 0, 2, -5, -9, 8}, { 10, 1, 2, -4, 0, -7, -10, -6}, { 6, 4, -2, -1, -2, 4, -5, -2}, { -9, -3, 0, 5, 8, 0, -1, -3}, { -5, 2, -1, 4, 1, -2, -3, -7}, { -3, 4, 0, -2, 8, -6, -6, 2}, { 4, 2, 0, -7, 3, -3, 2, 0}, { 4, -4, 2, -7, -10, 10, 6, -5}, { 9, 3, -4, 6, -9, 10, 3, -1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("wish.txt", NULL);
                    printf("#####END#####");

                    if (!2)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 8; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 147 bajtów)
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 147 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(147);
    
    //
    // -----------
    //
    

            int array[3][8] = {{ 9, 3, 6, 1, 7, 1, 1, 1}, { 6, 10, 1, 2, 3, 8, 5, 6}, { 4, 1, 0, 9, 6, 10, 9, 10}};

            printf("#####START#####");                            
            struct image_t *arr = load_image_t("region.bin", NULL);
            printf("#####END#####");

            test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
            test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
            test_error(arr->height == 3, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 3, a ustawiła na %d", arr->height);

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 8; ++j)
                    test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


            printf("#####START#####");
            destroy_image(&arr);
            printf("#####END#####");

            test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(27);
    
    //
    // -----------
    //
    

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(51);
    
    //
    // -----------
    //
    

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(83);
    
    //
    // -----------
    //
    

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(115);
    
    //
    // -----------
    //
    

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(27);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(51);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(83);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(115);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("region.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t(NULL, &err_code);
                    printf("#####END#####");

                    test_error(err_code == 1, "Funkcja load_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t(NULL, NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 50: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST50(void)
{
    // informacje o teście
    test_start(50, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][7] = {{ 7, 27, 68, 72, 11, 39, 68}, { 88, 87, 5, 8, 68, 24, 35}, { 96, 55, 79, 96, 4, 38, 74}, { 58, 36, 46, 40, 24, 45, 18}, { 68, 80, 81, 67, 39, 65, 34}, { 45, 81, 81, 6, 54, 33, 30}, { 54, 98, 36, 7, 85, 84, 80}, { 53, 67, 34, 24, 6, 19, 70}, { 31, 52, 48, 59, 56, 4, 14}};
                    int array_draw_rectangle[9][7] = {{ 43, 43, 43, 43, 43, 43, 43}, { 43, 87, 5, 8, 68, 24, 43}, { 43, 55, 79, 96, 4, 38, 43}, { 43, 36, 46, 40, 24, 45, 43}, { 43, 80, 81, 67, 39, 65, 43}, { 43, 81, 81, 6, 54, 33, 43}, { 43, 98, 36, 7, 85, 84, 43}, { 43, 67, 34, 24, 6, 19, 43}, { 43, 43, 43, 43, 43, 43, 43}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("evening.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 9; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 7, .height = 9 }, 43);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {
                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 7; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 51: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST51(void)
{
    // informacje o teście
    test_start(51, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[20][7] = {{ 45, 5, 72, 67, 4, 40, 77}, { 2, 22, 82, 75, 83, 31, 44}, { 96, 92, 56, 74, 9, 20, 98}, { 34, 61, 54, 56, 46, 30, 95}, { 23, 89, 83, 84, 9, 96, 92}, { 23, 96, 71, 5, 28, 53, 68}, { 36, 75, 85, 71, 23, 27, 23}, { 62, 42, 98, 12, 30, 22, 87}, { 73, 4, 98, 79, 44, 42, 89}, { 20, 48, 71, 61, 46, 76, 12}, { 14, 79, 55, 39, 25, 20, 49}, { 44, 53, 18, 51, 71, 40, 92}, { 99, 37, 23, 24, 14, 81, 66}, { 95, 39, 62, 94, 22, 82, 45}, { 96, 4, 48, 64, 28, 34, 84}, { 39, 38, 60, 90, 33, 74, 1}, { 20, 54, 65, 20, 98, 33, 80}, { 84, 6, 35, 90, 81, 53, 16}, { 4, 76, 9, 70, 66, 82, 57}, { 11, 87, 51, 34, 38, 29, 17}};
                    int array_draw_rectangle[20][7] = {{ 120, 120, 120, 120, 120, 120, 120}, { 120, 22, 82, 75, 83, 31, 120}, { 120, 92, 56, 74, 9, 20, 120}, { 120, 61, 54, 56, 46, 30, 120}, { 120, 89, 83, 84, 9, 96, 120}, { 120, 96, 71, 5, 28, 53, 120}, { 120, 75, 85, 71, 23, 27, 120}, { 120, 42, 98, 12, 30, 22, 120}, { 120, 4, 98, 79, 44, 42, 120}, { 120, 48, 71, 61, 46, 76, 120}, { 120, 79, 55, 39, 25, 20, 120}, { 120, 53, 18, 51, 71, 40, 120}, { 120, 37, 23, 24, 14, 81, 120}, { 120, 39, 62, 94, 22, 82, 120}, { 120, 4, 48, 64, 28, 34, 120}, { 120, 38, 60, 90, 33, 74, 120}, { 120, 54, 65, 20, 98, 33, 120}, { 120, 6, 35, 90, 81, 53, 120}, { 120, 76, 9, 70, 66, 82, 120}, { 120, 120, 120, 120, 120, 120, 120}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("by.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 20, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 20, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 20; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 7, .height = 20 }, 120);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {
                        for (int i = 0; i < 20; ++i)
                            for (int j = 0; j < 7; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 52: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST52(void)
{
    // informacje o teście
    test_start(52, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[162][93] = {{ 6, 62, 62, 13, 80, 52, 69, 3, 76, 80, 35, 58, 60, 84, 79, 36, 23, 33, 90, 5, 88, 20, 26, 69, 58, 2, 77, 1, 49, 87, 79, 18, 81, 81, 29, 78, 92, 59, 29, 92, 91, 43, 16, 24, 20, 25, 97, 69, 7, 60, 35, 6, 11, 28, 16, 23, 79, 91, 68, 13, 30, 21, 45, 42, 59, 100, 50, 80, 93, 49, 42, 56, 66, 51, 47, 72, 92, 67, 75, 60, 73, 7, 8, 57, 64, 99, 15, 33, 88, 92, 26, 94, 10}, { 75, 34, 95, 32, 73, 70, 54, 96, 40, 38, 33, 64, 5, 95, 83, 61, 51, 89, 16, 67, 99, 16, 100, 89, 91, 46, 5, 57, 95, 94, 57, 60, 39, 79, 1, 71, 56, 17, 85, 43, 48, 9, 52, 64, 5, 86, 5, 59, 61, 35, 23, 16, 1, 55, 72, 27, 77, 49, 52, 2, 99, 37, 66, 43, 51, 21, 42, 98, 74, 86, 9, 99, 50, 61, 41, 58, 97, 41, 4, 59, 55, 5, 3, 74, 86, 50, 56, 68, 46, 90, 23, 46, 23}, { 14, 90, 41, 17, 39, 15, 74, 85, 25, 40, 18, 4, 70, 24, 40, 18, 53, 15, 93, 48, 58, 69, 55, 78, 42, 72, 57, 2, 7, 76, 23, 54, 33, 85, 64, 42, 25, 76, 77, 33, 85, 39, 1, 80, 43, 8, 96, 75, 22, 91, 16, 16, 37, 72, 72, 42, 56, 9, 60, 26, 43, 76, 7, 96, 30, 29, 83, 13, 53, 21, 61, 8, 18, 38, 37, 3, 14, 27, 7, 6, 84, 68, 73, 22, 67, 22, 59, 26, 76, 10, 30, 94, 74}, { 45, 55, 62, 64, 34, 45, 85, 41, 77, 57, 37, 89, 18, 58, 87, 72, 15, 52, 31, 75, 95, 60, 36, 71, 2, 28, 42, 76, 96, 20, 2, 30, 38, 39, 13, 64, 25, 17, 23, 25, 94, 78, 65, 3, 89, 73, 24, 47, 26, 57, 83, 46, 57, 22, 66, 75, 83, 10, 96, 58, 81, 2, 91, 17, 96, 2, 36, 12, 73, 42, 81, 17, 68, 87, 58, 5, 30, 100, 63, 10, 5, 42, 48, 4, 44, 4, 83, 96, 44, 61, 77, 48, 43}, { 45, 18, 80, 50, 52, 3, 29, 17, 11, 33, 94, 61, 20, 23, 59, 7, 49, 100, 57, 34, 25, 38, 12, 12, 13, 34, 52, 97, 77, 3, 1, 92, 17, 75, 30, 98, 12, 16, 19, 25, 3, 34, 100, 52, 33, 55, 45, 99, 87, 94, 1, 92, 80, 11, 26, 25, 47, 21, 1, 27, 44, 43, 73, 61, 2, 64, 24, 63, 58, 10, 3, 68, 26, 17, 100, 71, 59, 22, 28, 87, 41, 88, 50, 81, 84, 31, 30, 100, 94, 24, 46, 15, 28}, { 29, 64, 25, 96, 76, 61, 88, 86, 89, 17, 22, 75, 18, 79, 62, 34, 100, 42, 75, 2, 61, 4, 65, 30, 2, 1, 93, 10, 5, 11, 23, 84, 94, 2, 9, 31, 30, 6, 1, 29, 100, 8, 81, 58, 82, 37, 75, 80, 97, 90, 23, 70, 73, 82, 48, 86, 16, 70, 68, 92, 78, 34, 33, 83, 80, 77, 31, 2, 41, 79, 3, 37, 89, 49, 10, 74, 34, 40, 89, 65, 89, 14, 86, 37, 65, 81, 55, 76, 78, 21, 37, 74, 36}, { 19, 72, 50, 40, 73, 99, 94, 67, 38, 97, 77, 28, 91, 20, 43, 69, 94, 83, 81, 65, 18, 20, 63, 11, 42, 47, 20, 2, 99, 62, 15, 70, 21, 8, 65, 79, 25, 83, 22, 18, 82, 7, 73, 37, 34, 98, 40, 80, 47, 67, 32, 63, 35, 18, 33, 88, 64, 61, 66, 15, 63, 72, 19, 61, 18, 79, 87, 19, 5, 74, 39, 79, 10, 16, 39, 47, 17, 57, 17, 82, 86, 89, 35, 100, 35, 7, 49, 57, 4, 8, 66, 58, 63}, { 95, 31, 62, 70, 40, 47, 29, 73, 86, 33, 33, 63, 19, 59, 3, 49, 43, 89, 97, 2, 32, 52, 60, 82, 91, 82, 73, 59, 51, 30, 86, 14, 95, 16, 79, 69, 59, 25, 61, 54, 76, 21, 11, 21, 40, 57, 77, 92, 26, 72, 35, 13, 38, 68, 28, 17, 50, 77, 84, 60, 84, 51, 9, 71, 39, 88, 6, 82, 8, 67, 8, 64, 66, 18, 87, 67, 2, 67, 82, 70, 24, 40, 4, 63, 99, 3, 76, 49, 34, 64, 69, 14, 81}, { 78, 32, 44, 51, 40, 73, 88, 65, 63, 86, 23, 82, 70, 92, 18, 29, 75, 2, 61, 6, 57, 64, 30, 8, 15, 53, 30, 73, 84, 89, 15, 79, 16, 24, 46, 99, 14, 49, 96, 29, 44, 24, 85, 59, 75, 98, 98, 43, 13, 45, 39, 5, 93, 37, 73, 77, 17, 99, 64, 65, 49, 11, 78, 18, 12, 52, 25, 40, 95, 23, 28, 49, 68, 60, 77, 72, 6, 20, 59, 77, 53, 34, 51, 31, 57, 11, 56, 47, 89, 29, 33, 41, 13}, { 62, 46, 46, 98, 14, 74, 40, 58, 53, 71, 63, 59, 100, 73, 2, 17, 97, 54, 66, 38, 25, 7, 77, 78, 81, 15, 99, 78, 53, 68, 35, 47, 73, 97, 37, 59, 83, 73, 66, 54, 66, 25, 90, 46, 17, 31, 38, 13, 70, 29, 55, 92, 15, 50, 99, 30, 38, 80, 14, 41, 77, 59, 58, 51, 47, 95, 100, 22, 66, 14, 57, 72, 39, 61, 26, 55, 56, 90, 49, 77, 5, 19, 55, 8, 83, 27, 93, 31, 99, 24, 43, 91, 72}, { 82, 77, 9, 28, 95, 66, 69, 1, 80, 81, 78, 51, 41, 95, 84, 3, 85, 46, 64, 47, 30, 17, 39, 15, 84, 13, 81, 36, 64, 33, 79, 23, 89, 8, 3, 94, 65, 24, 52, 6, 54, 98, 56, 74, 12, 2, 30, 80, 40, 24, 42, 20, 68, 66, 36, 50, 32, 73, 74, 90, 36, 34, 68, 16, 30, 80, 74, 20, 39, 31, 70, 17, 74, 24, 32, 100, 2, 73, 98, 31, 1, 45, 82, 19, 96, 70, 62, 21, 65, 6, 15, 65, 68}, { 66, 15, 49, 74, 66, 48, 24, 95, 21, 74, 16, 67, 93, 20, 52, 61, 82, 10, 78, 60, 55, 8, 5, 56, 30, 67, 77, 25, 2, 69, 30, 26, 40, 59, 12, 62, 35, 28, 42, 35, 1, 47, 19, 96, 5, 46, 63, 56, 26, 83, 86, 95, 16, 25, 22, 34, 55, 96, 72, 72, 23, 34, 31, 55, 17, 23, 16, 67, 79, 59, 31, 11, 53, 72, 32, 22, 54, 52, 9, 14, 62, 49, 33, 70, 72, 4, 88, 79, 2, 63, 81, 94, 44}, { 83, 8, 93, 3, 23, 80, 14, 94, 71, 94, 59, 80, 88, 11, 21, 60, 17, 30, 79, 46, 17, 55, 41, 9, 27, 42, 86, 51, 91, 47, 40, 59, 3, 74, 62, 42, 23, 32, 32, 3, 52, 92, 76, 25, 62, 46, 27, 53, 65, 2, 82, 51, 89, 87, 32, 59, 46, 36, 88, 77, 89, 7, 97, 84, 48, 90, 11, 23, 33, 74, 22, 40, 16, 1, 50, 15, 38, 65, 93, 35, 83, 85, 70, 85, 97, 88, 74, 64, 67, 55, 48, 59, 86}, { 12, 16, 53, 92, 94, 54, 58, 68, 80, 82, 91, 53, 6, 5, 88, 62, 59, 32, 48, 73, 94, 70, 29, 10, 18, 50, 70, 71, 6, 25, 65, 83, 64, 12, 51, 73, 56, 7, 92, 27, 2, 18, 74, 54, 81, 78, 68, 90, 56, 26, 41, 95, 76, 57, 35, 37, 93, 9, 16, 7, 67, 46, 4, 14, 77, 96, 29, 62, 86, 43, 32, 42, 46, 2, 99, 96, 81, 91, 58, 44, 26, 91, 79, 41, 64, 47, 8, 65, 79, 53, 60, 25, 34}, { 97, 76, 99, 3, 72, 89, 14, 75, 72, 2, 37, 79, 97, 38, 74, 41, 88, 58, 83, 88, 61, 92, 41, 45, 21, 75, 14, 6, 77, 84, 47, 75, 13, 47, 37, 44, 71, 56, 77, 64, 42, 70, 21, 25, 25, 84, 100, 12, 34, 98, 82, 41, 58, 19, 83, 6, 50, 96, 18, 36, 22, 25, 78, 98, 3, 50, 29, 80, 69, 8, 96, 99, 15, 95, 96, 96, 55, 80, 27, 13, 50, 59, 92, 8, 32, 25, 88, 31, 15, 25, 23, 27, 10}, { 42, 66, 35, 61, 5, 82, 27, 100, 73, 27, 87, 48, 19, 41, 60, 62, 55, 98, 99, 37, 37, 91, 62, 19, 55, 12, 41, 44, 7, 21, 94, 60, 29, 27, 64, 91, 24, 65, 54, 68, 41, 97, 87, 51, 52, 63, 88, 6, 59, 76, 49, 57, 89, 91, 78, 55, 28, 57, 34, 75, 43, 23, 21, 11, 45, 47, 64, 37, 10, 36, 57, 96, 54, 63, 18, 92, 27, 24, 9, 94, 23, 98, 93, 98, 21, 13, 33, 10, 31, 23, 33, 67, 25}, { 28, 89, 74, 25, 9, 94, 2, 61, 73, 61, 1, 100, 67, 10, 21, 96, 9, 100, 11, 90, 87, 33, 31, 13, 60, 34, 29, 24, 99, 15, 38, 48, 71, 90, 51, 21, 29, 56, 69, 100, 50, 57, 69, 55, 77, 53, 45, 3, 83, 91, 71, 20, 72, 10, 93, 68, 3, 58, 79, 59, 57, 56, 57, 17, 64, 62, 47, 21, 2, 1, 14, 80, 50, 61, 26, 81, 71, 3, 96, 82, 85, 83, 70, 19, 62, 48, 78, 44, 7, 62, 56, 90, 47}, { 65, 47, 12, 80, 36, 70, 66, 83, 44, 27, 72, 71, 3, 98, 66, 50, 37, 67, 9, 52, 83, 27, 57, 76, 9, 16, 1, 87, 94, 90, 31, 39, 85, 82, 53, 95, 26, 86, 14, 86, 47, 71, 68, 78, 12, 34, 56, 66, 65, 37, 63, 18, 62, 54, 96, 83, 27, 96, 79, 9, 45, 7, 64, 48, 44, 69, 20, 69, 59, 38, 93, 56, 39, 28, 38, 53, 3, 99, 30, 46, 22, 24, 39, 77, 23, 31, 4, 6, 45, 45, 67, 88, 100}, { 87, 11, 16, 69, 52, 76, 16, 74, 34, 22, 47, 25, 28, 40, 63, 98, 15, 100, 28, 91, 15, 17, 57, 89, 81, 24, 76, 38, 75, 93, 51, 81, 1, 81, 2, 47, 4, 72, 44, 67, 69, 19, 36, 16, 80, 63, 60, 49, 67, 15, 85, 97, 85, 52, 21, 61, 27, 38, 55, 80, 62, 43, 99, 84, 92, 92, 41, 50, 30, 7, 13, 48, 6, 76, 38, 7, 71, 56, 98, 89, 18, 48, 76, 23, 34, 43, 61, 24, 74, 87, 81, 63, 97}, { 76, 93, 18, 71, 62, 8, 49, 17, 79, 56, 1, 10, 15, 54, 98, 35, 31, 55, 52, 8, 72, 18, 57, 44, 11, 61, 39, 57, 68, 14, 50, 9, 20, 47, 65, 16, 8, 40, 63, 37, 80, 41, 22, 57, 76, 45, 94, 66, 75, 94, 39, 10, 79, 90, 7, 30, 41, 50, 12, 55, 35, 89, 6, 34, 53, 3, 39, 74, 7, 95, 98, 2, 6, 18, 61, 80, 36, 35, 93, 46, 83, 29, 92, 89, 1, 72, 7, 50, 3, 20, 73, 54, 41}, { 75, 78, 78, 84, 91, 88, 15, 24, 61, 32, 100, 82, 58, 73, 21, 88, 56, 49, 31, 24, 14, 65, 41, 67, 55, 1, 32, 62, 92, 1, 93, 38, 46, 36, 72, 8, 60, 74, 19, 75, 14, 69, 2, 77, 90, 33, 65, 10, 23, 98, 96, 88, 52, 88, 29, 39, 88, 19, 75, 79, 25, 53, 4, 24, 57, 20, 61, 60, 54, 45, 51, 37, 52, 55, 4, 17, 26, 12, 96, 53, 96, 94, 17, 17, 91, 55, 85, 90, 27, 7, 65, 45, 95}, { 56, 64, 36, 6, 66, 74, 54, 89, 15, 97, 36, 17, 17, 27, 85, 36, 10, 47, 77, 9, 39, 69, 87, 24, 11, 14, 77, 26, 65, 9, 85, 93, 48, 91, 21, 14, 47, 18, 27, 34, 91, 97, 46, 49, 31, 86, 50, 46, 31, 57, 53, 38, 29, 60, 7, 85, 1, 94, 58, 37, 63, 7, 87, 82, 61, 58, 86, 8, 99, 23, 30, 30, 73, 35, 98, 15, 17, 20, 53, 46, 13, 53, 80, 68, 96, 66, 57, 8, 1, 4, 29, 95, 20}, { 5, 29, 65, 100, 27, 59, 19, 18, 50, 93, 32, 76, 95, 70, 2, 40, 7, 66, 15, 70, 50, 39, 77, 63, 75, 75, 23, 96, 30, 14, 14, 42, 87, 88, 55, 22, 88, 76, 38, 96, 1, 8, 35, 67, 64, 5, 62, 44, 72, 62, 42, 8, 52, 95, 56, 21, 13, 68, 39, 69, 74, 53, 11, 47, 23, 88, 22, 70, 20, 38, 33, 96, 38, 89, 9, 52, 55, 21, 30, 34, 23, 71, 53, 22, 7, 7, 31, 2, 76, 88, 34, 33, 71}, { 66, 99, 26, 87, 97, 78, 70, 49, 42, 22, 77, 32, 32, 45, 20, 49, 16, 100, 58, 58, 66, 7, 92, 61, 95, 98, 50, 49, 9, 54, 45, 86, 99, 48, 45, 17, 12, 90, 36, 44, 11, 22, 57, 83, 36, 35, 5, 77, 29, 32, 81, 15, 8, 75, 3, 42, 8, 40, 41, 77, 74, 86, 46, 78, 59, 21, 14, 71, 98, 39, 59, 81, 84, 56, 43, 64, 51, 69, 68, 97, 38, 57, 89, 18, 24, 49, 44, 68, 61, 70, 69, 44, 88}, { 35, 78, 90, 98, 81, 45, 13, 78, 73, 96, 48, 26, 51, 98, 10, 27, 31, 65, 19, 33, 41, 62, 95, 99, 98, 42, 38, 96, 71, 65, 86, 39, 100, 21, 82, 66, 28, 50, 10, 90, 56, 20, 21, 71, 37, 19, 26, 6, 88, 42, 79, 77, 72, 20, 23, 49, 7, 52, 84, 89, 39, 9, 68, 12, 41, 94, 81, 86, 67, 88, 100, 89, 87, 55, 28, 54, 92, 87, 24, 31, 73, 17, 9, 38, 53, 70, 10, 53, 72, 25, 6, 95, 46}, { 70, 85, 60, 70, 76, 99, 77, 62, 16, 12, 47, 29, 89, 61, 58, 7, 75, 25, 83, 70, 94, 40, 86, 68, 12, 57, 93, 29, 36, 35, 64, 71, 50, 42, 47, 12, 19, 89, 55, 59, 14, 54, 45, 23, 79, 68, 59, 80, 42, 13, 25, 71, 24, 33, 67, 28, 76, 89, 47, 55, 13, 72, 80, 52, 6, 70, 85, 84, 13, 41, 64, 19, 48, 14, 85, 51, 73, 50, 66, 37, 55, 80, 91, 30, 60, 98, 29, 83, 74, 64, 67, 8, 3}, { 41, 53, 30, 26, 4, 8, 84, 58, 86, 52, 3, 84, 38, 91, 56, 32, 95, 70, 68, 7, 41, 24, 93, 23, 40, 65, 30, 89, 33, 91, 90, 62, 3, 59, 86, 37, 55, 78, 17, 60, 73, 39, 77, 36, 69, 51, 100, 38, 88, 35, 75, 50, 53, 19, 78, 87, 37, 33, 29, 10, 6, 61, 84, 64, 97, 75, 23, 24, 3, 12, 19, 45, 32, 3, 42, 57, 86, 27, 50, 26, 82, 63, 98, 35, 2, 46, 76, 50, 19, 32, 46, 9, 35}, { 87, 35, 79, 57, 81, 57, 34, 1, 18, 97, 19, 7, 33, 86, 22, 1, 29, 37, 77, 31, 16, 72, 12, 95, 43, 29, 73, 63, 37, 30, 43, 32, 89, 30, 2, 75, 75, 46, 97, 15, 21, 80, 63, 93, 21, 42, 7, 11, 92, 15, 56, 16, 62, 73, 63, 76, 51, 46, 91, 29, 98, 76, 96, 1, 7, 99, 21, 21, 78, 40, 98, 53, 44, 77, 75, 27, 97, 53, 70, 39, 3, 66, 1, 57, 41, 23, 85, 45, 68, 57, 26, 9, 92}, { 23, 19, 95, 79, 9, 51, 63, 26, 88, 39, 100, 4, 92, 79, 13, 35, 48, 77, 88, 24, 72, 90, 90, 90, 32, 82, 56, 46, 94, 56, 13, 55, 21, 75, 45, 60, 44, 73, 65, 9, 65, 60, 72, 76, 3, 40, 17, 6, 17, 100, 30, 55, 57, 85, 96, 64, 46, 23, 11, 5, 95, 10, 1, 91, 48, 88, 61, 22, 97, 71, 36, 47, 77, 27, 18, 40, 44, 60, 99, 92, 97, 8, 19, 32, 48, 55, 49, 98, 47, 68, 74, 30, 51}, { 40, 28, 77, 98, 72, 30, 49, 80, 89, 28, 40, 99, 36, 98, 67, 6, 94, 97, 84, 32, 49, 46, 40, 86, 38, 3, 91, 85, 97, 15, 27, 78, 90, 73, 63, 76, 78, 7, 55, 51, 31, 77, 49, 98, 9, 12, 43, 7, 25, 42, 59, 48, 54, 23, 70, 63, 9, 23, 18, 62, 21, 16, 61, 90, 68, 43, 43, 30, 86, 68, 96, 91, 29, 84, 7, 37, 89, 44, 82, 49, 3, 73, 67, 64, 18, 39, 47, 55, 83, 51, 96, 59, 86}, { 69, 20, 64, 6, 90, 86, 55, 64, 69, 4, 66, 100, 23, 38, 20, 70, 58, 67, 95, 86, 44, 31, 2, 65, 32, 7, 71, 78, 6, 54, 87, 52, 18, 90, 13, 21, 33, 93, 65, 35, 27, 70, 50, 70, 22, 33, 57, 7, 68, 4, 10, 11, 7, 8, 13, 78, 5, 88, 26, 65, 31, 88, 73, 62, 7, 21, 63, 86, 14, 62, 31, 22, 52, 65, 22, 33, 55, 44, 66, 69, 96, 56, 50, 30, 36, 23, 39, 13, 86, 50, 94, 50, 76}, { 92, 21, 44, 30, 10, 8, 46, 36, 37, 51, 72, 47, 47, 5, 62, 20, 64, 71, 59, 48, 5, 9, 25, 67, 37, 22, 62, 99, 11, 56, 91, 13, 52, 56, 44, 66, 86, 7, 15, 23, 83, 84, 79, 34, 72, 53, 28, 88, 97, 40, 85, 66, 76, 91, 89, 2, 48, 44, 31, 29, 88, 50, 3, 57, 6, 14, 41, 44, 89, 34, 76, 55, 76, 3, 77, 51, 70, 61, 51, 80, 1, 8, 94, 97, 32, 5, 36, 54, 79, 30, 47, 7, 55}, { 85, 58, 39, 91, 100, 21, 86, 1, 9, 30, 94, 27, 36, 78, 30, 65, 9, 15, 70, 22, 61, 83, 91, 50, 82, 43, 59, 72, 71, 21, 100, 10, 73, 54, 49, 32, 79, 34, 72, 69, 57, 65, 60, 86, 69, 39, 20, 51, 10, 69, 4, 22, 69, 80, 100, 13, 33, 65, 52, 58, 99, 75, 76, 37, 94, 27, 37, 69, 16, 38, 21, 78, 58, 83, 72, 85, 68, 8, 39, 70, 28, 88, 55, 83, 1, 17, 44, 72, 49, 73, 79, 90, 21}, { 86, 91, 35, 54, 58, 49, 96, 38, 85, 61, 64, 81, 79, 48, 48, 60, 30, 7, 54, 86, 44, 53, 52, 94, 2, 53, 75, 98, 24, 26, 67, 96, 8, 12, 51, 34, 43, 19, 57, 8, 95, 22, 12, 99, 97, 66, 98, 79, 36, 79, 70, 45, 53, 7, 99, 20, 36, 44, 97, 52, 70, 94, 55, 15, 65, 1, 69, 67, 66, 8, 4, 14, 75, 42, 26, 96, 20, 76, 32, 18, 29, 36, 27, 3, 66, 95, 2, 39, 74, 96, 23, 2, 67}, { 42, 26, 80, 97, 47, 28, 67, 92, 36, 79, 74, 57, 19, 86, 61, 33, 67, 29, 76, 74, 60, 69, 18, 35, 100, 92, 28, 37, 4, 74, 5, 98, 21, 42, 46, 46, 26, 85, 5, 64, 1, 16, 33, 11, 9, 92, 25, 66, 31, 16, 41, 38, 58, 30, 14, 89, 100, 58, 25, 33, 52, 32, 86, 18, 33, 65, 59, 13, 81, 8, 97, 84, 76, 37, 99, 47, 48, 24, 99, 46, 2, 79, 81, 31, 12, 46, 15, 75, 83, 42, 11, 50, 42}, { 93, 27, 77, 96, 51, 63, 60, 43, 19, 57, 41, 80, 60, 25, 89, 68, 2, 55, 30, 85, 59, 96, 70, 56, 66, 60, 3, 75, 51, 80, 34, 98, 7, 81, 33, 36, 24, 69, 93, 4, 70, 89, 72, 1, 94, 99, 99, 30, 88, 96, 58, 16, 95, 98, 10, 31, 86, 26, 53, 9, 41, 15, 85, 100, 8, 22, 40, 70, 5, 55, 75, 85, 46, 54, 52, 67, 88, 98, 3, 45, 25, 11, 21, 71, 80, 81, 44, 1, 86, 59, 31, 52, 84}, { 8, 1, 88, 35, 54, 38, 20, 54, 26, 31, 71, 95, 77, 61, 53, 41, 14, 77, 71, 80, 70, 61, 88, 53, 72, 15, 97, 16, 55, 55, 16, 56, 48, 29, 5, 40, 45, 36, 7, 75, 84, 12, 69, 83, 40, 46, 93, 35, 50, 93, 55, 15, 28, 16, 23, 64, 68, 69, 32, 3, 82, 49, 52, 80, 29, 31, 86, 17, 6, 54, 15, 32, 76, 89, 99, 70, 99, 14, 49, 22, 27, 70, 96, 38, 32, 98, 60, 55, 24, 64, 53, 87, 95}, { 37, 89, 24, 43, 4, 9, 40, 70, 100, 74, 68, 68, 18, 89, 70, 67, 63, 64, 48, 21, 72, 37, 28, 19, 92, 75, 53, 3, 94, 36, 44, 20, 5, 4, 39, 68, 58, 37, 47, 89, 76, 90, 25, 33, 72, 14, 37, 80, 100, 54, 46, 47, 95, 28, 87, 34, 39, 32, 26, 10, 48, 86, 38, 21, 45, 55, 49, 67, 93, 39, 39, 26, 78, 3, 71, 89, 96, 40, 32, 6, 93, 67, 60, 57, 10, 97, 72, 71, 23, 12, 45, 27, 52}, { 42, 81, 46, 59, 25, 48, 92, 83, 32, 98, 24, 27, 80, 10, 97, 92, 37, 40, 67, 52, 36, 53, 85, 93, 3, 23, 65, 68, 67, 22, 10, 1, 54, 6, 26, 79, 87, 74, 22, 24, 85, 75, 93, 19, 34, 67, 30, 56, 36, 88, 81, 58, 22, 25, 72, 9, 44, 49, 9, 71, 56, 49, 99, 53, 24, 75, 59, 43, 28, 94, 97, 48, 81, 57, 35, 96, 53, 84, 12, 37, 36, 22, 17, 34, 17, 40, 25, 54, 10, 43, 60, 48, 21}, { 47, 53, 11, 73, 64, 48, 90, 45, 81, 69, 5, 50, 55, 21, 64, 83, 68, 16, 80, 24, 1, 13, 39, 69, 83, 60, 60, 99, 25, 79, 41, 10, 67, 96, 43, 60, 24, 69, 27, 21, 67, 20, 53, 90, 68, 54, 21, 85, 38, 32, 18, 13, 65, 1, 40, 6, 72, 61, 31, 82, 2, 50, 43, 94, 17, 78, 72, 48, 11, 6, 60, 79, 30, 1, 54, 26, 88, 84, 65, 11, 32, 81, 78, 96, 87, 60, 46, 69, 30, 98, 61, 6, 33}, { 6, 12, 62, 10, 60, 83, 82, 44, 85, 40, 22, 57, 40, 20, 53, 77, 10, 74, 67, 78, 90, 84, 74, 77, 31, 5, 45, 64, 54, 78, 25, 59, 21, 77, 10, 61, 96, 66, 51, 68, 12, 65, 46, 29, 75, 53, 45, 59, 62, 34, 71, 24, 56, 14, 39, 75, 88, 71, 62, 53, 50, 95, 28, 9, 12, 5, 22, 44, 21, 31, 52, 73, 58, 18, 61, 29, 5, 98, 43, 42, 15, 8, 34, 35, 45, 98, 43, 63, 13, 60, 76, 56, 31}, { 4, 96, 74, 35, 74, 43, 93, 50, 62, 34, 9, 65, 29, 69, 36, 32, 29, 48, 28, 64, 39, 18, 54, 92, 37, 38, 46, 9, 81, 100, 78, 75, 1, 7, 91, 15, 65, 59, 15, 29, 17, 97, 7, 68, 53, 36, 29, 84, 44, 41, 48, 41, 56, 88, 37, 73, 82, 42, 12, 40, 47, 66, 73, 61, 62, 6, 6, 37, 73, 2, 17, 84, 66, 61, 40, 3, 73, 83, 12, 24, 40, 92, 93, 29, 88, 7, 98, 52, 89, 23, 19, 2, 65}, { 96, 52, 55, 87, 18, 53, 59, 41, 70, 21, 26, 28, 54, 27, 96, 19, 81, 74, 36, 34, 96, 6, 58, 27, 26, 70, 91, 55, 100, 57, 70, 54, 4, 88, 9, 16, 33, 79, 94, 18, 3, 84, 43, 100, 23, 71, 40, 53, 81, 39, 22, 30, 88, 20, 15, 9, 25, 90, 25, 7, 19, 21, 50, 80, 65, 57, 37, 47, 37, 47, 94, 74, 71, 12, 23, 67, 48, 52, 2, 67, 24, 8, 28, 98, 40, 82, 55, 58, 49, 85, 44, 95, 17}, { 23, 36, 41, 73, 90, 83, 55, 3, 16, 67, 97, 66, 87, 75, 49, 47, 76, 72, 32, 44, 90, 41, 43, 78, 23, 53, 91, 22, 81, 76, 90, 72, 10, 79, 16, 69, 51, 92, 79, 30, 26, 60, 16, 98, 54, 84, 29, 25, 59, 55, 20, 93, 79, 20, 31, 33, 84, 21, 86, 8, 74, 4, 40, 41, 33, 58, 89, 12, 34, 33, 44, 3, 17, 9, 57, 98, 82, 37, 84, 53, 72, 64, 10, 86, 53, 37, 53, 89, 63, 49, 80, 54, 93}, { 40, 41, 51, 29, 60, 81, 27, 74, 49, 19, 20, 65, 66, 2, 1, 70, 42, 25, 19, 44, 14, 11, 85, 96, 40, 2, 86, 86, 63, 33, 27, 51, 40, 69, 54, 27, 35, 73, 19, 1, 27, 95, 59, 62, 21, 7, 50, 40, 4, 78, 34, 87, 52, 77, 61, 30, 94, 94, 90, 91, 68, 83, 2, 49, 39, 33, 53, 11, 9, 98, 78, 9, 22, 28, 93, 100, 33, 25, 54, 16, 90, 93, 40, 41, 64, 59, 80, 59, 66, 86, 1, 73, 6}, { 99, 50, 88, 66, 78, 85, 64, 77, 90, 99, 76, 76, 89, 97, 85, 71, 56, 55, 60, 14, 15, 74, 57, 73, 61, 81, 66, 9, 14, 54, 60, 78, 88, 16, 27, 76, 57, 19, 58, 69, 54, 42, 16, 64, 10, 67, 79, 95, 46, 39, 41, 21, 25, 50, 77, 34, 96, 58, 72, 93, 90, 25, 64, 89, 1, 28, 64, 73, 18, 100, 1, 62, 94, 92, 5, 71, 78, 65, 90, 6, 3, 41, 50, 44, 80, 36, 100, 14, 57, 44, 97, 19, 91}, { 54, 94, 22, 27, 26, 33, 70, 83, 62, 63, 19, 19, 15, 29, 56, 46, 84, 93, 26, 84, 50, 87, 84, 77, 17, 58, 77, 57, 83, 47, 14, 11, 8, 98, 2, 65, 5, 15, 38, 73, 32, 55, 49, 24, 9, 6, 62, 61, 4, 22, 85, 36, 11, 16, 98, 80, 93, 55, 63, 65, 25, 5, 92, 5, 20, 11, 59, 86, 41, 38, 53, 14, 6, 89, 15, 18, 60, 87, 90, 77, 27, 50, 50, 58, 54, 71, 64, 29, 59, 38, 82, 22, 19}, { 31, 56, 22, 69, 1, 2, 2, 26, 36, 93, 33, 86, 100, 93, 8, 18, 15, 41, 53, 78, 80, 14, 73, 51, 96, 93, 62, 82, 59, 32, 14, 8, 12, 81, 90, 50, 78, 75, 16, 13, 89, 18, 20, 65, 48, 24, 92, 67, 2, 13, 72, 86, 45, 63, 57, 78, 47, 63, 13, 15, 57, 51, 100, 85, 94, 14, 19, 69, 71, 71, 81, 44, 78, 71, 42, 49, 39, 49, 32, 34, 91, 13, 93, 66, 87, 59, 99, 10, 32, 64, 57, 87, 55}, { 25, 49, 7, 64, 97, 60, 90, 92, 89, 44, 3, 54, 10, 40, 37, 72, 20, 63, 9, 73, 23, 57, 37, 29, 11, 58, 11, 54, 65, 59, 64, 84, 90, 34, 91, 80, 69, 99, 36, 11, 96, 60, 39, 4, 18, 68, 84, 71, 88, 23, 4, 70, 16, 44, 60, 61, 20, 7, 47, 84, 2, 54, 66, 71, 56, 54, 45, 24, 7, 93, 3, 87, 29, 26, 37, 80, 75, 87, 86, 75, 12, 35, 10, 17, 97, 59, 67, 90, 6, 62, 60, 80, 93}, { 17, 47, 19, 83, 49, 46, 77, 31, 56, 59, 80, 92, 72, 17, 56, 93, 73, 52, 92, 6, 63, 74, 15, 70, 98, 13, 38, 30, 22, 7, 19, 4, 80, 72, 92, 18, 48, 73, 96, 99, 40, 83, 29, 72, 4, 39, 98, 79, 89, 51, 79, 13, 60, 11, 17, 5, 30, 56, 42, 63, 8, 76, 11, 49, 2, 65, 3, 98, 7, 6, 53, 84, 2, 21, 28, 8, 3, 63, 59, 79, 76, 45, 60, 77, 72, 50, 86, 3, 70, 37, 60, 45, 63}, { 94, 16, 76, 40, 100, 10, 71, 32, 6, 41, 53, 58, 39, 73, 93, 94, 11, 49, 34, 16, 27, 92, 53, 98, 45, 83, 100, 26, 71, 40, 98, 6, 44, 17, 53, 66, 46, 92, 72, 47, 2, 73, 4, 10, 97, 81, 9, 37, 83, 49, 3, 38, 72, 53, 30, 50, 15, 10, 91, 97, 53, 36, 21, 56, 8, 77, 74, 65, 47, 94, 21, 34, 61, 77, 6, 73, 60, 24, 54, 39, 89, 58, 90, 91, 64, 52, 21, 50, 81, 41, 43, 100, 12}, { 99, 39, 33, 65, 39, 19, 3, 33, 7, 80, 34, 54, 65, 83, 99, 77, 16, 81, 69, 36, 33, 68, 74, 35, 58, 20, 41, 89, 39, 18, 73, 54, 65, 83, 65, 68, 67, 72, 52, 63, 58, 32, 24, 2, 9, 40, 95, 21, 40, 3, 50, 77, 55, 69, 46, 36, 51, 75, 76, 16, 43, 52, 42, 13, 18, 33, 73, 59, 5, 38, 47, 89, 32, 66, 99, 24, 25, 99, 42, 41, 55, 12, 72, 95, 33, 95, 64, 19, 87, 38, 93, 50, 26}, { 37, 94, 80, 69, 46, 14, 99, 91, 57, 6, 90, 66, 38, 3, 84, 71, 46, 83, 63, 96, 27, 25, 94, 29, 56, 57, 17, 63, 46, 83, 43, 99, 44, 10, 69, 59, 88, 92, 4, 85, 86, 65, 68, 81, 37, 69, 51, 7, 62, 14, 24, 57, 45, 15, 61, 93, 58, 82, 28, 6, 34, 16, 55, 74, 12, 39, 35, 36, 53, 62, 13, 70, 84, 29, 55, 51, 9, 12, 18, 12, 42, 56, 19, 79, 96, 33, 98, 97, 49, 18, 30, 6, 74}, { 25, 91, 25, 7, 83, 96, 76, 31, 83, 89, 74, 89, 56, 11, 98, 50, 30, 90, 85, 2, 21, 2, 98, 17, 12, 79, 64, 90, 20, 43, 60, 37, 75, 47, 22, 8, 38, 35, 77, 13, 30, 32, 36, 20, 15, 41, 67, 66, 25, 96, 49, 90, 40, 62, 41, 54, 100, 77, 80, 85, 38, 10, 55, 41, 24, 13, 18, 25, 16, 75, 18, 61, 16, 22, 13, 1, 28, 30, 21, 8, 2, 60, 85, 62, 35, 53, 74, 99, 4, 93, 34, 72, 97}, { 19, 35, 66, 40, 64, 4, 61, 73, 13, 16, 30, 87, 93, 77, 58, 22, 64, 37, 88, 68, 96, 81, 6, 97, 35, 9, 11, 57, 34, 34, 38, 46, 14, 97, 6, 25, 38, 79, 24, 84, 82, 100, 82, 31, 74, 42, 54, 47, 15, 72, 13, 82, 100, 87, 90, 54, 39, 4, 74, 84, 72, 65, 65, 97, 80, 43, 70, 82, 48, 83, 44, 96, 83, 82, 11, 98, 47, 35, 44, 88, 52, 3, 50, 74, 66, 27, 78, 1, 6, 17, 44, 30, 90}, { 35, 80, 30, 55, 37, 40, 98, 10, 100, 52, 29, 72, 92, 43, 7, 12, 92, 85, 33, 77, 73, 3, 84, 57, 41, 17, 3, 83, 74, 88, 33, 92, 20, 16, 43, 83, 82, 25, 50, 26, 68, 96, 74, 21, 35, 59, 50, 36, 9, 49, 33, 51, 65, 12, 32, 93, 63, 38, 92, 42, 29, 65, 1, 28, 78, 89, 51, 28, 90, 58, 52, 97, 17, 24, 38, 70, 23, 69, 95, 47, 81, 19, 79, 45, 66, 45, 12, 8, 27, 1, 78, 64, 51}, { 10, 93, 98, 36, 21, 23, 56, 86, 24, 31, 77, 79, 9, 56, 60, 77, 52, 98, 13, 86, 79, 95, 13, 62, 12, 50, 30, 84, 15, 96, 31, 71, 48, 13, 20, 5, 35, 97, 17, 45, 91, 92, 84, 94, 11, 64, 86, 23, 12, 46, 95, 100, 77, 50, 7, 38, 7, 32, 59, 3, 38, 81, 9, 57, 43, 55, 3, 89, 59, 86, 2, 14, 62, 96, 9, 48, 23, 1, 7, 37, 8, 55, 28, 92, 12, 53, 41, 76, 19, 55, 6, 63, 77}, { 73, 63, 46, 49, 60, 16, 1, 34, 86, 36, 14, 4, 29, 42, 20, 28, 45, 83, 63, 75, 45, 23, 83, 44, 48, 36, 89, 50, 40, 90, 77, 3, 27, 18, 87, 68, 10, 49, 42, 9, 25, 25, 51, 57, 13, 81, 68, 100, 52, 40, 53, 60, 72, 35, 11, 43, 37, 16, 66, 12, 22, 48, 42, 56, 25, 13, 43, 84, 42, 38, 56, 14, 36, 83, 94, 70, 69, 91, 11, 34, 75, 35, 54, 95, 49, 36, 30, 21, 36, 5, 95, 97, 33}, { 5, 30, 92, 7, 88, 59, 98, 88, 68, 90, 53, 93, 67, 84, 20, 86, 21, 68, 94, 57, 21, 4, 34, 65, 81, 94, 85, 53, 68, 92, 41, 97, 84, 73, 10, 11, 25, 9, 36, 34, 75, 90, 65, 96, 5, 92, 5, 49, 81, 85, 17, 31, 76, 48, 53, 12, 48, 69, 12, 18, 98, 30, 99, 11, 56, 52, 65, 17, 79, 92, 23, 44, 58, 49, 98, 59, 72, 32, 17, 61, 62, 63, 49, 97, 63, 51, 22, 28, 40, 78, 96, 97, 26}, { 10, 59, 22, 6, 52, 98, 88, 92, 80, 20, 25, 36, 32, 88, 14, 76, 92, 79, 73, 66, 70, 39, 39, 94, 70, 84, 72, 35, 69, 31, 94, 70, 75, 10, 32, 100, 22, 41, 100, 26, 42, 1, 11, 87, 100, 52, 28, 26, 35, 54, 15, 64, 37, 53, 45, 76, 8, 40, 62, 28, 57, 69, 69, 49, 38, 97, 33, 93, 28, 55, 31, 28, 15, 37, 14, 64, 65, 76, 55, 36, 56, 58, 86, 70, 73, 22, 23, 94, 5, 3, 86, 9, 59}, { 64, 87, 34, 32, 7, 98, 83, 1, 1, 16, 40, 26, 31, 8, 2, 86, 29, 85, 56, 24, 93, 94, 97, 81, 95, 57, 42, 97, 82, 34, 41, 5, 100, 60, 37, 32, 11, 44, 44, 46, 79, 94, 53, 71, 2, 84, 41, 17, 38, 82, 38, 88, 99, 83, 51, 44, 31, 19, 67, 41, 10, 96, 26, 26, 6, 71, 15, 28, 76, 3, 91, 62, 17, 12, 11, 83, 91, 49, 23, 40, 30, 23, 43, 64, 45, 60, 64, 75, 32, 60, 18, 68, 41}, { 23, 21, 59, 6, 52, 6, 4, 97, 48, 99, 49, 71, 71, 1, 21, 68, 57, 36, 61, 14, 41, 42, 47, 65, 89, 7, 1, 81, 17, 70, 5, 19, 63, 31, 84, 85, 15, 51, 64, 80, 30, 9, 51, 97, 57, 79, 4, 18, 50, 86, 35, 32, 16, 55, 42, 30, 44, 31, 7, 22, 16, 17, 69, 62, 2, 12, 4, 93, 34, 70, 1, 78, 2, 52, 14, 71, 8, 29, 83, 56, 84, 29, 57, 4, 92, 16, 14, 96, 71, 64, 88, 53, 80}, { 29, 78, 63, 76, 80, 7, 95, 40, 91, 45, 48, 2, 92, 99, 85, 56, 32, 97, 85, 95, 12, 56, 64, 16, 54, 78, 8, 40, 80, 81, 20, 3, 5, 91, 36, 69, 39, 33, 50, 50, 38, 99, 54, 78, 75, 63, 48, 59, 72, 53, 22, 91, 61, 36, 42, 39, 32, 43, 25, 45, 55, 11, 34, 18, 93, 44, 51, 50, 94, 39, 25, 38, 11, 95, 47, 83, 4, 5, 66, 72, 85, 67, 85, 92, 96, 1, 12, 74, 42, 43, 56, 86, 44}, { 69, 93, 25, 92, 72, 25, 70, 5, 88, 85, 81, 67, 25, 6, 19, 63, 22, 1, 33, 19, 66, 54, 88, 68, 72, 86, 76, 24, 33, 27, 27, 85, 59, 34, 27, 22, 71, 77, 58, 85, 11, 56, 11, 95, 59, 24, 89, 4, 33, 16, 79, 61, 56, 11, 7, 1, 80, 66, 54, 100, 41, 36, 40, 20, 39, 31, 97, 59, 1, 12, 18, 80, 77, 67, 66, 28, 32, 55, 82, 36, 75, 10, 28, 75, 48, 37, 98, 78, 20, 75, 84, 22, 17}, { 21, 60, 5, 69, 46, 73, 48, 89, 78, 21, 65, 25, 95, 14, 30, 54, 68, 92, 92, 51, 13, 85, 63, 2, 50, 53, 54, 76, 55, 2, 10, 4, 5, 99, 67, 78, 47, 82, 56, 41, 36, 59, 26, 26, 87, 27, 95, 87, 94, 41, 64, 70, 5, 81, 99, 74, 70, 77, 41, 73, 78, 18, 19, 45, 32, 86, 33, 88, 73, 46, 16, 73, 1, 91, 36, 91, 15, 32, 81, 75, 83, 28, 34, 45, 6, 58, 15, 95, 41, 74, 1, 46, 54}, { 29, 85, 42, 84, 83, 54, 52, 21, 73, 28, 85, 25, 12, 23, 54, 10, 92, 16, 87, 82, 85, 13, 60, 7, 10, 89, 71, 1, 70, 31, 1, 69, 69, 32, 69, 34, 38, 55, 66, 14, 43, 72, 77, 82, 34, 2, 16, 83, 18, 82, 74, 46, 42, 40, 51, 86, 81, 49, 74, 71, 92, 28, 71, 13, 25, 2, 45, 35, 96, 83, 23, 36, 73, 32, 31, 2, 29, 6, 93, 82, 29, 47, 54, 43, 54, 83, 56, 86, 92, 11, 96, 33, 62}, { 34, 9, 79, 19, 35, 15, 97, 19, 37, 4, 70, 69, 26, 95, 35, 87, 25, 37, 95, 22, 15, 64, 98, 56, 52, 62, 2, 78, 55, 7, 40, 80, 1, 6, 37, 51, 68, 30, 56, 64, 52, 63, 38, 81, 45, 77, 61, 5, 85, 18, 85, 41, 39, 98, 25, 70, 71, 40, 85, 13, 63, 74, 100, 21, 75, 81, 77, 2, 85, 10, 24, 10, 62, 80, 45, 40, 84, 58, 48, 60, 62, 68, 91, 52, 60, 6, 49, 3, 40, 73, 97, 74, 43}, { 70, 88, 75, 11, 32, 77, 81, 90, 96, 42, 82, 2, 50, 99, 66, 31, 97, 29, 94, 10, 15, 82, 71, 75, 80, 27, 34, 53, 74, 77, 46, 89, 80, 25, 54, 79, 25, 25, 86, 29, 99, 4, 57, 69, 42, 19, 5, 55, 85, 55, 47, 86, 63, 55, 21, 33, 80, 78, 78, 39, 52, 35, 40, 12, 68, 80, 2, 57, 6, 28, 19, 74, 17, 84, 17, 95, 29, 33, 41, 81, 73, 2, 15, 80, 75, 24, 76, 11, 82, 9, 89, 66, 1}, { 61, 3, 94, 19, 3, 65, 97, 39, 14, 28, 49, 12, 41, 31, 88, 43, 54, 6, 37, 53, 59, 51, 33, 33, 62, 33, 92, 94, 3, 25, 98, 71, 49, 7, 19, 14, 43, 91, 99, 81, 36, 7, 100, 35, 40, 12, 83, 12, 71, 33, 84, 20, 21, 12, 19, 85, 58, 50, 81, 9, 38, 34, 39, 41, 24, 83, 99, 72, 62, 55, 57, 4, 39, 93, 4, 56, 34, 26, 28, 42, 19, 13, 32, 2, 72, 75, 37, 91, 99, 16, 78, 95, 41}, { 32, 54, 10, 20, 52, 53, 9, 49, 9, 76, 9, 12, 28, 42, 19, 68, 53, 72, 65, 23, 48, 41, 24, 40, 1, 31, 8, 64, 88, 88, 60, 79, 8, 3, 69, 35, 2, 89, 65, 58, 39, 94, 6, 9, 30, 21, 99, 34, 87, 70, 17, 9, 94, 79, 48, 8, 69, 11, 39, 34, 19, 93, 42, 72, 78, 76, 93, 15, 93, 27, 74, 71, 47, 96, 47, 73, 58, 75, 59, 52, 98, 11, 34, 16, 20, 16, 19, 20, 71, 92, 43, 31, 73}, { 35, 9, 4, 19, 39, 56, 35, 99, 87, 37, 19, 28, 77, 7, 38, 81, 64, 60, 97, 7, 95, 11, 24, 50, 26, 68, 99, 61, 83, 54, 32, 72, 7, 89, 79, 15, 18, 99, 93, 76, 5, 30, 75, 61, 15, 17, 14, 29, 92, 22, 81, 70, 23, 100, 47, 46, 86, 3, 1, 74, 91, 86, 66, 81, 62, 86, 73, 28, 48, 1, 98, 87, 38, 50, 82, 79, 79, 35, 94, 70, 70, 36, 60, 33, 13, 17, 70, 25, 84, 94, 41, 77, 91}, { 41, 5, 73, 15, 33, 65, 61, 8, 83, 61, 69, 94, 83, 22, 23, 2, 22, 66, 7, 11, 18, 84, 75, 82, 83, 21, 45, 86, 65, 4, 53, 68, 38, 6, 64, 28, 18, 69, 64, 58, 41, 62, 78, 62, 11, 34, 4, 58, 75, 66, 30, 61, 57, 16, 24, 66, 81, 100, 23, 39, 57, 75, 100, 76, 56, 90, 96, 61, 27, 56, 26, 41, 27, 40, 37, 24, 52, 38, 58, 75, 69, 8, 17, 19, 75, 1, 57, 19, 14, 100, 22, 66, 98}, { 34, 65, 74, 56, 88, 50, 27, 49, 27, 37, 62, 47, 53, 15, 7, 39, 89, 33, 65, 21, 7, 5, 14, 57, 80, 28, 27, 21, 96, 99, 7, 60, 79, 95, 48, 56, 91, 26, 89, 64, 94, 96, 16, 96, 5, 6, 88, 68, 50, 77, 51, 10, 7, 11, 3, 27, 69, 31, 27, 80, 29, 64, 78, 6, 77, 21, 59, 88, 22, 71, 18, 76, 14, 42, 16, 68, 16, 5, 8, 68, 9, 15, 11, 7, 36, 83, 58, 84, 45, 34, 71, 97, 59}, { 65, 85, 69, 60, 60, 100, 16, 51, 96, 99, 56, 95, 98, 40, 22, 76, 11, 77, 68, 69, 70, 30, 52, 47, 27, 17, 84, 47, 25, 13, 19, 57, 48, 84, 45, 62, 31, 37, 47, 18, 68, 82, 42, 96, 75, 98, 66, 78, 58, 60, 80, 40, 53, 40, 22, 69, 42, 76, 35, 60, 100, 82, 71, 65, 16, 80, 75, 77, 53, 16, 75, 15, 26, 29, 94, 18, 100, 7, 60, 22, 15, 85, 4, 23, 72, 21, 48, 27, 55, 87, 15, 59, 48}, { 60, 59, 37, 76, 89, 8, 84, 44, 50, 10, 74, 24, 72, 46, 49, 31, 99, 76, 85, 47, 45, 65, 68, 93, 68, 31, 80, 70, 32, 22, 7, 53, 21, 35, 5, 73, 99, 4, 77, 35, 48, 14, 69, 10, 27, 54, 85, 84, 97, 22, 87, 8, 7, 13, 90, 74, 79, 5, 94, 40, 50, 91, 7, 8, 37, 87, 32, 56, 99, 33, 12, 56, 15, 19, 94, 95, 52, 98, 78, 25, 49, 92, 89, 97, 84, 5, 63, 41, 1, 100, 69, 26, 99}, { 38, 7, 42, 93, 16, 21, 57, 34, 8, 47, 7, 83, 75, 34, 57, 98, 65, 30, 36, 13, 50, 72, 38, 84, 52, 50, 92, 73, 53, 56, 12, 14, 8, 32, 79, 37, 88, 67, 43, 80, 30, 89, 74, 42, 99, 49, 7, 71, 81, 62, 26, 45, 48, 3, 53, 76, 32, 48, 11, 42, 60, 19, 81, 71, 64, 23, 50, 97, 97, 47, 8, 9, 83, 90, 79, 61, 6, 98, 42, 67, 39, 42, 85, 78, 74, 28, 66, 76, 48, 60, 29, 4, 83}, { 37, 13, 15, 83, 65, 12, 95, 37, 52, 85, 96, 62, 9, 1, 4, 92, 40, 74, 48, 81, 58, 12, 5, 21, 76, 97, 14, 21, 64, 89, 4, 71, 38, 25, 100, 11, 62, 13, 56, 35, 98, 56, 77, 28, 33, 14, 95, 46, 47, 74, 20, 25, 71, 77, 50, 75, 51, 37, 93, 12, 23, 8, 74, 20, 55, 35, 40, 72, 100, 29, 28, 84, 17, 100, 42, 37, 34, 46, 1, 45, 29, 62, 71, 13, 87, 42, 42, 47, 63, 33, 12, 40, 68}, { 70, 99, 7, 5, 55, 73, 56, 16, 86, 66, 82, 99, 81, 72, 68, 85, 13, 22, 7, 27, 13, 4, 19, 42, 13, 25, 45, 78, 7, 48, 87, 60, 1, 22, 32, 10, 46, 40, 19, 52, 30, 77, 32, 4, 87, 24, 25, 92, 70, 31, 77, 1, 32, 51, 42, 6, 33, 3, 65, 71, 13, 88, 31, 76, 83, 71, 85, 44, 27, 61, 62, 34, 69, 53, 38, 50, 21, 38, 82, 97, 64, 18, 11, 32, 95, 19, 77, 12, 28, 79, 66, 34, 100}, { 37, 34, 100, 31, 59, 25, 56, 85, 21, 44, 83, 27, 99, 60, 86, 36, 51, 66, 5, 82, 13, 64, 90, 5, 62, 13, 28, 69, 58, 48, 98, 66, 40, 97, 51, 16, 45, 45, 5, 7, 89, 86, 65, 71, 73, 51, 57, 43, 16, 6, 46, 50, 85, 60, 96, 49, 47, 7, 9, 50, 47, 48, 81, 94, 29, 98, 37, 87, 53, 22, 52, 68, 37, 99, 16, 58, 7, 39, 12, 70, 32, 46, 50, 56, 80, 91, 82, 39, 82, 78, 48, 22, 50}, { 92, 10, 48, 46, 26, 34, 58, 77, 58, 91, 68, 35, 52, 31, 76, 68, 7, 69, 30, 4, 89, 64, 10, 35, 49, 28, 5, 77, 93, 17, 43, 87, 23, 17, 100, 25, 82, 98, 96, 19, 60, 33, 50, 49, 12, 6, 64, 69, 85, 43, 48, 21, 56, 23, 34, 86, 64, 93, 46, 13, 46, 28, 11, 97, 27, 96, 8, 84, 84, 20, 100, 83, 50, 79, 22, 87, 1, 32, 83, 61, 79, 92, 24, 78, 24, 98, 23, 69, 95, 74, 7, 66, 64}, { 25, 39, 8, 33, 76, 38, 8, 79, 55, 11, 69, 7, 80, 39, 59, 75, 37, 72, 9, 93, 54, 34, 10, 1, 74, 24, 98, 60, 24, 54, 19, 80, 61, 38, 97, 93, 42, 65, 57, 69, 62, 5, 52, 33, 45, 35, 16, 50, 72, 56, 33, 11, 56, 99, 1, 91, 40, 4, 64, 56, 62, 16, 6, 32, 45, 34, 42, 96, 31, 85, 78, 100, 20, 80, 37, 48, 9, 38, 56, 79, 47, 10, 55, 46, 87, 50, 94, 69, 62, 53, 64, 26, 58}, { 46, 91, 16, 69, 88, 18, 91, 76, 9, 24, 13, 66, 61, 10, 60, 45, 90, 8, 78, 81, 2, 15, 94, 96, 1, 37, 100, 59, 36, 26, 6, 27, 17, 64, 80, 49, 66, 82, 92, 45, 29, 92, 54, 5, 55, 38, 39, 45, 60, 50, 69, 71, 42, 72, 50, 73, 5, 14, 88, 75, 15, 61, 36, 46, 38, 29, 87, 92, 81, 69, 4, 78, 61, 77, 46, 36, 78, 48, 75, 43, 70, 22, 35, 98, 96, 27, 57, 99, 50, 1, 54, 32, 62}, { 23, 57, 63, 57, 5, 79, 27, 24, 44, 10, 21, 50, 67, 76, 63, 38, 56, 64, 63, 91, 82, 38, 75, 48, 93, 59, 70, 91, 44, 9, 43, 55, 23, 14, 79, 78, 85, 97, 68, 58, 27, 20, 25, 65, 96, 72, 18, 14, 36, 53, 10, 20, 33, 71, 76, 78, 37, 8, 29, 71, 61, 84, 57, 82, 22, 18, 10, 79, 68, 39, 50, 69, 73, 22, 33, 1, 96, 94, 9, 8, 40, 68, 58, 73, 78, 28, 83, 85, 8, 52, 49, 93, 93}, { 99, 63, 5, 70, 26, 7, 65, 27, 77, 80, 42, 100, 29, 98, 96, 70, 10, 19, 75, 47, 29, 77, 41, 44, 2, 57, 91, 18, 74, 13, 1, 23, 10, 96, 76, 24, 81, 57, 46, 78, 55, 72, 19, 64, 34, 96, 32, 47, 19, 93, 63, 60, 21, 31, 43, 20, 1, 43, 4, 19, 12, 68, 15, 92, 3, 23, 99, 66, 56, 67, 27, 44, 79, 17, 13, 20, 60, 77, 88, 90, 81, 39, 46, 29, 92, 4, 31, 31, 89, 15, 99, 44, 52}, { 59, 33, 88, 46, 84, 96, 59, 87, 33, 92, 43, 98, 1, 95, 62, 6, 76, 6, 75, 56, 35, 16, 85, 79, 62, 92, 65, 95, 30, 65, 68, 62, 7, 63, 28, 37, 89, 7, 83, 88, 94, 50, 58, 4, 100, 7, 58, 14, 32, 83, 74, 62, 17, 8, 57, 19, 14, 18, 98, 64, 85, 70, 61, 76, 36, 59, 4, 93, 88, 37, 60, 80, 47, 20, 66, 7, 43, 100, 82, 87, 100, 92, 95, 65, 15, 42, 74, 23, 17, 16, 29, 41, 92}, { 97, 15, 93, 75, 99, 53, 81, 1, 43, 74, 78, 43, 68, 13, 7, 99, 26, 99, 82, 8, 25, 16, 89, 21, 7, 3, 66, 24, 23, 91, 22, 6, 40, 11, 56, 25, 50, 72, 4, 5, 84, 83, 92, 31, 44, 75, 48, 69, 29, 38, 2, 15, 99, 19, 70, 27, 17, 66, 64, 75, 63, 77, 76, 23, 28, 22, 3, 1, 37, 86, 53, 42, 70, 9, 15, 11, 38, 19, 64, 1, 15, 86, 86, 22, 21, 18, 38, 97, 60, 11, 57, 45, 47}, { 12, 44, 33, 57, 50, 90, 85, 59, 72, 65, 62, 37, 99, 14, 63, 39, 98, 79, 33, 88, 45, 8, 54, 88, 86, 27, 52, 73, 1, 90, 68, 39, 87, 34, 63, 86, 78, 6, 24, 54, 96, 46, 10, 1, 71, 85, 34, 52, 67, 25, 64, 96, 39, 54, 98, 69, 12, 23, 34, 62, 51, 90, 37, 84, 65, 90, 12, 42, 47, 50, 82, 60, 11, 8, 54, 43, 15, 89, 42, 56, 55, 69, 90, 39, 27, 69, 61, 85, 89, 14, 23, 18, 48}, { 87, 31, 75, 39, 34, 55, 52, 68, 52, 7, 89, 36, 2, 41, 40, 34, 17, 42, 82, 92, 50, 73, 30, 31, 50, 76, 47, 46, 44, 72, 20, 25, 20, 99, 2, 56, 63, 25, 92, 99, 76, 16, 32, 28, 62, 12, 89, 91, 56, 98, 21, 35, 68, 24, 41, 31, 87, 39, 90, 44, 24, 41, 18, 52, 27, 61, 3, 72, 70, 64, 26, 46, 18, 1, 22, 54, 25, 65, 27, 98, 53, 23, 38, 88, 19, 22, 71, 13, 48, 60, 74, 20, 84}, { 83, 1, 60, 89, 53, 43, 28, 67, 33, 61, 13, 30, 7, 71, 58, 56, 39, 9, 15, 58, 52, 5, 63, 3, 43, 95, 82, 78, 16, 94, 71, 92, 46, 6, 19, 74, 88, 86, 54, 38, 35, 47, 83, 67, 3, 76, 3, 41, 95, 30, 96, 40, 28, 90, 18, 59, 59, 85, 56, 7, 7, 79, 91, 63, 50, 21, 10, 63, 8, 1, 5, 58, 19, 56, 41, 61, 98, 21, 29, 42, 40, 88, 100, 14, 68, 65, 35, 92, 55, 57, 48, 40, 35}, { 87, 90, 61, 90, 58, 66, 72, 19, 21, 98, 57, 46, 74, 65, 1, 18, 18, 14, 1, 92, 49, 26, 49, 31, 29, 35, 17, 25, 17, 74, 27, 78, 50, 11, 5, 45, 86, 2, 38, 97, 91, 71, 41, 25, 18, 20, 49, 62, 10, 84, 38, 3, 37, 72, 40, 3, 90, 36, 18, 88, 37, 82, 65, 59, 59, 71, 99, 21, 5, 76, 76, 60, 64, 68, 28, 63, 98, 7, 99, 10, 25, 80, 100, 75, 15, 68, 6, 66, 93, 35, 9, 79, 90}, { 22, 54, 54, 35, 40, 77, 79, 58, 79, 89, 85, 10, 1, 49, 11, 47, 34, 24, 24, 79, 87, 15, 67, 51, 62, 46, 84, 70, 58, 77, 51, 71, 8, 56, 33, 34, 95, 8, 3, 35, 12, 93, 76, 64, 56, 92, 5, 35, 92, 32, 31, 82, 13, 25, 1, 37, 44, 45, 73, 100, 18, 94, 85, 14, 14, 73, 65, 36, 66, 86, 2, 82, 39, 23, 38, 22, 58, 78, 49, 2, 48, 33, 39, 70, 30, 99, 98, 67, 4, 48, 13, 58, 85}, { 61, 4, 99, 20, 8, 37, 64, 46, 57, 9, 4, 85, 64, 55, 2, 10, 86, 77, 85, 49, 79, 65, 63, 6, 74, 14, 54, 73, 47, 12, 70, 85, 58, 10, 27, 59, 33, 10, 6, 22, 48, 36, 52, 41, 84, 92, 51, 21, 28, 11, 32, 43, 48, 26, 30, 4, 24, 79, 45, 40, 4, 26, 91, 45, 4, 24, 62, 59, 43, 4, 30, 86, 28, 3, 38, 20, 62, 50, 33, 76, 59, 4, 75, 42, 19, 4, 80, 75, 75, 88, 13, 46, 60}, { 51, 35, 15, 67, 70, 90, 73, 16, 43, 18, 43, 47, 49, 92, 83, 32, 99, 2, 16, 82, 6, 55, 21, 90, 43, 98, 21, 69, 54, 86, 52, 50, 82, 90, 30, 89, 76, 89, 43, 62, 26, 63, 25, 21, 71, 92, 51, 53, 11, 48, 92, 48, 32, 30, 29, 27, 41, 63, 16, 91, 80, 36, 50, 6, 16, 73, 16, 26, 87, 46, 74, 88, 17, 4, 23, 53, 42, 50, 25, 64, 59, 87, 78, 47, 17, 26, 93, 6, 48, 98, 100, 13, 38}, { 14, 3, 95, 60, 7, 85, 49, 85, 100, 9, 75, 95, 78, 4, 55, 69, 52, 11, 27, 45, 9, 44, 74, 60, 92, 92, 13, 6, 79, 26, 8, 18, 26, 43, 32, 91, 56, 57, 35, 28, 75, 59, 84, 24, 3, 98, 13, 31, 37, 84, 16, 71, 66, 71, 85, 82, 45, 55, 19, 19, 74, 5, 54, 5, 70, 48, 19, 15, 45, 11, 30, 1, 52, 57, 58, 84, 98, 92, 62, 22, 96, 32, 14, 37, 55, 76, 13, 79, 44, 99, 17, 45, 73}, { 62, 2, 99, 75, 81, 30, 67, 91, 62, 39, 38, 18, 65, 42, 69, 42, 94, 1, 87, 18, 17, 10, 3, 94, 10, 88, 55, 96, 43, 43, 63, 29, 11, 26, 84, 50, 81, 54, 94, 45, 63, 91, 65, 56, 2, 54, 87, 40, 44, 33, 87, 1, 89, 25, 75, 49, 84, 85, 87, 4, 50, 8, 31, 22, 28, 91, 66, 94, 89, 82, 16, 59, 74, 80, 61, 95, 14, 61, 10, 16, 71, 87, 79, 45, 58, 86, 80, 79, 65, 55, 66, 2, 11}, { 71, 41, 48, 74, 81, 30, 40, 85, 24, 18, 3, 68, 13, 99, 15, 93, 33, 63, 49, 66, 12, 79, 19, 16, 91, 37, 70, 63, 84, 99, 59, 29, 25, 58, 2, 16, 81, 93, 6, 44, 94, 79, 17, 65, 49, 16, 34, 34, 78, 48, 73, 83, 28, 77, 32, 87, 14, 67, 45, 69, 70, 47, 47, 26, 78, 59, 97, 72, 73, 50, 15, 51, 48, 74, 16, 87, 90, 62, 63, 79, 6, 16, 84, 71, 56, 7, 59, 49, 80, 20, 59, 14, 84}, { 47, 33, 44, 63, 8, 52, 95, 96, 69, 89, 28, 68, 14, 3, 77, 86, 86, 89, 74, 1, 4, 21, 65, 62, 56, 91, 76, 55, 59, 83, 11, 24, 53, 5, 60, 8, 19, 40, 93, 7, 55, 73, 25, 71, 9, 30, 34, 22, 43, 64, 1, 57, 17, 73, 84, 87, 38, 14, 73, 92, 3, 90, 48, 93, 73, 15, 2, 14, 45, 86, 24, 45, 18, 78, 84, 55, 85, 3, 18, 18, 7, 15, 65, 32, 36, 94, 8, 43, 22, 72, 10, 44, 96}, { 32, 33, 59, 49, 96, 40, 96, 77, 75, 81, 26, 48, 71, 31, 79, 47, 24, 84, 78, 31, 40, 61, 50, 79, 75, 8, 91, 82, 48, 37, 87, 82, 100, 60, 32, 84, 100, 57, 52, 16, 80, 55, 47, 98, 84, 88, 11, 60, 27, 87, 11, 7, 94, 13, 68, 20, 77, 35, 54, 51, 92, 20, 38, 79, 74, 16, 50, 7, 6, 46, 88, 74, 98, 15, 43, 18, 25, 59, 61, 33, 74, 13, 88, 89, 83, 42, 44, 5, 33, 37, 20, 29, 60}, { 63, 97, 1, 75, 29, 22, 58, 26, 48, 38, 68, 54, 72, 35, 10, 92, 95, 77, 83, 10, 66, 47, 8, 65, 12, 79, 12, 14, 19, 89, 26, 21, 82, 66, 9, 62, 75, 14, 65, 46, 100, 14, 44, 92, 51, 12, 75, 8, 54, 10, 99, 36, 53, 3, 81, 21, 10, 10, 52, 96, 67, 17, 75, 87, 74, 89, 52, 45, 20, 98, 21, 9, 9, 67, 99, 84, 48, 52, 73, 74, 9, 14, 62, 60, 90, 43, 33, 73, 20, 33, 51, 96, 45}, { 83, 65, 93, 31, 83, 87, 49, 53, 84, 57, 20, 96, 75, 95, 94, 76, 2, 89, 65, 51, 79, 96, 85, 48, 53, 92, 62, 34, 67, 88, 61, 63, 19, 23, 87, 99, 45, 69, 31, 81, 49, 49, 35, 30, 72, 30, 93, 43, 42, 52, 64, 4, 75, 17, 48, 45, 100, 65, 77, 38, 82, 100, 62, 54, 14, 72, 51, 20, 54, 75, 3, 47, 10, 80, 4, 4, 83, 82, 25, 20, 63, 26, 78, 47, 99, 40, 53, 56, 68, 44, 76, 73, 18}, { 87, 30, 54, 67, 28, 57, 42, 71, 1, 69, 30, 6, 24, 74, 78, 64, 13, 92, 62, 96, 89, 86, 22, 93, 45, 98, 29, 2, 52, 30, 52, 42, 54, 29, 31, 14, 17, 66, 77, 63, 10, 3, 77, 81, 5, 46, 78, 77, 71, 18, 31, 58, 69, 46, 5, 9, 43, 3, 80, 27, 64, 5, 92, 4, 53, 35, 82, 50, 78, 89, 94, 27, 13, 55, 16, 8, 36, 44, 17, 30, 46, 28, 2, 98, 13, 6, 17, 80, 29, 37, 31, 9, 16}, { 42, 40, 56, 94, 59, 40, 67, 32, 49, 77, 69, 94, 42, 9, 55, 56, 94, 48, 75, 21, 50, 46, 67, 85, 14, 65, 72, 29, 87, 74, 80, 30, 80, 54, 54, 17, 39, 40, 84, 98, 39, 47, 79, 97, 35, 84, 85, 1, 43, 91, 62, 79, 69, 60, 99, 45, 76, 1, 78, 26, 78, 89, 50, 88, 69, 30, 1, 100, 41, 20, 1, 68, 13, 25, 76, 19, 62, 88, 77, 83, 68, 27, 64, 28, 6, 65, 34, 97, 32, 37, 89, 29, 14}, { 96, 68, 30, 11, 89, 55, 85, 2, 76, 40, 70, 81, 62, 29, 67, 68, 97, 2, 86, 5, 74, 94, 47, 78, 26, 75, 42, 50, 87, 35, 38, 60, 29, 28, 39, 58, 20, 6, 73, 77, 20, 25, 24, 33, 98, 35, 99, 98, 61, 88, 71, 85, 10, 31, 41, 29, 59, 83, 28, 74, 5, 4, 11, 95, 71, 37, 56, 86, 34, 76, 61, 93, 75, 97, 92, 45, 89, 94, 92, 44, 43, 20, 76, 85, 5, 79, 28, 78, 79, 100, 19, 57, 1}, { 46, 98, 87, 14, 47, 16, 99, 41, 26, 65, 95, 11, 59, 92, 28, 1, 34, 82, 54, 27, 52, 54, 100, 88, 70, 20, 5, 66, 16, 13, 12, 41, 4, 61, 81, 35, 59, 60, 19, 7, 15, 45, 98, 79, 63, 91, 64, 47, 3, 1, 5, 10, 54, 98, 64, 11, 62, 2, 69, 46, 99, 36, 20, 90, 29, 99, 56, 59, 41, 24, 59, 59, 52, 11, 24, 67, 92, 65, 31, 30, 60, 97, 54, 11, 22, 67, 38, 74, 11, 74, 82, 49, 27}, { 65, 81, 20, 34, 67, 85, 44, 17, 86, 95, 17, 63, 50, 46, 47, 56, 84, 32, 83, 30, 96, 89, 86, 59, 23, 17, 35, 86, 96, 17, 90, 74, 28, 60, 78, 78, 7, 65, 35, 40, 89, 25, 72, 96, 85, 13, 22, 7, 94, 45, 80, 11, 16, 51, 67, 65, 80, 29, 39, 72, 88, 71, 19, 23, 87, 41, 84, 51, 44, 63, 69, 33, 89, 71, 2, 55, 11, 73, 90, 4, 36, 41, 93, 17, 70, 28, 70, 89, 84, 77, 90, 63, 75}, { 52, 34, 3, 78, 92, 30, 25, 85, 1, 79, 85, 34, 63, 20, 100, 8, 99, 35, 7, 58, 58, 41, 20, 88, 8, 24, 9, 97, 69, 19, 86, 84, 18, 93, 69, 45, 95, 84, 29, 86, 11, 2, 4, 18, 70, 69, 3, 45, 73, 62, 75, 54, 57, 98, 86, 23, 33, 98, 95, 98, 90, 63, 55, 48, 86, 8, 10, 28, 11, 66, 44, 67, 39, 83, 75, 80, 56, 27, 75, 75, 62, 23, 21, 19, 92, 37, 73, 71, 81, 50, 70, 76, 63}, { 80, 72, 47, 87, 75, 90, 1, 53, 72, 25, 86, 2, 77, 73, 90, 98, 35, 96, 96, 64, 31, 1, 50, 92, 76, 64, 29, 2, 25, 10, 2, 97, 27, 42, 93, 80, 78, 2, 60, 53, 41, 96, 26, 44, 16, 39, 2, 80, 81, 5, 23, 63, 70, 32, 75, 38, 41, 84, 78, 92, 69, 39, 67, 15, 35, 60, 91, 24, 34, 96, 84, 34, 63, 76, 95, 74, 85, 27, 18, 43, 71, 9, 23, 76, 64, 47, 91, 81, 73, 39, 36, 57, 57}, { 70, 69, 29, 98, 84, 67, 70, 100, 63, 9, 11, 11, 43, 48, 6, 25, 87, 72, 80, 78, 87, 6, 29, 64, 18, 64, 42, 93, 19, 26, 42, 76, 76, 54, 83, 13, 100, 28, 17, 23, 69, 4, 54, 96, 85, 3, 66, 83, 47, 97, 12, 20, 12, 38, 8, 88, 51, 48, 98, 12, 93, 16, 65, 65, 90, 38, 91, 57, 42, 81, 42, 41, 5, 12, 26, 5, 49, 75, 65, 20, 22, 66, 23, 78, 76, 6, 8, 1, 38, 55, 43, 32, 72}, { 24, 52, 63, 93, 59, 33, 34, 12, 58, 63, 20, 84, 22, 30, 17, 95, 96, 36, 53, 91, 2, 9, 77, 43, 44, 45, 12, 14, 57, 33, 2, 61, 55, 1, 39, 64, 14, 78, 36, 11, 26, 2, 62, 80, 94, 15, 84, 4, 18, 65, 34, 18, 77, 26, 38, 95, 36, 9, 45, 41, 50, 9, 8, 3, 25, 32, 17, 12, 4, 83, 82, 39, 12, 77, 100, 11, 71, 56, 15, 65, 46, 81, 3, 7, 17, 37, 1, 14, 69, 94, 18, 62, 46}, { 50, 18, 27, 53, 8, 48, 91, 53, 85, 2, 44, 21, 38, 59, 60, 69, 35, 23, 19, 3, 92, 67, 60, 69, 91, 44, 38, 100, 20, 76, 35, 24, 11, 61, 98, 43, 19, 33, 5, 94, 95, 3, 92, 25, 73, 11, 1, 17, 96, 5, 37, 76, 95, 76, 19, 47, 100, 40, 60, 53, 93, 44, 100, 43, 11, 80, 92, 62, 85, 51, 82, 85, 1, 68, 34, 81, 42, 29, 81, 39, 80, 51, 40, 35, 28, 64, 38, 1, 22, 63, 19, 11, 38}, { 60, 52, 32, 96, 20, 21, 24, 57, 65, 7, 79, 18, 78, 45, 63, 24, 30, 30, 54, 43, 41, 22, 94, 25, 58, 84, 77, 13, 85, 66, 4, 28, 98, 68, 97, 45, 74, 81, 59, 28, 48, 92, 15, 91, 62, 11, 100, 91, 81, 2, 96, 29, 53, 29, 56, 32, 18, 100, 74, 63, 57, 15, 76, 3, 46, 34, 38, 8, 85, 58, 20, 88, 14, 1, 28, 22, 59, 56, 36, 93, 12, 5, 20, 100, 90, 16, 20, 39, 43, 96, 62, 98, 76}, { 51, 20, 54, 92, 95, 90, 61, 88, 91, 10, 81, 67, 20, 6, 55, 98, 46, 57, 11, 91, 40, 95, 46, 95, 2, 20, 7, 16, 7, 14, 92, 19, 25, 77, 86, 62, 31, 50, 57, 77, 95, 99, 28, 21, 33, 24, 97, 15, 95, 90, 10, 67, 46, 42, 54, 29, 54, 6, 56, 49, 62, 52, 51, 100, 89, 65, 27, 70, 52, 50, 94, 35, 76, 50, 25, 32, 62, 39, 35, 89, 18, 53, 64, 55, 56, 23, 5, 65, 18, 13, 52, 53, 60}, { 29, 26, 79, 49, 16, 5, 77, 23, 4, 46, 63, 1, 37, 83, 99, 10, 8, 4, 8, 94, 15, 7, 11, 39, 88, 53, 52, 84, 23, 4, 40, 6, 35, 86, 66, 54, 55, 68, 81, 41, 11, 76, 98, 83, 95, 31, 1, 36, 87, 93, 54, 37, 97, 12, 17, 73, 72, 22, 25, 64, 73, 18, 82, 44, 22, 98, 59, 48, 22, 91, 16, 53, 74, 82, 73, 37, 47, 94, 97, 34, 66, 67, 17, 67, 20, 56, 39, 77, 74, 39, 36, 79, 13}, { 60, 76, 84, 91, 37, 92, 64, 72, 73, 89, 64, 31, 62, 76, 65, 36, 50, 9, 44, 55, 13, 33, 46, 20, 98, 64, 57, 9, 85, 18, 26, 18, 79, 49, 94, 57, 92, 71, 45, 33, 58, 4, 32, 96, 81, 64, 26, 33, 45, 65, 18, 97, 31, 86, 92, 16, 26, 26, 44, 1, 83, 18, 36, 45, 10, 60, 64, 72, 20, 54, 42, 57, 96, 85, 18, 66, 66, 75, 94, 97, 80, 71, 91, 92, 52, 99, 12, 37, 91, 100, 25, 93, 12}, { 60, 49, 88, 9, 45, 95, 2, 11, 13, 62, 23, 76, 78, 71, 88, 59, 26, 87, 18, 15, 34, 14, 89, 81, 14, 46, 27, 70, 65, 3, 15, 51, 4, 85, 76, 61, 57, 35, 75, 29, 80, 26, 62, 62, 53, 86, 39, 94, 83, 14, 30, 58, 99, 48, 25, 21, 35, 72, 36, 88, 31, 49, 13, 79, 20, 36, 71, 36, 2, 18, 85, 59, 88, 16, 26, 42, 2, 32, 64, 7, 35, 38, 49, 18, 7, 8, 23, 4, 55, 14, 83, 61, 86}, { 30, 83, 8, 78, 61, 46, 90, 96, 16, 12, 78, 85, 91, 21, 6, 30, 75, 63, 70, 76, 50, 12, 25, 96, 89, 82, 47, 86, 77, 93, 47, 90, 49, 38, 91, 40, 30, 28, 32, 76, 60, 37, 43, 82, 22, 32, 1, 7, 29, 69, 82, 12, 16, 69, 64, 66, 59, 51, 98, 95, 76, 97, 98, 75, 19, 1, 81, 17, 70, 3, 2, 34, 32, 45, 65, 23, 58, 53, 48, 35, 83, 63, 63, 72, 22, 44, 3, 2, 54, 23, 12, 24, 76}, { 49, 2, 2, 99, 91, 85, 57, 60, 60, 71, 79, 39, 94, 32, 35, 53, 74, 98, 35, 33, 66, 30, 17, 50, 46, 84, 46, 45, 55, 88, 47, 94, 99, 70, 57, 86, 96, 6, 15, 11, 12, 8, 26, 2, 77, 1, 84, 22, 21, 35, 58, 76, 23, 53, 48, 49, 15, 7, 69, 81, 100, 35, 4, 74, 60, 29, 36, 34, 23, 32, 15, 74, 1, 91, 25, 79, 47, 93, 74, 33, 79, 79, 59, 4, 62, 27, 53, 5, 100, 61, 51, 10, 74}, { 90, 85, 16, 54, 85, 59, 19, 88, 13, 27, 2, 46, 82, 75, 11, 82, 71, 37, 59, 32, 86, 42, 67, 85, 61, 43, 90, 97, 41, 10, 74, 38, 38, 61, 14, 98, 100, 42, 16, 100, 42, 65, 44, 98, 84, 52, 82, 93, 78, 16, 84, 79, 38, 48, 46, 8, 90, 44, 66, 3, 29, 61, 22, 89, 94, 65, 86, 40, 16, 52, 21, 48, 99, 28, 9, 40, 33, 64, 29, 71, 76, 82, 62, 14, 38, 78, 57, 87, 48, 50, 97, 68, 40}, { 22, 82, 44, 71, 14, 71, 9, 72, 98, 76, 4, 50, 30, 97, 90, 63, 22, 43, 85, 47, 83, 16, 27, 30, 56, 10, 92, 62, 41, 74, 42, 29, 71, 66, 80, 21, 95, 22, 57, 56, 31, 7, 83, 77, 19, 66, 45, 2, 96, 43, 96, 40, 70, 16, 62, 22, 4, 68, 11, 27, 86, 92, 62, 8, 5, 94, 43, 58, 98, 54, 65, 39, 82, 83, 81, 7, 19, 24, 38, 6, 71, 84, 49, 56, 84, 86, 11, 57, 89, 95, 41, 88, 4}, { 25, 50, 95, 7, 39, 6, 72, 25, 20, 50, 50, 73, 53, 72, 88, 63, 21, 76, 100, 21, 90, 32, 71, 55, 34, 58, 20, 43, 12, 60, 59, 55, 71, 8, 14, 3, 26, 4, 26, 31, 34, 74, 27, 52, 13, 21, 22, 46, 91, 9, 74, 26, 40, 44, 69, 76, 13, 25, 98, 75, 80, 44, 13, 34, 16, 9, 32, 80, 6, 77, 91, 22, 20, 78, 12, 21, 6, 69, 27, 37, 91, 43, 95, 35, 17, 31, 31, 86, 87, 77, 75, 88, 30}, { 97, 45, 43, 75, 59, 45, 99, 97, 72, 39, 18, 93, 36, 46, 44, 26, 42, 27, 100, 52, 26, 55, 45, 90, 55, 32, 87, 2, 8, 2, 61, 25, 92, 5, 48, 74, 53, 29, 98, 69, 2, 67, 76, 63, 56, 17, 93, 68, 54, 78, 64, 17, 1, 76, 83, 86, 77, 99, 39, 82, 11, 11, 65, 1, 3, 77, 52, 45, 61, 40, 51, 30, 78, 80, 47, 40, 3, 78, 45, 98, 42, 56, 2, 55, 63, 49, 89, 23, 77, 84, 38, 32, 80}, { 92, 55, 48, 19, 1, 44, 20, 20, 96, 93, 82, 13, 57, 16, 91, 27, 8, 94, 31, 9, 65, 70, 4, 14, 98, 42, 15, 85, 39, 32, 6, 48, 31, 3, 8, 58, 3, 7, 82, 61, 62, 37, 82, 56, 52, 93, 47, 96, 78, 28, 6, 40, 64, 66, 68, 71, 43, 60, 55, 16, 89, 52, 68, 77, 66, 17, 100, 47, 77, 11, 87, 84, 100, 17, 80, 62, 68, 36, 55, 87, 47, 9, 19, 86, 68, 85, 89, 64, 38, 51, 13, 25, 83}, { 78, 35, 31, 59, 87, 34, 7, 8, 81, 38, 1, 92, 15, 8, 37, 58, 99, 60, 34, 68, 58, 60, 88, 72, 64, 41, 25, 4, 8, 42, 23, 23, 11, 82, 50, 21, 37, 76, 75, 61, 51, 60, 57, 17, 84, 93, 28, 12, 47, 71, 46, 5, 32, 38, 65, 27, 70, 15, 62, 81, 57, 52, 62, 23, 87, 74, 59, 84, 20, 30, 86, 76, 96, 10, 32, 62, 83, 72, 41, 93, 96, 9, 2, 57, 32, 95, 76, 4, 29, 91, 47, 83, 81}, { 29, 59, 25, 15, 92, 13, 31, 75, 38, 42, 88, 31, 38, 19, 77, 95, 30, 69, 22, 7, 59, 34, 59, 95, 7, 66, 100, 36, 48, 60, 85, 61, 83, 78, 11, 65, 15, 35, 10, 80, 30, 56, 85, 16, 47, 60, 73, 80, 84, 27, 19, 38, 25, 78, 90, 34, 80, 14, 41, 63, 7, 98, 81, 6, 19, 22, 46, 100, 12, 15, 96, 43, 90, 22, 72, 22, 53, 18, 30, 23, 95, 43, 33, 45, 98, 82, 45, 80, 66, 52, 68, 43, 18}, { 97, 48, 79, 67, 64, 80, 12, 17, 30, 84, 64, 52, 38, 25, 82, 98, 60, 13, 50, 77, 54, 77, 45, 80, 84, 13, 69, 29, 36, 8, 68, 49, 34, 33, 68, 93, 67, 83, 90, 19, 65, 47, 63, 50, 28, 10, 48, 44, 76, 98, 65, 69, 14, 63, 40, 42, 18, 43, 79, 19, 95, 35, 77, 67, 67, 1, 37, 60, 76, 35, 96, 97, 83, 58, 58, 23, 3, 46, 100, 70, 72, 96, 57, 55, 49, 5, 8, 47, 80, 86, 100, 62, 40}, { 99, 92, 9, 51, 47, 96, 6, 11, 36, 46, 52, 47, 78, 79, 75, 93, 9, 84, 45, 38, 12, 7, 46, 43, 85, 71, 1, 76, 10, 33, 25, 54, 30, 24, 5, 15, 37, 46, 30, 21, 81, 23, 62, 78, 5, 97, 50, 3, 97, 85, 4, 11, 40, 70, 82, 17, 55, 48, 78, 23, 83, 91, 76, 96, 46, 93, 97, 4, 58, 70, 84, 35, 85, 67, 15, 8, 12, 7, 12, 24, 89, 66, 80, 66, 59, 20, 100, 81, 79, 16, 73, 41, 89}, { 70, 99, 86, 22, 97, 1, 78, 64, 2, 29, 58, 58, 6, 43, 57, 31, 87, 35, 12, 21, 12, 51, 29, 6, 82, 35, 1, 85, 27, 86, 28, 97, 13, 90, 24, 58, 81, 47, 28, 19, 78, 15, 15, 41, 96, 38, 1, 9, 63, 97, 38, 80, 40, 63, 20, 37, 58, 22, 56, 10, 9, 98, 65, 83, 63, 90, 30, 4, 13, 29, 56, 87, 32, 30, 19, 47, 80, 56, 51, 57, 100, 61, 61, 68, 55, 48, 28, 45, 85, 15, 55, 86, 15}, { 91, 13, 76, 24, 20, 86, 68, 41, 92, 68, 35, 69, 43, 94, 54, 46, 59, 7, 95, 99, 8, 79, 51, 97, 51, 79, 54, 79, 60, 93, 82, 43, 52, 48, 66, 85, 49, 98, 73, 86, 28, 64, 91, 80, 74, 72, 64, 1, 42, 75, 70, 56, 68, 88, 82, 11, 90, 73, 9, 28, 5, 80, 92, 72, 40, 65, 66, 6, 74, 1, 94, 65, 70, 63, 31, 35, 100, 27, 39, 72, 6, 5, 59, 39, 33, 99, 72, 55, 26, 70, 24, 67, 72}, { 51, 52, 100, 35, 29, 98, 98, 40, 13, 1, 47, 32, 89, 42, 79, 97, 79, 53, 33, 23, 21, 69, 78, 15, 94, 62, 59, 28, 88, 50, 2, 94, 20, 82, 30, 62, 23, 56, 77, 11, 52, 62, 68, 52, 54, 83, 94, 93, 30, 57, 71, 30, 81, 30, 43, 76, 98, 39, 68, 65, 38, 63, 51, 62, 51, 46, 41, 59, 90, 11, 48, 63, 38, 100, 99, 83, 97, 47, 100, 84, 76, 97, 19, 17, 76, 97, 65, 60, 20, 40, 52, 16, 18}, { 12, 75, 37, 51, 46, 58, 67, 94, 15, 2, 11, 39, 94, 28, 8, 16, 51, 82, 14, 23, 13, 47, 91, 50, 70, 71, 7, 28, 18, 58, 19, 67, 36, 53, 45, 42, 52, 86, 63, 52, 10, 24, 25, 85, 35, 16, 14, 70, 89, 28, 25, 71, 75, 71, 4, 50, 75, 70, 21, 71, 89, 86, 55, 4, 46, 7, 16, 58, 76, 66, 96, 65, 21, 31, 71, 19, 94, 5, 9, 50, 18, 32, 34, 15, 34, 24, 10, 41, 2, 69, 2, 90, 84}, { 1, 90, 23, 85, 37, 14, 63, 100, 19, 98, 38, 25, 87, 4, 89, 60, 28, 53, 71, 88, 21, 27, 54, 83, 64, 77, 87, 55, 20, 10, 56, 74, 96, 92, 1, 56, 84, 63, 27, 8, 96, 9, 46, 88, 61, 2, 39, 47, 73, 39, 70, 5, 23, 14, 43, 26, 32, 65, 80, 93, 61, 88, 51, 43, 27, 69, 99, 68, 66, 97, 7, 62, 29, 46, 10, 14, 46, 42, 39, 94, 70, 57, 50, 57, 17, 36, 4, 66, 41, 27, 81, 76, 74}, { 79, 27, 49, 73, 77, 7, 53, 78, 27, 37, 70, 38, 85, 69, 27, 81, 76, 73, 44, 69, 16, 41, 63, 2, 85, 42, 55, 74, 45, 76, 88, 97, 8, 3, 83, 66, 79, 90, 22, 21, 97, 79, 18, 12, 38, 54, 11, 11, 74, 20, 73, 83, 1, 47, 77, 5, 21, 66, 57, 33, 89, 18, 21, 71, 77, 100, 13, 68, 62, 3, 25, 85, 69, 13, 76, 62, 4, 53, 99, 54, 14, 64, 70, 24, 85, 48, 14, 40, 89, 37, 94, 23, 99}, { 58, 86, 99, 80, 78, 37, 60, 41, 18, 43, 24, 25, 50, 91, 64, 66, 45, 23, 64, 36, 23, 26, 10, 10, 100, 30, 57, 1, 11, 28, 97, 53, 37, 78, 4, 27, 46, 54, 82, 45, 36, 8, 21, 41, 1, 47, 9, 7, 2, 7, 89, 93, 73, 61, 42, 56, 26, 13, 90, 64, 27, 61, 29, 49, 89, 30, 20, 80, 48, 9, 52, 30, 37, 30, 32, 27, 63, 90, 64, 46, 4, 40, 95, 76, 10, 13, 67, 81, 54, 51, 96, 16, 99}, { 64, 93, 52, 95, 26, 80, 92, 59, 59, 72, 31, 10, 10, 24, 97, 98, 44, 23, 52, 17, 5, 98, 100, 69, 82, 71, 20, 48, 12, 66, 66, 49, 79, 90, 67, 77, 22, 51, 72, 46, 8, 6, 78, 85, 36, 67, 54, 39, 56, 72, 86, 54, 94, 18, 85, 67, 85, 38, 94, 61, 45, 49, 66, 40, 40, 7, 86, 79, 28, 38, 96, 39, 84, 93, 47, 77, 56, 55, 95, 9, 100, 19, 54, 28, 8, 90, 96, 90, 95, 51, 15, 72, 87}, { 10, 61, 39, 84, 4, 26, 42, 47, 46, 37, 73, 86, 44, 70, 78, 10, 93, 35, 55, 56, 70, 30, 81, 39, 31, 99, 21, 71, 82, 33, 36, 25, 8, 33, 52, 39, 94, 64, 52, 31, 19, 61, 31, 80, 61, 73, 95, 47, 99, 5, 12, 13, 23, 85, 11, 64, 91, 75, 28, 93, 46, 1, 3, 71, 92, 54, 10, 94, 18, 49, 54, 56, 29, 25, 59, 51, 9, 83, 22, 22, 47, 56, 22, 98, 14, 4, 69, 36, 25, 78, 62, 71, 52}, { 41, 19, 84, 18, 22, 41, 63, 34, 45, 77, 30, 8, 83, 9, 48, 98, 53, 91, 82, 96, 49, 60, 53, 58, 6, 92, 61, 80, 19, 38, 31, 33, 100, 52, 85, 100, 25, 36, 63, 4, 17, 3, 11, 42, 89, 85, 51, 95, 2, 92, 91, 86, 66, 23, 56, 63, 63, 60, 24, 37, 11, 14, 92, 56, 73, 63, 46, 39, 91, 66, 91, 63, 27, 57, 29, 66, 71, 47, 4, 29, 58, 37, 25, 49, 92, 16, 73, 30, 2, 19, 10, 94, 32}, { 10, 4, 5, 54, 78, 20, 56, 44, 96, 41, 19, 9, 90, 57, 27, 70, 72, 80, 11, 100, 70, 52, 37, 40, 48, 50, 11, 94, 66, 1, 9, 2, 99, 9, 75, 73, 64, 78, 90, 26, 11, 41, 18, 52, 90, 23, 50, 24, 31, 66, 11, 27, 43, 84, 94, 67, 18, 73, 68, 32, 42, 9, 1, 64, 95, 85, 88, 56, 5, 91, 42, 46, 68, 2, 3, 10, 4, 69, 62, 17, 50, 86, 32, 41, 17, 62, 61, 14, 9, 34, 26, 64, 62}, { 72, 37, 90, 100, 64, 63, 59, 48, 83, 60, 10, 88, 34, 68, 74, 93, 46, 77, 57, 79, 43, 57, 66, 44, 56, 32, 7, 32, 65, 89, 64, 84, 95, 80, 21, 27, 68, 24, 39, 53, 3, 4, 84, 19, 33, 100, 25, 19, 86, 71, 83, 41, 17, 14, 69, 43, 4, 41, 60, 62, 51, 18, 28, 99, 97, 1, 20, 36, 56, 24, 12, 26, 3, 41, 1, 74, 43, 2, 96, 84, 17, 90, 7, 51, 7, 98, 53, 9, 52, 26, 58, 38, 71}, { 18, 80, 25, 41, 29, 87, 9, 14, 28, 44, 61, 78, 77, 32, 60, 41, 71, 95, 73, 53, 7, 96, 69, 73, 82, 12, 15, 53, 35, 2, 90, 32, 81, 30, 20, 68, 51, 12, 45, 53, 28, 43, 82, 15, 7, 73, 83, 6, 54, 37, 49, 100, 64, 79, 73, 5, 47, 70, 62, 47, 84, 75, 12, 5, 89, 65, 14, 3, 47, 34, 41, 22, 52, 75, 94, 97, 61, 41, 63, 66, 66, 73, 97, 17, 24, 50, 23, 77, 95, 72, 1, 62, 40}, { 71, 34, 22, 8, 38, 78, 14, 3, 41, 7, 35, 31, 37, 13, 52, 71, 2, 81, 80, 33, 33, 100, 84, 22, 34, 60, 7, 53, 98, 22, 37, 32, 75, 11, 28, 68, 14, 48, 11, 85, 20, 17, 45, 92, 26, 93, 63, 25, 30, 55, 12, 23, 49, 6, 28, 99, 84, 69, 9, 13, 65, 53, 17, 9, 83, 25, 94, 51, 7, 87, 64, 63, 68, 100, 80, 97, 63, 74, 24, 33, 17, 23, 17, 24, 85, 38, 66, 81, 53, 5, 28, 41, 6}, { 51, 74, 67, 93, 17, 78, 9, 46, 26, 91, 72, 73, 72, 2, 18, 14, 22, 34, 14, 1, 44, 46, 35, 34, 81, 51, 44, 7, 27, 96, 90, 4, 42, 23, 58, 14, 47, 46, 15, 71, 33, 47, 8, 3, 80, 10, 66, 49, 90, 21, 1, 88, 66, 81, 11, 10, 50, 94, 91, 5, 13, 57, 74, 25, 95, 12, 44, 95, 42, 47, 21, 24, 63, 17, 57, 41, 100, 82, 6, 55, 67, 38, 10, 70, 71, 96, 40, 98, 74, 73, 91, 94, 7}, { 24, 30, 89, 35, 7, 41, 45, 8, 12, 17, 93, 58, 67, 70, 20, 90, 6, 24, 12, 5, 45, 88, 80, 94, 64, 97, 62, 1, 11, 49, 68, 43, 61, 53, 48, 5, 30, 78, 30, 62, 11, 71, 88, 62, 17, 6, 91, 2, 88, 74, 89, 29, 83, 24, 12, 44, 59, 31, 39, 72, 50, 54, 69, 13, 70, 6, 35, 2, 56, 79, 88, 13, 5, 16, 4, 45, 18, 24, 48, 36, 67, 4, 40, 53, 33, 67, 3, 1, 22, 18, 32, 33, 37}, { 32, 59, 39, 98, 70, 36, 75, 9, 93, 56, 99, 1, 42, 98, 89, 38, 82, 1, 34, 25, 13, 91, 98, 41, 56, 57, 76, 66, 30, 14, 76, 79, 77, 42, 37, 100, 31, 64, 29, 100, 38, 98, 2, 76, 30, 92, 27, 20, 94, 59, 31, 68, 78, 60, 35, 63, 46, 94, 23, 75, 84, 19, 85, 91, 87, 47, 74, 89, 46, 15, 18, 84, 28, 90, 9, 38, 67, 9, 20, 81, 29, 23, 53, 72, 64, 12, 95, 81, 85, 78, 51, 71, 83}, { 85, 15, 69, 50, 51, 76, 98, 92, 31, 54, 53, 67, 6, 25, 75, 68, 30, 83, 6, 37, 18, 3, 72, 72, 4, 75, 19, 68, 28, 78, 28, 41, 88, 53, 39, 94, 97, 57, 66, 70, 22, 78, 3, 86, 8, 61, 42, 96, 86, 51, 6, 21, 26, 88, 37, 47, 50, 67, 86, 10, 86, 18, 23, 54, 4, 78, 82, 54, 7, 89, 56, 23, 61, 31, 39, 27, 36, 50, 73, 30, 76, 71, 87, 45, 2, 5, 30, 37, 100, 3, 8, 13, 11}, { 66, 7, 49, 47, 88, 64, 21, 44, 5, 51, 83, 69, 53, 16, 82, 66, 42, 92, 63, 69, 41, 100, 6, 71, 66, 54, 27, 95, 69, 19, 7, 13, 94, 10, 35, 28, 52, 76, 10, 84, 56, 98, 40, 78, 21, 95, 36, 40, 14, 74, 70, 85, 58, 53, 17, 52, 18, 35, 34, 98, 51, 86, 64, 88, 66, 55, 71, 41, 51, 50, 23, 46, 63, 34, 31, 28, 94, 50, 60, 100, 69, 86, 27, 81, 15, 42, 98, 15, 34, 11, 40, 75, 82}, { 7, 39, 61, 89, 80, 6, 87, 88, 48, 37, 89, 38, 63, 13, 98, 16, 41, 80, 65, 81, 79, 26, 90, 68, 74, 54, 53, 65, 28, 66, 25, 17, 39, 76, 60, 57, 48, 18, 41, 45, 20, 9, 88, 52, 50, 94, 26, 60, 19, 21, 60, 53, 51, 20, 17, 25, 18, 51, 78, 95, 22, 33, 65, 99, 53, 12, 43, 35, 14, 61, 71, 85, 10, 78, 34, 27, 20, 78, 28, 80, 88, 90, 12, 53, 11, 72, 39, 45, 6, 5, 62, 10, 84}, { 1, 8, 19, 77, 71, 57, 92, 20, 19, 39, 76, 79, 26, 20, 63, 60, 54, 73, 62, 73, 98, 8, 17, 48, 2, 43, 45, 22, 88, 71, 40, 43, 86, 77, 8, 37, 19, 90, 23, 65, 20, 69, 26, 70, 88, 49, 16, 88, 96, 73, 67, 39, 25, 64, 94, 86, 36, 15, 82, 11, 41, 11, 95, 3, 8, 94, 2, 22, 39, 50, 57, 49, 66, 4, 19, 66, 46, 60, 53, 75, 9, 57, 61, 94, 76, 45, 26, 72, 100, 100, 50, 89, 16}, { 73, 25, 77, 77, 94, 54, 8, 39, 93, 58, 81, 70, 44, 77, 85, 70, 76, 80, 51, 25, 34, 61, 51, 53, 14, 15, 9, 30, 83, 98, 42, 25, 16, 42, 72, 33, 94, 91, 87, 27, 54, 42, 81, 73, 93, 37, 67, 69, 6, 35, 63, 26, 47, 29, 62, 99, 67, 25, 70, 68, 83, 49, 45, 9, 65, 65, 61, 24, 29, 55, 94, 50, 57, 20, 27, 99, 1, 73, 61, 60, 20, 24, 65, 8, 53, 19, 21, 85, 76, 66, 42, 94, 80}, { 66, 33, 38, 75, 27, 82, 30, 49, 60, 63, 86, 72, 60, 88, 57, 55, 57, 55, 50, 13, 90, 20, 20, 31, 3, 78, 87, 74, 33, 29, 99, 47, 93, 46, 70, 76, 6, 64, 11, 63, 47, 95, 82, 54, 30, 20, 62, 10, 77, 75, 100, 3, 100, 83, 13, 79, 5, 90, 72, 36, 87, 27, 13, 41, 33, 64, 50, 77, 71, 83, 13, 71, 86, 88, 80, 39, 92, 93, 42, 99, 99, 38, 22, 88, 47, 8, 42, 66, 40, 33, 1, 56, 43}, { 51, 97, 30, 32, 71, 56, 53, 16, 50, 9, 58, 50, 19, 21, 91, 63, 74, 84, 1, 15, 98, 99, 23, 8, 34, 53, 49, 20, 17, 14, 20, 43, 77, 12, 16, 7, 20, 74, 8, 25, 82, 54, 39, 51, 23, 54, 77, 77, 11, 53, 72, 22, 5, 97, 62, 4, 56, 93, 11, 85, 4, 98, 16, 53, 40, 75, 66, 75, 83, 29, 43, 76, 68, 79, 41, 52, 58, 48, 95, 2, 69, 21, 50, 11, 30, 21, 20, 36, 18, 55, 30, 91, 38}, { 81, 77, 83, 86, 74, 79, 43, 82, 60, 2, 46, 2, 77, 88, 88, 16, 33, 7, 99, 62, 99, 47, 22, 47, 65, 47, 30, 17, 74, 23, 43, 63, 4, 85, 28, 38, 58, 93, 34, 7, 82, 48, 18, 50, 98, 28, 47, 61, 70, 75, 64, 12, 57, 1, 12, 29, 12, 78, 12, 54, 98, 9, 69, 95, 58, 64, 51, 75, 31, 45, 45, 39, 97, 40, 45, 54, 13, 13, 38, 26, 82, 15, 63, 98, 90, 100, 69, 40, 74, 34, 79, 84, 93}, { 14, 78, 29, 69, 89, 71, 52, 93, 12, 37, 80, 63, 59, 87, 48, 81, 48, 28, 93, 84, 56, 6, 46, 37, 43, 22, 20, 63, 58, 91, 26, 19, 33, 2, 19, 24, 24, 7, 78, 51, 95, 41, 92, 97, 32, 60, 57, 2, 55, 49, 44, 30, 38, 23, 45, 69, 21, 84, 64, 76, 8, 56, 21, 27, 18, 74, 15, 22, 34, 13, 76, 67, 88, 50, 30, 31, 14, 54, 37, 76, 67, 44, 58, 9, 74, 81, 13, 31, 81, 30, 16, 15, 45}, { 13, 63, 21, 32, 20, 14, 30, 25, 28, 42, 56, 45, 22, 6, 64, 94, 54, 61, 49, 46, 45, 70, 99, 71, 70, 36, 99, 53, 41, 24, 25, 94, 9, 72, 92, 97, 71, 97, 20, 8, 99, 14, 36, 4, 74, 30, 41, 50, 9, 21, 2, 17, 56, 95, 25, 26, 75, 72, 95, 100, 21, 93, 88, 34, 21, 81, 90, 50, 82, 52, 85, 78, 89, 49, 87, 31, 47, 13, 65, 37, 52, 3, 92, 63, 46, 66, 43, 93, 24, 93, 40, 92, 24}, { 87, 42, 19, 94, 61, 35, 42, 68, 48, 33, 78, 68, 49, 28, 19, 68, 86, 89, 25, 19, 72, 68, 91, 21, 54, 9, 46, 26, 65, 15, 92, 59, 48, 75, 54, 96, 21, 41, 31, 50, 53, 20, 87, 21, 78, 75, 41, 40, 95, 84, 15, 60, 72, 25, 64, 22, 72, 16, 65, 77, 27, 11, 29, 20, 24, 46, 100, 75, 1, 30, 57, 61, 38, 30, 82, 93, 81, 82, 49, 50, 99, 29, 68, 47, 63, 37, 17, 39, 37, 30, 68, 77, 48}, { 32, 86, 11, 50, 73, 96, 73, 69, 92, 78, 7, 49, 64, 4, 91, 33, 58, 4, 14, 26, 43, 3, 4, 59, 90, 31, 62, 24, 91, 14, 68, 48, 84, 66, 45, 46, 41, 77, 66, 53, 45, 21, 72, 66, 21, 39, 50, 42, 25, 83, 19, 16, 83, 42, 27, 72, 53, 37, 25, 48, 80, 59, 27, 50, 90, 85, 30, 41, 6, 45, 70, 43, 86, 6, 99, 89, 37, 86, 83, 57, 63, 30, 50, 97, 61, 69, 47, 51, 47, 59, 16, 24, 87}, { 23, 65, 11, 24, 79, 81, 76, 68, 78, 26, 46, 82, 5, 80, 87, 11, 62, 15, 14, 74, 11, 57, 91, 66, 12, 100, 90, 43, 11, 45, 78, 50, 94, 30, 39, 63, 30, 8, 72, 72, 35, 75, 92, 28, 28, 78, 74, 88, 18, 10, 41, 8, 74, 76, 62, 81, 42, 12, 29, 93, 25, 7, 8, 47, 3, 99, 92, 13, 94, 17, 30, 49, 89, 54, 33, 89, 19, 86, 88, 53, 52, 8, 88, 29, 12, 48, 35, 86, 48, 58, 26, 85, 37}, { 52, 6, 50, 85, 89, 96, 71, 38, 88, 23, 5, 14, 61, 98, 75, 87, 81, 13, 21, 51, 54, 59, 95, 59, 99, 49, 99, 59, 47, 94, 26, 38, 56, 80, 48, 28, 20, 46, 93, 11, 8, 21, 1, 2, 62, 82, 22, 69, 87, 44, 4, 78, 59, 46, 27, 44, 98, 71, 79, 15, 14, 47, 97, 34, 52, 50, 17, 74, 74, 19, 48, 83, 3, 16, 93, 69, 25, 58, 35, 12, 16, 60, 69, 39, 56, 31, 1, 69, 58, 24, 68, 16, 89}, { 35, 20, 55, 1, 30, 42, 28, 96, 80, 33, 27, 90, 37, 53, 21, 85, 24, 45, 65, 15, 8, 70, 1, 80, 34, 98, 44, 97, 43, 61, 33, 37, 32, 41, 7, 39, 68, 34, 58, 97, 96, 49, 68, 51, 66, 80, 63, 87, 48, 4, 43, 60, 13, 2, 90, 4, 5, 74, 89, 76, 37, 69, 28, 26, 66, 12, 85, 73, 97, 13, 26, 21, 78, 75, 51, 25, 28, 77, 36, 1, 55, 56, 9, 26, 11, 14, 17, 100, 28, 68, 96, 52, 9}, { 100, 6, 44, 84, 83, 46, 50, 84, 95, 72, 8, 62, 14, 71, 63, 11, 72, 5, 76, 21, 72, 43, 88, 16, 32, 75, 10, 67, 1, 29, 60, 30, 50, 25, 35, 2, 77, 40, 39, 35, 11, 49, 41, 14, 79, 95, 74, 21, 86, 72, 11, 58, 86, 22, 18, 4, 77, 6, 73, 75, 55, 79, 30, 86, 94, 34, 49, 79, 66, 7, 88, 9, 49, 93, 76, 35, 31, 37, 72, 6, 74, 73, 42, 43, 52, 66, 30, 90, 85, 41, 87, 6, 57}, { 94, 72, 39, 33, 22, 96, 10, 73, 32, 36, 64, 91, 46, 49, 94, 60, 6, 55, 28, 57, 33, 100, 18, 16, 91, 71, 97, 37, 41, 83, 46, 4, 11, 61, 75, 70, 90, 83, 68, 18, 57, 33, 42, 37, 83, 75, 93, 61, 77, 72, 60, 91, 53, 18, 79, 21, 64, 90, 95, 27, 18, 94, 11, 24, 43, 22, 67, 59, 79, 47, 15, 80, 7, 35, 39, 31, 95, 18, 66, 36, 84, 89, 53, 71, 39, 67, 66, 34, 46, 60, 65, 80, 82}, { 36, 78, 22, 15, 95, 63, 81, 4, 77, 93, 82, 10, 69, 31, 18, 60, 34, 52, 64, 93, 91, 99, 79, 87, 62, 92, 36, 47, 38, 40, 3, 57, 5, 28, 78, 33, 44, 61, 33, 73, 29, 88, 71, 55, 95, 100, 94, 82, 76, 22, 86, 67, 10, 41, 40, 50, 72, 55, 27, 31, 31, 68, 97, 30, 14, 14, 50, 28, 70, 92, 61, 25, 55, 33, 27, 87, 2, 56, 63, 38, 95, 37, 99, 61, 81, 53, 19, 73, 18, 46, 62, 87, 90}, { 36, 54, 86, 33, 87, 59, 90, 56, 41, 62, 53, 84, 48, 1, 88, 7, 42, 81, 46, 57, 69, 94, 78, 59, 45, 29, 33, 84, 88, 34, 25, 86, 52, 23, 66, 53, 8, 88, 12, 42, 36, 55, 83, 95, 31, 63, 5, 87, 19, 10, 36, 68, 87, 41, 70, 64, 7, 49, 94, 89, 14, 41, 68, 57, 22, 22, 16, 62, 58, 92, 58, 49, 84, 69, 66, 32, 83, 3, 20, 30, 19, 77, 27, 29, 4, 12, 18, 18, 36, 55, 52, 24, 85}};
                    int array_draw_rectangle[162][93] = {{ 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210}, { 210, 34, 95, 32, 73, 70, 54, 96, 40, 38, 33, 64, 5, 95, 83, 61, 51, 89, 16, 67, 99, 16, 100, 89, 91, 46, 5, 57, 95, 94, 57, 60, 39, 79, 1, 71, 56, 17, 85, 43, 48, 9, 52, 64, 5, 86, 5, 59, 61, 35, 23, 16, 1, 55, 72, 27, 77, 49, 52, 2, 99, 37, 66, 43, 51, 21, 42, 98, 74, 86, 9, 99, 50, 61, 41, 58, 97, 41, 4, 59, 55, 5, 3, 74, 86, 50, 56, 68, 46, 90, 23, 46, 210}, { 210, 90, 41, 17, 39, 15, 74, 85, 25, 40, 18, 4, 70, 24, 40, 18, 53, 15, 93, 48, 58, 69, 55, 78, 42, 72, 57, 2, 7, 76, 23, 54, 33, 85, 64, 42, 25, 76, 77, 33, 85, 39, 1, 80, 43, 8, 96, 75, 22, 91, 16, 16, 37, 72, 72, 42, 56, 9, 60, 26, 43, 76, 7, 96, 30, 29, 83, 13, 53, 21, 61, 8, 18, 38, 37, 3, 14, 27, 7, 6, 84, 68, 73, 22, 67, 22, 59, 26, 76, 10, 30, 94, 210}, { 210, 55, 62, 64, 34, 45, 85, 41, 77, 57, 37, 89, 18, 58, 87, 72, 15, 52, 31, 75, 95, 60, 36, 71, 2, 28, 42, 76, 96, 20, 2, 30, 38, 39, 13, 64, 25, 17, 23, 25, 94, 78, 65, 3, 89, 73, 24, 47, 26, 57, 83, 46, 57, 22, 66, 75, 83, 10, 96, 58, 81, 2, 91, 17, 96, 2, 36, 12, 73, 42, 81, 17, 68, 87, 58, 5, 30, 100, 63, 10, 5, 42, 48, 4, 44, 4, 83, 96, 44, 61, 77, 48, 210}, { 210, 18, 80, 50, 52, 3, 29, 17, 11, 33, 94, 61, 20, 23, 59, 7, 49, 100, 57, 34, 25, 38, 12, 12, 13, 34, 52, 97, 77, 3, 1, 92, 17, 75, 30, 98, 12, 16, 19, 25, 3, 34, 100, 52, 33, 55, 45, 99, 87, 94, 1, 92, 80, 11, 26, 25, 47, 21, 1, 27, 44, 43, 73, 61, 2, 64, 24, 63, 58, 10, 3, 68, 26, 17, 100, 71, 59, 22, 28, 87, 41, 88, 50, 81, 84, 31, 30, 100, 94, 24, 46, 15, 210}, { 210, 64, 25, 96, 76, 61, 88, 86, 89, 17, 22, 75, 18, 79, 62, 34, 100, 42, 75, 2, 61, 4, 65, 30, 2, 1, 93, 10, 5, 11, 23, 84, 94, 2, 9, 31, 30, 6, 1, 29, 100, 8, 81, 58, 82, 37, 75, 80, 97, 90, 23, 70, 73, 82, 48, 86, 16, 70, 68, 92, 78, 34, 33, 83, 80, 77, 31, 2, 41, 79, 3, 37, 89, 49, 10, 74, 34, 40, 89, 65, 89, 14, 86, 37, 65, 81, 55, 76, 78, 21, 37, 74, 210}, { 210, 72, 50, 40, 73, 99, 94, 67, 38, 97, 77, 28, 91, 20, 43, 69, 94, 83, 81, 65, 18, 20, 63, 11, 42, 47, 20, 2, 99, 62, 15, 70, 21, 8, 65, 79, 25, 83, 22, 18, 82, 7, 73, 37, 34, 98, 40, 80, 47, 67, 32, 63, 35, 18, 33, 88, 64, 61, 66, 15, 63, 72, 19, 61, 18, 79, 87, 19, 5, 74, 39, 79, 10, 16, 39, 47, 17, 57, 17, 82, 86, 89, 35, 100, 35, 7, 49, 57, 4, 8, 66, 58, 210}, { 210, 31, 62, 70, 40, 47, 29, 73, 86, 33, 33, 63, 19, 59, 3, 49, 43, 89, 97, 2, 32, 52, 60, 82, 91, 82, 73, 59, 51, 30, 86, 14, 95, 16, 79, 69, 59, 25, 61, 54, 76, 21, 11, 21, 40, 57, 77, 92, 26, 72, 35, 13, 38, 68, 28, 17, 50, 77, 84, 60, 84, 51, 9, 71, 39, 88, 6, 82, 8, 67, 8, 64, 66, 18, 87, 67, 2, 67, 82, 70, 24, 40, 4, 63, 99, 3, 76, 49, 34, 64, 69, 14, 210}, { 210, 32, 44, 51, 40, 73, 88, 65, 63, 86, 23, 82, 70, 92, 18, 29, 75, 2, 61, 6, 57, 64, 30, 8, 15, 53, 30, 73, 84, 89, 15, 79, 16, 24, 46, 99, 14, 49, 96, 29, 44, 24, 85, 59, 75, 98, 98, 43, 13, 45, 39, 5, 93, 37, 73, 77, 17, 99, 64, 65, 49, 11, 78, 18, 12, 52, 25, 40, 95, 23, 28, 49, 68, 60, 77, 72, 6, 20, 59, 77, 53, 34, 51, 31, 57, 11, 56, 47, 89, 29, 33, 41, 210}, { 210, 46, 46, 98, 14, 74, 40, 58, 53, 71, 63, 59, 100, 73, 2, 17, 97, 54, 66, 38, 25, 7, 77, 78, 81, 15, 99, 78, 53, 68, 35, 47, 73, 97, 37, 59, 83, 73, 66, 54, 66, 25, 90, 46, 17, 31, 38, 13, 70, 29, 55, 92, 15, 50, 99, 30, 38, 80, 14, 41, 77, 59, 58, 51, 47, 95, 100, 22, 66, 14, 57, 72, 39, 61, 26, 55, 56, 90, 49, 77, 5, 19, 55, 8, 83, 27, 93, 31, 99, 24, 43, 91, 210}, { 210, 77, 9, 28, 95, 66, 69, 1, 80, 81, 78, 51, 41, 95, 84, 3, 85, 46, 64, 47, 30, 17, 39, 15, 84, 13, 81, 36, 64, 33, 79, 23, 89, 8, 3, 94, 65, 24, 52, 6, 54, 98, 56, 74, 12, 2, 30, 80, 40, 24, 42, 20, 68, 66, 36, 50, 32, 73, 74, 90, 36, 34, 68, 16, 30, 80, 74, 20, 39, 31, 70, 17, 74, 24, 32, 100, 2, 73, 98, 31, 1, 45, 82, 19, 96, 70, 62, 21, 65, 6, 15, 65, 210}, { 210, 15, 49, 74, 66, 48, 24, 95, 21, 74, 16, 67, 93, 20, 52, 61, 82, 10, 78, 60, 55, 8, 5, 56, 30, 67, 77, 25, 2, 69, 30, 26, 40, 59, 12, 62, 35, 28, 42, 35, 1, 47, 19, 96, 5, 46, 63, 56, 26, 83, 86, 95, 16, 25, 22, 34, 55, 96, 72, 72, 23, 34, 31, 55, 17, 23, 16, 67, 79, 59, 31, 11, 53, 72, 32, 22, 54, 52, 9, 14, 62, 49, 33, 70, 72, 4, 88, 79, 2, 63, 81, 94, 210}, { 210, 8, 93, 3, 23, 80, 14, 94, 71, 94, 59, 80, 88, 11, 21, 60, 17, 30, 79, 46, 17, 55, 41, 9, 27, 42, 86, 51, 91, 47, 40, 59, 3, 74, 62, 42, 23, 32, 32, 3, 52, 92, 76, 25, 62, 46, 27, 53, 65, 2, 82, 51, 89, 87, 32, 59, 46, 36, 88, 77, 89, 7, 97, 84, 48, 90, 11, 23, 33, 74, 22, 40, 16, 1, 50, 15, 38, 65, 93, 35, 83, 85, 70, 85, 97, 88, 74, 64, 67, 55, 48, 59, 210}, { 210, 16, 53, 92, 94, 54, 58, 68, 80, 82, 91, 53, 6, 5, 88, 62, 59, 32, 48, 73, 94, 70, 29, 10, 18, 50, 70, 71, 6, 25, 65, 83, 64, 12, 51, 73, 56, 7, 92, 27, 2, 18, 74, 54, 81, 78, 68, 90, 56, 26, 41, 95, 76, 57, 35, 37, 93, 9, 16, 7, 67, 46, 4, 14, 77, 96, 29, 62, 86, 43, 32, 42, 46, 2, 99, 96, 81, 91, 58, 44, 26, 91, 79, 41, 64, 47, 8, 65, 79, 53, 60, 25, 210}, { 210, 76, 99, 3, 72, 89, 14, 75, 72, 2, 37, 79, 97, 38, 74, 41, 88, 58, 83, 88, 61, 92, 41, 45, 21, 75, 14, 6, 77, 84, 47, 75, 13, 47, 37, 44, 71, 56, 77, 64, 42, 70, 21, 25, 25, 84, 100, 12, 34, 98, 82, 41, 58, 19, 83, 6, 50, 96, 18, 36, 22, 25, 78, 98, 3, 50, 29, 80, 69, 8, 96, 99, 15, 95, 96, 96, 55, 80, 27, 13, 50, 59, 92, 8, 32, 25, 88, 31, 15, 25, 23, 27, 210}, { 210, 66, 35, 61, 5, 82, 27, 100, 73, 27, 87, 48, 19, 41, 60, 62, 55, 98, 99, 37, 37, 91, 62, 19, 55, 12, 41, 44, 7, 21, 94, 60, 29, 27, 64, 91, 24, 65, 54, 68, 41, 97, 87, 51, 52, 63, 88, 6, 59, 76, 49, 57, 89, 91, 78, 55, 28, 57, 34, 75, 43, 23, 21, 11, 45, 47, 64, 37, 10, 36, 57, 96, 54, 63, 18, 92, 27, 24, 9, 94, 23, 98, 93, 98, 21, 13, 33, 10, 31, 23, 33, 67, 210}, { 210, 89, 74, 25, 9, 94, 2, 61, 73, 61, 1, 100, 67, 10, 21, 96, 9, 100, 11, 90, 87, 33, 31, 13, 60, 34, 29, 24, 99, 15, 38, 48, 71, 90, 51, 21, 29, 56, 69, 100, 50, 57, 69, 55, 77, 53, 45, 3, 83, 91, 71, 20, 72, 10, 93, 68, 3, 58, 79, 59, 57, 56, 57, 17, 64, 62, 47, 21, 2, 1, 14, 80, 50, 61, 26, 81, 71, 3, 96, 82, 85, 83, 70, 19, 62, 48, 78, 44, 7, 62, 56, 90, 210}, { 210, 47, 12, 80, 36, 70, 66, 83, 44, 27, 72, 71, 3, 98, 66, 50, 37, 67, 9, 52, 83, 27, 57, 76, 9, 16, 1, 87, 94, 90, 31, 39, 85, 82, 53, 95, 26, 86, 14, 86, 47, 71, 68, 78, 12, 34, 56, 66, 65, 37, 63, 18, 62, 54, 96, 83, 27, 96, 79, 9, 45, 7, 64, 48, 44, 69, 20, 69, 59, 38, 93, 56, 39, 28, 38, 53, 3, 99, 30, 46, 22, 24, 39, 77, 23, 31, 4, 6, 45, 45, 67, 88, 210}, { 210, 11, 16, 69, 52, 76, 16, 74, 34, 22, 47, 25, 28, 40, 63, 98, 15, 100, 28, 91, 15, 17, 57, 89, 81, 24, 76, 38, 75, 93, 51, 81, 1, 81, 2, 47, 4, 72, 44, 67, 69, 19, 36, 16, 80, 63, 60, 49, 67, 15, 85, 97, 85, 52, 21, 61, 27, 38, 55, 80, 62, 43, 99, 84, 92, 92, 41, 50, 30, 7, 13, 48, 6, 76, 38, 7, 71, 56, 98, 89, 18, 48, 76, 23, 34, 43, 61, 24, 74, 87, 81, 63, 210}, { 210, 93, 18, 71, 62, 8, 49, 17, 79, 56, 1, 10, 15, 54, 98, 35, 31, 55, 52, 8, 72, 18, 57, 44, 11, 61, 39, 57, 68, 14, 50, 9, 20, 47, 65, 16, 8, 40, 63, 37, 80, 41, 22, 57, 76, 45, 94, 66, 75, 94, 39, 10, 79, 90, 7, 30, 41, 50, 12, 55, 35, 89, 6, 34, 53, 3, 39, 74, 7, 95, 98, 2, 6, 18, 61, 80, 36, 35, 93, 46, 83, 29, 92, 89, 1, 72, 7, 50, 3, 20, 73, 54, 210}, { 210, 78, 78, 84, 91, 88, 15, 24, 61, 32, 100, 82, 58, 73, 21, 88, 56, 49, 31, 24, 14, 65, 41, 67, 55, 1, 32, 62, 92, 1, 93, 38, 46, 36, 72, 8, 60, 74, 19, 75, 14, 69, 2, 77, 90, 33, 65, 10, 23, 98, 96, 88, 52, 88, 29, 39, 88, 19, 75, 79, 25, 53, 4, 24, 57, 20, 61, 60, 54, 45, 51, 37, 52, 55, 4, 17, 26, 12, 96, 53, 96, 94, 17, 17, 91, 55, 85, 90, 27, 7, 65, 45, 210}, { 210, 64, 36, 6, 66, 74, 54, 89, 15, 97, 36, 17, 17, 27, 85, 36, 10, 47, 77, 9, 39, 69, 87, 24, 11, 14, 77, 26, 65, 9, 85, 93, 48, 91, 21, 14, 47, 18, 27, 34, 91, 97, 46, 49, 31, 86, 50, 46, 31, 57, 53, 38, 29, 60, 7, 85, 1, 94, 58, 37, 63, 7, 87, 82, 61, 58, 86, 8, 99, 23, 30, 30, 73, 35, 98, 15, 17, 20, 53, 46, 13, 53, 80, 68, 96, 66, 57, 8, 1, 4, 29, 95, 210}, { 210, 29, 65, 100, 27, 59, 19, 18, 50, 93, 32, 76, 95, 70, 2, 40, 7, 66, 15, 70, 50, 39, 77, 63, 75, 75, 23, 96, 30, 14, 14, 42, 87, 88, 55, 22, 88, 76, 38, 96, 1, 8, 35, 67, 64, 5, 62, 44, 72, 62, 42, 8, 52, 95, 56, 21, 13, 68, 39, 69, 74, 53, 11, 47, 23, 88, 22, 70, 20, 38, 33, 96, 38, 89, 9, 52, 55, 21, 30, 34, 23, 71, 53, 22, 7, 7, 31, 2, 76, 88, 34, 33, 210}, { 210, 99, 26, 87, 97, 78, 70, 49, 42, 22, 77, 32, 32, 45, 20, 49, 16, 100, 58, 58, 66, 7, 92, 61, 95, 98, 50, 49, 9, 54, 45, 86, 99, 48, 45, 17, 12, 90, 36, 44, 11, 22, 57, 83, 36, 35, 5, 77, 29, 32, 81, 15, 8, 75, 3, 42, 8, 40, 41, 77, 74, 86, 46, 78, 59, 21, 14, 71, 98, 39, 59, 81, 84, 56, 43, 64, 51, 69, 68, 97, 38, 57, 89, 18, 24, 49, 44, 68, 61, 70, 69, 44, 210}, { 210, 78, 90, 98, 81, 45, 13, 78, 73, 96, 48, 26, 51, 98, 10, 27, 31, 65, 19, 33, 41, 62, 95, 99, 98, 42, 38, 96, 71, 65, 86, 39, 100, 21, 82, 66, 28, 50, 10, 90, 56, 20, 21, 71, 37, 19, 26, 6, 88, 42, 79, 77, 72, 20, 23, 49, 7, 52, 84, 89, 39, 9, 68, 12, 41, 94, 81, 86, 67, 88, 100, 89, 87, 55, 28, 54, 92, 87, 24, 31, 73, 17, 9, 38, 53, 70, 10, 53, 72, 25, 6, 95, 210}, { 210, 85, 60, 70, 76, 99, 77, 62, 16, 12, 47, 29, 89, 61, 58, 7, 75, 25, 83, 70, 94, 40, 86, 68, 12, 57, 93, 29, 36, 35, 64, 71, 50, 42, 47, 12, 19, 89, 55, 59, 14, 54, 45, 23, 79, 68, 59, 80, 42, 13, 25, 71, 24, 33, 67, 28, 76, 89, 47, 55, 13, 72, 80, 52, 6, 70, 85, 84, 13, 41, 64, 19, 48, 14, 85, 51, 73, 50, 66, 37, 55, 80, 91, 30, 60, 98, 29, 83, 74, 64, 67, 8, 210}, { 210, 53, 30, 26, 4, 8, 84, 58, 86, 52, 3, 84, 38, 91, 56, 32, 95, 70, 68, 7, 41, 24, 93, 23, 40, 65, 30, 89, 33, 91, 90, 62, 3, 59, 86, 37, 55, 78, 17, 60, 73, 39, 77, 36, 69, 51, 100, 38, 88, 35, 75, 50, 53, 19, 78, 87, 37, 33, 29, 10, 6, 61, 84, 64, 97, 75, 23, 24, 3, 12, 19, 45, 32, 3, 42, 57, 86, 27, 50, 26, 82, 63, 98, 35, 2, 46, 76, 50, 19, 32, 46, 9, 210}, { 210, 35, 79, 57, 81, 57, 34, 1, 18, 97, 19, 7, 33, 86, 22, 1, 29, 37, 77, 31, 16, 72, 12, 95, 43, 29, 73, 63, 37, 30, 43, 32, 89, 30, 2, 75, 75, 46, 97, 15, 21, 80, 63, 93, 21, 42, 7, 11, 92, 15, 56, 16, 62, 73, 63, 76, 51, 46, 91, 29, 98, 76, 96, 1, 7, 99, 21, 21, 78, 40, 98, 53, 44, 77, 75, 27, 97, 53, 70, 39, 3, 66, 1, 57, 41, 23, 85, 45, 68, 57, 26, 9, 210}, { 210, 19, 95, 79, 9, 51, 63, 26, 88, 39, 100, 4, 92, 79, 13, 35, 48, 77, 88, 24, 72, 90, 90, 90, 32, 82, 56, 46, 94, 56, 13, 55, 21, 75, 45, 60, 44, 73, 65, 9, 65, 60, 72, 76, 3, 40, 17, 6, 17, 100, 30, 55, 57, 85, 96, 64, 46, 23, 11, 5, 95, 10, 1, 91, 48, 88, 61, 22, 97, 71, 36, 47, 77, 27, 18, 40, 44, 60, 99, 92, 97, 8, 19, 32, 48, 55, 49, 98, 47, 68, 74, 30, 210}, { 210, 28, 77, 98, 72, 30, 49, 80, 89, 28, 40, 99, 36, 98, 67, 6, 94, 97, 84, 32, 49, 46, 40, 86, 38, 3, 91, 85, 97, 15, 27, 78, 90, 73, 63, 76, 78, 7, 55, 51, 31, 77, 49, 98, 9, 12, 43, 7, 25, 42, 59, 48, 54, 23, 70, 63, 9, 23, 18, 62, 21, 16, 61, 90, 68, 43, 43, 30, 86, 68, 96, 91, 29, 84, 7, 37, 89, 44, 82, 49, 3, 73, 67, 64, 18, 39, 47, 55, 83, 51, 96, 59, 210}, { 210, 20, 64, 6, 90, 86, 55, 64, 69, 4, 66, 100, 23, 38, 20, 70, 58, 67, 95, 86, 44, 31, 2, 65, 32, 7, 71, 78, 6, 54, 87, 52, 18, 90, 13, 21, 33, 93, 65, 35, 27, 70, 50, 70, 22, 33, 57, 7, 68, 4, 10, 11, 7, 8, 13, 78, 5, 88, 26, 65, 31, 88, 73, 62, 7, 21, 63, 86, 14, 62, 31, 22, 52, 65, 22, 33, 55, 44, 66, 69, 96, 56, 50, 30, 36, 23, 39, 13, 86, 50, 94, 50, 210}, { 210, 21, 44, 30, 10, 8, 46, 36, 37, 51, 72, 47, 47, 5, 62, 20, 64, 71, 59, 48, 5, 9, 25, 67, 37, 22, 62, 99, 11, 56, 91, 13, 52, 56, 44, 66, 86, 7, 15, 23, 83, 84, 79, 34, 72, 53, 28, 88, 97, 40, 85, 66, 76, 91, 89, 2, 48, 44, 31, 29, 88, 50, 3, 57, 6, 14, 41, 44, 89, 34, 76, 55, 76, 3, 77, 51, 70, 61, 51, 80, 1, 8, 94, 97, 32, 5, 36, 54, 79, 30, 47, 7, 210}, { 210, 58, 39, 91, 100, 21, 86, 1, 9, 30, 94, 27, 36, 78, 30, 65, 9, 15, 70, 22, 61, 83, 91, 50, 82, 43, 59, 72, 71, 21, 100, 10, 73, 54, 49, 32, 79, 34, 72, 69, 57, 65, 60, 86, 69, 39, 20, 51, 10, 69, 4, 22, 69, 80, 100, 13, 33, 65, 52, 58, 99, 75, 76, 37, 94, 27, 37, 69, 16, 38, 21, 78, 58, 83, 72, 85, 68, 8, 39, 70, 28, 88, 55, 83, 1, 17, 44, 72, 49, 73, 79, 90, 210}, { 210, 91, 35, 54, 58, 49, 96, 38, 85, 61, 64, 81, 79, 48, 48, 60, 30, 7, 54, 86, 44, 53, 52, 94, 2, 53, 75, 98, 24, 26, 67, 96, 8, 12, 51, 34, 43, 19, 57, 8, 95, 22, 12, 99, 97, 66, 98, 79, 36, 79, 70, 45, 53, 7, 99, 20, 36, 44, 97, 52, 70, 94, 55, 15, 65, 1, 69, 67, 66, 8, 4, 14, 75, 42, 26, 96, 20, 76, 32, 18, 29, 36, 27, 3, 66, 95, 2, 39, 74, 96, 23, 2, 210}, { 210, 26, 80, 97, 47, 28, 67, 92, 36, 79, 74, 57, 19, 86, 61, 33, 67, 29, 76, 74, 60, 69, 18, 35, 100, 92, 28, 37, 4, 74, 5, 98, 21, 42, 46, 46, 26, 85, 5, 64, 1, 16, 33, 11, 9, 92, 25, 66, 31, 16, 41, 38, 58, 30, 14, 89, 100, 58, 25, 33, 52, 32, 86, 18, 33, 65, 59, 13, 81, 8, 97, 84, 76, 37, 99, 47, 48, 24, 99, 46, 2, 79, 81, 31, 12, 46, 15, 75, 83, 42, 11, 50, 210}, { 210, 27, 77, 96, 51, 63, 60, 43, 19, 57, 41, 80, 60, 25, 89, 68, 2, 55, 30, 85, 59, 96, 70, 56, 66, 60, 3, 75, 51, 80, 34, 98, 7, 81, 33, 36, 24, 69, 93, 4, 70, 89, 72, 1, 94, 99, 99, 30, 88, 96, 58, 16, 95, 98, 10, 31, 86, 26, 53, 9, 41, 15, 85, 100, 8, 22, 40, 70, 5, 55, 75, 85, 46, 54, 52, 67, 88, 98, 3, 45, 25, 11, 21, 71, 80, 81, 44, 1, 86, 59, 31, 52, 210}, { 210, 1, 88, 35, 54, 38, 20, 54, 26, 31, 71, 95, 77, 61, 53, 41, 14, 77, 71, 80, 70, 61, 88, 53, 72, 15, 97, 16, 55, 55, 16, 56, 48, 29, 5, 40, 45, 36, 7, 75, 84, 12, 69, 83, 40, 46, 93, 35, 50, 93, 55, 15, 28, 16, 23, 64, 68, 69, 32, 3, 82, 49, 52, 80, 29, 31, 86, 17, 6, 54, 15, 32, 76, 89, 99, 70, 99, 14, 49, 22, 27, 70, 96, 38, 32, 98, 60, 55, 24, 64, 53, 87, 210}, { 210, 89, 24, 43, 4, 9, 40, 70, 100, 74, 68, 68, 18, 89, 70, 67, 63, 64, 48, 21, 72, 37, 28, 19, 92, 75, 53, 3, 94, 36, 44, 20, 5, 4, 39, 68, 58, 37, 47, 89, 76, 90, 25, 33, 72, 14, 37, 80, 100, 54, 46, 47, 95, 28, 87, 34, 39, 32, 26, 10, 48, 86, 38, 21, 45, 55, 49, 67, 93, 39, 39, 26, 78, 3, 71, 89, 96, 40, 32, 6, 93, 67, 60, 57, 10, 97, 72, 71, 23, 12, 45, 27, 210}, { 210, 81, 46, 59, 25, 48, 92, 83, 32, 98, 24, 27, 80, 10, 97, 92, 37, 40, 67, 52, 36, 53, 85, 93, 3, 23, 65, 68, 67, 22, 10, 1, 54, 6, 26, 79, 87, 74, 22, 24, 85, 75, 93, 19, 34, 67, 30, 56, 36, 88, 81, 58, 22, 25, 72, 9, 44, 49, 9, 71, 56, 49, 99, 53, 24, 75, 59, 43, 28, 94, 97, 48, 81, 57, 35, 96, 53, 84, 12, 37, 36, 22, 17, 34, 17, 40, 25, 54, 10, 43, 60, 48, 210}, { 210, 53, 11, 73, 64, 48, 90, 45, 81, 69, 5, 50, 55, 21, 64, 83, 68, 16, 80, 24, 1, 13, 39, 69, 83, 60, 60, 99, 25, 79, 41, 10, 67, 96, 43, 60, 24, 69, 27, 21, 67, 20, 53, 90, 68, 54, 21, 85, 38, 32, 18, 13, 65, 1, 40, 6, 72, 61, 31, 82, 2, 50, 43, 94, 17, 78, 72, 48, 11, 6, 60, 79, 30, 1, 54, 26, 88, 84, 65, 11, 32, 81, 78, 96, 87, 60, 46, 69, 30, 98, 61, 6, 210}, { 210, 12, 62, 10, 60, 83, 82, 44, 85, 40, 22, 57, 40, 20, 53, 77, 10, 74, 67, 78, 90, 84, 74, 77, 31, 5, 45, 64, 54, 78, 25, 59, 21, 77, 10, 61, 96, 66, 51, 68, 12, 65, 46, 29, 75, 53, 45, 59, 62, 34, 71, 24, 56, 14, 39, 75, 88, 71, 62, 53, 50, 95, 28, 9, 12, 5, 22, 44, 21, 31, 52, 73, 58, 18, 61, 29, 5, 98, 43, 42, 15, 8, 34, 35, 45, 98, 43, 63, 13, 60, 76, 56, 210}, { 210, 96, 74, 35, 74, 43, 93, 50, 62, 34, 9, 65, 29, 69, 36, 32, 29, 48, 28, 64, 39, 18, 54, 92, 37, 38, 46, 9, 81, 100, 78, 75, 1, 7, 91, 15, 65, 59, 15, 29, 17, 97, 7, 68, 53, 36, 29, 84, 44, 41, 48, 41, 56, 88, 37, 73, 82, 42, 12, 40, 47, 66, 73, 61, 62, 6, 6, 37, 73, 2, 17, 84, 66, 61, 40, 3, 73, 83, 12, 24, 40, 92, 93, 29, 88, 7, 98, 52, 89, 23, 19, 2, 210}, { 210, 52, 55, 87, 18, 53, 59, 41, 70, 21, 26, 28, 54, 27, 96, 19, 81, 74, 36, 34, 96, 6, 58, 27, 26, 70, 91, 55, 100, 57, 70, 54, 4, 88, 9, 16, 33, 79, 94, 18, 3, 84, 43, 100, 23, 71, 40, 53, 81, 39, 22, 30, 88, 20, 15, 9, 25, 90, 25, 7, 19, 21, 50, 80, 65, 57, 37, 47, 37, 47, 94, 74, 71, 12, 23, 67, 48, 52, 2, 67, 24, 8, 28, 98, 40, 82, 55, 58, 49, 85, 44, 95, 210}, { 210, 36, 41, 73, 90, 83, 55, 3, 16, 67, 97, 66, 87, 75, 49, 47, 76, 72, 32, 44, 90, 41, 43, 78, 23, 53, 91, 22, 81, 76, 90, 72, 10, 79, 16, 69, 51, 92, 79, 30, 26, 60, 16, 98, 54, 84, 29, 25, 59, 55, 20, 93, 79, 20, 31, 33, 84, 21, 86, 8, 74, 4, 40, 41, 33, 58, 89, 12, 34, 33, 44, 3, 17, 9, 57, 98, 82, 37, 84, 53, 72, 64, 10, 86, 53, 37, 53, 89, 63, 49, 80, 54, 210}, { 210, 41, 51, 29, 60, 81, 27, 74, 49, 19, 20, 65, 66, 2, 1, 70, 42, 25, 19, 44, 14, 11, 85, 96, 40, 2, 86, 86, 63, 33, 27, 51, 40, 69, 54, 27, 35, 73, 19, 1, 27, 95, 59, 62, 21, 7, 50, 40, 4, 78, 34, 87, 52, 77, 61, 30, 94, 94, 90, 91, 68, 83, 2, 49, 39, 33, 53, 11, 9, 98, 78, 9, 22, 28, 93, 100, 33, 25, 54, 16, 90, 93, 40, 41, 64, 59, 80, 59, 66, 86, 1, 73, 210}, { 210, 50, 88, 66, 78, 85, 64, 77, 90, 99, 76, 76, 89, 97, 85, 71, 56, 55, 60, 14, 15, 74, 57, 73, 61, 81, 66, 9, 14, 54, 60, 78, 88, 16, 27, 76, 57, 19, 58, 69, 54, 42, 16, 64, 10, 67, 79, 95, 46, 39, 41, 21, 25, 50, 77, 34, 96, 58, 72, 93, 90, 25, 64, 89, 1, 28, 64, 73, 18, 100, 1, 62, 94, 92, 5, 71, 78, 65, 90, 6, 3, 41, 50, 44, 80, 36, 100, 14, 57, 44, 97, 19, 210}, { 210, 94, 22, 27, 26, 33, 70, 83, 62, 63, 19, 19, 15, 29, 56, 46, 84, 93, 26, 84, 50, 87, 84, 77, 17, 58, 77, 57, 83, 47, 14, 11, 8, 98, 2, 65, 5, 15, 38, 73, 32, 55, 49, 24, 9, 6, 62, 61, 4, 22, 85, 36, 11, 16, 98, 80, 93, 55, 63, 65, 25, 5, 92, 5, 20, 11, 59, 86, 41, 38, 53, 14, 6, 89, 15, 18, 60, 87, 90, 77, 27, 50, 50, 58, 54, 71, 64, 29, 59, 38, 82, 22, 210}, { 210, 56, 22, 69, 1, 2, 2, 26, 36, 93, 33, 86, 100, 93, 8, 18, 15, 41, 53, 78, 80, 14, 73, 51, 96, 93, 62, 82, 59, 32, 14, 8, 12, 81, 90, 50, 78, 75, 16, 13, 89, 18, 20, 65, 48, 24, 92, 67, 2, 13, 72, 86, 45, 63, 57, 78, 47, 63, 13, 15, 57, 51, 100, 85, 94, 14, 19, 69, 71, 71, 81, 44, 78, 71, 42, 49, 39, 49, 32, 34, 91, 13, 93, 66, 87, 59, 99, 10, 32, 64, 57, 87, 210}, { 210, 49, 7, 64, 97, 60, 90, 92, 89, 44, 3, 54, 10, 40, 37, 72, 20, 63, 9, 73, 23, 57, 37, 29, 11, 58, 11, 54, 65, 59, 64, 84, 90, 34, 91, 80, 69, 99, 36, 11, 96, 60, 39, 4, 18, 68, 84, 71, 88, 23, 4, 70, 16, 44, 60, 61, 20, 7, 47, 84, 2, 54, 66, 71, 56, 54, 45, 24, 7, 93, 3, 87, 29, 26, 37, 80, 75, 87, 86, 75, 12, 35, 10, 17, 97, 59, 67, 90, 6, 62, 60, 80, 210}, { 210, 47, 19, 83, 49, 46, 77, 31, 56, 59, 80, 92, 72, 17, 56, 93, 73, 52, 92, 6, 63, 74, 15, 70, 98, 13, 38, 30, 22, 7, 19, 4, 80, 72, 92, 18, 48, 73, 96, 99, 40, 83, 29, 72, 4, 39, 98, 79, 89, 51, 79, 13, 60, 11, 17, 5, 30, 56, 42, 63, 8, 76, 11, 49, 2, 65, 3, 98, 7, 6, 53, 84, 2, 21, 28, 8, 3, 63, 59, 79, 76, 45, 60, 77, 72, 50, 86, 3, 70, 37, 60, 45, 210}, { 210, 16, 76, 40, 100, 10, 71, 32, 6, 41, 53, 58, 39, 73, 93, 94, 11, 49, 34, 16, 27, 92, 53, 98, 45, 83, 100, 26, 71, 40, 98, 6, 44, 17, 53, 66, 46, 92, 72, 47, 2, 73, 4, 10, 97, 81, 9, 37, 83, 49, 3, 38, 72, 53, 30, 50, 15, 10, 91, 97, 53, 36, 21, 56, 8, 77, 74, 65, 47, 94, 21, 34, 61, 77, 6, 73, 60, 24, 54, 39, 89, 58, 90, 91, 64, 52, 21, 50, 81, 41, 43, 100, 210}, { 210, 39, 33, 65, 39, 19, 3, 33, 7, 80, 34, 54, 65, 83, 99, 77, 16, 81, 69, 36, 33, 68, 74, 35, 58, 20, 41, 89, 39, 18, 73, 54, 65, 83, 65, 68, 67, 72, 52, 63, 58, 32, 24, 2, 9, 40, 95, 21, 40, 3, 50, 77, 55, 69, 46, 36, 51, 75, 76, 16, 43, 52, 42, 13, 18, 33, 73, 59, 5, 38, 47, 89, 32, 66, 99, 24, 25, 99, 42, 41, 55, 12, 72, 95, 33, 95, 64, 19, 87, 38, 93, 50, 210}, { 210, 94, 80, 69, 46, 14, 99, 91, 57, 6, 90, 66, 38, 3, 84, 71, 46, 83, 63, 96, 27, 25, 94, 29, 56, 57, 17, 63, 46, 83, 43, 99, 44, 10, 69, 59, 88, 92, 4, 85, 86, 65, 68, 81, 37, 69, 51, 7, 62, 14, 24, 57, 45, 15, 61, 93, 58, 82, 28, 6, 34, 16, 55, 74, 12, 39, 35, 36, 53, 62, 13, 70, 84, 29, 55, 51, 9, 12, 18, 12, 42, 56, 19, 79, 96, 33, 98, 97, 49, 18, 30, 6, 210}, { 210, 91, 25, 7, 83, 96, 76, 31, 83, 89, 74, 89, 56, 11, 98, 50, 30, 90, 85, 2, 21, 2, 98, 17, 12, 79, 64, 90, 20, 43, 60, 37, 75, 47, 22, 8, 38, 35, 77, 13, 30, 32, 36, 20, 15, 41, 67, 66, 25, 96, 49, 90, 40, 62, 41, 54, 100, 77, 80, 85, 38, 10, 55, 41, 24, 13, 18, 25, 16, 75, 18, 61, 16, 22, 13, 1, 28, 30, 21, 8, 2, 60, 85, 62, 35, 53, 74, 99, 4, 93, 34, 72, 210}, { 210, 35, 66, 40, 64, 4, 61, 73, 13, 16, 30, 87, 93, 77, 58, 22, 64, 37, 88, 68, 96, 81, 6, 97, 35, 9, 11, 57, 34, 34, 38, 46, 14, 97, 6, 25, 38, 79, 24, 84, 82, 100, 82, 31, 74, 42, 54, 47, 15, 72, 13, 82, 100, 87, 90, 54, 39, 4, 74, 84, 72, 65, 65, 97, 80, 43, 70, 82, 48, 83, 44, 96, 83, 82, 11, 98, 47, 35, 44, 88, 52, 3, 50, 74, 66, 27, 78, 1, 6, 17, 44, 30, 210}, { 210, 80, 30, 55, 37, 40, 98, 10, 100, 52, 29, 72, 92, 43, 7, 12, 92, 85, 33, 77, 73, 3, 84, 57, 41, 17, 3, 83, 74, 88, 33, 92, 20, 16, 43, 83, 82, 25, 50, 26, 68, 96, 74, 21, 35, 59, 50, 36, 9, 49, 33, 51, 65, 12, 32, 93, 63, 38, 92, 42, 29, 65, 1, 28, 78, 89, 51, 28, 90, 58, 52, 97, 17, 24, 38, 70, 23, 69, 95, 47, 81, 19, 79, 45, 66, 45, 12, 8, 27, 1, 78, 64, 210}, { 210, 93, 98, 36, 21, 23, 56, 86, 24, 31, 77, 79, 9, 56, 60, 77, 52, 98, 13, 86, 79, 95, 13, 62, 12, 50, 30, 84, 15, 96, 31, 71, 48, 13, 20, 5, 35, 97, 17, 45, 91, 92, 84, 94, 11, 64, 86, 23, 12, 46, 95, 100, 77, 50, 7, 38, 7, 32, 59, 3, 38, 81, 9, 57, 43, 55, 3, 89, 59, 86, 2, 14, 62, 96, 9, 48, 23, 1, 7, 37, 8, 55, 28, 92, 12, 53, 41, 76, 19, 55, 6, 63, 210}, { 210, 63, 46, 49, 60, 16, 1, 34, 86, 36, 14, 4, 29, 42, 20, 28, 45, 83, 63, 75, 45, 23, 83, 44, 48, 36, 89, 50, 40, 90, 77, 3, 27, 18, 87, 68, 10, 49, 42, 9, 25, 25, 51, 57, 13, 81, 68, 100, 52, 40, 53, 60, 72, 35, 11, 43, 37, 16, 66, 12, 22, 48, 42, 56, 25, 13, 43, 84, 42, 38, 56, 14, 36, 83, 94, 70, 69, 91, 11, 34, 75, 35, 54, 95, 49, 36, 30, 21, 36, 5, 95, 97, 210}, { 210, 30, 92, 7, 88, 59, 98, 88, 68, 90, 53, 93, 67, 84, 20, 86, 21, 68, 94, 57, 21, 4, 34, 65, 81, 94, 85, 53, 68, 92, 41, 97, 84, 73, 10, 11, 25, 9, 36, 34, 75, 90, 65, 96, 5, 92, 5, 49, 81, 85, 17, 31, 76, 48, 53, 12, 48, 69, 12, 18, 98, 30, 99, 11, 56, 52, 65, 17, 79, 92, 23, 44, 58, 49, 98, 59, 72, 32, 17, 61, 62, 63, 49, 97, 63, 51, 22, 28, 40, 78, 96, 97, 210}, { 210, 59, 22, 6, 52, 98, 88, 92, 80, 20, 25, 36, 32, 88, 14, 76, 92, 79, 73, 66, 70, 39, 39, 94, 70, 84, 72, 35, 69, 31, 94, 70, 75, 10, 32, 100, 22, 41, 100, 26, 42, 1, 11, 87, 100, 52, 28, 26, 35, 54, 15, 64, 37, 53, 45, 76, 8, 40, 62, 28, 57, 69, 69, 49, 38, 97, 33, 93, 28, 55, 31, 28, 15, 37, 14, 64, 65, 76, 55, 36, 56, 58, 86, 70, 73, 22, 23, 94, 5, 3, 86, 9, 210}, { 210, 87, 34, 32, 7, 98, 83, 1, 1, 16, 40, 26, 31, 8, 2, 86, 29, 85, 56, 24, 93, 94, 97, 81, 95, 57, 42, 97, 82, 34, 41, 5, 100, 60, 37, 32, 11, 44, 44, 46, 79, 94, 53, 71, 2, 84, 41, 17, 38, 82, 38, 88, 99, 83, 51, 44, 31, 19, 67, 41, 10, 96, 26, 26, 6, 71, 15, 28, 76, 3, 91, 62, 17, 12, 11, 83, 91, 49, 23, 40, 30, 23, 43, 64, 45, 60, 64, 75, 32, 60, 18, 68, 210}, { 210, 21, 59, 6, 52, 6, 4, 97, 48, 99, 49, 71, 71, 1, 21, 68, 57, 36, 61, 14, 41, 42, 47, 65, 89, 7, 1, 81, 17, 70, 5, 19, 63, 31, 84, 85, 15, 51, 64, 80, 30, 9, 51, 97, 57, 79, 4, 18, 50, 86, 35, 32, 16, 55, 42, 30, 44, 31, 7, 22, 16, 17, 69, 62, 2, 12, 4, 93, 34, 70, 1, 78, 2, 52, 14, 71, 8, 29, 83, 56, 84, 29, 57, 4, 92, 16, 14, 96, 71, 64, 88, 53, 210}, { 210, 78, 63, 76, 80, 7, 95, 40, 91, 45, 48, 2, 92, 99, 85, 56, 32, 97, 85, 95, 12, 56, 64, 16, 54, 78, 8, 40, 80, 81, 20, 3, 5, 91, 36, 69, 39, 33, 50, 50, 38, 99, 54, 78, 75, 63, 48, 59, 72, 53, 22, 91, 61, 36, 42, 39, 32, 43, 25, 45, 55, 11, 34, 18, 93, 44, 51, 50, 94, 39, 25, 38, 11, 95, 47, 83, 4, 5, 66, 72, 85, 67, 85, 92, 96, 1, 12, 74, 42, 43, 56, 86, 210}, { 210, 93, 25, 92, 72, 25, 70, 5, 88, 85, 81, 67, 25, 6, 19, 63, 22, 1, 33, 19, 66, 54, 88, 68, 72, 86, 76, 24, 33, 27, 27, 85, 59, 34, 27, 22, 71, 77, 58, 85, 11, 56, 11, 95, 59, 24, 89, 4, 33, 16, 79, 61, 56, 11, 7, 1, 80, 66, 54, 100, 41, 36, 40, 20, 39, 31, 97, 59, 1, 12, 18, 80, 77, 67, 66, 28, 32, 55, 82, 36, 75, 10, 28, 75, 48, 37, 98, 78, 20, 75, 84, 22, 210}, { 210, 60, 5, 69, 46, 73, 48, 89, 78, 21, 65, 25, 95, 14, 30, 54, 68, 92, 92, 51, 13, 85, 63, 2, 50, 53, 54, 76, 55, 2, 10, 4, 5, 99, 67, 78, 47, 82, 56, 41, 36, 59, 26, 26, 87, 27, 95, 87, 94, 41, 64, 70, 5, 81, 99, 74, 70, 77, 41, 73, 78, 18, 19, 45, 32, 86, 33, 88, 73, 46, 16, 73, 1, 91, 36, 91, 15, 32, 81, 75, 83, 28, 34, 45, 6, 58, 15, 95, 41, 74, 1, 46, 210}, { 210, 85, 42, 84, 83, 54, 52, 21, 73, 28, 85, 25, 12, 23, 54, 10, 92, 16, 87, 82, 85, 13, 60, 7, 10, 89, 71, 1, 70, 31, 1, 69, 69, 32, 69, 34, 38, 55, 66, 14, 43, 72, 77, 82, 34, 2, 16, 83, 18, 82, 74, 46, 42, 40, 51, 86, 81, 49, 74, 71, 92, 28, 71, 13, 25, 2, 45, 35, 96, 83, 23, 36, 73, 32, 31, 2, 29, 6, 93, 82, 29, 47, 54, 43, 54, 83, 56, 86, 92, 11, 96, 33, 210}, { 210, 9, 79, 19, 35, 15, 97, 19, 37, 4, 70, 69, 26, 95, 35, 87, 25, 37, 95, 22, 15, 64, 98, 56, 52, 62, 2, 78, 55, 7, 40, 80, 1, 6, 37, 51, 68, 30, 56, 64, 52, 63, 38, 81, 45, 77, 61, 5, 85, 18, 85, 41, 39, 98, 25, 70, 71, 40, 85, 13, 63, 74, 100, 21, 75, 81, 77, 2, 85, 10, 24, 10, 62, 80, 45, 40, 84, 58, 48, 60, 62, 68, 91, 52, 60, 6, 49, 3, 40, 73, 97, 74, 210}, { 210, 88, 75, 11, 32, 77, 81, 90, 96, 42, 82, 2, 50, 99, 66, 31, 97, 29, 94, 10, 15, 82, 71, 75, 80, 27, 34, 53, 74, 77, 46, 89, 80, 25, 54, 79, 25, 25, 86, 29, 99, 4, 57, 69, 42, 19, 5, 55, 85, 55, 47, 86, 63, 55, 21, 33, 80, 78, 78, 39, 52, 35, 40, 12, 68, 80, 2, 57, 6, 28, 19, 74, 17, 84, 17, 95, 29, 33, 41, 81, 73, 2, 15, 80, 75, 24, 76, 11, 82, 9, 89, 66, 210}, { 210, 3, 94, 19, 3, 65, 97, 39, 14, 28, 49, 12, 41, 31, 88, 43, 54, 6, 37, 53, 59, 51, 33, 33, 62, 33, 92, 94, 3, 25, 98, 71, 49, 7, 19, 14, 43, 91, 99, 81, 36, 7, 100, 35, 40, 12, 83, 12, 71, 33, 84, 20, 21, 12, 19, 85, 58, 50, 81, 9, 38, 34, 39, 41, 24, 83, 99, 72, 62, 55, 57, 4, 39, 93, 4, 56, 34, 26, 28, 42, 19, 13, 32, 2, 72, 75, 37, 91, 99, 16, 78, 95, 210}, { 210, 54, 10, 20, 52, 53, 9, 49, 9, 76, 9, 12, 28, 42, 19, 68, 53, 72, 65, 23, 48, 41, 24, 40, 1, 31, 8, 64, 88, 88, 60, 79, 8, 3, 69, 35, 2, 89, 65, 58, 39, 94, 6, 9, 30, 21, 99, 34, 87, 70, 17, 9, 94, 79, 48, 8, 69, 11, 39, 34, 19, 93, 42, 72, 78, 76, 93, 15, 93, 27, 74, 71, 47, 96, 47, 73, 58, 75, 59, 52, 98, 11, 34, 16, 20, 16, 19, 20, 71, 92, 43, 31, 210}, { 210, 9, 4, 19, 39, 56, 35, 99, 87, 37, 19, 28, 77, 7, 38, 81, 64, 60, 97, 7, 95, 11, 24, 50, 26, 68, 99, 61, 83, 54, 32, 72, 7, 89, 79, 15, 18, 99, 93, 76, 5, 30, 75, 61, 15, 17, 14, 29, 92, 22, 81, 70, 23, 100, 47, 46, 86, 3, 1, 74, 91, 86, 66, 81, 62, 86, 73, 28, 48, 1, 98, 87, 38, 50, 82, 79, 79, 35, 94, 70, 70, 36, 60, 33, 13, 17, 70, 25, 84, 94, 41, 77, 210}, { 210, 5, 73, 15, 33, 65, 61, 8, 83, 61, 69, 94, 83, 22, 23, 2, 22, 66, 7, 11, 18, 84, 75, 82, 83, 21, 45, 86, 65, 4, 53, 68, 38, 6, 64, 28, 18, 69, 64, 58, 41, 62, 78, 62, 11, 34, 4, 58, 75, 66, 30, 61, 57, 16, 24, 66, 81, 100, 23, 39, 57, 75, 100, 76, 56, 90, 96, 61, 27, 56, 26, 41, 27, 40, 37, 24, 52, 38, 58, 75, 69, 8, 17, 19, 75, 1, 57, 19, 14, 100, 22, 66, 210}, { 210, 65, 74, 56, 88, 50, 27, 49, 27, 37, 62, 47, 53, 15, 7, 39, 89, 33, 65, 21, 7, 5, 14, 57, 80, 28, 27, 21, 96, 99, 7, 60, 79, 95, 48, 56, 91, 26, 89, 64, 94, 96, 16, 96, 5, 6, 88, 68, 50, 77, 51, 10, 7, 11, 3, 27, 69, 31, 27, 80, 29, 64, 78, 6, 77, 21, 59, 88, 22, 71, 18, 76, 14, 42, 16, 68, 16, 5, 8, 68, 9, 15, 11, 7, 36, 83, 58, 84, 45, 34, 71, 97, 210}, { 210, 85, 69, 60, 60, 100, 16, 51, 96, 99, 56, 95, 98, 40, 22, 76, 11, 77, 68, 69, 70, 30, 52, 47, 27, 17, 84, 47, 25, 13, 19, 57, 48, 84, 45, 62, 31, 37, 47, 18, 68, 82, 42, 96, 75, 98, 66, 78, 58, 60, 80, 40, 53, 40, 22, 69, 42, 76, 35, 60, 100, 82, 71, 65, 16, 80, 75, 77, 53, 16, 75, 15, 26, 29, 94, 18, 100, 7, 60, 22, 15, 85, 4, 23, 72, 21, 48, 27, 55, 87, 15, 59, 210}, { 210, 59, 37, 76, 89, 8, 84, 44, 50, 10, 74, 24, 72, 46, 49, 31, 99, 76, 85, 47, 45, 65, 68, 93, 68, 31, 80, 70, 32, 22, 7, 53, 21, 35, 5, 73, 99, 4, 77, 35, 48, 14, 69, 10, 27, 54, 85, 84, 97, 22, 87, 8, 7, 13, 90, 74, 79, 5, 94, 40, 50, 91, 7, 8, 37, 87, 32, 56, 99, 33, 12, 56, 15, 19, 94, 95, 52, 98, 78, 25, 49, 92, 89, 97, 84, 5, 63, 41, 1, 100, 69, 26, 210}, { 210, 7, 42, 93, 16, 21, 57, 34, 8, 47, 7, 83, 75, 34, 57, 98, 65, 30, 36, 13, 50, 72, 38, 84, 52, 50, 92, 73, 53, 56, 12, 14, 8, 32, 79, 37, 88, 67, 43, 80, 30, 89, 74, 42, 99, 49, 7, 71, 81, 62, 26, 45, 48, 3, 53, 76, 32, 48, 11, 42, 60, 19, 81, 71, 64, 23, 50, 97, 97, 47, 8, 9, 83, 90, 79, 61, 6, 98, 42, 67, 39, 42, 85, 78, 74, 28, 66, 76, 48, 60, 29, 4, 210}, { 210, 13, 15, 83, 65, 12, 95, 37, 52, 85, 96, 62, 9, 1, 4, 92, 40, 74, 48, 81, 58, 12, 5, 21, 76, 97, 14, 21, 64, 89, 4, 71, 38, 25, 100, 11, 62, 13, 56, 35, 98, 56, 77, 28, 33, 14, 95, 46, 47, 74, 20, 25, 71, 77, 50, 75, 51, 37, 93, 12, 23, 8, 74, 20, 55, 35, 40, 72, 100, 29, 28, 84, 17, 100, 42, 37, 34, 46, 1, 45, 29, 62, 71, 13, 87, 42, 42, 47, 63, 33, 12, 40, 210}, { 210, 99, 7, 5, 55, 73, 56, 16, 86, 66, 82, 99, 81, 72, 68, 85, 13, 22, 7, 27, 13, 4, 19, 42, 13, 25, 45, 78, 7, 48, 87, 60, 1, 22, 32, 10, 46, 40, 19, 52, 30, 77, 32, 4, 87, 24, 25, 92, 70, 31, 77, 1, 32, 51, 42, 6, 33, 3, 65, 71, 13, 88, 31, 76, 83, 71, 85, 44, 27, 61, 62, 34, 69, 53, 38, 50, 21, 38, 82, 97, 64, 18, 11, 32, 95, 19, 77, 12, 28, 79, 66, 34, 210}, { 210, 34, 100, 31, 59, 25, 56, 85, 21, 44, 83, 27, 99, 60, 86, 36, 51, 66, 5, 82, 13, 64, 90, 5, 62, 13, 28, 69, 58, 48, 98, 66, 40, 97, 51, 16, 45, 45, 5, 7, 89, 86, 65, 71, 73, 51, 57, 43, 16, 6, 46, 50, 85, 60, 96, 49, 47, 7, 9, 50, 47, 48, 81, 94, 29, 98, 37, 87, 53, 22, 52, 68, 37, 99, 16, 58, 7, 39, 12, 70, 32, 46, 50, 56, 80, 91, 82, 39, 82, 78, 48, 22, 210}, { 210, 10, 48, 46, 26, 34, 58, 77, 58, 91, 68, 35, 52, 31, 76, 68, 7, 69, 30, 4, 89, 64, 10, 35, 49, 28, 5, 77, 93, 17, 43, 87, 23, 17, 100, 25, 82, 98, 96, 19, 60, 33, 50, 49, 12, 6, 64, 69, 85, 43, 48, 21, 56, 23, 34, 86, 64, 93, 46, 13, 46, 28, 11, 97, 27, 96, 8, 84, 84, 20, 100, 83, 50, 79, 22, 87, 1, 32, 83, 61, 79, 92, 24, 78, 24, 98, 23, 69, 95, 74, 7, 66, 210}, { 210, 39, 8, 33, 76, 38, 8, 79, 55, 11, 69, 7, 80, 39, 59, 75, 37, 72, 9, 93, 54, 34, 10, 1, 74, 24, 98, 60, 24, 54, 19, 80, 61, 38, 97, 93, 42, 65, 57, 69, 62, 5, 52, 33, 45, 35, 16, 50, 72, 56, 33, 11, 56, 99, 1, 91, 40, 4, 64, 56, 62, 16, 6, 32, 45, 34, 42, 96, 31, 85, 78, 100, 20, 80, 37, 48, 9, 38, 56, 79, 47, 10, 55, 46, 87, 50, 94, 69, 62, 53, 64, 26, 210}, { 210, 91, 16, 69, 88, 18, 91, 76, 9, 24, 13, 66, 61, 10, 60, 45, 90, 8, 78, 81, 2, 15, 94, 96, 1, 37, 100, 59, 36, 26, 6, 27, 17, 64, 80, 49, 66, 82, 92, 45, 29, 92, 54, 5, 55, 38, 39, 45, 60, 50, 69, 71, 42, 72, 50, 73, 5, 14, 88, 75, 15, 61, 36, 46, 38, 29, 87, 92, 81, 69, 4, 78, 61, 77, 46, 36, 78, 48, 75, 43, 70, 22, 35, 98, 96, 27, 57, 99, 50, 1, 54, 32, 210}, { 210, 57, 63, 57, 5, 79, 27, 24, 44, 10, 21, 50, 67, 76, 63, 38, 56, 64, 63, 91, 82, 38, 75, 48, 93, 59, 70, 91, 44, 9, 43, 55, 23, 14, 79, 78, 85, 97, 68, 58, 27, 20, 25, 65, 96, 72, 18, 14, 36, 53, 10, 20, 33, 71, 76, 78, 37, 8, 29, 71, 61, 84, 57, 82, 22, 18, 10, 79, 68, 39, 50, 69, 73, 22, 33, 1, 96, 94, 9, 8, 40, 68, 58, 73, 78, 28, 83, 85, 8, 52, 49, 93, 210}, { 210, 63, 5, 70, 26, 7, 65, 27, 77, 80, 42, 100, 29, 98, 96, 70, 10, 19, 75, 47, 29, 77, 41, 44, 2, 57, 91, 18, 74, 13, 1, 23, 10, 96, 76, 24, 81, 57, 46, 78, 55, 72, 19, 64, 34, 96, 32, 47, 19, 93, 63, 60, 21, 31, 43, 20, 1, 43, 4, 19, 12, 68, 15, 92, 3, 23, 99, 66, 56, 67, 27, 44, 79, 17, 13, 20, 60, 77, 88, 90, 81, 39, 46, 29, 92, 4, 31, 31, 89, 15, 99, 44, 210}, { 210, 33, 88, 46, 84, 96, 59, 87, 33, 92, 43, 98, 1, 95, 62, 6, 76, 6, 75, 56, 35, 16, 85, 79, 62, 92, 65, 95, 30, 65, 68, 62, 7, 63, 28, 37, 89, 7, 83, 88, 94, 50, 58, 4, 100, 7, 58, 14, 32, 83, 74, 62, 17, 8, 57, 19, 14, 18, 98, 64, 85, 70, 61, 76, 36, 59, 4, 93, 88, 37, 60, 80, 47, 20, 66, 7, 43, 100, 82, 87, 100, 92, 95, 65, 15, 42, 74, 23, 17, 16, 29, 41, 210}, { 210, 15, 93, 75, 99, 53, 81, 1, 43, 74, 78, 43, 68, 13, 7, 99, 26, 99, 82, 8, 25, 16, 89, 21, 7, 3, 66, 24, 23, 91, 22, 6, 40, 11, 56, 25, 50, 72, 4, 5, 84, 83, 92, 31, 44, 75, 48, 69, 29, 38, 2, 15, 99, 19, 70, 27, 17, 66, 64, 75, 63, 77, 76, 23, 28, 22, 3, 1, 37, 86, 53, 42, 70, 9, 15, 11, 38, 19, 64, 1, 15, 86, 86, 22, 21, 18, 38, 97, 60, 11, 57, 45, 210}, { 210, 44, 33, 57, 50, 90, 85, 59, 72, 65, 62, 37, 99, 14, 63, 39, 98, 79, 33, 88, 45, 8, 54, 88, 86, 27, 52, 73, 1, 90, 68, 39, 87, 34, 63, 86, 78, 6, 24, 54, 96, 46, 10, 1, 71, 85, 34, 52, 67, 25, 64, 96, 39, 54, 98, 69, 12, 23, 34, 62, 51, 90, 37, 84, 65, 90, 12, 42, 47, 50, 82, 60, 11, 8, 54, 43, 15, 89, 42, 56, 55, 69, 90, 39, 27, 69, 61, 85, 89, 14, 23, 18, 210}, { 210, 31, 75, 39, 34, 55, 52, 68, 52, 7, 89, 36, 2, 41, 40, 34, 17, 42, 82, 92, 50, 73, 30, 31, 50, 76, 47, 46, 44, 72, 20, 25, 20, 99, 2, 56, 63, 25, 92, 99, 76, 16, 32, 28, 62, 12, 89, 91, 56, 98, 21, 35, 68, 24, 41, 31, 87, 39, 90, 44, 24, 41, 18, 52, 27, 61, 3, 72, 70, 64, 26, 46, 18, 1, 22, 54, 25, 65, 27, 98, 53, 23, 38, 88, 19, 22, 71, 13, 48, 60, 74, 20, 210}, { 210, 1, 60, 89, 53, 43, 28, 67, 33, 61, 13, 30, 7, 71, 58, 56, 39, 9, 15, 58, 52, 5, 63, 3, 43, 95, 82, 78, 16, 94, 71, 92, 46, 6, 19, 74, 88, 86, 54, 38, 35, 47, 83, 67, 3, 76, 3, 41, 95, 30, 96, 40, 28, 90, 18, 59, 59, 85, 56, 7, 7, 79, 91, 63, 50, 21, 10, 63, 8, 1, 5, 58, 19, 56, 41, 61, 98, 21, 29, 42, 40, 88, 100, 14, 68, 65, 35, 92, 55, 57, 48, 40, 210}, { 210, 90, 61, 90, 58, 66, 72, 19, 21, 98, 57, 46, 74, 65, 1, 18, 18, 14, 1, 92, 49, 26, 49, 31, 29, 35, 17, 25, 17, 74, 27, 78, 50, 11, 5, 45, 86, 2, 38, 97, 91, 71, 41, 25, 18, 20, 49, 62, 10, 84, 38, 3, 37, 72, 40, 3, 90, 36, 18, 88, 37, 82, 65, 59, 59, 71, 99, 21, 5, 76, 76, 60, 64, 68, 28, 63, 98, 7, 99, 10, 25, 80, 100, 75, 15, 68, 6, 66, 93, 35, 9, 79, 210}, { 210, 54, 54, 35, 40, 77, 79, 58, 79, 89, 85, 10, 1, 49, 11, 47, 34, 24, 24, 79, 87, 15, 67, 51, 62, 46, 84, 70, 58, 77, 51, 71, 8, 56, 33, 34, 95, 8, 3, 35, 12, 93, 76, 64, 56, 92, 5, 35, 92, 32, 31, 82, 13, 25, 1, 37, 44, 45, 73, 100, 18, 94, 85, 14, 14, 73, 65, 36, 66, 86, 2, 82, 39, 23, 38, 22, 58, 78, 49, 2, 48, 33, 39, 70, 30, 99, 98, 67, 4, 48, 13, 58, 210}, { 210, 4, 99, 20, 8, 37, 64, 46, 57, 9, 4, 85, 64, 55, 2, 10, 86, 77, 85, 49, 79, 65, 63, 6, 74, 14, 54, 73, 47, 12, 70, 85, 58, 10, 27, 59, 33, 10, 6, 22, 48, 36, 52, 41, 84, 92, 51, 21, 28, 11, 32, 43, 48, 26, 30, 4, 24, 79, 45, 40, 4, 26, 91, 45, 4, 24, 62, 59, 43, 4, 30, 86, 28, 3, 38, 20, 62, 50, 33, 76, 59, 4, 75, 42, 19, 4, 80, 75, 75, 88, 13, 46, 210}, { 210, 35, 15, 67, 70, 90, 73, 16, 43, 18, 43, 47, 49, 92, 83, 32, 99, 2, 16, 82, 6, 55, 21, 90, 43, 98, 21, 69, 54, 86, 52, 50, 82, 90, 30, 89, 76, 89, 43, 62, 26, 63, 25, 21, 71, 92, 51, 53, 11, 48, 92, 48, 32, 30, 29, 27, 41, 63, 16, 91, 80, 36, 50, 6, 16, 73, 16, 26, 87, 46, 74, 88, 17, 4, 23, 53, 42, 50, 25, 64, 59, 87, 78, 47, 17, 26, 93, 6, 48, 98, 100, 13, 210}, { 210, 3, 95, 60, 7, 85, 49, 85, 100, 9, 75, 95, 78, 4, 55, 69, 52, 11, 27, 45, 9, 44, 74, 60, 92, 92, 13, 6, 79, 26, 8, 18, 26, 43, 32, 91, 56, 57, 35, 28, 75, 59, 84, 24, 3, 98, 13, 31, 37, 84, 16, 71, 66, 71, 85, 82, 45, 55, 19, 19, 74, 5, 54, 5, 70, 48, 19, 15, 45, 11, 30, 1, 52, 57, 58, 84, 98, 92, 62, 22, 96, 32, 14, 37, 55, 76, 13, 79, 44, 99, 17, 45, 210}, { 210, 2, 99, 75, 81, 30, 67, 91, 62, 39, 38, 18, 65, 42, 69, 42, 94, 1, 87, 18, 17, 10, 3, 94, 10, 88, 55, 96, 43, 43, 63, 29, 11, 26, 84, 50, 81, 54, 94, 45, 63, 91, 65, 56, 2, 54, 87, 40, 44, 33, 87, 1, 89, 25, 75, 49, 84, 85, 87, 4, 50, 8, 31, 22, 28, 91, 66, 94, 89, 82, 16, 59, 74, 80, 61, 95, 14, 61, 10, 16, 71, 87, 79, 45, 58, 86, 80, 79, 65, 55, 66, 2, 210}, { 210, 41, 48, 74, 81, 30, 40, 85, 24, 18, 3, 68, 13, 99, 15, 93, 33, 63, 49, 66, 12, 79, 19, 16, 91, 37, 70, 63, 84, 99, 59, 29, 25, 58, 2, 16, 81, 93, 6, 44, 94, 79, 17, 65, 49, 16, 34, 34, 78, 48, 73, 83, 28, 77, 32, 87, 14, 67, 45, 69, 70, 47, 47, 26, 78, 59, 97, 72, 73, 50, 15, 51, 48, 74, 16, 87, 90, 62, 63, 79, 6, 16, 84, 71, 56, 7, 59, 49, 80, 20, 59, 14, 210}, { 210, 33, 44, 63, 8, 52, 95, 96, 69, 89, 28, 68, 14, 3, 77, 86, 86, 89, 74, 1, 4, 21, 65, 62, 56, 91, 76, 55, 59, 83, 11, 24, 53, 5, 60, 8, 19, 40, 93, 7, 55, 73, 25, 71, 9, 30, 34, 22, 43, 64, 1, 57, 17, 73, 84, 87, 38, 14, 73, 92, 3, 90, 48, 93, 73, 15, 2, 14, 45, 86, 24, 45, 18, 78, 84, 55, 85, 3, 18, 18, 7, 15, 65, 32, 36, 94, 8, 43, 22, 72, 10, 44, 210}, { 210, 33, 59, 49, 96, 40, 96, 77, 75, 81, 26, 48, 71, 31, 79, 47, 24, 84, 78, 31, 40, 61, 50, 79, 75, 8, 91, 82, 48, 37, 87, 82, 100, 60, 32, 84, 100, 57, 52, 16, 80, 55, 47, 98, 84, 88, 11, 60, 27, 87, 11, 7, 94, 13, 68, 20, 77, 35, 54, 51, 92, 20, 38, 79, 74, 16, 50, 7, 6, 46, 88, 74, 98, 15, 43, 18, 25, 59, 61, 33, 74, 13, 88, 89, 83, 42, 44, 5, 33, 37, 20, 29, 210}, { 210, 97, 1, 75, 29, 22, 58, 26, 48, 38, 68, 54, 72, 35, 10, 92, 95, 77, 83, 10, 66, 47, 8, 65, 12, 79, 12, 14, 19, 89, 26, 21, 82, 66, 9, 62, 75, 14, 65, 46, 100, 14, 44, 92, 51, 12, 75, 8, 54, 10, 99, 36, 53, 3, 81, 21, 10, 10, 52, 96, 67, 17, 75, 87, 74, 89, 52, 45, 20, 98, 21, 9, 9, 67, 99, 84, 48, 52, 73, 74, 9, 14, 62, 60, 90, 43, 33, 73, 20, 33, 51, 96, 210}, { 210, 65, 93, 31, 83, 87, 49, 53, 84, 57, 20, 96, 75, 95, 94, 76, 2, 89, 65, 51, 79, 96, 85, 48, 53, 92, 62, 34, 67, 88, 61, 63, 19, 23, 87, 99, 45, 69, 31, 81, 49, 49, 35, 30, 72, 30, 93, 43, 42, 52, 64, 4, 75, 17, 48, 45, 100, 65, 77, 38, 82, 100, 62, 54, 14, 72, 51, 20, 54, 75, 3, 47, 10, 80, 4, 4, 83, 82, 25, 20, 63, 26, 78, 47, 99, 40, 53, 56, 68, 44, 76, 73, 210}, { 210, 30, 54, 67, 28, 57, 42, 71, 1, 69, 30, 6, 24, 74, 78, 64, 13, 92, 62, 96, 89, 86, 22, 93, 45, 98, 29, 2, 52, 30, 52, 42, 54, 29, 31, 14, 17, 66, 77, 63, 10, 3, 77, 81, 5, 46, 78, 77, 71, 18, 31, 58, 69, 46, 5, 9, 43, 3, 80, 27, 64, 5, 92, 4, 53, 35, 82, 50, 78, 89, 94, 27, 13, 55, 16, 8, 36, 44, 17, 30, 46, 28, 2, 98, 13, 6, 17, 80, 29, 37, 31, 9, 210}, { 210, 40, 56, 94, 59, 40, 67, 32, 49, 77, 69, 94, 42, 9, 55, 56, 94, 48, 75, 21, 50, 46, 67, 85, 14, 65, 72, 29, 87, 74, 80, 30, 80, 54, 54, 17, 39, 40, 84, 98, 39, 47, 79, 97, 35, 84, 85, 1, 43, 91, 62, 79, 69, 60, 99, 45, 76, 1, 78, 26, 78, 89, 50, 88, 69, 30, 1, 100, 41, 20, 1, 68, 13, 25, 76, 19, 62, 88, 77, 83, 68, 27, 64, 28, 6, 65, 34, 97, 32, 37, 89, 29, 210}, { 210, 68, 30, 11, 89, 55, 85, 2, 76, 40, 70, 81, 62, 29, 67, 68, 97, 2, 86, 5, 74, 94, 47, 78, 26, 75, 42, 50, 87, 35, 38, 60, 29, 28, 39, 58, 20, 6, 73, 77, 20, 25, 24, 33, 98, 35, 99, 98, 61, 88, 71, 85, 10, 31, 41, 29, 59, 83, 28, 74, 5, 4, 11, 95, 71, 37, 56, 86, 34, 76, 61, 93, 75, 97, 92, 45, 89, 94, 92, 44, 43, 20, 76, 85, 5, 79, 28, 78, 79, 100, 19, 57, 210}, { 210, 98, 87, 14, 47, 16, 99, 41, 26, 65, 95, 11, 59, 92, 28, 1, 34, 82, 54, 27, 52, 54, 100, 88, 70, 20, 5, 66, 16, 13, 12, 41, 4, 61, 81, 35, 59, 60, 19, 7, 15, 45, 98, 79, 63, 91, 64, 47, 3, 1, 5, 10, 54, 98, 64, 11, 62, 2, 69, 46, 99, 36, 20, 90, 29, 99, 56, 59, 41, 24, 59, 59, 52, 11, 24, 67, 92, 65, 31, 30, 60, 97, 54, 11, 22, 67, 38, 74, 11, 74, 82, 49, 210}, { 210, 81, 20, 34, 67, 85, 44, 17, 86, 95, 17, 63, 50, 46, 47, 56, 84, 32, 83, 30, 96, 89, 86, 59, 23, 17, 35, 86, 96, 17, 90, 74, 28, 60, 78, 78, 7, 65, 35, 40, 89, 25, 72, 96, 85, 13, 22, 7, 94, 45, 80, 11, 16, 51, 67, 65, 80, 29, 39, 72, 88, 71, 19, 23, 87, 41, 84, 51, 44, 63, 69, 33, 89, 71, 2, 55, 11, 73, 90, 4, 36, 41, 93, 17, 70, 28, 70, 89, 84, 77, 90, 63, 210}, { 210, 34, 3, 78, 92, 30, 25, 85, 1, 79, 85, 34, 63, 20, 100, 8, 99, 35, 7, 58, 58, 41, 20, 88, 8, 24, 9, 97, 69, 19, 86, 84, 18, 93, 69, 45, 95, 84, 29, 86, 11, 2, 4, 18, 70, 69, 3, 45, 73, 62, 75, 54, 57, 98, 86, 23, 33, 98, 95, 98, 90, 63, 55, 48, 86, 8, 10, 28, 11, 66, 44, 67, 39, 83, 75, 80, 56, 27, 75, 75, 62, 23, 21, 19, 92, 37, 73, 71, 81, 50, 70, 76, 210}, { 210, 72, 47, 87, 75, 90, 1, 53, 72, 25, 86, 2, 77, 73, 90, 98, 35, 96, 96, 64, 31, 1, 50, 92, 76, 64, 29, 2, 25, 10, 2, 97, 27, 42, 93, 80, 78, 2, 60, 53, 41, 96, 26, 44, 16, 39, 2, 80, 81, 5, 23, 63, 70, 32, 75, 38, 41, 84, 78, 92, 69, 39, 67, 15, 35, 60, 91, 24, 34, 96, 84, 34, 63, 76, 95, 74, 85, 27, 18, 43, 71, 9, 23, 76, 64, 47, 91, 81, 73, 39, 36, 57, 210}, { 210, 69, 29, 98, 84, 67, 70, 100, 63, 9, 11, 11, 43, 48, 6, 25, 87, 72, 80, 78, 87, 6, 29, 64, 18, 64, 42, 93, 19, 26, 42, 76, 76, 54, 83, 13, 100, 28, 17, 23, 69, 4, 54, 96, 85, 3, 66, 83, 47, 97, 12, 20, 12, 38, 8, 88, 51, 48, 98, 12, 93, 16, 65, 65, 90, 38, 91, 57, 42, 81, 42, 41, 5, 12, 26, 5, 49, 75, 65, 20, 22, 66, 23, 78, 76, 6, 8, 1, 38, 55, 43, 32, 210}, { 210, 52, 63, 93, 59, 33, 34, 12, 58, 63, 20, 84, 22, 30, 17, 95, 96, 36, 53, 91, 2, 9, 77, 43, 44, 45, 12, 14, 57, 33, 2, 61, 55, 1, 39, 64, 14, 78, 36, 11, 26, 2, 62, 80, 94, 15, 84, 4, 18, 65, 34, 18, 77, 26, 38, 95, 36, 9, 45, 41, 50, 9, 8, 3, 25, 32, 17, 12, 4, 83, 82, 39, 12, 77, 100, 11, 71, 56, 15, 65, 46, 81, 3, 7, 17, 37, 1, 14, 69, 94, 18, 62, 210}, { 210, 18, 27, 53, 8, 48, 91, 53, 85, 2, 44, 21, 38, 59, 60, 69, 35, 23, 19, 3, 92, 67, 60, 69, 91, 44, 38, 100, 20, 76, 35, 24, 11, 61, 98, 43, 19, 33, 5, 94, 95, 3, 92, 25, 73, 11, 1, 17, 96, 5, 37, 76, 95, 76, 19, 47, 100, 40, 60, 53, 93, 44, 100, 43, 11, 80, 92, 62, 85, 51, 82, 85, 1, 68, 34, 81, 42, 29, 81, 39, 80, 51, 40, 35, 28, 64, 38, 1, 22, 63, 19, 11, 210}, { 210, 52, 32, 96, 20, 21, 24, 57, 65, 7, 79, 18, 78, 45, 63, 24, 30, 30, 54, 43, 41, 22, 94, 25, 58, 84, 77, 13, 85, 66, 4, 28, 98, 68, 97, 45, 74, 81, 59, 28, 48, 92, 15, 91, 62, 11, 100, 91, 81, 2, 96, 29, 53, 29, 56, 32, 18, 100, 74, 63, 57, 15, 76, 3, 46, 34, 38, 8, 85, 58, 20, 88, 14, 1, 28, 22, 59, 56, 36, 93, 12, 5, 20, 100, 90, 16, 20, 39, 43, 96, 62, 98, 210}, { 210, 20, 54, 92, 95, 90, 61, 88, 91, 10, 81, 67, 20, 6, 55, 98, 46, 57, 11, 91, 40, 95, 46, 95, 2, 20, 7, 16, 7, 14, 92, 19, 25, 77, 86, 62, 31, 50, 57, 77, 95, 99, 28, 21, 33, 24, 97, 15, 95, 90, 10, 67, 46, 42, 54, 29, 54, 6, 56, 49, 62, 52, 51, 100, 89, 65, 27, 70, 52, 50, 94, 35, 76, 50, 25, 32, 62, 39, 35, 89, 18, 53, 64, 55, 56, 23, 5, 65, 18, 13, 52, 53, 210}, { 210, 26, 79, 49, 16, 5, 77, 23, 4, 46, 63, 1, 37, 83, 99, 10, 8, 4, 8, 94, 15, 7, 11, 39, 88, 53, 52, 84, 23, 4, 40, 6, 35, 86, 66, 54, 55, 68, 81, 41, 11, 76, 98, 83, 95, 31, 1, 36, 87, 93, 54, 37, 97, 12, 17, 73, 72, 22, 25, 64, 73, 18, 82, 44, 22, 98, 59, 48, 22, 91, 16, 53, 74, 82, 73, 37, 47, 94, 97, 34, 66, 67, 17, 67, 20, 56, 39, 77, 74, 39, 36, 79, 210}, { 210, 76, 84, 91, 37, 92, 64, 72, 73, 89, 64, 31, 62, 76, 65, 36, 50, 9, 44, 55, 13, 33, 46, 20, 98, 64, 57, 9, 85, 18, 26, 18, 79, 49, 94, 57, 92, 71, 45, 33, 58, 4, 32, 96, 81, 64, 26, 33, 45, 65, 18, 97, 31, 86, 92, 16, 26, 26, 44, 1, 83, 18, 36, 45, 10, 60, 64, 72, 20, 54, 42, 57, 96, 85, 18, 66, 66, 75, 94, 97, 80, 71, 91, 92, 52, 99, 12, 37, 91, 100, 25, 93, 210}, { 210, 49, 88, 9, 45, 95, 2, 11, 13, 62, 23, 76, 78, 71, 88, 59, 26, 87, 18, 15, 34, 14, 89, 81, 14, 46, 27, 70, 65, 3, 15, 51, 4, 85, 76, 61, 57, 35, 75, 29, 80, 26, 62, 62, 53, 86, 39, 94, 83, 14, 30, 58, 99, 48, 25, 21, 35, 72, 36, 88, 31, 49, 13, 79, 20, 36, 71, 36, 2, 18, 85, 59, 88, 16, 26, 42, 2, 32, 64, 7, 35, 38, 49, 18, 7, 8, 23, 4, 55, 14, 83, 61, 210}, { 210, 83, 8, 78, 61, 46, 90, 96, 16, 12, 78, 85, 91, 21, 6, 30, 75, 63, 70, 76, 50, 12, 25, 96, 89, 82, 47, 86, 77, 93, 47, 90, 49, 38, 91, 40, 30, 28, 32, 76, 60, 37, 43, 82, 22, 32, 1, 7, 29, 69, 82, 12, 16, 69, 64, 66, 59, 51, 98, 95, 76, 97, 98, 75, 19, 1, 81, 17, 70, 3, 2, 34, 32, 45, 65, 23, 58, 53, 48, 35, 83, 63, 63, 72, 22, 44, 3, 2, 54, 23, 12, 24, 210}, { 210, 2, 2, 99, 91, 85, 57, 60, 60, 71, 79, 39, 94, 32, 35, 53, 74, 98, 35, 33, 66, 30, 17, 50, 46, 84, 46, 45, 55, 88, 47, 94, 99, 70, 57, 86, 96, 6, 15, 11, 12, 8, 26, 2, 77, 1, 84, 22, 21, 35, 58, 76, 23, 53, 48, 49, 15, 7, 69, 81, 100, 35, 4, 74, 60, 29, 36, 34, 23, 32, 15, 74, 1, 91, 25, 79, 47, 93, 74, 33, 79, 79, 59, 4, 62, 27, 53, 5, 100, 61, 51, 10, 210}, { 210, 85, 16, 54, 85, 59, 19, 88, 13, 27, 2, 46, 82, 75, 11, 82, 71, 37, 59, 32, 86, 42, 67, 85, 61, 43, 90, 97, 41, 10, 74, 38, 38, 61, 14, 98, 100, 42, 16, 100, 42, 65, 44, 98, 84, 52, 82, 93, 78, 16, 84, 79, 38, 48, 46, 8, 90, 44, 66, 3, 29, 61, 22, 89, 94, 65, 86, 40, 16, 52, 21, 48, 99, 28, 9, 40, 33, 64, 29, 71, 76, 82, 62, 14, 38, 78, 57, 87, 48, 50, 97, 68, 210}, { 210, 82, 44, 71, 14, 71, 9, 72, 98, 76, 4, 50, 30, 97, 90, 63, 22, 43, 85, 47, 83, 16, 27, 30, 56, 10, 92, 62, 41, 74, 42, 29, 71, 66, 80, 21, 95, 22, 57, 56, 31, 7, 83, 77, 19, 66, 45, 2, 96, 43, 96, 40, 70, 16, 62, 22, 4, 68, 11, 27, 86, 92, 62, 8, 5, 94, 43, 58, 98, 54, 65, 39, 82, 83, 81, 7, 19, 24, 38, 6, 71, 84, 49, 56, 84, 86, 11, 57, 89, 95, 41, 88, 210}, { 210, 50, 95, 7, 39, 6, 72, 25, 20, 50, 50, 73, 53, 72, 88, 63, 21, 76, 100, 21, 90, 32, 71, 55, 34, 58, 20, 43, 12, 60, 59, 55, 71, 8, 14, 3, 26, 4, 26, 31, 34, 74, 27, 52, 13, 21, 22, 46, 91, 9, 74, 26, 40, 44, 69, 76, 13, 25, 98, 75, 80, 44, 13, 34, 16, 9, 32, 80, 6, 77, 91, 22, 20, 78, 12, 21, 6, 69, 27, 37, 91, 43, 95, 35, 17, 31, 31, 86, 87, 77, 75, 88, 210}, { 210, 45, 43, 75, 59, 45, 99, 97, 72, 39, 18, 93, 36, 46, 44, 26, 42, 27, 100, 52, 26, 55, 45, 90, 55, 32, 87, 2, 8, 2, 61, 25, 92, 5, 48, 74, 53, 29, 98, 69, 2, 67, 76, 63, 56, 17, 93, 68, 54, 78, 64, 17, 1, 76, 83, 86, 77, 99, 39, 82, 11, 11, 65, 1, 3, 77, 52, 45, 61, 40, 51, 30, 78, 80, 47, 40, 3, 78, 45, 98, 42, 56, 2, 55, 63, 49, 89, 23, 77, 84, 38, 32, 210}, { 210, 55, 48, 19, 1, 44, 20, 20, 96, 93, 82, 13, 57, 16, 91, 27, 8, 94, 31, 9, 65, 70, 4, 14, 98, 42, 15, 85, 39, 32, 6, 48, 31, 3, 8, 58, 3, 7, 82, 61, 62, 37, 82, 56, 52, 93, 47, 96, 78, 28, 6, 40, 64, 66, 68, 71, 43, 60, 55, 16, 89, 52, 68, 77, 66, 17, 100, 47, 77, 11, 87, 84, 100, 17, 80, 62, 68, 36, 55, 87, 47, 9, 19, 86, 68, 85, 89, 64, 38, 51, 13, 25, 210}, { 210, 35, 31, 59, 87, 34, 7, 8, 81, 38, 1, 92, 15, 8, 37, 58, 99, 60, 34, 68, 58, 60, 88, 72, 64, 41, 25, 4, 8, 42, 23, 23, 11, 82, 50, 21, 37, 76, 75, 61, 51, 60, 57, 17, 84, 93, 28, 12, 47, 71, 46, 5, 32, 38, 65, 27, 70, 15, 62, 81, 57, 52, 62, 23, 87, 74, 59, 84, 20, 30, 86, 76, 96, 10, 32, 62, 83, 72, 41, 93, 96, 9, 2, 57, 32, 95, 76, 4, 29, 91, 47, 83, 210}, { 210, 59, 25, 15, 92, 13, 31, 75, 38, 42, 88, 31, 38, 19, 77, 95, 30, 69, 22, 7, 59, 34, 59, 95, 7, 66, 100, 36, 48, 60, 85, 61, 83, 78, 11, 65, 15, 35, 10, 80, 30, 56, 85, 16, 47, 60, 73, 80, 84, 27, 19, 38, 25, 78, 90, 34, 80, 14, 41, 63, 7, 98, 81, 6, 19, 22, 46, 100, 12, 15, 96, 43, 90, 22, 72, 22, 53, 18, 30, 23, 95, 43, 33, 45, 98, 82, 45, 80, 66, 52, 68, 43, 210}, { 210, 48, 79, 67, 64, 80, 12, 17, 30, 84, 64, 52, 38, 25, 82, 98, 60, 13, 50, 77, 54, 77, 45, 80, 84, 13, 69, 29, 36, 8, 68, 49, 34, 33, 68, 93, 67, 83, 90, 19, 65, 47, 63, 50, 28, 10, 48, 44, 76, 98, 65, 69, 14, 63, 40, 42, 18, 43, 79, 19, 95, 35, 77, 67, 67, 1, 37, 60, 76, 35, 96, 97, 83, 58, 58, 23, 3, 46, 100, 70, 72, 96, 57, 55, 49, 5, 8, 47, 80, 86, 100, 62, 210}, { 210, 92, 9, 51, 47, 96, 6, 11, 36, 46, 52, 47, 78, 79, 75, 93, 9, 84, 45, 38, 12, 7, 46, 43, 85, 71, 1, 76, 10, 33, 25, 54, 30, 24, 5, 15, 37, 46, 30, 21, 81, 23, 62, 78, 5, 97, 50, 3, 97, 85, 4, 11, 40, 70, 82, 17, 55, 48, 78, 23, 83, 91, 76, 96, 46, 93, 97, 4, 58, 70, 84, 35, 85, 67, 15, 8, 12, 7, 12, 24, 89, 66, 80, 66, 59, 20, 100, 81, 79, 16, 73, 41, 210}, { 210, 99, 86, 22, 97, 1, 78, 64, 2, 29, 58, 58, 6, 43, 57, 31, 87, 35, 12, 21, 12, 51, 29, 6, 82, 35, 1, 85, 27, 86, 28, 97, 13, 90, 24, 58, 81, 47, 28, 19, 78, 15, 15, 41, 96, 38, 1, 9, 63, 97, 38, 80, 40, 63, 20, 37, 58, 22, 56, 10, 9, 98, 65, 83, 63, 90, 30, 4, 13, 29, 56, 87, 32, 30, 19, 47, 80, 56, 51, 57, 100, 61, 61, 68, 55, 48, 28, 45, 85, 15, 55, 86, 210}, { 210, 13, 76, 24, 20, 86, 68, 41, 92, 68, 35, 69, 43, 94, 54, 46, 59, 7, 95, 99, 8, 79, 51, 97, 51, 79, 54, 79, 60, 93, 82, 43, 52, 48, 66, 85, 49, 98, 73, 86, 28, 64, 91, 80, 74, 72, 64, 1, 42, 75, 70, 56, 68, 88, 82, 11, 90, 73, 9, 28, 5, 80, 92, 72, 40, 65, 66, 6, 74, 1, 94, 65, 70, 63, 31, 35, 100, 27, 39, 72, 6, 5, 59, 39, 33, 99, 72, 55, 26, 70, 24, 67, 210}, { 210, 52, 100, 35, 29, 98, 98, 40, 13, 1, 47, 32, 89, 42, 79, 97, 79, 53, 33, 23, 21, 69, 78, 15, 94, 62, 59, 28, 88, 50, 2, 94, 20, 82, 30, 62, 23, 56, 77, 11, 52, 62, 68, 52, 54, 83, 94, 93, 30, 57, 71, 30, 81, 30, 43, 76, 98, 39, 68, 65, 38, 63, 51, 62, 51, 46, 41, 59, 90, 11, 48, 63, 38, 100, 99, 83, 97, 47, 100, 84, 76, 97, 19, 17, 76, 97, 65, 60, 20, 40, 52, 16, 210}, { 210, 75, 37, 51, 46, 58, 67, 94, 15, 2, 11, 39, 94, 28, 8, 16, 51, 82, 14, 23, 13, 47, 91, 50, 70, 71, 7, 28, 18, 58, 19, 67, 36, 53, 45, 42, 52, 86, 63, 52, 10, 24, 25, 85, 35, 16, 14, 70, 89, 28, 25, 71, 75, 71, 4, 50, 75, 70, 21, 71, 89, 86, 55, 4, 46, 7, 16, 58, 76, 66, 96, 65, 21, 31, 71, 19, 94, 5, 9, 50, 18, 32, 34, 15, 34, 24, 10, 41, 2, 69, 2, 90, 210}, { 210, 90, 23, 85, 37, 14, 63, 100, 19, 98, 38, 25, 87, 4, 89, 60, 28, 53, 71, 88, 21, 27, 54, 83, 64, 77, 87, 55, 20, 10, 56, 74, 96, 92, 1, 56, 84, 63, 27, 8, 96, 9, 46, 88, 61, 2, 39, 47, 73, 39, 70, 5, 23, 14, 43, 26, 32, 65, 80, 93, 61, 88, 51, 43, 27, 69, 99, 68, 66, 97, 7, 62, 29, 46, 10, 14, 46, 42, 39, 94, 70, 57, 50, 57, 17, 36, 4, 66, 41, 27, 81, 76, 210}, { 210, 27, 49, 73, 77, 7, 53, 78, 27, 37, 70, 38, 85, 69, 27, 81, 76, 73, 44, 69, 16, 41, 63, 2, 85, 42, 55, 74, 45, 76, 88, 97, 8, 3, 83, 66, 79, 90, 22, 21, 97, 79, 18, 12, 38, 54, 11, 11, 74, 20, 73, 83, 1, 47, 77, 5, 21, 66, 57, 33, 89, 18, 21, 71, 77, 100, 13, 68, 62, 3, 25, 85, 69, 13, 76, 62, 4, 53, 99, 54, 14, 64, 70, 24, 85, 48, 14, 40, 89, 37, 94, 23, 210}, { 210, 86, 99, 80, 78, 37, 60, 41, 18, 43, 24, 25, 50, 91, 64, 66, 45, 23, 64, 36, 23, 26, 10, 10, 100, 30, 57, 1, 11, 28, 97, 53, 37, 78, 4, 27, 46, 54, 82, 45, 36, 8, 21, 41, 1, 47, 9, 7, 2, 7, 89, 93, 73, 61, 42, 56, 26, 13, 90, 64, 27, 61, 29, 49, 89, 30, 20, 80, 48, 9, 52, 30, 37, 30, 32, 27, 63, 90, 64, 46, 4, 40, 95, 76, 10, 13, 67, 81, 54, 51, 96, 16, 210}, { 210, 93, 52, 95, 26, 80, 92, 59, 59, 72, 31, 10, 10, 24, 97, 98, 44, 23, 52, 17, 5, 98, 100, 69, 82, 71, 20, 48, 12, 66, 66, 49, 79, 90, 67, 77, 22, 51, 72, 46, 8, 6, 78, 85, 36, 67, 54, 39, 56, 72, 86, 54, 94, 18, 85, 67, 85, 38, 94, 61, 45, 49, 66, 40, 40, 7, 86, 79, 28, 38, 96, 39, 84, 93, 47, 77, 56, 55, 95, 9, 100, 19, 54, 28, 8, 90, 96, 90, 95, 51, 15, 72, 210}, { 210, 61, 39, 84, 4, 26, 42, 47, 46, 37, 73, 86, 44, 70, 78, 10, 93, 35, 55, 56, 70, 30, 81, 39, 31, 99, 21, 71, 82, 33, 36, 25, 8, 33, 52, 39, 94, 64, 52, 31, 19, 61, 31, 80, 61, 73, 95, 47, 99, 5, 12, 13, 23, 85, 11, 64, 91, 75, 28, 93, 46, 1, 3, 71, 92, 54, 10, 94, 18, 49, 54, 56, 29, 25, 59, 51, 9, 83, 22, 22, 47, 56, 22, 98, 14, 4, 69, 36, 25, 78, 62, 71, 210}, { 210, 19, 84, 18, 22, 41, 63, 34, 45, 77, 30, 8, 83, 9, 48, 98, 53, 91, 82, 96, 49, 60, 53, 58, 6, 92, 61, 80, 19, 38, 31, 33, 100, 52, 85, 100, 25, 36, 63, 4, 17, 3, 11, 42, 89, 85, 51, 95, 2, 92, 91, 86, 66, 23, 56, 63, 63, 60, 24, 37, 11, 14, 92, 56, 73, 63, 46, 39, 91, 66, 91, 63, 27, 57, 29, 66, 71, 47, 4, 29, 58, 37, 25, 49, 92, 16, 73, 30, 2, 19, 10, 94, 210}, { 210, 4, 5, 54, 78, 20, 56, 44, 96, 41, 19, 9, 90, 57, 27, 70, 72, 80, 11, 100, 70, 52, 37, 40, 48, 50, 11, 94, 66, 1, 9, 2, 99, 9, 75, 73, 64, 78, 90, 26, 11, 41, 18, 52, 90, 23, 50, 24, 31, 66, 11, 27, 43, 84, 94, 67, 18, 73, 68, 32, 42, 9, 1, 64, 95, 85, 88, 56, 5, 91, 42, 46, 68, 2, 3, 10, 4, 69, 62, 17, 50, 86, 32, 41, 17, 62, 61, 14, 9, 34, 26, 64, 210}, { 210, 37, 90, 100, 64, 63, 59, 48, 83, 60, 10, 88, 34, 68, 74, 93, 46, 77, 57, 79, 43, 57, 66, 44, 56, 32, 7, 32, 65, 89, 64, 84, 95, 80, 21, 27, 68, 24, 39, 53, 3, 4, 84, 19, 33, 100, 25, 19, 86, 71, 83, 41, 17, 14, 69, 43, 4, 41, 60, 62, 51, 18, 28, 99, 97, 1, 20, 36, 56, 24, 12, 26, 3, 41, 1, 74, 43, 2, 96, 84, 17, 90, 7, 51, 7, 98, 53, 9, 52, 26, 58, 38, 210}, { 210, 80, 25, 41, 29, 87, 9, 14, 28, 44, 61, 78, 77, 32, 60, 41, 71, 95, 73, 53, 7, 96, 69, 73, 82, 12, 15, 53, 35, 2, 90, 32, 81, 30, 20, 68, 51, 12, 45, 53, 28, 43, 82, 15, 7, 73, 83, 6, 54, 37, 49, 100, 64, 79, 73, 5, 47, 70, 62, 47, 84, 75, 12, 5, 89, 65, 14, 3, 47, 34, 41, 22, 52, 75, 94, 97, 61, 41, 63, 66, 66, 73, 97, 17, 24, 50, 23, 77, 95, 72, 1, 62, 210}, { 210, 34, 22, 8, 38, 78, 14, 3, 41, 7, 35, 31, 37, 13, 52, 71, 2, 81, 80, 33, 33, 100, 84, 22, 34, 60, 7, 53, 98, 22, 37, 32, 75, 11, 28, 68, 14, 48, 11, 85, 20, 17, 45, 92, 26, 93, 63, 25, 30, 55, 12, 23, 49, 6, 28, 99, 84, 69, 9, 13, 65, 53, 17, 9, 83, 25, 94, 51, 7, 87, 64, 63, 68, 100, 80, 97, 63, 74, 24, 33, 17, 23, 17, 24, 85, 38, 66, 81, 53, 5, 28, 41, 210}, { 210, 74, 67, 93, 17, 78, 9, 46, 26, 91, 72, 73, 72, 2, 18, 14, 22, 34, 14, 1, 44, 46, 35, 34, 81, 51, 44, 7, 27, 96, 90, 4, 42, 23, 58, 14, 47, 46, 15, 71, 33, 47, 8, 3, 80, 10, 66, 49, 90, 21, 1, 88, 66, 81, 11, 10, 50, 94, 91, 5, 13, 57, 74, 25, 95, 12, 44, 95, 42, 47, 21, 24, 63, 17, 57, 41, 100, 82, 6, 55, 67, 38, 10, 70, 71, 96, 40, 98, 74, 73, 91, 94, 210}, { 210, 30, 89, 35, 7, 41, 45, 8, 12, 17, 93, 58, 67, 70, 20, 90, 6, 24, 12, 5, 45, 88, 80, 94, 64, 97, 62, 1, 11, 49, 68, 43, 61, 53, 48, 5, 30, 78, 30, 62, 11, 71, 88, 62, 17, 6, 91, 2, 88, 74, 89, 29, 83, 24, 12, 44, 59, 31, 39, 72, 50, 54, 69, 13, 70, 6, 35, 2, 56, 79, 88, 13, 5, 16, 4, 45, 18, 24, 48, 36, 67, 4, 40, 53, 33, 67, 3, 1, 22, 18, 32, 33, 210}, { 210, 59, 39, 98, 70, 36, 75, 9, 93, 56, 99, 1, 42, 98, 89, 38, 82, 1, 34, 25, 13, 91, 98, 41, 56, 57, 76, 66, 30, 14, 76, 79, 77, 42, 37, 100, 31, 64, 29, 100, 38, 98, 2, 76, 30, 92, 27, 20, 94, 59, 31, 68, 78, 60, 35, 63, 46, 94, 23, 75, 84, 19, 85, 91, 87, 47, 74, 89, 46, 15, 18, 84, 28, 90, 9, 38, 67, 9, 20, 81, 29, 23, 53, 72, 64, 12, 95, 81, 85, 78, 51, 71, 210}, { 210, 15, 69, 50, 51, 76, 98, 92, 31, 54, 53, 67, 6, 25, 75, 68, 30, 83, 6, 37, 18, 3, 72, 72, 4, 75, 19, 68, 28, 78, 28, 41, 88, 53, 39, 94, 97, 57, 66, 70, 22, 78, 3, 86, 8, 61, 42, 96, 86, 51, 6, 21, 26, 88, 37, 47, 50, 67, 86, 10, 86, 18, 23, 54, 4, 78, 82, 54, 7, 89, 56, 23, 61, 31, 39, 27, 36, 50, 73, 30, 76, 71, 87, 45, 2, 5, 30, 37, 100, 3, 8, 13, 210}, { 210, 7, 49, 47, 88, 64, 21, 44, 5, 51, 83, 69, 53, 16, 82, 66, 42, 92, 63, 69, 41, 100, 6, 71, 66, 54, 27, 95, 69, 19, 7, 13, 94, 10, 35, 28, 52, 76, 10, 84, 56, 98, 40, 78, 21, 95, 36, 40, 14, 74, 70, 85, 58, 53, 17, 52, 18, 35, 34, 98, 51, 86, 64, 88, 66, 55, 71, 41, 51, 50, 23, 46, 63, 34, 31, 28, 94, 50, 60, 100, 69, 86, 27, 81, 15, 42, 98, 15, 34, 11, 40, 75, 210}, { 210, 39, 61, 89, 80, 6, 87, 88, 48, 37, 89, 38, 63, 13, 98, 16, 41, 80, 65, 81, 79, 26, 90, 68, 74, 54, 53, 65, 28, 66, 25, 17, 39, 76, 60, 57, 48, 18, 41, 45, 20, 9, 88, 52, 50, 94, 26, 60, 19, 21, 60, 53, 51, 20, 17, 25, 18, 51, 78, 95, 22, 33, 65, 99, 53, 12, 43, 35, 14, 61, 71, 85, 10, 78, 34, 27, 20, 78, 28, 80, 88, 90, 12, 53, 11, 72, 39, 45, 6, 5, 62, 10, 210}, { 210, 8, 19, 77, 71, 57, 92, 20, 19, 39, 76, 79, 26, 20, 63, 60, 54, 73, 62, 73, 98, 8, 17, 48, 2, 43, 45, 22, 88, 71, 40, 43, 86, 77, 8, 37, 19, 90, 23, 65, 20, 69, 26, 70, 88, 49, 16, 88, 96, 73, 67, 39, 25, 64, 94, 86, 36, 15, 82, 11, 41, 11, 95, 3, 8, 94, 2, 22, 39, 50, 57, 49, 66, 4, 19, 66, 46, 60, 53, 75, 9, 57, 61, 94, 76, 45, 26, 72, 100, 100, 50, 89, 210}, { 210, 25, 77, 77, 94, 54, 8, 39, 93, 58, 81, 70, 44, 77, 85, 70, 76, 80, 51, 25, 34, 61, 51, 53, 14, 15, 9, 30, 83, 98, 42, 25, 16, 42, 72, 33, 94, 91, 87, 27, 54, 42, 81, 73, 93, 37, 67, 69, 6, 35, 63, 26, 47, 29, 62, 99, 67, 25, 70, 68, 83, 49, 45, 9, 65, 65, 61, 24, 29, 55, 94, 50, 57, 20, 27, 99, 1, 73, 61, 60, 20, 24, 65, 8, 53, 19, 21, 85, 76, 66, 42, 94, 210}, { 210, 33, 38, 75, 27, 82, 30, 49, 60, 63, 86, 72, 60, 88, 57, 55, 57, 55, 50, 13, 90, 20, 20, 31, 3, 78, 87, 74, 33, 29, 99, 47, 93, 46, 70, 76, 6, 64, 11, 63, 47, 95, 82, 54, 30, 20, 62, 10, 77, 75, 100, 3, 100, 83, 13, 79, 5, 90, 72, 36, 87, 27, 13, 41, 33, 64, 50, 77, 71, 83, 13, 71, 86, 88, 80, 39, 92, 93, 42, 99, 99, 38, 22, 88, 47, 8, 42, 66, 40, 33, 1, 56, 210}, { 210, 97, 30, 32, 71, 56, 53, 16, 50, 9, 58, 50, 19, 21, 91, 63, 74, 84, 1, 15, 98, 99, 23, 8, 34, 53, 49, 20, 17, 14, 20, 43, 77, 12, 16, 7, 20, 74, 8, 25, 82, 54, 39, 51, 23, 54, 77, 77, 11, 53, 72, 22, 5, 97, 62, 4, 56, 93, 11, 85, 4, 98, 16, 53, 40, 75, 66, 75, 83, 29, 43, 76, 68, 79, 41, 52, 58, 48, 95, 2, 69, 21, 50, 11, 30, 21, 20, 36, 18, 55, 30, 91, 210}, { 210, 77, 83, 86, 74, 79, 43, 82, 60, 2, 46, 2, 77, 88, 88, 16, 33, 7, 99, 62, 99, 47, 22, 47, 65, 47, 30, 17, 74, 23, 43, 63, 4, 85, 28, 38, 58, 93, 34, 7, 82, 48, 18, 50, 98, 28, 47, 61, 70, 75, 64, 12, 57, 1, 12, 29, 12, 78, 12, 54, 98, 9, 69, 95, 58, 64, 51, 75, 31, 45, 45, 39, 97, 40, 45, 54, 13, 13, 38, 26, 82, 15, 63, 98, 90, 100, 69, 40, 74, 34, 79, 84, 210}, { 210, 78, 29, 69, 89, 71, 52, 93, 12, 37, 80, 63, 59, 87, 48, 81, 48, 28, 93, 84, 56, 6, 46, 37, 43, 22, 20, 63, 58, 91, 26, 19, 33, 2, 19, 24, 24, 7, 78, 51, 95, 41, 92, 97, 32, 60, 57, 2, 55, 49, 44, 30, 38, 23, 45, 69, 21, 84, 64, 76, 8, 56, 21, 27, 18, 74, 15, 22, 34, 13, 76, 67, 88, 50, 30, 31, 14, 54, 37, 76, 67, 44, 58, 9, 74, 81, 13, 31, 81, 30, 16, 15, 210}, { 210, 63, 21, 32, 20, 14, 30, 25, 28, 42, 56, 45, 22, 6, 64, 94, 54, 61, 49, 46, 45, 70, 99, 71, 70, 36, 99, 53, 41, 24, 25, 94, 9, 72, 92, 97, 71, 97, 20, 8, 99, 14, 36, 4, 74, 30, 41, 50, 9, 21, 2, 17, 56, 95, 25, 26, 75, 72, 95, 100, 21, 93, 88, 34, 21, 81, 90, 50, 82, 52, 85, 78, 89, 49, 87, 31, 47, 13, 65, 37, 52, 3, 92, 63, 46, 66, 43, 93, 24, 93, 40, 92, 210}, { 210, 42, 19, 94, 61, 35, 42, 68, 48, 33, 78, 68, 49, 28, 19, 68, 86, 89, 25, 19, 72, 68, 91, 21, 54, 9, 46, 26, 65, 15, 92, 59, 48, 75, 54, 96, 21, 41, 31, 50, 53, 20, 87, 21, 78, 75, 41, 40, 95, 84, 15, 60, 72, 25, 64, 22, 72, 16, 65, 77, 27, 11, 29, 20, 24, 46, 100, 75, 1, 30, 57, 61, 38, 30, 82, 93, 81, 82, 49, 50, 99, 29, 68, 47, 63, 37, 17, 39, 37, 30, 68, 77, 210}, { 210, 86, 11, 50, 73, 96, 73, 69, 92, 78, 7, 49, 64, 4, 91, 33, 58, 4, 14, 26, 43, 3, 4, 59, 90, 31, 62, 24, 91, 14, 68, 48, 84, 66, 45, 46, 41, 77, 66, 53, 45, 21, 72, 66, 21, 39, 50, 42, 25, 83, 19, 16, 83, 42, 27, 72, 53, 37, 25, 48, 80, 59, 27, 50, 90, 85, 30, 41, 6, 45, 70, 43, 86, 6, 99, 89, 37, 86, 83, 57, 63, 30, 50, 97, 61, 69, 47, 51, 47, 59, 16, 24, 210}, { 210, 65, 11, 24, 79, 81, 76, 68, 78, 26, 46, 82, 5, 80, 87, 11, 62, 15, 14, 74, 11, 57, 91, 66, 12, 100, 90, 43, 11, 45, 78, 50, 94, 30, 39, 63, 30, 8, 72, 72, 35, 75, 92, 28, 28, 78, 74, 88, 18, 10, 41, 8, 74, 76, 62, 81, 42, 12, 29, 93, 25, 7, 8, 47, 3, 99, 92, 13, 94, 17, 30, 49, 89, 54, 33, 89, 19, 86, 88, 53, 52, 8, 88, 29, 12, 48, 35, 86, 48, 58, 26, 85, 210}, { 210, 6, 50, 85, 89, 96, 71, 38, 88, 23, 5, 14, 61, 98, 75, 87, 81, 13, 21, 51, 54, 59, 95, 59, 99, 49, 99, 59, 47, 94, 26, 38, 56, 80, 48, 28, 20, 46, 93, 11, 8, 21, 1, 2, 62, 82, 22, 69, 87, 44, 4, 78, 59, 46, 27, 44, 98, 71, 79, 15, 14, 47, 97, 34, 52, 50, 17, 74, 74, 19, 48, 83, 3, 16, 93, 69, 25, 58, 35, 12, 16, 60, 69, 39, 56, 31, 1, 69, 58, 24, 68, 16, 210}, { 210, 20, 55, 1, 30, 42, 28, 96, 80, 33, 27, 90, 37, 53, 21, 85, 24, 45, 65, 15, 8, 70, 1, 80, 34, 98, 44, 97, 43, 61, 33, 37, 32, 41, 7, 39, 68, 34, 58, 97, 96, 49, 68, 51, 66, 80, 63, 87, 48, 4, 43, 60, 13, 2, 90, 4, 5, 74, 89, 76, 37, 69, 28, 26, 66, 12, 85, 73, 97, 13, 26, 21, 78, 75, 51, 25, 28, 77, 36, 1, 55, 56, 9, 26, 11, 14, 17, 100, 28, 68, 96, 52, 210}, { 210, 6, 44, 84, 83, 46, 50, 84, 95, 72, 8, 62, 14, 71, 63, 11, 72, 5, 76, 21, 72, 43, 88, 16, 32, 75, 10, 67, 1, 29, 60, 30, 50, 25, 35, 2, 77, 40, 39, 35, 11, 49, 41, 14, 79, 95, 74, 21, 86, 72, 11, 58, 86, 22, 18, 4, 77, 6, 73, 75, 55, 79, 30, 86, 94, 34, 49, 79, 66, 7, 88, 9, 49, 93, 76, 35, 31, 37, 72, 6, 74, 73, 42, 43, 52, 66, 30, 90, 85, 41, 87, 6, 210}, { 210, 72, 39, 33, 22, 96, 10, 73, 32, 36, 64, 91, 46, 49, 94, 60, 6, 55, 28, 57, 33, 100, 18, 16, 91, 71, 97, 37, 41, 83, 46, 4, 11, 61, 75, 70, 90, 83, 68, 18, 57, 33, 42, 37, 83, 75, 93, 61, 77, 72, 60, 91, 53, 18, 79, 21, 64, 90, 95, 27, 18, 94, 11, 24, 43, 22, 67, 59, 79, 47, 15, 80, 7, 35, 39, 31, 95, 18, 66, 36, 84, 89, 53, 71, 39, 67, 66, 34, 46, 60, 65, 80, 210}, { 210, 78, 22, 15, 95, 63, 81, 4, 77, 93, 82, 10, 69, 31, 18, 60, 34, 52, 64, 93, 91, 99, 79, 87, 62, 92, 36, 47, 38, 40, 3, 57, 5, 28, 78, 33, 44, 61, 33, 73, 29, 88, 71, 55, 95, 100, 94, 82, 76, 22, 86, 67, 10, 41, 40, 50, 72, 55, 27, 31, 31, 68, 97, 30, 14, 14, 50, 28, 70, 92, 61, 25, 55, 33, 27, 87, 2, 56, 63, 38, 95, 37, 99, 61, 81, 53, 19, 73, 18, 46, 62, 87, 210}, { 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("plane.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 93, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 93, a ustawiła na %d", arr->width);
                    test_error(arr->height == 162, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 162, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 162; ++i)
                        for (int j = 0; j < 93; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 93, .height = 162 }, 210);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {
                        for (int i = 0; i < 162; ++i)
                            for (int j = 0; j < 93; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 53: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST53(void)
{
    // informacje o teście
    test_start(53, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244}, { 244, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 244}, { 244, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 244}, { 244, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 244}, { 244, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 244}, { 244, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 244}, { 244, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 244}, { 244, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 244}, { 244, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 244}, { 244, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 244}, { 244, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 244}, { 244, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 244}, { 244, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 244}, { 244, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 244}, { 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 17, .height = 15 }, 244);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 54: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST54(void)
{
    // informacje o teście
    test_start(54, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 38, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 15, 13 }, .width = 1, .height = 1 }, 38);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 55: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST55(void)
{
    // informacje o teście
    test_start(55, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 222, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 222);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 56: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST56(void)
{
    // informacje o teście
    test_start(56, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 255, 255, 255, 255, 255, 255, 255, 255, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 255, 255, 255, 255, 255, 255, 255, 255, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 12 }, .width = 8, .height = 2 }, 255);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 57: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST57(void)
{
    // informacje o teście
    test_start(57, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 211, 211, 211, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 211, 38, 211, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 211, 211, 211, 62, 43, 18, 20, 54, 78}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 8, 12 }, .width = 3, .height = 3 }, 211);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 58: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST58(void)
{
    // informacje o teście
    test_start(58, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 17, 0 }, .width = 1, .height = 11 }, 66);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 59: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST59(void)
{
    // informacje o teście
    test_start(59, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 17, 0 }, .width = 9, .height = 7 }, 110);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 60: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST60(void)
{
    // informacje o teście
    test_start(60, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 15 }, .width = 12, .height = 1 }, 33);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 61: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST61(void)
{
    // informacje o teście
    test_start(61, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 15 }, .width = 7, .height = 10 }, 189);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 62: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST62(void)
{
    // informacje o teście
    test_start(62, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 0, .height = 3 }, 17);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 63: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST63(void)
{
    // informacje o teście
    test_start(63, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 13, .height = 0 }, 189);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 64: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST64(void)
{
    // informacje o teście
    test_start(64, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = -13 }, 226);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 65: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST65(void)
{
    // informacje o teście
    test_start(65, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = -13, .height = 1 }, 47);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 66: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST66(void)
{
    // informacje o teście
    test_start(66, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, -1 }, .width = 1, .height = 2 }, 230);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 67: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST67(void)
{
    // informacje o teście
    test_start(67, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { -4, 0 }, .width = 8, .height = 1 }, 1);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 68: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST68(void)
{
    // informacje o teście
    test_start(68, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 11 }, .width = 16, .height = 9 }, 203);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 69: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST69(void)
{
    // informacje o teście
    test_start(69, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 7, 11 }, .width = 21, .height = 3 }, 52);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 70: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST70(void)
{
    // informacje o teście
    test_start(70, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 30 }, .width = 1, .height = 1 }, 16);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 71: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST71(void)
{
    // informacje o teście
    test_start(71, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};
                    int array_draw_rectangle[15][17] = {{ 25, 21, 71, 84, 27, 34, 74, 38, 27, 71, 72, 63, 54, 81, 97, 64, 83}, { 85, 44, 95, 72, 46, 77, 31, 13, 48, 91, 32, 57, 71, 14, 16, 48, 73}, { 1, 32, 19, 19, 28, 82, 71, 78, 30, 37, 44, 2, 76, 45, 34, 61, 97}, { 59, 19, 94, 97, 77, 40, 85, 76, 53, 81, 99, 74, 81, 86, 91, 14, 17}, { 98, 55, 4, 16, 100, 92, 68, 52, 54, 69, 57, 11, 44, 46, 79, 10, 25}, { 34, 99, 90, 63, 84, 54, 13, 99, 58, 65, 89, 13, 70, 47, 82, 33, 69}, { 23, 81, 13, 22, 16, 86, 77, 51, 13, 78, 3, 80, 56, 72, 66, 64, 10}, { 42, 95, 76, 77, 46, 9, 97, 35, 80, 48, 22, 2, 9, 38, 32, 76, 93}, { 4, 39, 5, 70, 71, 47, 12, 38, 94, 82, 85, 81, 20, 92, 6, 59, 98}, { 5, 47, 5, 46, 48, 85, 46, 77, 56, 11, 14, 21, 29, 63, 82, 60, 32}, { 91, 46, 40, 99, 50, 59, 64, 75, 13, 41, 65, 81, 75, 65, 59, 71, 71}, { 18, 34, 42, 50, 62, 46, 82, 77, 11, 23, 28, 15, 39, 49, 88, 59, 91}, { 30, 67, 86, 66, 22, 53, 4, 33, 57, 66, 41, 43, 99, 75, 75, 43, 6}, { 65, 63, 28, 7, 63, 14, 13, 71, 68, 38, 25, 10, 14, 55, 3, 18, 15}, { 3, 77, 8, 86, 13, 31, 29, 94, 99, 92, 76, 62, 43, 18, 20, 54, 78}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("method.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 17, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 17; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 29, 0 }, .width = 11, .height = 2 }, 117);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {
                        for (int i = 0; i < 15; ++i)
                            for (int j = 0; j < 17; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 72: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST72(void)
{
    // informacje o teście
    test_start(72, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = image_draw_rectangle(NULL, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 249);
                printf("#####END#####");

                test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 73: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST73(void)
{
    // informacje o teście
    test_start(73, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = image_draw_rectangle(NULL, NULL, 194);
                printf("#####END#####");

                test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 74: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST74(void)
{
    // informacje o teście
    test_start(74, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("yard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 8;
                    arr->height = -17;

                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 38);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 8;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 75: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST75(void)
{
    // informacje o teście
    test_start(75, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("yard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -8;
                    arr->height = -17;

                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 191);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 8;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 76: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST76(void)
{
    // informacje o teście
    test_start(76, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("yard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -8;
                    arr->height = 17;

                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 212);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 8;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 77: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST77(void)
{
    // informacje o teście
    test_start(77, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("yard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 8;
                    arr->height = 0;

                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 217);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 8;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 78: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST78(void)
{
    // informacje o teście
    test_start(78, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("yard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 17;

                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 103);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 8;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 79: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST79(void)
{
    // informacje o teście
    test_start(79, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("yard.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 193);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 8;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 80: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST80(void)
{
    // informacje o teście
    test_start(80, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};

                int err_code = 4;

                printf("#####START#####");
                struct image_t *arr = load_image_t("yard.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 17; ++i)
                    for (int j = 0; j < 8; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                printf("#####START#####");
                int res = image_draw_rectangle(arr, NULL, 23);
                printf("#####END#####");

                test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 81: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST81(void)
{
    // informacje o teście
    test_start(81, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};
        
                    int err_code = 1;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("yard.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, -88);
                    printf("#####END#####");
        
                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 82: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST82(void)
{
    // informacje o teście
    test_start(82, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};
        
                    int err_code = 3;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("yard.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 256);
                    printf("#####END#####");
        
                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 83: Sprawdzanie poprawności działania funkcji image_negate
//
void UTEST83(void)
{
    // informacje o teście
    test_start(83, "Sprawdzanie poprawności działania funkcji image_negate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][8] = {{ 2, 7, 0, 9, 4, 3, 0, 9}, { 4, 1, 10, 10, 2, 5, 6, 7}, { 8, 4, 1, 9, 7, 4, 10, 10}, { 2, 10, 0, 9, 2, 1, 1, 0}, { 6, 9, 3, 5, 9, 10, 9, 0}, { 5, 4, 7, 8, 6, 3, 2, 7}, { 8, 7, 0, 7, 3, 2, 8, 8}, { 9, 2, 6, 5, 6, 6, 0, 4}, { 8, 7, 1, 5, 3, 0, 0, 9}, { 0, 2, 9, 10, 5, 1, 3, 10}, { 0, 10, 7, 7, 10, 5, 2, 5}, { 1, 7, 9, 5, 0, 7, 6, 6}, { 8, 4, 0, 5, 2, 0, 1, 0}, { 9, 7, 0, 9, 7, 3, 0, 0}, { 8, 9, 5, 3, 2, 10, 4, 7}, { 8, 8, 1, 4, 1, 2, 5, 0}, { 9, 4, 3, 0, 9, 8, 10, 8}};
        
                    int err_code = 0;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("yard.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 8; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    int res = image_draw_rectangle(arr, &(struct rectangle_t){ .p  = { 0, 0 }, .width = 1, .height = 1 }, 318);
                    printf("#####END#####");
        
                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 84: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST84(void)
{
    // informacje o teście
    test_start(84, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};

                int err_code = 4;

                printf("#####START#####");
                struct image_t *arr = load_image_t("spread.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 19; ++i)
                    for (int j = 0; j < 5; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 19; ++i)
                    for (int j = 0; j < 5; ++j)
                    {
                        printf("#####START#####");
                        const int *res = image_get_pixel(arr, j, i);
                        printf("#####END#####");
                        test_error(res != NULL, "Funkcja image_get_pixel() powinna zwrócić adres komórki (%d, %d) w tablicy, a zwróciła NULL", j, i);
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(*res == array[i][j], "Funkcja image_get_pixel() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], *res);
                        
                    }
                    
                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 85: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST85(void)
{
    // informacje o teście
    test_start(85, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};
        
                    int err_code = 4;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 19);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 86: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST86(void)
{
    // informacje o teście
    test_start(86, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};
        
                    int err_code = 1;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 5, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 87: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST87(void)
{
    // informacje o teście
    test_start(87, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};
        
                    int err_code = 2;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 5, 19);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 88: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST88(void)
{
    // informacje o teście
    test_start(88, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};
        
                    int err_code = 3;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 6, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 89: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST89(void)
{
    // informacje o teście
    test_start(89, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};
        
                    int err_code = 4;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 33);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 90: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST90(void)
{
    // informacje o teście
    test_start(90, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};
        
                    int err_code = 0;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, -2, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 91: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST91(void)
{
    // informacje o teście
    test_start(91, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};
        
                    int err_code = 2;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, -16);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 92: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST92(void)
{
    // informacje o teście
    test_start(92, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 5;
                    arr->height = -19;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 5;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 93: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST93(void)
{
    // informacje o teście
    test_start(93, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -5;
                    arr->height = -19;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 5;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 94: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST94(void)
{
    // informacje o teście
    test_start(94, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -5;
                    arr->height = 19;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 5;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 95: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST95(void)
{
    // informacje o teście
    test_start(95, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 5;
                    arr->height = 0;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 5;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 96: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST96(void)
{
    // informacje o teście
    test_start(96, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 19;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 5;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 97: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST97(void)
{
    // informacje o teście
    test_start(97, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][5] = {{ 2, 9, 10, 6, 2}, { 10, 3, 6, 5, 10}, { 10, 6, 1, 4, 5}, { 5, 3, 7, 9, 1}, { 8, 1, 3, 0, 4}, { 2, 9, 3, 1, 3}, { 5, 10, 7, 1, 6}, { 3, 10, 5, 0, 5}, { 5, 1, 10, 10, 0}, { 2, 1, 7, 9, 4}, { 0, 2, 6, 5, 10}, { 2, 2, 7, 8, 3}, { 4, 3, 6, 8, 9}, { 0, 8, 3, 8, 6}, { 5, 9, 8, 1, 9}, { 10, 5, 0, 1, 10}, { 4, 6, 4, 2, 9}, { 9, 6, 4, 3, 10}, { 5, 5, 9, 6, 7}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("spread.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 5;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 98: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST98(void)
{
    // informacje o teście
    test_start(98, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


                printf("#####START#####");
                const int *res = image_get_pixel(NULL, 0, 0);
                printf("#####END#####");

                test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 99: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST99(void)
{
    // informacje o teście
    test_start(99, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                int err_code = 4;

                printf("#####START#####");
                struct image_t *arr = load_image_t("market.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 17; ++i)
                    for (int j = 0; j < 6; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 17; ++i)
                    for (int j = 0; j < 6; ++j)
                    {
                        printf("#####START#####");
                        int *res = image_set_pixel(arr, j, i);
                        printf("#####END#####");
                        test_error(res != NULL, "Funkcja image_set_pixel() powinna zwrócić adres komórki (%d, %d) w tablicy, a zwróciła NULL", j, i);
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(res == &arr->ptr[i][j], "Funkcja image_set_pixel() zwróciła niepoprawny adres komórki, powinna zwrócić adres komórki (%d, %d)", i, j);

                    }

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 100: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST100(void)
{
    // informacje o teście
    test_start(100, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 17);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 101: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST101(void)
{
    // informacje o teście
    test_start(101, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 6, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 102: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST102(void)
{
    // informacje o teście
    test_start(102, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 6, 17);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 103: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST103(void)
{
    // informacje o teście
    test_start(103, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 7, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 104: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST104(void)
{
    // informacje o teście
    test_start(104, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 24);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 105: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST105(void)
{
    // informacje o teście
    test_start(105, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, -2, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 106: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST106(void)
{
    // informacje o teście
    test_start(106, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, -13);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 107: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST107(void)
{
    // informacje o teście
    test_start(107, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 6;
                    arr->height = -17;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 108: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST108(void)
{
    // informacje o teście
    test_start(108, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -6;
                    arr->height = -17;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 109: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST109(void)
{
    // informacje o teście
    test_start(109, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -6;
                    arr->height = 17;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 110: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST110(void)
{
    // informacje o teście
    test_start(110, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 6;
                    arr->height = 0;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 111: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST111(void)
{
    // informacje o teście
    test_start(111, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 17;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 112: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST112(void)
{
    // informacje o teście
    test_start(112, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][6] = {{ 3, 5, 1, 9, 4, 8}, { 10, 9, 0, 3, 8, 1}, { 9, 5, 7, 3, 3, 8}, { 5, 5, 1, 4, 1, 8}, { 6, 5, 6, 2, 5, 3}, { 10, 2, 4, 9, 6, 4}, { 2, 4, 9, 3, 9, 7}, { 6, 1, 6, 9, 1, 10}, { 1, 0, 7, 0, 7, 4}, { 0, 10, 9, 1, 0, 0}, { 1, 2, 2, 1, 3, 7}, { 8, 6, 5, 1, 10, 7}, { 9, 8, 0, 1, 6, 1}, { 9, 1, 7, 9, 2, 4}, { 5, 7, 7, 9, 9, 10}, { 8, 1, 4, 9, 6, 4}, { 9, 9, 10, 5, 10, 10}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("market.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 113: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST113(void)
{
    // informacje o teście
    test_start(113, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


                printf("#####START#####");
                const int *res = image_set_pixel(NULL, 0, 0);
                printf("#####END#####");

                test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 114: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST114(void)
{
    // informacje o teście
    test_start(114, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][9] = {{ 1, 7, 6, 4, 5, 10, 7, 4, 5}, { 6, 10, 6, 6, 5, 9, 4, 9, 2}, { 2, 4, 3, 1, 0, 4, 8, 2, 3}, { 0, 6, 1, 10, 6, 1, 4, 3, 3}, { 3, 3, 3, 3, 5, 8, 5, 9, 1}, { 5, 9, 2, 2, 1, 10, 6, 3, 3}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("check.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 6; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("paragraph.bin", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 115: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST115(void)
{
    // informacje o teście
    test_start(115, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[15][10] = {{ 10, 4, 10, 10, 2, 5, 9, 8, 7, 6}, { 7, 10, 1, 6, 2, 8, 3, 2, 10, 8}, { 8, 4, 3, 3, 5, 8, 8, 9, 10, 1}, { 2, 2, 2, 2, 6, 0, 10, 1, 6, 6}, { 3, 1, 6, 3, 3, 10, 5, 2, 10, 10}, { 10, 2, 7, 4, 10, 9, 3, 4, 8, 3}, { 1, 10, 6, 7, 9, 3, 7, 9, 5, 8}, { 5, 6, 0, 10, 7, 8, 3, 4, 8, 3}, { 5, 0, 4, 0, 9, 1, 0, 10, 6, 6}, { 3, 1, 10, 8, 1, 5, 9, 3, 6, 8}, { 7, 6, 4, 3, 3, 6, 9, 8, 4, 8}, { 6, 10, 10, 4, 10, 4, 10, 4, 2, 0}, { 3, 4, 8, 7, 6, 3, 1, 3, 0, 5}, { 1, 3, 6, 5, 4, 3, 0, 9, 6, 0}, { 2, 1, 5, 10, 4, 5, 8, 6, 6, 2}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("shell.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 15, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 15, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 15; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("sight.txt", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 116: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST116(void)
{
    // informacje o teście
    test_start(116, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[20][1] = {{ 8}, { 9}, { 10}, { 10}, { 4}, { 7}, { 10}, { 4}, { 3}, { 9}, { 5}, { 1}, { 4}, { 9}, { 2}, { 0}, { 2}, { 8}, { 7}, { 3}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("symbol.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 20, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 20, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 20; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("farmtxt", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 117: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST117(void)
{
    // informacje o teście
    test_start(117, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][10] = {{ 10, 6, 6, 6, 5, 7, 3, 8, 4, 1}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("king.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("several", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 118: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST118(void)
{
    // informacje o teście
    test_start(118, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 9}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("spend.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("allminesilentcourselategardencamponlyappearconsider", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 119: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST119(void)
{
    // informacje o teście
    test_start(119, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][5] = {{ 0, 10, 6, 2, 6}, { 10, 0, 3, 9, 1}, { 9, 10, 6, 8, 3}, { 2, 9, 5, 1, 4}, { 10, 5, 3, 10, 0}, { 2, 4, 5, 3, 8}, { 10, 8, 4, 5, 5}, { 1, 3, 2, 7, 10}, { 0, 10, 6, 4, 6}, { 1, 10, 7, 9, 5}, { 2, 2, 7, 7, 5}, { 4, 8, 4, 3, 10}, { 5, 4, 8, 9, 5}, { 1, 2, 7, 5, 4}, { 1, 6, 6, 4, 10}, { 1, 3, 0, 6, 2}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("else.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 5;
                    arr->height = -16;

                    printf("#####START#####");                            
                    int res = save_image_t("spend.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 16;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 120: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST120(void)
{
    // informacje o teście
    test_start(120, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][5] = {{ 0, 10, 6, 2, 6}, { 10, 0, 3, 9, 1}, { 9, 10, 6, 8, 3}, { 2, 9, 5, 1, 4}, { 10, 5, 3, 10, 0}, { 2, 4, 5, 3, 8}, { 10, 8, 4, 5, 5}, { 1, 3, 2, 7, 10}, { 0, 10, 6, 4, 6}, { 1, 10, 7, 9, 5}, { 2, 2, 7, 7, 5}, { 4, 8, 4, 3, 10}, { 5, 4, 8, 9, 5}, { 1, 2, 7, 5, 4}, { 1, 6, 6, 4, 10}, { 1, 3, 0, 6, 2}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("else.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -5;
                    arr->height = -16;

                    printf("#####START#####");                            
                    int res = save_image_t("spend.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 16;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 121: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST121(void)
{
    // informacje o teście
    test_start(121, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][5] = {{ 0, 10, 6, 2, 6}, { 10, 0, 3, 9, 1}, { 9, 10, 6, 8, 3}, { 2, 9, 5, 1, 4}, { 10, 5, 3, 10, 0}, { 2, 4, 5, 3, 8}, { 10, 8, 4, 5, 5}, { 1, 3, 2, 7, 10}, { 0, 10, 6, 4, 6}, { 1, 10, 7, 9, 5}, { 2, 2, 7, 7, 5}, { 4, 8, 4, 3, 10}, { 5, 4, 8, 9, 5}, { 1, 2, 7, 5, 4}, { 1, 6, 6, 4, 10}, { 1, 3, 0, 6, 2}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("else.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -5;
                    arr->height = 16;

                    printf("#####START#####");                            
                    int res = save_image_t("spend.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 16;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 122: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST122(void)
{
    // informacje o teście
    test_start(122, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][5] = {{ 0, 10, 6, 2, 6}, { 10, 0, 3, 9, 1}, { 9, 10, 6, 8, 3}, { 2, 9, 5, 1, 4}, { 10, 5, 3, 10, 0}, { 2, 4, 5, 3, 8}, { 10, 8, 4, 5, 5}, { 1, 3, 2, 7, 10}, { 0, 10, 6, 4, 6}, { 1, 10, 7, 9, 5}, { 2, 2, 7, 7, 5}, { 4, 8, 4, 3, 10}, { 5, 4, 8, 9, 5}, { 1, 2, 7, 5, 4}, { 1, 6, 6, 4, 10}, { 1, 3, 0, 6, 2}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("else.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 5;
                    arr->height = 0;

                    printf("#####START#####");                            
                    int res = save_image_t("spend.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 16;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 123: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST123(void)
{
    // informacje o teście
    test_start(123, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][5] = {{ 0, 10, 6, 2, 6}, { 10, 0, 3, 9, 1}, { 9, 10, 6, 8, 3}, { 2, 9, 5, 1, 4}, { 10, 5, 3, 10, 0}, { 2, 4, 5, 3, 8}, { 10, 8, 4, 5, 5}, { 1, 3, 2, 7, 10}, { 0, 10, 6, 4, 6}, { 1, 10, 7, 9, 5}, { 2, 2, 7, 7, 5}, { 4, 8, 4, 3, 10}, { 5, 4, 8, 9, 5}, { 1, 2, 7, 5, 4}, { 1, 6, 6, 4, 10}, { 1, 3, 0, 6, 2}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("else.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 16;

                    printf("#####START#####");                            
                    int res = save_image_t("spend.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 16;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 124: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST124(void)
{
    // informacje o teście
    test_start(124, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][5] = {{ 0, 10, 6, 2, 6}, { 10, 0, 3, 9, 1}, { 9, 10, 6, 8, 3}, { 2, 9, 5, 1, 4}, { 10, 5, 3, 10, 0}, { 2, 4, 5, 3, 8}, { 10, 8, 4, 5, 5}, { 1, 3, 2, 7, 10}, { 0, 10, 6, 4, 6}, { 1, 10, 7, 9, 5}, { 2, 2, 7, 7, 5}, { 4, 8, 4, 3, 10}, { 5, 4, 8, 9, 5}, { 1, 2, 7, 5, 4}, { 1, 6, 6, 4, 10}, { 1, 3, 0, 6, 2}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("else.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 5; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");                            
                    int res = save_image_t("spend.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 5;
                    arr->height = 16;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 125: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST125(void)
{
    // informacje o teście
    test_start(125, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[16][5] = {{ 0, 10, 6, 2, 6}, { 10, 0, 3, 9, 1}, { 9, 10, 6, 8, 3}, { 2, 9, 5, 1, 4}, { 10, 5, 3, 10, 0}, { 2, 4, 5, 3, 8}, { 10, 8, 4, 5, 5}, { 1, 3, 2, 7, 10}, { 0, 10, 6, 4, 6}, { 1, 10, 7, 9, 5}, { 2, 2, 7, 7, 5}, { 4, 8, 4, 3, 10}, { 5, 4, 8, 9, 5}, { 1, 2, 7, 5, 4}, { 1, 6, 6, 4, 10}, { 1, 3, 0, 6, 2}};

                int err_code = 2;

                printf("#####START#####");                            
                struct image_t *arr = load_image_t("else.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 16; ++i)
                    for (int j = 0; j < 5; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                arr->width = 0;
                arr->height = 0;

                printf("#####START#####");                            
                int res = save_image_t(NULL, arr);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                arr->width = 5;
                arr->height = 16;            

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 126: Reakcja funkcji save_image_t na brak możliwości utworzenia pliku (fopen zwróci NULL przy drugim wywołaniu)
//
void UTEST126(void)
{
    // informacje o teście
    test_start(126, "Reakcja funkcji save_image_t na brak możliwości utworzenia pliku (fopen zwróci NULL przy drugim wywołaniu)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 1);
    
    //
    // -----------
    //
    

                int array[16][5] = {{ 0, 10, 6, 2, 6}, { 10, 0, 3, 9, 1}, { 9, 10, 6, 8, 3}, { 2, 9, 5, 1, 4}, { 10, 5, 3, 10, 0}, { 2, 4, 5, 3, 8}, { 10, 8, 4, 5, 5}, { 1, 3, 2, 7, 10}, { 0, 10, 6, 4, 6}, { 1, 10, 7, 9, 5}, { 2, 2, 7, 7, 5}, { 4, 8, 4, 3, 10}, { 5, 4, 8, 9, 5}, { 1, 2, 7, 5, 4}, { 1, 6, 6, 4, 10}, { 1, 3, 0, 6, 2}};

                int err_code = 1;

                printf("#####START#####");                            
                struct image_t *arr = load_image_t("else.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 5, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 5, a ustawiła na %d", arr->width);
                test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 16; ++i)
                    for (int j = 0; j < 5; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                printf("#####START#####");                            
                int res = save_image_t("spend.bin", arr);
                printf("#####END#####");

                test_error(res == 2, "Funkcja save_image_t() powinna zwrócić kod błędu 2, a zwróciła %d", res);

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 127: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST127(void)
{
    // informacje o teście
    test_start(127, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct image_t arr = {.ptr = NULL, .width = 5, .height = 7, .type = "P2" };

                printf("#####START#####");
                int res = save_image_t("else.bin", &arr);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 128: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST128(void)
{
    // informacje o teście
    test_start(128, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = save_image_t("else.bin", NULL);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 129: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST129(void)
{
    // informacje o teście
    test_start(129, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = save_image_t(NULL, NULL);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja bład funkcji fopen (dozwolone jednokrotne wywołanie fopen)
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja bład funkcji fopen (dozwolone jednokrotne wywołanie fopen)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 1);
    
    //
    // -----------
    //
    
            printf("Kolejny test pamięci");
            printf("***START***\n");
            int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
            printf("\n***END***\n");
            test_error(ret_code == 5, "Funkcja main zakończyła się kodem %d a powinna 5", ret_code);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci - limit ustawiony na 0 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci - limit ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci - limit ustawiony na 40 bajtów
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci - limit ustawiony na 40 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(40);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na brak pamięci - limit ustawiony na 152 bajtów
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na brak pamięci - limit ustawiony na 152 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(152);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST2, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST3, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST4, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST5, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST6, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST7, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST8, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST9, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST10, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST11, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST12, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST13, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST14, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST15, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST16, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST17, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST18, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST19, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST20, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST21, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST22, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST23, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST24, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST25, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST26, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST27, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST28, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST29, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST30, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST31, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST32, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST33, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST34, // Sprawdzanie poprawności działania funkcji matrix_load_t
            UTEST35, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 147 bajtów)
            UTEST36, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
            UTEST37, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
            UTEST38, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
            UTEST39, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)
            UTEST40, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)
            UTEST41, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)
            UTEST42, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
            UTEST43, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
            UTEST44, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
            UTEST45, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)
            UTEST46, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)
            UTEST47, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)
            UTEST48, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST49, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST50, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST51, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST52, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST53, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST54, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST55, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST56, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST57, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST58, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST59, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST60, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST61, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST62, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST63, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST64, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST65, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST66, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST67, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST68, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST69, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST70, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST71, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST72, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST73, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST74, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST75, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST76, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST77, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST78, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST79, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST80, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST81, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST82, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST83, // Sprawdzanie poprawności działania funkcji image_negate
            UTEST84, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST85, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST86, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST87, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST88, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST89, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST90, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST91, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST92, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST93, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST94, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST95, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST96, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST97, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST98, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST99, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST100, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST101, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST102, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST103, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST104, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST105, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST106, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST107, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST108, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST109, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST110, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST111, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST112, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST113, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST114, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST115, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST116, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST117, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST118, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST119, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST120, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST121, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST122, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST123, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST124, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST125, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST126, // Reakcja funkcji save_image_t na brak możliwości utworzenia pliku (fopen zwróci NULL przy drugim wywołaniu)
            UTEST127, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST128, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST129, // Sprawdzanie poprawności działania funkcji save_image_t
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(129); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja bład funkcji fopen (dozwolone jednokrotne wywołanie fopen)
            MTEST2, // Reakcja na brak pamięci - limit ustawiony na 0 bajtów
            MTEST3, // Reakcja na brak pamięci - limit ustawiony na 40 bajtów
            MTEST4, // Reakcja na brak pamięci - limit ustawiony na 152 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(4); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}