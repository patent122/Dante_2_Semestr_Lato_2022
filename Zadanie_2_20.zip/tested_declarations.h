/*
 * Test dla zadania Ukryta wiadomość II
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-09 21:50:05.601261
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta



            struct message_t;
            int decode_message(const struct message_t *cp, int size, char *msg, int text_size);
            int load_data(struct message_t *cp, int size, const char *filename);


    

#endif // _TESTED_DECLARATIONS_H_