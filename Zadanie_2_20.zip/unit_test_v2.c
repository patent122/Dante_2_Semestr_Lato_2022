/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Ukryta wiadomość II
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-09 21:50:05.598216
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//


    
            struct message_t
            {
                char a;
                double b;
                int c;
            };
    


//
//  Test 1: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned char input_array[] = {108, 73, 116, 32, 105, 115, 32, 98, 247, 212, 215, 145, 119, 212, 70, 192, 255, 255, 255, 255, 101, 116, 116, 101, 98, 114, 32, 116, 111, 32, 98, 101, 208, 238, 190, 155, 155, 151, 72, 64, 205, 255, 255, 255, 32, 104, 97, 116, 78, 101, 100, 32, 102, 111, 114, 32, 55, 152, 50, 26, 205, 158, 69, 192, 182, 255, 255, 255, 119, 104, 97, 116, 73, 32, 121, 111, 117, 32, 97, 114, 64, 73, 142, 243, 106, 61, 0, 192, 170, 255, 255, 255, 101, 32, 116, 104, 90, 97, 110, 32, 116, 111, 32, 98, 6, 144, 163, 168, 131, 58, 75, 192, 229, 255, 255, 255, 101, 32, 108, 111, 116, 118, 101, 100, 32, 102, 111, 114, 227, 43, 122, 136, 190, 226, 83, 192, 81, 0, 0, 0, 32, 119, 104, 97, 72, 116, 32, 121, 111, 117, 32, 97, 80, 79, 9, 220, 62, 34, 44, 192, 40, 0, 0, 0, 114, 101, 32, 110, 69, 111, 116, 46, 32, 45, 32, 65, 152, 147, 15, 174, 111, 254, 78, 64, 11, 0, 0, 0, 110, 100, 114, 101, 97, 32, 71, 105, 100, 101, 0, 0, 89, 205, 217, 220, 213, 57, 71, 192, 49, 0, 0, 0, 0, 0, 0, 0};
                char encoded_msg[94];
                char *expected_msg = "It is better to be hated for what you are than to be loved for what you are not. - Andre Gide";

                struct message_t msg[9];
                
                memcpy(msg, input_array, sizeof(input_array));
                
                printf("#####START#####");
                int res = decode_message(msg, 9, encoded_msg, 94);
                printf("#####END#####\n");

                test_error(strcmp(expected_msg, encoded_msg) == 0, "Funkcja decode_message niepoprawnie rozszyfrowała wiadomość, powinno być %s, a jest %s", expected_msg, encoded_msg);
                test_error(res == 0, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 0, res);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned char input_array[] = {106, 34, 87, 101, 32, 109, 97, 121, 160, 115, 132, 77, 214, 210, 9, 64, 241, 255, 255, 255, 32, 101, 110, 99, 85, 111, 117, 110, 116, 101, 114, 32, 108, 158, 44, 158, 133, 187, 80, 192, 230, 255, 255, 255, 109, 97, 110, 121, 66, 32, 100, 101, 102, 101, 97, 116, 236, 122, 29, 85, 216, 21, 85, 192, 35, 0, 0, 0, 115, 32, 98, 117, 73, 116, 32, 119, 101, 32, 109, 117, 246, 151, 176, 74, 43, 170, 64, 192, 211, 255, 255, 255, 115, 116, 32, 110, 121, 111, 116, 32, 98, 101, 32, 100, 24, 209, 137, 214, 169, 207, 79, 64, 176, 255, 255, 255, 101, 102, 101, 97, 100, 116, 101, 100, 46, 34, 45, 32, 230, 255, 48, 73, 103, 234, 82, 192, 3, 0, 0, 0, 77, 97, 121, 97, 100, 32, 65, 110, 103, 101, 108, 111, 108, 143, 171, 58, 18, 154, 65, 64, 91, 0, 0, 0, 117, 0, 0, 0};
                char encoded_msg[74];
                char *expected_msg = "\"We may encounter many defeats but we must not be defeated.\"- Maya Angelo";

                struct message_t msg[7];
                
                memcpy(msg, input_array, sizeof(input_array));
                
                printf("#####START#####");
                int res = decode_message(msg, 7, encoded_msg, 74);
                printf("#####END#####\n");

                test_error(strcmp(expected_msg, encoded_msg) == 0, "Funkcja decode_message niepoprawnie rozszyfrowała wiadomość, powinno być %s, a jest %s", expected_msg, encoded_msg);
                test_error(res == 0, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 0, res);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned char input_array[] = {111, 72, 111, 119, 32, 119, 111, 110, 184, 27, 4, 234, 193, 22, 84, 64, 59, 0, 0, 0, 100, 101, 114, 102, 115, 117, 108, 32, 105, 116, 32, 105, 240, 90, 59, 220, 171, 111, 65, 192, 15, 0, 0, 0, 115, 32, 116, 104, 122, 97, 116, 32, 110, 111, 98, 111, 0, 243, 224, 175, 20, 9, 14, 192, 98, 0, 0, 0, 100, 121, 32, 110, 104, 101, 101, 100, 32, 119, 97, 105, 102, 197, 154, 172, 91, 194, 81, 192, 84, 0, 0, 0, 116, 32, 97, 32, 121, 115, 105, 110, 103, 108, 101, 32, 104, 150, 93, 91, 251, 162, 44, 192, 63, 0, 0, 0, 109, 111, 109, 101, 104, 110, 116, 32, 98, 101, 102, 111, 164, 152, 39, 143, 168, 133, 69, 64, 212, 255, 255, 255, 114, 101, 32, 115, 88, 116, 97, 114, 116, 105, 110, 103, 52, 233, 63, 211, 245, 172, 50, 64, 203, 255, 255, 255, 32, 116, 111, 32, 114, 105, 109, 112, 114, 111, 118, 101, 144, 118, 192, 255, 232, 174, 76, 64, 169, 255, 255, 255, 32, 116, 104, 101, 122, 32, 119, 111, 114, 108, 100, 46, 76, 194, 74, 170, 249, 54, 77, 64, 219, 255, 255, 255, 32, 45, 32, 65, 79, 110, 110, 101, 32, 70, 114, 97, 16, 5, 186, 163, 163, 124, 43, 64, 79, 0, 0, 0, 110, 107, 0, 0};
                char encoded_msg[1];
                char *expected_msg = "";

                struct message_t msg[10];
                
                memcpy(msg, input_array, sizeof(input_array));
                
                printf("#####START#####");
                int res = decode_message(msg, 10, encoded_msg, 1);
                printf("#####END#####\n");

                test_error(strcmp(expected_msg, encoded_msg) == 0, "Funkcja decode_message niepoprawnie rozszyfrowała wiadomość, powinno być %s, a jest %s", expected_msg, encoded_msg);
                test_error(res == 0, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 0, res);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned char input_array[] = {82, 34, 71, 111, 111, 100, 32, 100, 212, 154, 88, 133, 24, 69, 66, 64, 79, 0, 0, 0, 101, 115, 105, 103, 79, 110, 32, 97, 100, 100, 115, 32, 240, 10, 97, 37, 107, 131, 55, 192, 84, 0, 0, 0, 118, 97, 108, 117, 116, 101, 32, 102, 97, 115, 116, 101, 92, 5, 110, 143, 99, 60, 80, 192, 220, 255, 255, 255, 114, 32, 116, 104, 68, 97, 110, 32, 105, 116, 32, 97, 102, 160, 61, 30, 126, 98, 82, 64, 48, 0, 0, 0, 100, 100, 115, 32, 86, 99, 111, 115, 116, 46, 34, 32, 168, 67, 69, 244, 172, 76, 68, 64, 12, 0, 0, 0, 45, 32, 84, 104, 97, 111, 109, 97, 115, 32, 67, 46, 216, 81, 26, 179, 165, 218, 86, 192, 71, 0, 0, 0, 32, 71, 97, 108, 89, 0, 0, 0, 0, 0, 0, 0, 216, 234, 199, 33, 50, 195, 65, 192, 239, 255, 255, 255, 0, 0, 0, 0};
                char encoded_msg[67];
                char *expected_msg = "\"Good design adds value faster than it adds cost.\" - Thomas C. Gal";

                struct message_t msg[7];
                
                memcpy(msg, input_array, sizeof(input_array));
                
                printf("#####START#####");
                int res = decode_message(msg, 7, encoded_msg, 67);
                printf("#####END#####\n");

                test_error(strcmp(expected_msg, encoded_msg) == 0, "Funkcja decode_message niepoprawnie rozszyfrowała wiadomość, powinno być %s, a jest %s", expected_msg, encoded_msg);
                test_error(res == 0, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 0, res);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct message_t msg[40];

            printf("#####START#####");
            int res = decode_message(msg, 2, NULL, 83);
            printf("#####END#####\n");

            test_error(res == 1, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            char encoded_msg[20];

            printf("#####START#####");
            int res = decode_message(NULL, 2, encoded_msg, 94);
            printf("#####END#####\n");

            test_error(res == 1, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct message_t msg[22];
            char encoded_msg[73];

            printf("#####START#####");
            int res = decode_message(msg, 0, encoded_msg, 42);
            printf("#####END#####\n");

            test_error(res == 1, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct message_t msg[50];
            char encoded_msg[97];

            printf("#####START#####");
            int res = decode_message(msg, 69, encoded_msg, 0);
            printf("#####END#####\n");

            test_error(res == 1, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct message_t msg[75];
            char encoded_msg[96];

            printf("#####START#####");
            int res = decode_message(msg, -58, encoded_msg, 41);
            printf("#####END#####\n");

            test_error(res == 1, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzenie poprawności działania funkcji decode_message
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzenie poprawności działania funkcji decode_message", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct message_t msg[24];
            char encoded_msg[77];

            printf("#####START#####");
            int res = decode_message(msg, 59, encoded_msg, -25);
            printf("#####END#####\n");

            test_error(res == 1, "Funkcja decode_message zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned char input_array[] = {67, 72, 101, 97, 108, 116, 104, 99, 36, 107, 140, 245, 29, 216, 59, 192, 18, 0, 0, 0, 97, 114, 101, 32, 79, 105, 115, 32, 98, 101, 99, 111, 240, 94, 39, 51, 76, 36, 16, 192, 163, 255, 255, 255, 109, 105, 110, 103, 114, 32, 112, 97, 114, 116, 32, 111, 216, 175, 218, 247, 170, 207, 59, 64, 171, 255, 255, 255, 102, 32, 105, 110, 90, 102, 111, 114, 109, 97, 116, 105, 248, 19, 167, 96, 226, 51, 80, 64, 177, 255, 255, 255, 111, 110, 32, 116, 81, 101, 99, 104, 110, 111, 108, 111, 176, 29, 177, 103, 181, 183, 36, 192, 99, 0, 0, 0, 103, 121, 46, 32, 70, 45, 32, 66, 105, 108, 108, 32, 210, 142, 99, 26, 255, 101, 87, 64, 203, 255, 255, 255, 77, 97, 114, 105, 65, 115, 0, 0, 0, 0, 0, 0, 206, 39, 20, 237, 109, 249, 83, 64, 168, 255, 255, 255, 0, 0, 0, 0};

                struct message_t msg[7];
                
                printf("#####START#####");
                int res = load_data(msg, 7, "importance.bin");
                printf("#####END#####\n");

                // znajdź pierwszą różnicę
                int diff_pos = mem_find_first_difference(input_array, &msg, sizeof(input_array));
            
                // jeśli jest, to raportuj błąd
                test_error(diff_pos == -1, "Treść odczytana z pliku play.bin nie jest poprawna; różnica w bajcie %d; jest 0x%02x a powinno być 0x%02x",
                    diff_pos, mem_get_byte(input_array, diff_pos), mem_get_byte(&msg, diff_pos));

                test_error(res == 7, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 7, res);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned char input_array[] = {105, 73, 102, 32, 121, 111, 117, 32, 236, 126, 109, 99, 237, 18, 69, 64, 171, 255, 255, 255, 119, 97, 110, 116};

                struct message_t msg[1];
                
                printf("#####START#####");
                int res = load_data(msg, 1, "discussion.bin");
                printf("#####END#####\n");

                // znajdź pierwszą różnicę
                int diff_pos = mem_find_first_difference(input_array, &msg, sizeof(input_array));
            
                // jeśli jest, to raportuj błąd
                test_error(diff_pos == -1, "Treść odczytana z pliku play.bin nie jest poprawna; różnica w bajcie %d; jest 0x%02x a powinno być 0x%02x",
                    diff_pos, mem_get_byte(input_array, diff_pos), mem_get_byte(&msg, diff_pos));

                test_error(res == 1, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 1, res);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned char input_array[] = {81, 73, 32, 97, 109, 32, 101, 110, 76, 151, 254, 195, 0, 136, 62, 192, 25, 0, 0, 0, 111, 117, 103, 104, 102, 32, 111, 102, 32, 97, 110, 32, 164, 188, 145, 197, 220, 229, 84, 64, 219, 255, 255, 255, 97, 114, 116, 105, 76, 115, 116, 32, 116, 111, 32, 100, 40, 39, 9, 158, 160, 54, 84, 64, 32, 0, 0, 0, 114, 97, 119, 32, 110, 102, 114, 101, 101, 108, 121, 32, 32, 84, 211, 247, 6, 95, 65, 192, 184, 255, 255, 255, 117, 112, 111, 110, 80, 32, 109, 121, 32, 105, 109, 97, 164, 21, 103, 131, 181, 177, 64, 192, 207, 255, 255, 255, 103, 105, 110, 97, 105, 116, 105, 111, 110, 46, 32, 73, 156, 169, 95, 169, 211, 29, 83, 64, 39, 0, 0, 0, 109, 97, 103, 105, 70, 110, 97, 116, 105, 111, 110, 32, 192, 96, 114, 252, 114, 218, 65, 192, 86, 0, 0, 0, 105, 115, 32, 109, 84, 111, 114, 101, 32, 105, 109, 112, 48, 165, 57, 234, 178, 237, 42, 64, 199, 255, 255, 255, 111, 114, 116, 97, 121, 110, 116, 32, 116, 104, 97, 110, 204, 222, 123, 94, 140, 239, 88, 192, 236, 255, 255, 255, 32, 107, 110, 111, 83, 119, 108, 101, 100, 103, 101, 46, 221, 228, 230, 44, 137, 252, 70, 192, 58, 0, 0, 0, 32, 75, 110, 111, 118, 119, 108, 101, 100, 103, 101, 32, 30, 225, 163, 198, 45, 187, 66, 192, 90, 0, 0, 0, 105, 115, 32, 108, 66, 105, 109, 105, 116, 101, 100, 46, 245, 102, 44, 248, 46, 65, 69, 192, 83, 0, 0, 0, 32, 73, 109, 97, 110, 103, 105, 110, 97, 116, 105, 111, 64, 122, 235, 96, 151, 254, 68, 64, 189, 255, 255, 255, 110, 32, 101, 110, 117, 99, 105, 114, 99, 108, 101, 115, 136, 73, 99, 76, 123, 185, 78, 64, 168, 255, 255, 255, 32, 116, 104, 101, 82, 32, 119, 111, 114, 108, 100, 46, 104, 200, 249, 182, 23, 183, 86, 64, 33, 0, 0, 0, 32, 45, 32, 65, 75, 108, 98, 101, 114, 116, 32, 69, 136, 55, 250, 140, 158, 128, 59, 64, 87, 0, 0, 0, 105, 110, 115, 116, 104, 101, 105, 110, 10, 78, 105, 110, 212, 236, 134, 199, 133, 223, 67, 192, 234, 255, 255, 255, 101, 116, 121, 32, 105, 112, 101, 114, 99, 101, 110, 116, 110, 201, 15, 205, 41, 24, 81, 192, 250, 255, 255, 255, 32, 111, 102, 32, 107, 103, 97, 109, 101, 115, 32, 108, 180, 13, 115, 21, 57, 129, 50, 64, 180, 255, 255, 255, 111, 115, 101, 32, 117, 109, 111, 110, 101, 121, 59, 32, 32, 202, 214, 174, 145, 196, 39, 192, 5, 0, 0, 0, 49, 48, 32, 112, 66, 101, 114, 99, 101, 110, 116, 32, 168, 121, 52, 39, 231, 206, 53, 64, 90, 0, 0, 0, 109, 97, 107, 101, 119, 32, 97, 32, 108, 111, 116, 32, 230, 204, 134, 128, 88, 213, 83, 192, 85, 0, 0, 0, 111, 102, 32, 109, 71, 111, 110, 101, 121, 46, 32, 65, 144, 133, 254, 139, 1, 59, 84, 64, 64, 0, 0, 0, 110, 100, 32, 116, 83, 104, 101, 114, 101, 39, 115, 32, 239, 220, 34, 25, 56, 220, 88, 192, 46, 0, 0, 0, 97, 32, 99, 111, 115, 110, 115, 105, 115, 116, 101, 110, 184, 7, 252, 16, 97, 89, 52, 64, 16, 0, 0, 0, 99, 121, 32, 97, 114, 114, 111, 117, 110, 100, 32, 116, 40, 133, 250, 217, 139, 218, 65, 64, 200, 255, 255, 255, 104, 101, 32, 99, 82, 111, 109, 112, 101, 116, 105, 116, 26, 91, 225, 206, 109, 138, 84, 64, 66, 0, 0, 0, 105, 118, 101, 32, 87, 97, 100, 118, 97, 110, 116, 97, 124, 120, 210, 148, 28, 87, 50, 64, 78, 0, 0, 0, 103, 101, 115, 32, 113, 121, 111, 117, 32, 99, 114, 101, 185, 196, 192, 24, 90, 221, 86, 192, 246, 255, 255, 255, 97, 116, 101, 44, 90, 32, 115, 111, 32, 105, 102, 32, 236, 220, 72, 57, 183, 226, 65, 192, 251, 255, 255, 255, 121, 111, 117, 32, 118, 99, 97, 110, 32, 97, 99, 116, 238, 186, 237, 216, 201, 82, 80, 192, 98, 0, 0, 0, 117, 97, 108, 108, 85, 121, 32, 108, 101, 97, 114, 110, 190, 103, 91, 134, 177, 113, 78, 192, 225, 255, 255, 255, 32, 104, 111, 119, 71, 32, 116, 111, 32, 100, 111, 32, 94, 71, 76, 138, 24, 185, 85, 64, 161, 255, 255, 255, 116, 104, 101, 32, 110, 97, 114, 116, 44, 32, 116, 104, 16, 148, 147, 199, 194, 107, 35, 192, 38, 0, 0, 0, 101, 32, 100, 101, 122, 115, 105, 103, 110, 44, 32, 97, 232, 129, 10, 183, 64, 185, 69, 64, 235, 255, 255, 255, 110, 100, 32, 116, 87, 104, 101, 32, 112, 114, 111, 103, 204, 209, 66, 238, 76, 90, 78, 64, 7, 0, 0, 0, 114, 97, 109, 109, 76, 105, 110, 103, 44, 32, 121, 111, 36, 163, 151, 247, 184, 246, 84, 64, 26, 0, 0, 0, 117, 32, 119, 111, 120, 117, 108, 100, 32, 98, 101, 32, 24, 100, 4, 201, 136, 73, 62, 192, 179, 255, 255, 255, 99, 111, 110, 115, 90, 105, 115, 116, 101, 110, 116, 108, 67, 141, 54, 92, 79, 198, 88, 192, 12, 0, 0, 0, 121, 32, 118, 101, 110, 114, 121, 32, 112, 114, 111, 102, 150, 78, 6, 187, 196, 128, 81, 192, 219, 255, 255, 255, 105, 116, 97, 98, 76, 108, 101, 46, 32, 45, 32, 71, 138, 254, 90, 67, 109, 13, 77, 192, 172, 255, 255, 255, 97, 98, 101, 32, 117, 78, 101, 119, 101, 108, 108, 0, 180, 46, 111, 27, 243, 163, 58, 64, 209, 255, 255, 255, 0, 0, 0, 0};

                struct message_t msg[42];
                
                printf("#####START#####");
                int res = load_data(msg, 42, "play.bin");
                printf("#####END#####\n");

                // znajdź pierwszą różnicę
                int diff_pos = mem_find_first_difference(input_array, &msg, sizeof(input_array));
            
                // jeśli jest, to raportuj błąd
                test_error(diff_pos == -1, "Treść odczytana z pliku play.bin nie jest poprawna; różnica w bajcie %d; jest 0x%02x a powinno być 0x%02x",
                    diff_pos, mem_get_byte(input_array, diff_pos), mem_get_byte(&msg, diff_pos));

                test_error(res == 42, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", 42, res);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct message_t msg[13];

            printf("#####START#####");
            int res = load_data(msg, 13, "initially.bin");
            printf("#####END#####\n");

            test_error(res == -2, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", -2, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct message_t msg[13];

            printf("#####START#####");
            int res = load_data(msg, 0, "initially.bin");
            printf("#####END#####\n");

            test_error(res == -1, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", -1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct message_t msg[13];

            printf("#####START#####");
            int res = load_data(msg, -13, "initially.bin");
            printf("#####END#####\n");

            test_error(res == -1, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", -1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct message_t msg[13];

            printf("#####START#####");
            int res = load_data(msg, 13, NULL);
            printf("#####END#####\n");

            test_error(res == -1, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", -1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            int res = load_data(NULL, 13, "initially.bin");
            printf("#####END#####\n");

            test_error(res == -1, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", -1, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

             struct message_t msg[10];

             printf("#####START#####");
             int res = load_data(msg, 10, "disorder.bin");
             printf("#####END#####\n");

             test_error(res == -3, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", -3, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

             struct message_t msg[6];

             printf("#####START#####");
             int res = load_data(msg, 6, "nut.bin");
             printf("#####END#####\n");

             test_error(res == -3, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", -3, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzenie poprawności działania funkcji load_data
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzenie poprawności działania funkcji load_data", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

             struct message_t msg[12];

             printf("#####START#####");
             int res = load_data(msg, 12, "promise.bin");
             printf("#####END#####\n");

             test_error(res == -3, "Funkcja load_data zwróciła nieprawidłową wartość, powinno być %d, a jest %d", -3, res);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}




enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST2, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST3, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST4, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST5, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST6, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST7, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST8, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST9, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST10, // Sprawdzenie poprawności działania funkcji decode_message
            UTEST11, // Sprawdzenie poprawności działania funkcji load_data
            UTEST12, // Sprawdzenie poprawności działania funkcji load_data
            UTEST13, // Sprawdzenie poprawności działania funkcji load_data
            UTEST14, // Sprawdzenie poprawności działania funkcji load_data
            UTEST15, // Sprawdzenie poprawności działania funkcji load_data
            UTEST16, // Sprawdzenie poprawności działania funkcji load_data
            UTEST17, // Sprawdzenie poprawności działania funkcji load_data
            UTEST18, // Sprawdzenie poprawności działania funkcji load_data
            UTEST19, // Sprawdzenie poprawności działania funkcji load_data
            UTEST20, // Sprawdzenie poprawności działania funkcji load_data
            UTEST21, // Sprawdzenie poprawności działania funkcji load_data
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(21); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(0); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}