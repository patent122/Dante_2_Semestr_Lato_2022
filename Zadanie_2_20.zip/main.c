﻿#include<stdio.h>
#include<stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"
#include "tested_declarations.h"
#include "rdebug.h"



struct message_t
{
    char a;
    double b;
    int c;
};
int decode_message(const struct message_t* cp, int size, char* msg, int text_size)
{
    if (msg == NULL) return 1;
    if (text_size <= 0) return 1;
    if (cp == NULL) return 1;
    if (size <= 0) return 1;
    unsigned  char* tem = (unsigned char*)cp;
    int bajt = 0;
    int j = 0;
    for(int i=0;i<size;i++)
    {
        for (bajt = i * 24 + 1; bajt < i * 24 + 8; bajt++)
        {

            *(msg + j) = *(tem + bajt);
            j++;

        }
        for (bajt = i * 24 + 20; bajt < i * 24 + 24; bajt++)
        {

            *(msg + j) = *(tem + bajt);
            j++;

        }
    }
    *(msg + text_size - 1) = '\0';
    *(msg + j) = '\0';
    return 0;
}
int load_data(struct message_t* cp, int size, const char* filename)
{
    if (size <= 0) return -1;
    if (filename == NULL) return -1;
    if (cp == NULL) return -1;
    FILE* file;
    file = fopen(filename, "rb");
    if (file == NULL)

    {
        return -2;
    }

    int g = 0;

    if (fread(&g, sizeof(unsigned int), 1, file) != 1)
    {
        fclose(file);
        return -3;
    }
    if (g <= 0)
    {
        fclose(file);
        return -3;
    }
    int licz = 0;
    for(int i=0;i<size;i++)
    {
        if (fread(cp + i, sizeof(struct message_t), 1, file) != 1) break;
        else licz++;
    }
    if ((licz * 24 == g + 1) || licz == 0)
    {
        fclose(file);
        return -3;
    }
    fclose(file);
    return licz;
}
int main()
{
    struct message_t s[100];
    char wiadom[2000];
    char nazwa[31];
    printf("Enter file name:");
    scanf("%30[^\n]", nazwa);
    while (getchar() != '\n');
    int result=load_data(s, 100, nazwa);
    if (result == -3)
    {
        printf("File corrupted");
        return 6;
    }
    else if (result == -2)
    {
        printf("Couldn't open file");
        return 4;
    }
    decode_message(s, result, wiadom, 2000);

    printf("%s", wiadom);

    return 0;
}


