#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int number_2_words(char** tekst, unsigned long long numer);

char* my_strcat(char** dest, const char* zrodlo);

char* ltoa(unsigned long long numer);

void reverse(char*);

int main() {
    unsigned long long numer;
    printf("Enter a number:");
    int r = scanf("%llu", &numer);
    if (r != 1) {
        printf("Incorrect input");
        return 1;
    }
    char* tekst;
    r = number_2_words(&tekst, numer);
    if (r == 2) {
        printf("Failed to allocate memory");
        return 8;
    }
    printf("%s", tekst);
    free(tekst);
    return 0;
}

void reverse(char* bufor_tekst) {
    for (int i = 0; i < (int)strlen(bufor_tekst) / 2; i++) {
        char tt = *(bufor_tekst + i);
        *(bufor_tekst + i) = *(bufor_tekst + strlen(bufor_tekst) - 1 - i);
        *(bufor_tekst + strlen(bufor_tekst) - 1 - i) = tt;
    }
}

char* concat(char** tekst, const char* zrodlo) {
    if (*tekst == NULL) {
        return my_strcat(tekst, zrodlo);
    }
    char* r = my_strcat(tekst, " ");
    if (r == NULL) {
        return NULL;
    }
    return my_strcat(tekst, zrodlo);
}

char* numbers(char** tekst, int nn) {
    
    if (nn >= 20) {
        const char* textadd = NULL;
        switch (nn / 10) {
        case 9:
            textadd = "Ninety";
            break;
        case 8:
            textadd = "Eighty";
            break;
        case 7:
            textadd = "Seventy";
            break;
        case 6:
            textadd = "Sixty";
            break;
        case 5:
            textadd = "Fifty";
            break;
        case 4:
            textadd = "Forty";
            break;
        case 3:
            textadd = "Thirty";
            break;
        case 2:
            textadd = "Twenty";
            break;
        case 1:
            textadd = "Ten";
            break;
        }
        if (textadd != NULL) {
            char* r = concat(tekst, textadd);
            if (r == NULL) {
                return NULL;
            }
        }
        nn %= 10;
    }
    const char* textadd = NULL;
    switch (nn) {
    case 19:
        textadd = "Nineteen";
        break;
    case 18:
        textadd = "Eighteen";
        break;
    case 17:
        textadd = "Seventeen";
        break;
    case 16:
        textadd = "Sixteen";
        break;
    case 15:
        textadd = "Fifteen";
        break;
    case 14:
        textadd = "Fourteen";
        break;
    case 13:
        textadd = "Thirteen";
        break;
    case 12:
        textadd = "Twelve";
        break;
    case 11:
        textadd = "Eleven";
        break;
    case 10:
        textadd = "Ten";
        break;
    case 9:
        textadd = "Nine";
        break;
    case 8:
        textadd = "Eight";
        break;
    case 7:
        textadd = "Seven";
        break;
    case 6:
        textadd = "Six";
        break;
    case 5:
        textadd = "Five";
        break;
    case 4:
        textadd = "Four";
        break;
    case 3:
        textadd = "Three";
        break;
    case 2:
        textadd = "Two";
        break;
    case 1:
        textadd = "One";
        break;
    }
    if (textadd != NULL) {
        char* r = concat(tekst, textadd);
        if (r == NULL)
            return NULL;
    }
    return *tekst;
}

int number_2_words(char** tekst, unsigned long long numer) {
    if (tekst == NULL) {
        return 1;
    }
    *tekst = NULL;
    if (numer == 0) {
        *tekst = strdup("Zero");
        if (*tekst == NULL) {
            return 2;
        }
        return 0;
    }
    char* liczba = ltoa(numer);
    if (liczba == NULL) {
        return 2;
    }
    char* nums = liczba;
    int ok = 0;
    
    reverse(liczba);
    int nn = 0;
    if (strlen(liczba) >= 20) {
        nn += *(liczba + 19) - '0';
        nn *= 10;
        
    }
    if (strlen(liczba) >= 19) {
        nn += *(liczba + 18) - '0';
        
    }
    if (nn != 0) {
        if (numbers(tekst, nn) == NULL || concat(tekst, "Quintillion") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    nn = 0;
    if (strlen(liczba) >= 18) {
        nn += *(liczba + 17) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL || concat(tekst, "Hundred") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    nn = 0;
    if (strlen(liczba) >= 17) {
        nn += *(liczba + 16) - '0';
        nn *= 10;
        
    }
    if (strlen(liczba) >= 16) {
        nn += *(liczba + 15) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    if (ok) {
        if (concat(tekst, "Quadrillion") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    ok = 0;
    nn = 0;
    if (strlen(liczba) >= 15) {
        nn += *(liczba + 14) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL || concat(tekst, "Hundred") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    nn = 0;
    if (strlen(liczba) >= 14) {
        nn += *(liczba + 13) - '0';
        nn *= 10;
        
    }
    if (strlen(liczba) >= 13) {
        nn += *(liczba + 12) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    if (ok) {
        if (concat(tekst, "Trillion") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    ok = 0;
    nn = 0;
    if (strlen(liczba) >= 12) {
        nn += *(liczba + 11) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL || concat(tekst, "Hundred") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    nn = 0;
    if (strlen(liczba) >= 11) {
        nn += *(liczba + 10) - '0';
        nn *= 10;
        
    }
    if (strlen(liczba) >= 10) {
        nn += *(liczba + 9) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    if (ok) {
        if (concat(tekst, "Billion") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    ok = 0;
    nn = 0;
    if (strlen(liczba) >= 9) {
        nn += *(liczba + 8) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL || concat(tekst, "Hundred") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    nn = 0;
    if (strlen(liczba) >= 8) {
        nn += *(liczba + 7) - '0';
        nn *= 10;
        
    }
    if (strlen(liczba) >= 7) {
        nn += *(liczba + 6) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    if (ok) {
        if (concat(tekst, "Million") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    ok = 0;
    nn = 0;
    if (strlen(liczba) >= 6) {
        nn += *(liczba + 5) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL || concat(tekst, "Hundred") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    nn = 0;
    if (strlen(liczba) >= 5) {
        nn += *(liczba + 4) - '0';
        nn *= 10;
        
    }
    if (strlen(liczba) >= 4) {
        nn += *(liczba + 3) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    if (ok) {
        if (concat(tekst, "Thousand") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    ok = 0;
    nn = 0;
    if (strlen(liczba) >= 3) {
        nn += *(liczba + 2) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL || concat(tekst, "Hundred") == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    nn = 0;
    if (strlen(liczba) >= 2) {
        nn += *(liczba + 1) - '0';
        nn *= 10;
        
    }
    if (strlen(liczba) >= 1) {
        nn += *(liczba + 0) - '0';
        
    }
    if (nn != 0) {
        ok = 1;
        if (numbers(tekst, nn) == NULL) {
            free(*tekst);
            *tekst = NULL;
            free(nums);
            return 2;
        }
    }
    ok = 0;
    nn = 0;
    free(nums);
    return 0;
}

char* my_strcat(char** dest, const char* zrodlo) {
    if (dest == NULL || zrodlo == NULL) {
        return NULL;
    }
    if (*dest == NULL) {
        *dest = strdup(zrodlo);
        return *dest;
    }
    char* d = realloc(*dest, strlen(*dest) + strlen(zrodlo) + 1);
    if (d == NULL) {
        return NULL;
    }
    strcat(d, zrodlo);
    *dest = d;
    return d;
}

char* ltoa_(unsigned long long numer) {
    if (numer == 0) {
        return strdup("");
    }
    unsigned long long liczba = numer % 10;
    char* bufor_tekst = ltoa_(numer / 10);
    if (bufor_tekst == NULL) {
        return NULL;
    }
    char* bufor_tekst2 = realloc(bufor_tekst, strlen(bufor_tekst) + 2);
    if (bufor_tekst2 == NULL) {
        free(bufor_tekst);
        return NULL;
    }
    *(bufor_tekst2 + strlen(bufor_tekst2) + 1) = '\0';
    *(bufor_tekst2 + strlen(bufor_tekst2)) = '0' + liczba;
    return bufor_tekst2;
}

char* ltoa(unsigned long long numer) {
    if (numer == 0) {
        return strdup("0");
    }
    return ltoa_(numer);
}
