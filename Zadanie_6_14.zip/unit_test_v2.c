/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Naprawdę duże liczby VI
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-19 18:50:37.949058
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 134 bajtów
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 134 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(134);
    
    //
    // -----------
    //
    

                char *output = NULL;
            

                char *temp = my_strcat(&output, "");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "", output);        

                temp = my_strcat(&output, "By far, the greatest danger of Artificial Intelligence is that people conclude too early that they understand it. - Eliezer Yudkowsky");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "By far, the greatest danger of Artificial Intelligence is that people conclude too early that they understand it. - Eliezer Yudkowsky") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "By far, the greatest danger of Artificial Intelligence is that people conclude too early that they understand it. - Eliezer Yudkowsky", output);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 111 bajtów
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 111 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(111);
    
    //
    // -----------
    //
    

                char *output = NULL;
            

                char *temp = my_strcat(&output, "\"Man is a slow, sloppy and brilliant thinker; the machine is fast, accurate and stupid.\"  - William M. Kelly");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"Man is a slow, sloppy and brilliant thinker; the machine is fast, accurate and stupid.\"  - William M. Kelly") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"Man is a slow, sloppy and brilliant thinker; the machine is fast, accurate and stupid.\"  - William M. Kelly", output);        

                temp = my_strcat(&output, "");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"Man is a slow, sloppy and brilliant thinker; the machine is fast, accurate and stupid.\"  - William M. Kelly") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"Man is a slow, sloppy and brilliant thinker; the machine is fast, accurate and stupid.\"  - William M. Kelly", output);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 83 bajtów
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 83 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(83);
    
    //
    // -----------
    //
    

                char *output = NULL;
            

                char *temp = my_strcat(&output, "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke", output);        

                temp = my_strcat(&output, " ");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke ") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke ", output);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 128 bajtów
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 128 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(128);
    
    //
    // -----------
    //
    

                char *output = NULL;
            

                char *temp = my_strcat(&output, " ");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, " ") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", " ", output);        

                temp = my_strcat(&output, "Always code as if the guy who ends up maintaining your code will be a violent psychopath who knows where you live - John Woods");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, " Always code as if the guy who ends up maintaining your code will be a violent psychopath who knows where you live - John Woods") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", " Always code as if the guy who ends up maintaining your code will be a violent psychopath who knows where you live - John Woods", output);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 245 bajtów
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 245 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(245);
    
    //
    // -----------
    //
    

                char *output = NULL;
            

                char *temp = my_strcat(&output, "\"                     ,                ,            .\" -    ");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"                     ,                ,            .\" -    ") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"                     ,                ,            .\" -    ", output);        

                temp = my_strcat(&output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"                     ,                ,            .\" -    \"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"                     ,                ,            .\" -    \"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens", output);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 245 bajtów
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 245 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(245);
    
    //
    // -----------
    //
    

                char *output = NULL;
            

                char *temp = my_strcat(&output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens", output);        

                temp = my_strcat(&output, "\"                     ,                ,            .\" -    ");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens\"                     ,                ,            .\" -    ") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens\"                     ,                ,            .\" -    ", output);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 535 bajtów
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 535 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(535);
    
    //
    // -----------
    //
    

                char *output = NULL;
            

                char *temp = my_strcat(&output, "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead", output);        

                temp = my_strcat(&output, "\"Western society has accepted as unquestionable a technological imperative that is quite as arbitrary as the most primitive taboo:  not merely the duty to foster invention and constantly to create technological novelties, but equally the duty to surrender to these novelties unconditionally, just because they are offered, without respect to their human consequences.\"  - Lewis Mumford");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead\"Western society has accepted as unquestionable a technological imperative that is quite as arbitrary as the most primitive taboo:  not merely the duty to foster invention and constantly to create technological novelties, but equally the duty to surrender to these novelties unconditionally, just because they are offered, without respect to their human consequences.\"  - Lewis Mumford") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead\"Western society has accepted as unquestionable a technological imperative that is quite as arbitrary as the most primitive taboo:  not merely the duty to foster invention and constantly to create technological novelties, but equally the duty to surrender to these novelties unconditionally, just because they are offered, without respect to their human consequences.\"  - Lewis Mumford", output);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 735 bajtów
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 735 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(735);
    
    //
    // -----------
    //
    

                char *output = NULL;
            

                char *temp = my_strcat(&output, "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel", output);        

                temp = my_strcat(&output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens", output);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji my_strcat
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji my_strcat", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            char text[] = {59, 4, 117, 14, 16, 94, 111, 10, 3, 44, 18, 46, 47, 91, 15, 75, 108, 126, 64, 105, 55, 121, 77, 82, 28, 19, 86, 96, 88, 93, 100, 114, 99, 13, 2, 104, 39, 124, 22, 110, 5, 90, 79, 61, 112, 32, 45, 107, 125, 27, 102, 97, 81, 53, 87, 118, 62, 71, 73, 76, 69, 7, 57, 83, 36, 23, 11, 78, 84, 21, 6, 24, 70, 60, 101, 52, 115, 98, 1, 119, 29, 48, 66, 54, 103, 122, 49, 85, 20, 9, 43, 123, 65, 113, 35, 42, 74, 37, 50, 68, 89, 72, 38, 67, 41, 109, 80, 33, 17, 120, 95, 116, 51, 31, 25, 63, 106, 56, 30, 26, 12, 92, 8, 40, 58, 34, 0};
            char text_2[] = {15, 94, 117, 62, 97, 55, 79, 42, 33, 73, 17, 8, 109, 58, 34, 81, 76, 64, 20, 40, 30, 9, 3, 78, 115, 71, 21, 1, 83, 60, 2, 86, 84, 49, 112, 90, 41, 22, 43, 29, 107, 69, 68, 101, 31, 13, 61, 74, 7, 63, 114, 36, 48, 91, 93, 102, 51, 98, 4, 54, 121, 18, 104, 77, 124, 118, 23, 111, 106, 26, 50, 100, 46, 39, 12, 38, 108, 19, 125, 72, 110, 103, 88, 32, 75, 80, 10, 66, 67, 53, 123, 56, 25, 65, 96, 122, 89, 59, 99, 87, 52, 85, 120, 105, 44, 47, 35, 5, 70, 119, 95, 45, 16, 92, 57, 11, 14, 28, 116, 82, 27, 6, 126, 113, 24, 37, 0};
            char expected_text[] = {59, 4, 117, 14, 16, 94, 111, 10, 3, 44, 18, 46, 47, 91, 15, 75, 108, 126, 64, 105, 55, 121, 77, 82, 28, 19, 86, 96, 88, 93, 100, 114, 99, 13, 2, 104, 39, 124, 22, 110, 5, 90, 79, 61, 112, 32, 45, 107, 125, 27, 102, 97, 81, 53, 87, 118, 62, 71, 73, 76, 69, 7, 57, 83, 36, 23, 11, 78, 84, 21, 6, 24, 70, 60, 101, 52, 115, 98, 1, 119, 29, 48, 66, 54, 103, 122, 49, 85, 20, 9, 43, 123, 65, 113, 35, 42, 74, 37, 50, 68, 89, 72, 38, 67, 41, 109, 80, 33, 17, 120, 95, 116, 51, 31, 25, 63, 106, 56, 30, 26, 12, 92, 8, 40, 58, 34, 15, 94, 117, 62, 97, 55, 79, 42, 33, 73, 17, 8, 109, 58, 34, 81, 76, 64, 20, 40, 30, 9, 3, 78, 115, 71, 21, 1, 83, 60, 2, 86, 84, 49, 112, 90, 41, 22, 43, 29, 107, 69, 68, 101, 31, 13, 61, 74, 7, 63, 114, 36, 48, 91, 93, 102, 51, 98, 4, 54, 121, 18, 104, 77, 124, 118, 23, 111, 106, 26, 50, 100, 46, 39, 12, 38, 108, 19, 125, 72, 110, 103, 88, 32, 75, 80, 10, 66, 67, 53, 123, 56, 25, 65, 96, 122, 89, 59, 99, 87, 52, 85, 120, 105, 44, 47, 35, 5, 70, 119, 95, 45, 16, 92, 57, 11, 14, 28, 116, 82, 27, 6, 126, 113, 24, 37, 0};

            char *output = NULL;
            
            char *temp = my_strcat(&output, text);

            test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
            test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
            test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(strcmp(output, text) == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", text, output);        

            temp = my_strcat(&output, text_2);

            test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
            test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
            test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(strcmp(output, expected_text) == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", expected_text, output);        

            free(temp);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 82 bajtów
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 82 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(82);
    
    //
    // -----------
    //
    

                char *output = NULL;


                char *temp = my_strcat(&output, "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke", output);        

                temp = my_strcat(&output, " ");

                test_error(temp == NULL, "Funkcja my_strcat() powinna zwrócić NULL");        
                test_error(output != NULL, "Funkcja my_strcat() nie powinna modyfikować adresu pamięci zmiennej output");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Any sufficiently advanced technology is equivalent to magic.-Sir Arthur C. Clarke", output);        

                free(output);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 127 bajtów
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 127 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(127);
    
    //
    // -----------
    //
    

                char *output = NULL;


                char *temp = my_strcat(&output, " ");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, " ") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", " ", output);        

                temp = my_strcat(&output, "Always code as if the guy who ends up maintaining your code will be a violent psychopath who knows where you live - John Woods");

                test_error(temp == NULL, "Funkcja my_strcat() powinna zwrócić NULL");        
                test_error(output != NULL, "Funkcja my_strcat() nie powinna modyfikować adresu pamięci zmiennej output");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, " ") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", " ", output);        

                free(output);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 240 bajtów
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 240 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(240);
    
    //
    // -----------
    //
    

                char *output = NULL;


                char *temp = my_strcat(&output, "\"                     ,                ,            .\" -    ");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"                     ,                ,            .\" -    ") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"                     ,                ,            .\" -    ", output);        

                temp = my_strcat(&output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens");

                test_error(temp == NULL, "Funkcja my_strcat() powinna zwrócić NULL");        
                test_error(output != NULL, "Funkcja my_strcat() nie powinna modyfikować adresu pamięci zmiennej output");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"                     ,                ,            .\" -    ") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"                     ,                ,            .\" -    ", output);        

                free(output);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 240 bajtów
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 240 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(240);
    
    //
    // -----------
    //
    

                char *output = NULL;


                char *temp = my_strcat(&output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens", output);        

                temp = my_strcat(&output, "\"                     ,                ,            .\" -    ");

                test_error(temp == NULL, "Funkcja my_strcat() powinna zwrócić NULL");        
                test_error(output != NULL, "Funkcja my_strcat() nie powinna modyfikować adresu pamięci zmiennej output");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens", output);        

                free(output);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 532 bajtów
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 532 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(532);
    
    //
    // -----------
    //
    

                char *output = NULL;


                char *temp = my_strcat(&output, "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead", output);        

                temp = my_strcat(&output, "\"Western society has accepted as unquestionable a technological imperative that is quite as arbitrary as the most primitive taboo:  not merely the duty to foster invention and constantly to create technological novelties, but equally the duty to surrender to these novelties unconditionally, just because they are offered, without respect to their human consequences.\"  - Lewis Mumford");

                test_error(temp == NULL, "Funkcja my_strcat() powinna zwrócić NULL");        
                test_error(output != NULL, "Funkcja my_strcat() nie powinna modyfikować adresu pamięci zmiennej output");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead", output);        

                free(output);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 723 bajtów
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 723 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(723);
    
    //
    // -----------
    //
    

                char *output = NULL;


                char *temp = my_strcat(&output, "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel");

                test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
                test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
                test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel", output);        

                temp = my_strcat(&output, "\"PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and insidious evil, perpetrated by skilled but perverted professionals.\" - Jon Ribbens");

                test_error(temp == NULL, "Funkcja my_strcat() powinna zwrócić NULL");        
                test_error(output != NULL, "Funkcja my_strcat() nie powinna modyfikować adresu pamięci zmiennej output");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(output, "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Technology\' is a queer thing. It brings you great gifts with one hand, and it stabs you in the back with the other.-Carrie Snow\nYou\'ve gotta dance like there\'s nobody watching,Love like you\'ll never be hurt,Sing like there\'s nobody listening,And live like it\'s heaven on earth. - William W. Purkey\nPeople don\'t want to believe that technology is broken. Pharmaceuticals, robotics, artificial intelligence, nanotechnology - all these areas where the progress has been a lot more limited than people think. And the question is why. - Peter Thiel", output);        

                free(output);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji my_strcat
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji my_strcat", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            char *output = NULL;


            char *temp = my_strcat(&output, "Information technology and business are becoming inextricably interwoven. I don\'t think anybody can talk meaningfully about one without the talking about the other. - Bill Gates");

            test_error(temp != NULL, "Funkcja my_strcat() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
            test_error(output != NULL, "Funkcja my_strcat() powinna przypisać do output adres przydzielonej pamięci, a przypsiała NULL");        
            test_error(output == temp, "Funkcja my_strcat() powinna przypisać do output ten sam adres zwraca");        

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(strcmp(output, "Information technology and business are becoming inextricably interwoven. I don\'t think anybody can talk meaningfully about one without the talking about the other. - Bill Gates") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Information technology and business are becoming inextricably interwoven. I don\'t think anybody can talk meaningfully about one without the talking about the other. - Bill Gates", output);        

            temp = my_strcat(&output, NULL);

            test_error(temp == NULL, "Funkcja my_strcat() powinna zwrócić NULL");        
            test_error(output != NULL, "Funkcja my_strcat() nie powinna modyfikować adresu pamięci zmiennej output");        

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(strcmp(output, "Information technology and business are becoming inextricably interwoven. I don\'t think anybody can talk meaningfully about one without the talking about the other. - Bill Gates") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Information technology and business are becoming inextricably interwoven. I don\'t think anybody can talk meaningfully about one without the talking about the other. - Bill Gates", output);        

            free(output);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji my_strcat
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji my_strcat", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            char *temp = my_strcat(NULL, "Information technology and business are becoming inextricably interwoven. I don\'t think anybody can talk meaningfully about one without the talking about the other. - Bill Gates");

            test_error(temp == NULL, "Funkcja my_strcat() powinna zwrócić NULL");        

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji my_strcat
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji my_strcat", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            char *temp = my_strcat(NULL, NULL);

            test_error(temp == NULL, "Funkcja my_strcat() powinna zwrócić NULL");        

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 2 bajtów
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 2 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(2);
    
    //
    // -----------
    //
    

                char *temp = ltoa(0ULL);

                test_error(temp != NULL, "Funkcja ltoa() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "0") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "0", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 2 bajtów
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 2 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(2);
    
    //
    // -----------
    //
    

                char *temp = ltoa(9ULL);

                test_error(temp != NULL, "Funkcja ltoa() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "9") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "9", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 4 bajtów
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 4 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(4);
    
    //
    // -----------
    //
    

                char *temp = ltoa(342ULL);

                test_error(temp != NULL, "Funkcja ltoa() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "342") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "342", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 7 bajtów
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 7 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(7);
    
    //
    // -----------
    //
    

                char *temp = ltoa(342217ULL);

                test_error(temp != NULL, "Funkcja ltoa() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "342217") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "342217", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 10 bajtów
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 10 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(10);
    
    //
    // -----------
    //
    

                char *temp = ltoa(396616077ULL);

                test_error(temp != NULL, "Funkcja ltoa() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "396616077") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "396616077", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 15 bajtów
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 15 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(15);
    
    //
    // -----------
    //
    

                char *temp = ltoa(10000000000040ULL);

                test_error(temp != NULL, "Funkcja ltoa() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "10000000000040") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "10000000000040", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 21 bajtów
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 21 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(21);
    
    //
    // -----------
    //
    

                char *temp = ltoa(18446744073709551615ULL);

                test_error(temp != NULL, "Funkcja ltoa() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "18446744073709551615") == 0, "Funkcja my_strcat() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "18446744073709551615", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 1 bajtów
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 1 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1);
    
    //
    // -----------
    //
    

                char *temp = ltoa(0ULL);

                test_error(temp == NULL, "Funkcja ltoa() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 1 bajtów
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 1 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1);
    
    //
    // -----------
    //
    

                char *temp = ltoa(9ULL);

                test_error(temp == NULL, "Funkcja ltoa() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 3 bajtów
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 3 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    

                char *temp = ltoa(342ULL);

                test_error(temp == NULL, "Funkcja ltoa() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 6 bajtów
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 6 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(6);
    
    //
    // -----------
    //
    

                char *temp = ltoa(342217ULL);

                test_error(temp == NULL, "Funkcja ltoa() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 9 bajtów
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 9 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(9);
    
    //
    // -----------
    //
    

                char *temp = ltoa(396616077ULL);

                test_error(temp == NULL, "Funkcja ltoa() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 14 bajtów
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 14 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(14);
    
    //
    // -----------
    //
    

                char *temp = ltoa(10000000000040ULL);

                test_error(temp == NULL, "Funkcja ltoa() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 20 bajtów
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 20 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(20);
    
    //
    // -----------
    //
    

                char *temp = ltoa(18446744073709551615ULL);

                test_error(temp == NULL, "Funkcja ltoa() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(7);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 0ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Zero") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Zero", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(8);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 8ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Eight") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Eight", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 25 bajtów
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 25 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(25);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 780ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Seven Hundred Eighty") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Seven Hundred Eighty", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 28 bajtów
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 28 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(28);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 225ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Two Hundred Twenty Five") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Two Hundred Twenty Five", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 31 bajtów
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 31 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(31);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 374ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Three Hundred Seventy Four") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Three Hundred Seventy Four", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 30 bajtów
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 30 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(30);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 358ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Three Hundred Fifty Eight") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Three Hundred Fifty Eight", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 28 bajtów
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 28 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(28);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 426ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Four Hundred Twenty Six") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Four Hundred Twenty Six", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 44 bajtów
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 44 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(44);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 816003ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Eight Hundred Sixteen Thousand Three") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Eight Hundred Sixteen Thousand Three", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 63 bajtów
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 63 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(63);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 113575ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "One Hundred Thirteen Thousand Five Hundred Seventy Five") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "One Hundred Thirteen Thousand Five Hundred Seventy Five", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 65 bajtów
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 65 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(65);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 894126ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Eight Hundred Ninety Four Thousand One Hundred Twenty Six") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Eight Hundred Ninety Four Thousand One Hundred Twenty Six", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 61 bajtów
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 61 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(61);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 662145ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Six Hundred Sixty Two Thousand One Hundred Forty Five") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Six Hundred Sixty Two Thousand One Hundred Forty Five", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 67 bajtów
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 67 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(67);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 998443ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Nine Hundred Ninety Eight Thousand Four Hundred Forty Three") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Nine Hundred Ninety Eight Thousand Four Hundred Forty Three", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 93 bajtów
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 93 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(93);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 661197540ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Six Hundred Sixty One Million One Hundred Ninety Seven Thousand Five Hundred Forty") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Six Hundred Sixty One Million One Hundred Ninety Seven Thousand Five Hundred Forty", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 100 bajtów
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 100 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(100);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 692923361ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Six Hundred Ninety Two Million Nine Hundred Twenty Three Thousand Three Hundred Sixty One") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Six Hundred Ninety Two Million Nine Hundred Twenty Three Thousand Three Hundred Sixty One", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 85 bajtów
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 85 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(85);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 858871060ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Eight Hundred Fifty Eight Million Eight Hundred Seventy One Thousand Sixty") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Eight Hundred Fifty Eight Million Eight Hundred Seventy One Thousand Sixty", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 86 bajtów
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 86 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(86);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 578652042ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Five Hundred Seventy Eight Million Six Hundred Fifty Two Thousand Forty Two") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Five Hundred Seventy Eight Million Six Hundred Fifty Two Thousand Forty Two", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 93 bajtów
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 93 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(93);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 455667409ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Four Hundred Fifty Five Million Six Hundred Sixty Seven Thousand Four Hundred Nine") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Four Hundred Fifty Five Million Six Hundred Sixty Seven Thousand Four Hundred Nine", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 50: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 48 bajtów
//
void UTEST50(void)
{
    // informacje o teście
    test_start(50, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 48 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(48);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 1000000000000000100ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "One Quintillion One Hundred") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "One Quintillion One Hundred", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 51: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 46 bajtów
//
void UTEST51(void)
{
    // informacje o teście
    test_start(51, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 46 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(46);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 10000000000000024ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Ten Quadrillion Twenty Four") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Ten Quadrillion Twenty Four", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 52: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 37 bajtów
//
void UTEST52(void)
{
    // informacje o teście
    test_start(52, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 37 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(37);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 10000000000014ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Ten Trillion Fourteen") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Ten Trillion Fourteen", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 53: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 44 bajtów
//
void UTEST53(void)
{
    // informacje o teście
    test_start(53, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 44 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(44);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 10000000000000066ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Ten Quadrillion Sixty Six") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Ten Quadrillion Sixty Six", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 54: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 45 bajtów
//
void UTEST54(void)
{
    // informacje o teście
    test_start(54, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 45 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(45);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 10000000000000045ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Ten Quadrillion Forty Five") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Ten Quadrillion Forty Five", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 55: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 212 bajtów
//
void UTEST55(void)
{
    // informacje o teście
    test_start(55, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 212 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(212);
    
    //
    // -----------
    //
    

                char *temp;
                 
                int err_code = number_2_words(&temp, 18446744073709551615ULL);

                test_error(temp != NULL, "Funkcja number_2_words() powinna przypisać adres przydzielonej pamięci, a przypisała NULL");        
                test_error(err_code == 0, "Funkcja number_2_words() powinna zwrócić 0, a zwróciła %d", err_code);        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(temp, "Eighteen Quintillion Four Hundred Forty Six Quadrillion Seven Hundred Forty Four Trillion Seventy Three Billion Seven Hundred Nine Million Five Hundred Fifty One Thousand Six Hundred Fifteen") == 0, "Funkcja number_2_words() niepoprawnie dołączyła tekst; powinno być %s, a jest %s", "Eighteen Quintillion Four Hundred Forty Six Quadrillion Seven Hundred Forty Four Trillion Seventy Three Billion Seven Hundred Nine Million Five Hundred Fifty One Thousand Six Hundred Fifteen", temp);        

                free(temp);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 56: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 0 bajtów
//
void UTEST56(void)
{
    // informacje o teście
    test_start(56, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 57: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 1 bajtów
//
void UTEST57(void)
{
    // informacje o teście
    test_start(57, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 1 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 58: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 2 bajtów
//
void UTEST58(void)
{
    // informacje o teście
    test_start(58, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 2 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(2);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 59: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 3 bajtów
//
void UTEST59(void)
{
    // informacje o teście
    test_start(59, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 3 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 60: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 4 bajtów
//
void UTEST60(void)
{
    // informacje o teście
    test_start(60, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 4 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(4);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 61: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 5 bajtów
//
void UTEST61(void)
{
    // informacje o teście
    test_start(61, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 5 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(5);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 62: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 6 bajtów
//
void UTEST62(void)
{
    // informacje o teście
    test_start(62, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 6 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(6);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 63: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów
//
void UTEST63(void)
{
    // informacje o teście
    test_start(63, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(7);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 64: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów
//
void UTEST64(void)
{
    // informacje o teście
    test_start(64, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(8);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 65: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 9 bajtów
//
void UTEST65(void)
{
    // informacje o teście
    test_start(65, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 9 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(9);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 66: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 10 bajtów
//
void UTEST66(void)
{
    // informacje o teście
    test_start(66, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 10 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(10);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 67: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 11 bajtów
//
void UTEST67(void)
{
    // informacje o teście
    test_start(67, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 11 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(11);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 68: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 12 bajtów
//
void UTEST68(void)
{
    // informacje o teście
    test_start(68, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 12 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(12);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 69: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 13 bajtów
//
void UTEST69(void)
{
    // informacje o teście
    test_start(69, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 13 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(13);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 70: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 14 bajtów
//
void UTEST70(void)
{
    // informacje o teście
    test_start(70, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 14 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(14);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 71: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 15 bajtów
//
void UTEST71(void)
{
    // informacje o teście
    test_start(71, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 15 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(15);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 72: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 16 bajtów
//
void UTEST72(void)
{
    // informacje o teście
    test_start(72, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 16 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(16);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 73: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 17 bajtów
//
void UTEST73(void)
{
    // informacje o teście
    test_start(73, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 17 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(17);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 74: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 18 bajtów
//
void UTEST74(void)
{
    // informacje o teście
    test_start(74, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 18 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(18);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 75: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 19 bajtów
//
void UTEST75(void)
{
    // informacje o teście
    test_start(75, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 19 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(19);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 76: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 20 bajtów
//
void UTEST76(void)
{
    // informacje o teście
    test_start(76, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 20 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(20);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 77: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 21 bajtów
//
void UTEST77(void)
{
    // informacje o teście
    test_start(77, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 21 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(21);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 78: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 22 bajtów
//
void UTEST78(void)
{
    // informacje o teście
    test_start(78, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 22 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(22);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 79: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 23 bajtów
//
void UTEST79(void)
{
    // informacje o teście
    test_start(79, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 23 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(23);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 80: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 24 bajtów
//
void UTEST80(void)
{
    // informacje o teście
    test_start(80, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 24 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(24);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 81: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 25 bajtów
//
void UTEST81(void)
{
    // informacje o teście
    test_start(81, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 25 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(25);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 82: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 26 bajtów
//
void UTEST82(void)
{
    // informacje o teście
    test_start(82, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 26 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(26);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 83: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 27 bajtów
//
void UTEST83(void)
{
    // informacje o teście
    test_start(83, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 27 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(27);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 84: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 28 bajtów
//
void UTEST84(void)
{
    // informacje o teście
    test_start(84, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 28 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(28);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 85: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 29 bajtów
//
void UTEST85(void)
{
    // informacje o teście
    test_start(85, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 29 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(29);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 86: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 30 bajtów
//
void UTEST86(void)
{
    // informacje o teście
    test_start(86, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 30 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(30);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 87: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 31 bajtów
//
void UTEST87(void)
{
    // informacje o teście
    test_start(87, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 31 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(31);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 88: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 32 bajtów
//
void UTEST88(void)
{
    // informacje o teście
    test_start(88, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 32 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 89: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 33 bajtów
//
void UTEST89(void)
{
    // informacje o teście
    test_start(89, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 33 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(33);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 90: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 34 bajtów
//
void UTEST90(void)
{
    // informacje o teście
    test_start(90, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 34 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(34);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 91: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 35 bajtów
//
void UTEST91(void)
{
    // informacje o teście
    test_start(91, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 35 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(35);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 92: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 36 bajtów
//
void UTEST92(void)
{
    // informacje o teście
    test_start(92, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 36 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(36);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 93: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 37 bajtów
//
void UTEST93(void)
{
    // informacje o teście
    test_start(93, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 37 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(37);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 94: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 38 bajtów
//
void UTEST94(void)
{
    // informacje o teście
    test_start(94, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 38 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(38);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 95: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 39 bajtów
//
void UTEST95(void)
{
    // informacje o teście
    test_start(95, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 39 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(39);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 96: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 40 bajtów
//
void UTEST96(void)
{
    // informacje o teście
    test_start(96, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 40 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(40);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 97: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 41 bajtów
//
void UTEST97(void)
{
    // informacje o teście
    test_start(97, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 41 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(41);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 98: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 42 bajtów
//
void UTEST98(void)
{
    // informacje o teście
    test_start(98, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 42 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(42);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 99: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 43 bajtów
//
void UTEST99(void)
{
    // informacje o teście
    test_start(99, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 43 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(43);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 100: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 44 bajtów
//
void UTEST100(void)
{
    // informacje o teście
    test_start(100, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 44 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(44);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 101: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 45 bajtów
//
void UTEST101(void)
{
    // informacje o teście
    test_start(101, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 45 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(45);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 102: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 46 bajtów
//
void UTEST102(void)
{
    // informacje o teście
    test_start(102, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 46 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(46);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 103: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 47 bajtów
//
void UTEST103(void)
{
    // informacje o teście
    test_start(103, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 47 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(47);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 104: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 48 bajtów
//
void UTEST104(void)
{
    // informacje o teście
    test_start(104, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 48 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(48);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 105: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 49 bajtów
//
void UTEST105(void)
{
    // informacje o teście
    test_start(105, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 49 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(49);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 106: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 50 bajtów
//
void UTEST106(void)
{
    // informacje o teście
    test_start(106, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 50 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(50);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 107: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 51 bajtów
//
void UTEST107(void)
{
    // informacje o teście
    test_start(107, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 51 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(51);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 108: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 52 bajtów
//
void UTEST108(void)
{
    // informacje o teście
    test_start(108, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 52 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(52);
    
    //
    // -----------
    //
    
        
                char *temp;
        
                int err_code = number_2_words(&temp, 257613ULL);
        
                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 109: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 0 bajtów
//
void UTEST109(void)
{
    // informacje o teście
    test_start(109, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 110: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 1 bajtów
//
void UTEST110(void)
{
    // informacje o teście
    test_start(110, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 1 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 111: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 2 bajtów
//
void UTEST111(void)
{
    // informacje o teście
    test_start(111, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 2 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(2);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 112: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 3 bajtów
//
void UTEST112(void)
{
    // informacje o teście
    test_start(112, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 3 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 113: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 4 bajtów
//
void UTEST113(void)
{
    // informacje o teście
    test_start(113, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 4 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(4);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 114: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 5 bajtów
//
void UTEST114(void)
{
    // informacje o teście
    test_start(114, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 5 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(5);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 115: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 6 bajtów
//
void UTEST115(void)
{
    // informacje o teście
    test_start(115, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 6 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(6);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 116: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów
//
void UTEST116(void)
{
    // informacje o teście
    test_start(116, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(7);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 117: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów
//
void UTEST117(void)
{
    // informacje o teście
    test_start(117, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(8);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 118: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 9 bajtów
//
void UTEST118(void)
{
    // informacje o teście
    test_start(118, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 9 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(9);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 119: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 10 bajtów
//
void UTEST119(void)
{
    // informacje o teście
    test_start(119, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 10 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(10);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 120: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 11 bajtów
//
void UTEST120(void)
{
    // informacje o teście
    test_start(120, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 11 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(11);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 121: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 12 bajtów
//
void UTEST121(void)
{
    // informacje o teście
    test_start(121, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 12 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(12);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 122: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 13 bajtów
//
void UTEST122(void)
{
    // informacje o teście
    test_start(122, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 13 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(13);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 123: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 14 bajtów
//
void UTEST123(void)
{
    // informacje o teście
    test_start(123, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 14 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(14);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 124: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 15 bajtów
//
void UTEST124(void)
{
    // informacje o teście
    test_start(124, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 15 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(15);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 125: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 16 bajtów
//
void UTEST125(void)
{
    // informacje o teście
    test_start(125, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 16 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(16);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 126: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 17 bajtów
//
void UTEST126(void)
{
    // informacje o teście
    test_start(126, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 17 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(17);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 127: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 18 bajtów
//
void UTEST127(void)
{
    // informacje o teście
    test_start(127, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 18 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(18);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 128: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 19 bajtów
//
void UTEST128(void)
{
    // informacje o teście
    test_start(128, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 19 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(19);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 129: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 20 bajtów
//
void UTEST129(void)
{
    // informacje o teście
    test_start(129, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 20 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(20);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 130: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 21 bajtów
//
void UTEST130(void)
{
    // informacje o teście
    test_start(130, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 21 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(21);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 669ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 131: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 0 bajtów
//
void UTEST131(void)
{
    // informacje o teście
    test_start(131, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 132: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 1 bajtów
//
void UTEST132(void)
{
    // informacje o teście
    test_start(132, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 1 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 133: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 2 bajtów
//
void UTEST133(void)
{
    // informacje o teście
    test_start(133, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 2 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(2);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 134: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 3 bajtów
//
void UTEST134(void)
{
    // informacje o teście
    test_start(134, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 3 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 135: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 4 bajtów
//
void UTEST135(void)
{
    // informacje o teście
    test_start(135, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 4 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(4);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 136: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 5 bajtów
//
void UTEST136(void)
{
    // informacje o teście
    test_start(136, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 5 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(5);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 137: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 6 bajtów
//
void UTEST137(void)
{
    // informacje o teście
    test_start(137, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 6 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(6);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 138: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów
//
void UTEST138(void)
{
    // informacje o teście
    test_start(138, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(7);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 139: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów
//
void UTEST139(void)
{
    // informacje o teście
    test_start(139, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(8);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 140: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 9 bajtów
//
void UTEST140(void)
{
    // informacje o teście
    test_start(140, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 9 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(9);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 141: Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 10 bajtów
//
void UTEST141(void)
{
    // informacje o teście
    test_start(141, "Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 10 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(10);
    
    //
    // -----------
    //
    

                char *temp;

                int err_code = number_2_words(&temp, 58ULL);

                test_error(temp == NULL, "Funkcja number_2_words() powinna przypisać zmiennej temp wartość NULL");        
                test_error(err_code == 2, "Funkcja number_2_words() powinna zwrócić 2, a zwróciła %d", err_code);        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 142: Sprawdzanie poprawności działania funkcji number_2_words
//
void UTEST142(void)
{
    // informacje o teście
    test_start(142, "Sprawdzanie poprawności działania funkcji number_2_words", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = number_2_words(NULL, 58ULL);

            test_error(err_code == 1, "Funkcja number_2_words() powinna zwrócić 1, a zwróciła %d", err_code);        

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci; limit ustawiono na 0 bajtów
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci; limit ustawiono na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                test_no_heap_leakage();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci; limit ustawiono na 4 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci; limit ustawiono na 4 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(4);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                test_no_heap_leakage();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 134 bajtów
            UTEST2, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 111 bajtów
            UTEST3, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 83 bajtów
            UTEST4, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 128 bajtów
            UTEST5, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 245 bajtów
            UTEST6, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 245 bajtów
            UTEST7, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 535 bajtów
            UTEST8, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 735 bajtów
            UTEST9, // Sprawdzanie poprawności działania funkcji my_strcat
            UTEST10, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 82 bajtów
            UTEST11, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 127 bajtów
            UTEST12, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 240 bajtów
            UTEST13, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 240 bajtów
            UTEST14, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 532 bajtów
            UTEST15, // Sprawdzanie poprawności działania funkcji my_strcat - limit pamięci ustawiony na 723 bajtów
            UTEST16, // Sprawdzanie poprawności działania funkcji my_strcat
            UTEST17, // Sprawdzanie poprawności działania funkcji my_strcat
            UTEST18, // Sprawdzanie poprawności działania funkcji my_strcat
            UTEST19, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 2 bajtów
            UTEST20, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 2 bajtów
            UTEST21, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 4 bajtów
            UTEST22, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 7 bajtów
            UTEST23, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 10 bajtów
            UTEST24, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 15 bajtów
            UTEST25, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 21 bajtów
            UTEST26, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 1 bajtów
            UTEST27, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 1 bajtów
            UTEST28, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 3 bajtów
            UTEST29, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 6 bajtów
            UTEST30, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 9 bajtów
            UTEST31, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 14 bajtów
            UTEST32, // Sprawdzanie poprawności działania funkcji ltoa - limit pamięci ustawiony na 20 bajtów
            UTEST33, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów
            UTEST34, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów
            UTEST35, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 25 bajtów
            UTEST36, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 28 bajtów
            UTEST37, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 31 bajtów
            UTEST38, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 30 bajtów
            UTEST39, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 28 bajtów
            UTEST40, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 44 bajtów
            UTEST41, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 63 bajtów
            UTEST42, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 65 bajtów
            UTEST43, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 61 bajtów
            UTEST44, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 67 bajtów
            UTEST45, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 93 bajtów
            UTEST46, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 100 bajtów
            UTEST47, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 85 bajtów
            UTEST48, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 86 bajtów
            UTEST49, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 93 bajtów
            UTEST50, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 48 bajtów
            UTEST51, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 46 bajtów
            UTEST52, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 37 bajtów
            UTEST53, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 44 bajtów
            UTEST54, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 45 bajtów
            UTEST55, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 212 bajtów
            UTEST56, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 0 bajtów
            UTEST57, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 1 bajtów
            UTEST58, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 2 bajtów
            UTEST59, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 3 bajtów
            UTEST60, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 4 bajtów
            UTEST61, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 5 bajtów
            UTEST62, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 6 bajtów
            UTEST63, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów
            UTEST64, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów
            UTEST65, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 9 bajtów
            UTEST66, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 10 bajtów
            UTEST67, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 11 bajtów
            UTEST68, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 12 bajtów
            UTEST69, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 13 bajtów
            UTEST70, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 14 bajtów
            UTEST71, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 15 bajtów
            UTEST72, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 16 bajtów
            UTEST73, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 17 bajtów
            UTEST74, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 18 bajtów
            UTEST75, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 19 bajtów
            UTEST76, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 20 bajtów
            UTEST77, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 21 bajtów
            UTEST78, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 22 bajtów
            UTEST79, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 23 bajtów
            UTEST80, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 24 bajtów
            UTEST81, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 25 bajtów
            UTEST82, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 26 bajtów
            UTEST83, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 27 bajtów
            UTEST84, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 28 bajtów
            UTEST85, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 29 bajtów
            UTEST86, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 30 bajtów
            UTEST87, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 31 bajtów
            UTEST88, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 32 bajtów
            UTEST89, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 33 bajtów
            UTEST90, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 34 bajtów
            UTEST91, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 35 bajtów
            UTEST92, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 36 bajtów
            UTEST93, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 37 bajtów
            UTEST94, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 38 bajtów
            UTEST95, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 39 bajtów
            UTEST96, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 40 bajtów
            UTEST97, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 41 bajtów
            UTEST98, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 42 bajtów
            UTEST99, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 43 bajtów
            UTEST100, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 44 bajtów
            UTEST101, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 45 bajtów
            UTEST102, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 46 bajtów
            UTEST103, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 47 bajtów
            UTEST104, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 48 bajtów
            UTEST105, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 49 bajtów
            UTEST106, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 50 bajtów
            UTEST107, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 51 bajtów
            UTEST108, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 52 bajtów
            UTEST109, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 0 bajtów
            UTEST110, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 1 bajtów
            UTEST111, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 2 bajtów
            UTEST112, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 3 bajtów
            UTEST113, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 4 bajtów
            UTEST114, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 5 bajtów
            UTEST115, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 6 bajtów
            UTEST116, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów
            UTEST117, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów
            UTEST118, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 9 bajtów
            UTEST119, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 10 bajtów
            UTEST120, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 11 bajtów
            UTEST121, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 12 bajtów
            UTEST122, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 13 bajtów
            UTEST123, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 14 bajtów
            UTEST124, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 15 bajtów
            UTEST125, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 16 bajtów
            UTEST126, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 17 bajtów
            UTEST127, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 18 bajtów
            UTEST128, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 19 bajtów
            UTEST129, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 20 bajtów
            UTEST130, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 21 bajtów
            UTEST131, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 0 bajtów
            UTEST132, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 1 bajtów
            UTEST133, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 2 bajtów
            UTEST134, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 3 bajtów
            UTEST135, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 4 bajtów
            UTEST136, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 5 bajtów
            UTEST137, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 6 bajtów
            UTEST138, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 7 bajtów
            UTEST139, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 8 bajtów
            UTEST140, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 9 bajtów
            UTEST141, // Sprawdzanie poprawności działania funkcji number_2_words - limit pamięci ustawiony na 10 bajtów
            UTEST142, // Sprawdzanie poprawności działania funkcji number_2_words
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(142); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci; limit ustawiono na 0 bajtów
            MTEST2, // Reakcja na brak pamięci; limit ustawiono na 4 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(2); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}