#include <stdio.h>
#include "array.h"
#include "tested_declarations.h"
#include "rdebug.h"

void czysc(void)
{
    int c;
    do
    {
        c = getchar();
    }while(c != '\n' && c != EOF);
}

int main()
{
    struct array_t *tablica;
    int ile;
    int rozmiar;

    printf("Podaj wielkosc tablicy: ");

    if(scanf("%d", &rozmiar) != 1)
    {
        printf("Incorrect input\n");
        return 1;
    }
    if(rozmiar < 1)
    {
        printf("Incorrect input data\n");
        return 2;
    }

    int error = array_create_struct(&tablica, rozmiar);
    if(error == 2)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }

    while(1)
    {
        int option;
        printf("Co chcesz zrobić: ");

        if(scanf("%d", &option) != 1)
        {
            printf("Incorrect input\n");
            array_destroy_struct(&tablica);
            return 1;
        }

        czysc();

        switch (option)
        {
            case 0:
                //End program
                array_destroy_struct(&tablica);
                return 0;
            case 1:
                //Add items to tablica

                printf("Podaj liczby do tablicy: ");

                do {
                    if(scanf("%d", &ile) != 1)
                    {
                        printf("Incorrect input\n");
                        array_destroy_struct(&tablica);
                        return 1;
                    }

                    if(ile == 0) break;

                    array_push_back(tablica, ile);
                    if(tablica->size == tablica->capacity)
                    {
                        break;
                    }

                }while(1);

                if(tablica->size == tablica->capacity)
                {
                    printf("Buffer is full\n");
                    czysc();
                }

                if(tablica->size != 0)
                {
                    array_display(tablica);
                    printf("\n");
                }


                break;
            case 2:
                //Delete items from tablica

                printf("Podaj liczby do usuniecia z tablicy: ");

                do {
                    if(scanf("%d", &ile) != 1)
                    {
                        printf("Incorrect input\n");
                        array_destroy_struct(&tablica);
                        return 1;
                    }

                    if(ile == 0) break;

                    array_remove_item(tablica, ile);
                    if(tablica->size == 0)
                    {
                        break;
                    }

                }while(1);

                if(tablica->size == 0)
                {
                    printf("Buffer is empty\n");
                    czysc();
                }

                if(tablica->size != 0)
                {
                    array_display(tablica);
                    printf("\n");
                }

                break;
            default:
                printf("Incorrect input data\n");
                break;
        }
    }
}
