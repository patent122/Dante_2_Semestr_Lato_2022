/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Usuwanie elementów z tablicy
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 20:13:53.195278
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = 5, .capacity = -5 };

                printf("#####START#####");
                int res = array_create(&ptr, -18);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!1)
                {           
            
                    test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == -18, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na -18, a ustawiła na %d", ptr.size);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = 8, .capacity = -8 };

                printf("#####START#####");
                int res = array_create(&ptr, 0);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!1)
                {           
            
                    test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = 6, .capacity = 0 };

                printf("#####START#####");
                int res = array_create(&ptr, 76);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!0)
                {           
            
                    test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == 76, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 76, a ustawiła na %d", ptr.size);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = 1, .capacity = 4 };

                printf("#####START#####");
                int res = array_create(&ptr, 1840);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!0)
                {           
            
                    test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == 1840, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 1840, a ustawiła na %d", ptr.size);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 356 bajtów)
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 356 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(356);
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = -4, .capacity = 8 };

                printf("#####START#####");
                int res = array_create(&ptr, 89);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 89, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 89, a ustawiła na %d", ptr.size);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 301 bajtów)
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 301 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(301);
    
    //
    // -----------
    //
    

                struct array_t ptr = { .size = -2, .capacity = -5 };

                printf("#####START#####");
                int res = array_create(&ptr, 89);
                printf("#####END#####");

                test_error(res == 2, "Funkcja array_create() powinna zwrócić wartość 2, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji array_create
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji array_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = array_create(NULL, 89);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji array_create_struct
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji array_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, -37);
                printf("#####END#####");

                test_error(ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę array_t, a przypisała NULL");
                test_error(res == 1, "Funkcja array_create_struct() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                if (!1)
                {           
        
                    test_error(ptr->ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze array_t, a przypisała NULL");
                    test_error(ptr->size == 0, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                    test_error(ptr->capacity == -37, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na -37, a ustawiła na %d", ptr->size);

                    free(ptr->ptr);
                    free(ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji array_create_struct
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji array_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 0);
                printf("#####END#####");

                test_error(ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę array_t, a przypisała NULL");
                test_error(res == 1, "Funkcja array_create_struct() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                if (!1)
                {           
        
                    test_error(ptr->ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze array_t, a przypisała NULL");
                    test_error(ptr->size == 0, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                    test_error(ptr->capacity == 0, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);

                    free(ptr->ptr);
                    free(ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji array_create_struct
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji array_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 78);
                printf("#####END#####");

                test_error(ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę array_t, a przypisała NULL");
                test_error(res == 0, "Funkcja array_create_struct() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                if (!0)
                {           
        
                    test_error(ptr->ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze array_t, a przypisała NULL");
                    test_error(ptr->size == 0, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                    test_error(ptr->capacity == 78, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 78, a ustawiła na %d", ptr->size);

                    free(ptr->ptr);
                    free(ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji array_create_struct
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji array_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 4046);
                printf("#####END#####");

                test_error(ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę array_t, a przypisała NULL");
                test_error(res == 0, "Funkcja array_create_struct() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                if (!0)
                {           
        
                    test_error(ptr->ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze array_t, a przypisała NULL");
                    test_error(ptr->size == 0, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                    test_error(ptr->capacity == 4046, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 4046, a ustawiła na %d", ptr->size);

                    free(ptr->ptr);
                    free(ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie reakcji funkcji array_create_struct na limit pamięci (limit sterty ustawiono na 136 bajtów)
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie reakcji funkcji array_create_struct na limit pamięci (limit sterty ustawiono na 136 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(136);
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 30);
                printf("#####END#####");

         
                test_error(ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę array_t, a przypisała NULL");
                test_error(res == 0, "Funkcja array_create_struct() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze array_t, a przypisała NULL");
                test_error(ptr->size == 0, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                test_error(ptr->capacity == 30, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 30, a ustawiła na %d", ptr->size);

                free(ptr->ptr);
                free(ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie reakcji funkcji array_create_struct na limit pamięci (limit sterty ustawiono na 16 bajtów)
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie reakcji funkcji array_create_struct na limit pamięci (limit sterty ustawiono na 16 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(16);
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 30);
                printf("#####END#####");

                test_error(res == 2, "Funkcja array_create_struct() powinna zwrócić wartość 2, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie reakcji funkcji array_create_struct na limit pamięci (limit sterty ustawiono na 48 bajtów)
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie reakcji funkcji array_create_struct na limit pamięci (limit sterty ustawiono na 48 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(48);
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 30);
                printf("#####END#####");

                test_error(res == 2, "Funkcja array_create_struct() powinna zwrócić wartość 2, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji array_create_struct
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji array_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = array_create_struct(NULL, 30);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_create_struct() powinna zwrócić wartość 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int array[] = {60, 46, -29, -1, 25, 48, 12, -73, -91, -26, 57, -59, 65, -35, 97, 72, 60, -65};
        
                struct array_t ptr = { .size = 10, .capacity = -2 };

                printf("#####START#####");
                int res = array_create(&ptr, 18);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 18, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 18, a ustawiła na %d", ptr.size);

                for (int i = 0; i < 18; ++i)
                {
                        printf("#####START#####");
                        res = array_push_back(&ptr, array[i]);
                        printf("#####END#####");
                        
                        test_error(res == 0, "Funkcja array_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 18, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na 18, a ustawiła na %d", ptr.size);
                        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr.ptr[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                printf("#####START#####");
                res = array_push_back(&ptr, 7);
                printf("#####END#####");

                test_error(res == 2, "Funkcja array_push_back() powinna zwrócić wartość 2, a zwróciła %d", res);
                test_error(ptr.size == 18, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na 18, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 18, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na 18, a ustawiła na %d", ptr.size);
                
                for (int j = 0; j < 18; ++j)
                    test_error(ptr.ptr[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr.ptr[j]);
                
                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int array[] = {83, 96, -45, 10, -45, 99, 58, 47, -53, 27, -32, 30, -33, -99, -48, -72, -16, 26, -34, -47, -38, -34, 27, -74, -30, -39, 21, -3, -62, 46, 19, -6, 52, 34, 84, -84, -5, 60, 61, 19, 41, 69, 46, -38, 73, 13, -6, 1, 90, 4, 30, -79, 70, -64, -87, -59, 26, 31, 74, -86, -62, 19, -52, -18, -90};
        
                struct array_t ptr = { .size = -9, .capacity = -4 };

                printf("#####START#####");
                int res = array_create(&ptr, 65);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 65, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 65, a ustawiła na %d", ptr.size);

                for (int i = 0; i < 65; ++i)
                {
                        printf("#####START#####");
                        res = array_push_back(&ptr, array[i]);
                        printf("#####END#####");
                        
                        test_error(res == 0, "Funkcja array_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 65, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na 65, a ustawiła na %d", ptr.size);
                        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr.ptr[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                printf("#####START#####");
                res = array_push_back(&ptr, 64);
                printf("#####END#####");

                test_error(res == 2, "Funkcja array_push_back() powinna zwrócić wartość 2, a zwróciła %d", res);
                test_error(ptr.size == 65, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na 65, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 65, "Funkcja array_push_back() powinna ustawić wartość pola size w strukturze na 65, a ustawiła na %d", ptr.size);
                
                for (int j = 0; j < 65; ++j)
                    test_error(ptr.ptr[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr.ptr[j]);
                
                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {-58, 90, -79, -34, 49, 47, -96, -57, 46, -83, 32, -33, -9, -4, 69, 81, -54, -70, 73, 41};
                struct array_t ptr = { .ptr = array, .size = -2, .capacity = 3 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, 14);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {-58, 90, -79, -34, 49, 47, -96, -57, 46, -83, 32, -33, -9, -4, 69, 81, -54, -70, 73, 41};
                struct array_t ptr = { .ptr = array, .size = 0, .capacity = -1 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, -60);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {-58, 90, -79, -34, 49, 47, -96, -57, 46, -83, 32, -33, -9, -4, 69, 81, -54, -70, 73, 41};
                struct array_t ptr = { .ptr = array, .size = 17, .capacity = 9 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, -80);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {-58, 90, -79, -34, 49, 47, -96, -57, 46, -83, 32, -33, -9, -4, 69, 81, -54, -70, 73, 41};
                struct array_t ptr = { .ptr = array, .size = 0, .capacity = 0 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, 13);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {-58, 90, -79, -34, 49, 47, -96, -57, 46, -83, 32, -33, -9, -4, 69, 81, -54, -70, 73, 41};
                struct array_t ptr = { .ptr = array, .size = 13, .capacity = -4 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, -60);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[] = {-58, 90, -79, -34, 49, 47, -96, -57, 46, -83, 32, -33, -9, -4, 69, 81, -54, -70, 73, 41};
                struct array_t ptr = { .ptr = array, .size = -14, .capacity = -1 };
                    
                printf("#####START#####");
                int res = array_push_back(&ptr, -2);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji array_push_back
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji array_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            int res = array_push_back(NULL, 26);
            printf("#####END#####");

            test_error(res == 1, "Funkcja array_create() powinna zwrócić wartość 1, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-38, 62, 69, 0, 2, 40, -63, -69, -68, 61, 35};
                const int expected_array[] = {62, 69, 0, 2, 40, -63, -69, -68, 61, 35};

                struct array_t ptr = { .size = 11, .capacity = 11 };
                ptr.ptr = array;

                printf("#####START#####");
                int res = array_remove_item(&ptr, -38);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_remove_item() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 10, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 10, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 11, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 11, a ustawiła na %d", ptr.size);

                for (int j = 0; j < 10; ++j)
                    test_error(ptr.ptr[j] == expected_array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_array[j], ptr.ptr[j]);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {42};
                const int expected_array[] = {0};

                struct array_t ptr = { .size = 1, .capacity = 1 };
                ptr.ptr = array;

                printf("#####START#####");
                int res = array_remove_item(&ptr, 42);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_remove_item() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 1, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 1, a ustawiła na %d", ptr.size);

                for (int j = 0; j < 0; ++j)
                    test_error(ptr.ptr[j] == expected_array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_array[j], ptr.ptr[j]);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-33};
                const int expected_array[] = {-33};

                struct array_t ptr = { .size = 1, .capacity = 1 };
                ptr.ptr = array;

                printf("#####START#####");
                int res = array_remove_item(&ptr, -32);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_remove_item() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 1, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 1, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 1, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 1, a ustawiła na %d", ptr.size);

                for (int j = 0; j < 1; ++j)
                    test_error(ptr.ptr[j] == expected_array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_array[j], ptr.ptr[j]);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-87, -78, 59, -60, -26, -9, -26, 75, 67, -24, 39, 72, -32, -82, -68, 1, -20, 8, -90, -72, 57, 65, 46, 26, -70, 83, -22, 6};
                const int expected_array[] = {-87, -78, 59, -60, -26, -9, -26, 75, 67, -24, 39, 72, -32, -82, -68, 1, -20, 8, -90, -72, 57, 65, 46, 26, -70, 83, -22};

                struct array_t ptr = { .size = 28, .capacity = 28 };
                ptr.ptr = array;

                printf("#####START#####");
                int res = array_remove_item(&ptr, 6);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_remove_item() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 27, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 27, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 28, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 28, a ustawiła na %d", ptr.size);

                for (int j = 0; j < 27; ++j)
                    test_error(ptr.ptr[j] == expected_array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_array[j], ptr.ptr[j]);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-7, 11, 34, -33, -65, -55, 89, -66, 22, -77, 14, -3, -12, 91, 64, -70, -7, 80, -53, -43, 31, -22, -52, -26, 53, -71, -95, 90, 50, -44};
                const int expected_array[] = {-7, 11, 34, -33, -65, 89, -66, 22, -77, 14, -3, -12, 91, 64, -70, -7, 80, -53, -43, 31, -22, -52, -26, 53, -71, -95, 90, 50, -44};

                struct array_t ptr = { .size = 30, .capacity = 30 };
                ptr.ptr = array;

                printf("#####START#####");
                int res = array_remove_item(&ptr, -55);
                printf("#####END#####");

                test_error(res == 1, "Funkcja array_remove_item() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 29, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 29, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 30, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 30, a ustawiła na %d", ptr.size);

                for (int j = 0; j < 29; ++j)
                    test_error(ptr.ptr[j] == expected_array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_array[j], ptr.ptr[j]);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {2, 4, 0, 4, 3, 4, 4, -6, -3, 6, -10, 6, -7, -1, -6, -4, 5, -9, -7, 3, -4, -10, 0, 1, -6, 4, 1, -8, -3, -10, 2, 8, 7, 1, 7, 0, -4, 1, 4, -5, -8, -10, 8, 6, 0, -3};
                const int expected_array[] = {2, 4, 4, 3, 4, 4, -6, -3, 6, -10, 6, -7, -1, -6, -4, 5, -9, -7, 3, -4, -10, 1, -6, 4, 1, -8, -3, -10, 2, 8, 7, 1, 7, -4, 1, 4, -5, -8, -10, 8, 6, -3};

                struct array_t ptr = { .size = 46, .capacity = 46 };
                ptr.ptr = array;

                printf("#####START#####");
                int res = array_remove_item(&ptr, 0);
                printf("#####END#####");

                test_error(res == 4, "Funkcja array_remove_item() powinna zwrócić wartość 4, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 42, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 42, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 46, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 46, a ustawiła na %d", ptr.size);

                for (int j = 0; j < 42; ++j)
                    test_error(ptr.ptr[j] == expected_array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_array[j], ptr.ptr[j]);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10};
                const int expected_array[] = {0};

                struct array_t ptr = { .size = 48, .capacity = 48 };
                ptr.ptr = array;

                printf("#####START#####");
                int res = array_remove_item(&ptr, 10);
                printf("#####END#####");

                test_error(res == 48, "Funkcja array_remove_item() powinna zwrócić wartość 48, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 48, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 48, a ustawiła na %d", ptr.size);

                for (int j = 0; j < 0; ++j)
                    test_error(ptr.ptr[j] == expected_array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_array[j], ptr.ptr[j]);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8};
                const int expected_array[] = {-8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8};

                struct array_t ptr = { .size = 42, .capacity = 42 };
                ptr.ptr = array;

                printf("#####START#####");
                int res = array_remove_item(&ptr, 4);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_remove_item() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 42, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 42, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 42, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 42, a ustawiła na %d", ptr.size);

                for (int j = 0; j < 42; ++j)
                    test_error(ptr.ptr[j] == expected_array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_array[j], ptr.ptr[j]);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-33, -22, 45, 9, -25, -42, 67, 88, 39, 57, 13, 7, 57, -36, 94, 70, -79, 85, 13, 4, -29, 60, -92, 74, 42, -87, 31, -50, 2, -55, -17, 78, 6, -71, 49, -71, 1, 31, 70, -27, 84, -1, 16, 55};
                const int expected_array[] = {-33, -22, 45, 9, -25, -42, 67, 88, 39, 57, 13, 7, 57, -36, 94, 70, -79, 85, 13, 4, -29, 60, -92, 74, 42, -87, 31, -50, 2, -55, -17, 78, 6, -71, 49, -71, 1, 31, 70, -27, 84, -1, 16, 55};

                struct array_t ptr = { .size = 44, .capacity = 44 };
                ptr.ptr = array;

                printf("#####START#####");
                int res = array_remove_item(&ptr, -48);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_remove_item() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 44, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 44, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 44, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 44, a ustawiła na %d", ptr.size);

                for (int j = 0; j < 44; ++j)
                    test_error(ptr.ptr[j] == expected_array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_array[j], ptr.ptr[j]);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int array[8];

            struct array_t ptr = { .size = 0, .capacity = 8 };
            ptr.ptr = array;

            printf("#####START#####");
            int res = array_remove_item(&ptr, 0);
            printf("#####END#####");

            test_error(res == 0, "Funkcja array_remove_item() powinna zwrócić wartość 0, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(ptr.size == 0, "Funkcja array_remove_item() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
            test_error(ptr.capacity == 8, "Funkcja array_remove_item() powinna ustawić wartość pola capacity w strukturze na 8, a ustawiła na %d", ptr.size);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-40, -25, -65, -71, 15, -87, 33, 56, -49, -2, -25, -93, 16, 83, 16, 66, 1, 64};
                struct array_t ptr = { .ptr = array, .size = -9, .capacity = 8 };

                printf("#####START#####");
                int res = array_remove_item(&ptr, 10);
                printf("#####END#####");

                test_error(res == -1, "Funkcja array_remove_item() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-40, -25, -65, -71, 15, -87, 33, 56, -49, -2, -25, -93, 16, 83, 16, 66, 1, 64};
                struct array_t ptr = { .ptr = array, .size = 0, .capacity = -6 };

                printf("#####START#####");
                int res = array_remove_item(&ptr, 77);
                printf("#####END#####");

                test_error(res == -1, "Funkcja array_remove_item() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-40, -25, -65, -71, 15, -87, 33, 56, -49, -2, -25, -93, 16, 83, 16, 66, 1, 64};
                struct array_t ptr = { .ptr = array, .size = 12, .capacity = 4 };

                printf("#####START#####");
                int res = array_remove_item(&ptr, 57);
                printf("#####END#####");

                test_error(res == -1, "Funkcja array_remove_item() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-40, -25, -65, -71, 15, -87, 33, 56, -49, -2, -25, -93, 16, 83, 16, 66, 1, 64};
                struct array_t ptr = { .ptr = array, .size = 0, .capacity = 0 };

                printf("#####START#####");
                int res = array_remove_item(&ptr, -56);
                printf("#####END#####");

                test_error(res == -1, "Funkcja array_remove_item() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-40, -25, -65, -71, 15, -87, 33, 56, -49, -2, -25, -93, 16, 83, 16, 66, 1, 64};
                struct array_t ptr = { .ptr = array, .size = 15, .capacity = -6 };

                printf("#####START#####");
                int res = array_remove_item(&ptr, 91);
                printf("#####END#####");

                test_error(res == -1, "Funkcja array_remove_item() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-40, -25, -65, -71, 15, -87, 33, 56, -49, -2, -25, -93, 16, 83, 16, 66, 1, 64};
                struct array_t ptr = { .ptr = array, .size = -20, .capacity = -4 };

                printf("#####START#####");
                int res = array_remove_item(&ptr, -79);
                printf("#####END#####");

                test_error(res == -1, "Funkcja array_remove_item() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji array_remove_item
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji array_remove_item", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            int res = array_remove_item(NULL, 44);
            printf("#####END#####");

            test_error(res == -1, "Funkcja array_create() powinna zwrócić wartość -1, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji array_destroy
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji array_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 18);
                printf("#####END#####");

         
                test_error(ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę array_t, a przypisała NULL");
                test_error(res == 0, "Funkcja array_create_struct() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze array_t, a przypisała NULL");
                test_error(ptr->size == 0, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                test_error(ptr->capacity == 18, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 18, a ustawiła na %d", ptr->size);

                printf("#####START#####");
                array_destroy_struct(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji array_destroy
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji array_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 18);
                printf("#####END#####");

         
                test_error(ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę array_t, a przypisała NULL");
                test_error(res == 0, "Funkcja array_create_struct() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->ptr != NULL, "Funkcja array_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze array_t, a przypisała NULL");
                test_error(ptr->size == 0, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                test_error(ptr->capacity == 18, "Funkcja array_create_struct() powinna ustawić wartość pola size w strukturze na 18, a ustawiła na %d", ptr->size);

                printf("#####START#####");
                array_destroy_struct(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie poprawności działania funkcji array_destroy
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie poprawności działania funkcji array_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


            printf("#####START#####");
            array_destroy_struct(NULL);
            printf("#####END#####");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie poprawności działania funkcji array_destroy_struct
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie poprawności działania funkcji array_destroy_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 13);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                test_error(ptr->capacity == 13, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 13, a ustawiła na %d", ptr->size);

                printf("#####START#####");
                array_destroy_struct(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie poprawności działania funkcji array_destroy_struct
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie poprawności działania funkcji array_destroy_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct array_t *ptr;

                printf("#####START#####");
                int res = array_create_struct(&ptr, 7349);
                printf("#####END#####");

                test_error(res == 0, "Funkcja array_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->size == 0, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                test_error(ptr->capacity == 7349, "Funkcja array_create() powinna ustawić wartość pola size w strukturze na 7349, a ustawiła na %d", ptr->size);

                printf("#####START#####");
                array_destroy_struct(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie poprawności działania funkcji array_destroy
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie poprawności działania funkcji array_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


            printf("#####START#####");
            array_destroy(NULL);
            printf("#####END#####");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie poprawności działania funkcji array_destroy
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie poprawności działania funkcji array_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct array_t ptr = { .ptr = NULL, .size = 4, .capacity = 16 };

            printf("#####START#####");
            array_destroy(&ptr);
            printf("#####END#####");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie poprawności działania funkcji array_display
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie poprawności działania funkcji array_display", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int array[] = {-40, -25, -65, -71, 15, -87, 33, 56, -49, -2, -25, -93, 16, 83, 16, 66, 1, 64};

            struct array_t arr;
            arr.ptr = array;

    //-------------1-----------------------

            printf("***START***\n");
            array_display(NULL);
            printf("***END***\n");


    //-------------2-----------------------

            arr.capacity = 17;
            arr.size = 18;

            printf("***START***\n");
            array_display(&arr);
            printf("***END***\n");


    //-------------3-----------------------

            arr.capacity = 18;
            arr.size = -18;

            printf("***START***\n");
            array_display(&arr);
            printf("***END***\n");


    //-------------4-----------------------

            arr.capacity = 18;
            arr.size = 0;

            printf("***START***\n");
            array_display(&arr);
            printf("***END***\n");

    //-------------5-----------------------

            arr.capacity = 18;
            arr.size = 18;
            arr.ptr = NULL;

            printf("***START***\n");
            array_display(&arr);
            printf("***END***\n");

    //-------------6-----------------------

            arr.capacity = 18;
            arr.size = 18;
            arr.ptr = array;

            printf("***START***\n");
            array_display(&arr);
            printf("***END***\n");

    //-------------7-----------------------

            arr.capacity = 18;
            arr.size = 18 - 1;

            printf("***START***\n");
            array_display(&arr);
            printf("***END***\n");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci (limit sterty ustawiono na 16 bajtów)
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci (limit sterty ustawiono na 16 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(16);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji array_create
            UTEST2, // Sprawdzanie poprawności działania funkcji array_create
            UTEST3, // Sprawdzanie poprawności działania funkcji array_create
            UTEST4, // Sprawdzanie poprawności działania funkcji array_create
            UTEST5, // Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 356 bajtów)
            UTEST6, // Sprawdzanie reakcji funkcji create_array_int na limit pamięci (limit sterty ustawiono na 301 bajtów)
            UTEST7, // Sprawdzanie poprawności działania funkcji array_create
            UTEST8, // Sprawdzanie poprawności działania funkcji array_create_struct
            UTEST9, // Sprawdzanie poprawności działania funkcji array_create_struct
            UTEST10, // Sprawdzanie poprawności działania funkcji array_create_struct
            UTEST11, // Sprawdzanie poprawności działania funkcji array_create_struct
            UTEST12, // Sprawdzanie reakcji funkcji array_create_struct na limit pamięci (limit sterty ustawiono na 136 bajtów)
            UTEST13, // Sprawdzanie reakcji funkcji array_create_struct na limit pamięci (limit sterty ustawiono na 16 bajtów)
            UTEST14, // Sprawdzanie reakcji funkcji array_create_struct na limit pamięci (limit sterty ustawiono na 48 bajtów)
            UTEST15, // Sprawdzanie poprawności działania funkcji array_create_struct
            UTEST16, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST17, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST18, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST19, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST20, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST21, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST22, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST23, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST24, // Sprawdzanie poprawności działania funkcji array_push_back
            UTEST25, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST26, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST27, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST28, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST29, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST30, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST31, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST32, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST33, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST34, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST35, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST36, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST37, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST38, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST39, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST40, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST41, // Sprawdzanie poprawności działania funkcji array_remove_item
            UTEST42, // Sprawdzanie poprawności działania funkcji array_destroy
            UTEST43, // Sprawdzanie poprawności działania funkcji array_destroy
            UTEST44, // Sprawdzanie poprawności działania funkcji array_destroy
            UTEST45, // Sprawdzanie poprawności działania funkcji array_destroy_struct
            UTEST46, // Sprawdzanie poprawności działania funkcji array_destroy_struct
            UTEST47, // Sprawdzanie poprawności działania funkcji array_destroy
            UTEST48, // Sprawdzanie poprawności działania funkcji array_destroy
            UTEST49, // Sprawdzanie poprawności działania funkcji array_display
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(49); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)
            MTEST2, // Reakcja na brak pamięci (limit sterty ustawiono na 16 bajtów)
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(2); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}