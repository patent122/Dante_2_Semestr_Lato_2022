#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <float.h>
#include "tested_declarations.h"
#include "rdebug.h"

struct point_t 
{
    int x;
    int y;
};

float distance(const struct point_t* punkt_a, const struct point_t* punkt_b, int* blad);

int main()
{
    float odleglosc = DBL_MAX;
    struct point_t punkt_a, punkt_b, najlepszy_a, najlepszy_b;
    char filename[100];
    int blad;
    int c;
    FILE* plik1, * plik2;


    printf("Podaj sciezke:\n");
    scanf("%99s", filename);

    if ((plik1 = fopen(filename, "r")) == NULL)
    {
        printf("Couldn't open file\n");
        return 4;
    }

    if ((plik2 = fopen(filename, "r")) == NULL)
    {
        printf("Couldn't open file\n");
        fclose(plik1);
        return 4;
    }
    while ((c = fgetc(plik1)) != EOF)
    {
        if (isalpha((int)c) != 0)
        {
            printf("File corrupted\n");
            fclose(plik1);
            fclose(plik2);
            return 6;
        }
    }
    fseek(plik1, 0, SEEK_SET);
    int ile = 0;
    while (
        fscanf(plik1, "%d %d", &punkt_a.x, &punkt_a.y) == 2 
        && !ferror(plik2))
    {
        ile++;
        fseek(plik2, ftell(plik1), SEEK_SET);
        while (
            fscanf(plik2, "%d %d", &punkt_b.x, &punkt_b.y) == 2 
            && !ferror(plik1))
        {

            float aktualna = distance(&punkt_a, &punkt_b, &blad);

            if (aktualna < odleglosc)
            {
                odleglosc = aktualna;
                najlepszy_a.x = punkt_a.x;
                najlepszy_a.y = punkt_a.y;
                najlepszy_b.x = punkt_b.x;
                najlepszy_b.y = punkt_b.y;
            }
            if (aktualna == odleglosc)
            {
                int ax = punkt_a.x < punkt_b.x ? punkt_a.x : punkt_b.x;
                int najlepszy_x = najlepszy_a.x < najlepszy_b.x ? najlepszy_a.x : najlepszy_b.x;
                if (ax < najlepszy_x) {
                    odleglosc = aktualna;
                    najlepszy_a.x = punkt_a.x;
                    najlepszy_a.y = punkt_a.y;
                    najlepszy_b.x = punkt_b.x;
                    najlepszy_b.y = punkt_b.y;
                }
            }
        }
    }
    if (ile < 2) 
    {
        fclose(plik1);
        fclose(plik2);
        printf("File corrupted\n");
        return 6;
    }
    if (ferror(plik1) 
        || 
        ferror(plik2)) 
    {
        fclose(plik1);
        fclose(plik2);
        printf("File corrupted\n");
        return 6;
    }
    printf("%d %d %d %d\n", najlepszy_b.x, najlepszy_b.y, najlepszy_a.x, najlepszy_a.y);
    fclose(plik1);
    fclose(plik2);
    return 0;
}

float distance(const struct point_t* punkt_a, const struct point_t* punkt_b, int* blad)
{
    if (punkt_a == NULL || punkt_b == NULL)
    {
        if (blad == NULL)
            return -1;
        else
        {
            *blad = 1;
            return -1;
        }
    }

    float aktualna = sqrtf(powf((float)punkt_b->x - (float)punkt_a->x, 2) + powf((float)punkt_b->y - (float)punkt_a->y, 2));

    if (blad != NULL)
    {
        if (aktualna >= 0)
        {
            *blad = 0;
        }
        else
        {
            *blad = 1;
        }
    }
    return aktualna;
}
