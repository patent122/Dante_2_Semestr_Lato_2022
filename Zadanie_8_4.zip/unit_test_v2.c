/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Dynamiczne łączenie tekstów
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 22:16:54.189171
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 260 bajtów)
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 260 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(260);
    
    //
    // -----------
    //
    

                char *expected_result = "Technology... is a queer thing.  It brings you great gifts with one hand, and it stabs you in the back with the other.  - C.P. Snow I think goals should never be easy, they should force you to work, even if they are uncomfortable at the time. - Michael Phelps";

                char *res = concatenate(2, "Technology... is a queer thing.  It brings you great gifts with one hand, and it stabs you in the back with the other.  - C.P. Snow", "I think goals should never be easy, they should force you to work, even if they are uncomfortable at the time. - Michael Phelps");

                test_error(res != NULL, "Funkcja concatenate() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");     
                             
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(expected_result, res) == 0, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa, powinno być 'Technology... is a queer thing.  It brings you great gifts with one hand, and it stabs you in the back with the other.  - C.P. Snow I think goals should never be easy, they should force you to work, even if they are uncomfortable at the time. - Michael Phelps', a jest '%s'", res);

                free(res);
                
                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 452 bajtów)
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 452 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(452);
    
    //
    // -----------
    //
    

                char *expected_result = "Man, the living creature, the creating individual, is always more important than any established style or system. - Bruce Lee\nPunishments include such things as flashbacks, flooding of unbearable emotions, painful body memories, flooding of memories in which the survivor perpetrated against others, self-harm, and suicide attempts. - Alison Miller Its not whether you get knocked down, its whether you get up. - Inspirational Quote by Vince Lombardi";

                char *res = concatenate(2, "Man, the living creature, the creating individual, is always more important than any established style or system. - Bruce Lee\nPunishments include such things as flashbacks, flooding of unbearable emotions, painful body memories, flooding of memories in which the survivor perpetrated against others, self-harm, and suicide attempts. - Alison Miller", "Its not whether you get knocked down, its whether you get up. - Inspirational Quote by Vince Lombardi");

                test_error(res != NULL, "Funkcja concatenate() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");     
                             
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(expected_result, res) == 0, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa, powinno być 'Man, the living creature, the creating individual, is always more important than any established style or system. - Bruce Lee\nPunishments include such things as flashbacks, flooding of unbearable emotions, painful body memories, flooding of memories in which the survivor perpetrated against others, self-harm, and suicide attempts. - Alison Miller Its not whether you get knocked down, its whether you get up. - Inspirational Quote by Vince Lombardi', a jest '%s'", res);

                free(res);
                
                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 401 bajtów)
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 401 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(401);
    
    //
    // -----------
    //
    

                char *expected_result = "The system of nature, of which man is a part, tends to be self-balancing, self-adjusting, self-cleansing.  Not so with technology.  - E.F. Schumacher  All hope abandon, ye who enter here. - Dante Alighieri, The Divine ComedyInformation technology and business are becoming inextricably interwoven. I dont think anybody can talk meaningfully about one without the talking about the other. - Bill Gates";

                char *res = concatenate(3, "The system of nature, of which man is a part, tends to be self-balancing, self-adjusting, self-cleansing.  Not so with technology.  - E.F. Schumacher", "", "All hope abandon, ye who enter here. - Dante Alighieri, The Divine ComedyInformation technology and business are becoming inextricably interwoven. I dont think anybody can talk meaningfully about one without the talking about the other. - Bill Gates");

                test_error(res != NULL, "Funkcja concatenate() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");     
                             
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(expected_result, res) == 0, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa, powinno być 'The system of nature, of which man is a part, tends to be self-balancing, self-adjusting, self-cleansing.  Not so with technology.  - E.F. Schumacher  All hope abandon, ye who enter here. - Dante Alighieri, The Divine ComedyInformation technology and business are becoming inextricably interwoven. I dont think anybody can talk meaningfully about one without the talking about the other. - Bill Gates', a jest '%s'", res);

                free(res);
                
                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 254 bajtów)
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 254 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(254);
    
    //
    // -----------
    //
    

                char *expected_result = "    All hope abandon, ye who enter here. - Dante Alighieri, The Divine ComedyInformation technology and business are becoming inextricably interwoven. I dont think anybody can talk meaningfully about one without the talking about the other. - Bill Gates";

                char *res = concatenate(5, "", "", "", "", "All hope abandon, ye who enter here. - Dante Alighieri, The Divine ComedyInformation technology and business are becoming inextricably interwoven. I dont think anybody can talk meaningfully about one without the talking about the other. - Bill Gates");

                test_error(res != NULL, "Funkcja concatenate() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");     
                             
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(expected_result, res) == 0, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa, powinno być '    All hope abandon, ye who enter here. - Dante Alighieri, The Divine ComedyInformation technology and business are becoming inextricably interwoven. I dont think anybody can talk meaningfully about one without the talking about the other. - Bill Gates', a jest '%s'", res);

                free(res);
                
                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 289 bajtów)
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 289 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(289);
    
    //
    // -----------
    //
    

                char *expected_result = "Darkness cannot drive out darkness: only light can do that. Hate cannot drive out hate: only love can do that. - Martin Luther King Jr. To see what is right and not do it is a lack of courage.- Confucious Im not a great programmer; Im just a good programmer with great habits. - Kent Beck";

                char *res = concatenate(3, "Darkness cannot drive out darkness: only light can do that. Hate cannot drive out hate: only love can do that. - Martin Luther King Jr.", "To see what is right and not do it is a lack of courage.- Confucious", "Im not a great programmer; Im just a good programmer with great habits. - Kent Beck");

                test_error(res != NULL, "Funkcja concatenate() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");     
                             
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(strcmp(expected_result, res) == 0, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa, powinno być 'Darkness cannot drive out darkness: only light can do that. Hate cannot drive out hate: only love can do that. - Martin Luther King Jr. To see what is right and not do it is a lack of courage.- Confucious Im not a great programmer; Im just a good programmer with great habits. - Kent Beck', a jest '%s'", res);

                free(res);
                
                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 0 bajtów)
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                char *res = concatenate(7, "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "It is impossible to work in information technology without also engaging in social engineering. - Jaron Lanier", "I have always wished for my computer to be as easy to use as my telephone; my wish has come true because I can no longer figure out how to use my telephone. - Bjarne Stroustrup", "Twenty years from now you will be more disappointed by the things that you didnt do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.", "The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency. - Bill Gates", "Programming is one of the most difficult branches of applied mathematics; the poorer mathematicians had better remain pure mathematicians. - Edsger Dijkstra", "C is quirky, flawed, and an enormous success. - Dennis M. Ritchie.");

                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 309 bajtów)
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 309 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(309);
    
    //
    // -----------
    //
    

                char *res = concatenate(7, "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "It is impossible to work in information technology without also engaging in social engineering. - Jaron Lanier", "I have always wished for my computer to be as easy to use as my telephone; my wish has come true because I can no longer figure out how to use my telephone. - Bjarne Stroustrup", "Twenty years from now you will be more disappointed by the things that you didnt do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.", "The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency. - Bill Gates", "Programming is one of the most difficult branches of applied mathematics; the poorer mathematicians had better remain pure mathematicians. - Edsger Dijkstra", "C is quirky, flawed, and an enormous success. - Dennis M. Ritchie.");

                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 420 bajtów)
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 420 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(420);
    
    //
    // -----------
    //
    

                char *res = concatenate(7, "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "It is impossible to work in information technology without also engaging in social engineering. - Jaron Lanier", "I have always wished for my computer to be as easy to use as my telephone; my wish has come true because I can no longer figure out how to use my telephone. - Bjarne Stroustrup", "Twenty years from now you will be more disappointed by the things that you didnt do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.", "The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency. - Bill Gates", "Programming is one of the most difficult branches of applied mathematics; the poorer mathematicians had better remain pure mathematicians. - Edsger Dijkstra", "C is quirky, flawed, and an enormous success. - Dennis M. Ritchie.");

                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 597 bajtów)
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 597 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(597);
    
    //
    // -----------
    //
    

                char *res = concatenate(7, "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "It is impossible to work in information technology without also engaging in social engineering. - Jaron Lanier", "I have always wished for my computer to be as easy to use as my telephone; my wish has come true because I can no longer figure out how to use my telephone. - Bjarne Stroustrup", "Twenty years from now you will be more disappointed by the things that you didnt do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.", "The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency. - Bill Gates", "Programming is one of the most difficult branches of applied mathematics; the poorer mathematicians had better remain pure mathematicians. - Edsger Dijkstra", "C is quirky, flawed, and an enormous success. - Dennis M. Ritchie.");

                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 855 bajtów)
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 855 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(855);
    
    //
    // -----------
    //
    

                char *res = concatenate(7, "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "It is impossible to work in information technology without also engaging in social engineering. - Jaron Lanier", "I have always wished for my computer to be as easy to use as my telephone; my wish has come true because I can no longer figure out how to use my telephone. - Bjarne Stroustrup", "Twenty years from now you will be more disappointed by the things that you didnt do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.", "The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency. - Bill Gates", "Programming is one of the most difficult branches of applied mathematics; the poorer mathematicians had better remain pure mathematicians. - Edsger Dijkstra", "C is quirky, flawed, and an enormous success. - Dennis M. Ritchie.");

                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 1099 bajtów)
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 1099 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1099);
    
    //
    // -----------
    //
    

                char *res = concatenate(7, "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "It is impossible to work in information technology without also engaging in social engineering. - Jaron Lanier", "I have always wished for my computer to be as easy to use as my telephone; my wish has come true because I can no longer figure out how to use my telephone. - Bjarne Stroustrup", "Twenty years from now you will be more disappointed by the things that you didnt do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.", "The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency. - Bill Gates", "Programming is one of the most difficult branches of applied mathematics; the poorer mathematicians had better remain pure mathematicians. - Edsger Dijkstra", "C is quirky, flawed, and an enormous success. - Dennis M. Ritchie.");

                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 1256 bajtów)
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 1256 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1256);
    
    //
    // -----------
    //
    

                char *res = concatenate(7, "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "It is impossible to work in information technology without also engaging in social engineering. - Jaron Lanier", "I have always wished for my computer to be as easy to use as my telephone; my wish has come true because I can no longer figure out how to use my telephone. - Bjarne Stroustrup", "Twenty years from now you will be more disappointed by the things that you didnt do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.", "The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency. - Bill Gates", "Programming is one of the most difficult branches of applied mathematics; the poorer mathematicians had better remain pure mathematicians. - Edsger Dijkstra", "C is quirky, flawed, and an enormous success. - Dennis M. Ritchie.");

                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 1322 bajtów)
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 1322 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1322);
    
    //
    // -----------
    //
    

                char *res = concatenate(7, "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "It is impossible to work in information technology without also engaging in social engineering. - Jaron Lanier", "I have always wished for my computer to be as easy to use as my telephone; my wish has come true because I can no longer figure out how to use my telephone. - Bjarne Stroustrup", "Twenty years from now you will be more disappointed by the things that you didnt do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.", "The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency. - Bill Gates", "Programming is one of the most difficult branches of applied mathematics; the poorer mathematicians had better remain pure mathematicians. - Edsger Dijkstra", "C is quirky, flawed, and an enormous success. - Dennis M. Ritchie.");

                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


                char *res = concatenate(-5, "Its not the load that breaks you down, its the way you carry it. - Lou Holtz", "It is hard enough to remember my opinions, without also remembering my reasons for them! - Friedrich Nietzsche", "There was a time in the 1930s when magazine writers could actually make a good living. The Saturday Evening Post and Colliers both had three stories in each issue. These were usually entertaining, and people really went for them. But then television came along, and now of course, information technology... the new way of killing time. - Tom Wolfe", "First learn computer science and all the theory. Next develop a programming style. Then forget all that and just hack. - George Carrette", "Youve baked a really lovely cake, but then youve used dog shit for frosting. - Steve Jobs");
                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                char *res = concatenate(0, "Its not the load that breaks you down, its the way you carry it. - Lou Holtz", "It is hard enough to remember my opinions, without also remembering my reasons for them! - Friedrich Nietzsche", "There was a time in the 1930s when magazine writers could actually make a good living. The Saturday Evening Post and Colliers both had three stories in each issue. These were usually entertaining, and people really went for them. But then television came along, and now of course, information technology... the new way of killing time. - Tom Wolfe", "First learn computer science and all the theory. Next develop a programming style. Then forget all that and just hack. - George Carrette", "Youve baked a really lovely cake, but then youve used dog shit for frosting. - Steve Jobs");
                test_error(res == NULL, "Funkcja concatenate() powinna zwrócić NULL");     

                test_no_heap_leakage();
                onerror_terminate(); // przerwnie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci - limit pamięci ustawiony na 0
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci - limit pamięci ustawiony na 0", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci - limit pamięci ustawiony na 32
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci - limit pamięci ustawiony na 32", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci - limit pamięci ustawiony na 1033
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci - limit pamięci ustawiony na 1033", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1033);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na brak pamięci - limit pamięci ustawiony na 2034
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na brak pamięci - limit pamięci ustawiony na 2034", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(2034);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Reakcja na brak pamięci - limit pamięci ustawiony na 3035
//
void MTEST5(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(5, "Reakcja na brak pamięci - limit pamięci ustawiony na 3035", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3035);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Reakcja na brak pamięci - limit pamięci ustawiony na 4036
//
void MTEST6(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(6, "Reakcja na brak pamięci - limit pamięci ustawiony na 4036", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(4036);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Reakcja programu na ograniczoną pamięć, wystarczającą na wykonanie wszystkich operacji - limit pamięci ustawiony na 4510
//
void MTEST7(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(7, "Reakcja programu na ograniczoną pamięć, wystarczającą na wykonanie wszystkich operacji - limit pamięci ustawiony na 4510", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(4510);
    
    //
    // -----------
    //
    
             printf("***START***\n");
             int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
             printf("\n***END***\n");
             test_error(ret_code == 0, "Funkcja main zakończyła się kodem %d a powinna 0", ret_code); 
         
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 260 bajtów)
            UTEST2, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 452 bajtów)
            UTEST3, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 401 bajtów)
            UTEST4, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 254 bajtów)
            UTEST5, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 289 bajtów)
            UTEST6, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 0 bajtów)
            UTEST7, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 309 bajtów)
            UTEST8, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 420 bajtów)
            UTEST9, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 597 bajtów)
            UTEST10, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 855 bajtów)
            UTEST11, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 1099 bajtów)
            UTEST12, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 1256 bajtów)
            UTEST13, // Sprawdzanie poprawności działania funkcji concatenate - (limit sterty ustawiono na 1322 bajtów)
            UTEST14, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST15, // Sprawdzanie poprawności działania funkcji concatenate
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(15); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci - limit pamięci ustawiony na 0
            MTEST2, // Reakcja na brak pamięci - limit pamięci ustawiony na 32
            MTEST3, // Reakcja na brak pamięci - limit pamięci ustawiony na 1033
            MTEST4, // Reakcja na brak pamięci - limit pamięci ustawiony na 2034
            MTEST5, // Reakcja na brak pamięci - limit pamięci ustawiony na 3035
            MTEST6, // Reakcja na brak pamięci - limit pamięci ustawiony na 4036
            MTEST7, // Reakcja programu na ograniczoną pamięć, wystarczającą na wykonanie wszystkich operacji - limit pamięci ustawiony na 4510
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(7); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}