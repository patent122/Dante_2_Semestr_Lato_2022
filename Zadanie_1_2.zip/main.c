#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int file_size_from_file(FILE* f)
{
	if (f == NULL)
	{
		return -2;
	}

	int current = ftell(f);
	fseek(f, 0, SEEK_SET);
	fseek(f, 0, SEEK_END);
	int size = ftell(f);
	fseek(f, current, SEEK_SET);

	return size;
}

int file_size_from_path(const char* path)
{
	if (path == NULL)
	{
		return -2;
	}

	FILE* file = fopen(path, "rb");

	if (file == NULL)
	{
		return -1;
	}

	int size = file_size_from_file(file);
	fclose(file);
	return size;
}

int main()
{
	char path[31];
	printf("Input file path: ");
	scanf("%30s", path);
	FILE* file = fopen(path, "rb");

	int size1 = file_size_from_path(path);
	int size2 = file_size_from_file(file);

	if (size1 < 0 || size2 < 0)
	{
		printf("Couldn't open file");
		
		if (file != NULL)
		{
			fclose(file);
		}
		return 4;
	}
	if (size1 == size2)
	{
		printf("%d bytes", size1);
	}
	else
	{
		printf("error");
	}

	fclose(file);

	return 0;
}

