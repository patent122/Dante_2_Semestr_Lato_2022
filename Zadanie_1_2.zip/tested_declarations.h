/*
 * Test dla zadania Ile waży plik (trojański?)
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-03-07 20:33:48.827868
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta



        int file_size_from_path(const char *path);
        int file_size_from_file(FILE *f);
    

#endif // _TESTED_DECLARATIONS_H_