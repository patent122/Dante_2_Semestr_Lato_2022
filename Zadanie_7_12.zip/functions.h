#ifndef INC_6_12_FUNCTIONS_H
#define INC_6_12_FUNCTIONS_H

void print_chicken(void);
void print_egg(void);
void print_rabbit(void);

void* easter(int size, void (*f1)(void), void (*f2)(void), void (*f3)(void));

#endif //INC_6_12_FUNCTIONS_H_BOARD_H