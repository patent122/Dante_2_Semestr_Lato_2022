#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include "tested_declarations.h"
#include "rdebug.h"


int main()
{
    int rozmiar;
    printf("Input table rozmiar: ");

    if(scanf("%d", &rozmiar) != 1)
    {
        printf("Incorrect input\n");

        return 1;
    }
    if (rozmiar < 1)
    {
        printf("Incorrect input data\n");
        return 2;
    }

    void (**tabliczka)(void) = easter(rozmiar, print_chicken, print_egg, print_rabbit);
    if(tabliczka == NULL)
    {
        printf("Failed to allocate memory\n");
        free(tabliczka);
        return 8;
    }

    for (int i = 0; i < rozmiar; ++i)
    {
        (*(tabliczka + i))();
    }

    free(tabliczka);
    return 0;
}
