#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int* create_array_int(int N);
int* copy_array_int(const int* liczby, int N);
void display_array_int(const int* liczby, int N);

int main()
{
    int *liczby = NULL;
    int rozmiar;
    printf("Podaj rozmiar tablicy: ");
    if(scanf("%d", &rozmiar) != 1)
    {
        printf("Incorrect input\n");
        return 1;
    }
    if(rozmiar < 1)
    {
        printf("Incorrect input data\n");
        return 2;
    }

    liczby = create_array_int(rozmiar);

    if(liczby == NULL)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }

    int x = 0;
    printf("Podaj liczby: ");
    while(x < rozmiar)
    {
        int blad = scanf("%d", liczby + x);
        if(blad != 1)
        {
            printf("Incorrect input\n");
            free(liczby);
            return 1;
        }
        x++;
    }

    int *nowa = copy_array_int(liczby, rozmiar);

    if(nowa == NULL)
    {
        printf("Failed to allocate memory\n");
        free(liczby);
        return 8;
    }

    display_array_int(liczby, rozmiar);
    display_array_int(nowa, rozmiar);

    free(liczby);
    free(nowa);

    return 0;
}

int* create_array_int(int N)
{
    if(N < 1) return NULL;

    int *liczby = malloc(N * sizeof(int));

    if(liczby == NULL) return NULL;

    return liczby;
}
int* copy_array_int(const int* liczby, int N)
{
    if(liczby == NULL || N < 1) return NULL;

    int *nowa = malloc(N * sizeof(int));

    if(nowa == NULL)
    {
        return NULL;
    }

    for (int i = 0; i < N; ++i)
    {
        *(nowa + i) = *(liczby + i);
    }

    return nowa;
}
void display_array_int(const int* liczby, int N)
{
    if(liczby == NULL || N < 1) return;

    for (int i = 0; i < N; ++i)
    {
        printf("%d ", *(liczby+i));
    }
    printf("\n");
}
