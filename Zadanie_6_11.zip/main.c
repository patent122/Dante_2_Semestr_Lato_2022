#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tested_declarations.h"
#include "rdebug.h"

int main() {
    char* tekst = malloc(1);
    if (tekst == NULL) {
        printf("Failed to allocate memory");
        return 8;
    }
    *tekst = '\0';
    printf("Podaj tekst");
    while (1) {
        char znak = getchar();
        if (znak == '\n') {
            break;
        }
        char* nn = realloc(tekst, strlen(tekst) + 2);
        if (nn == NULL) {
            printf("%s", tekst);
            free(tekst);
            return 0;
        }
        tekst = nn;
        *(tekst + strlen(tekst) + 1) = '\0';
        *(tekst + strlen(tekst)) = znak;
    }
    printf("%s", tekst);
    free(tekst);
    return 0;
}
