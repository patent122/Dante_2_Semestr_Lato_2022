#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int create_array_2d_2(int ***tablica, int szerokosc, int wysokosc);
void destroy_array_2d(int ***tablica, int wysokosc);
void display_array_2d(int **tablica, int szerokosc, int wysokosc);
int sum_array_2d(int **tablica, int szerokosc, int wysokosc);
int sum_row(int *tablica, int szerokosc);

int main()
{
    int **dane = NULL;
    int szerokosc, wysokosc, blad;
    printf("Podaj szerokość i wysokość: ");
    if(scanf("%d %d", &szerokosc, &wysokosc) != 2)
    {
        printf("Incorrect input\n");
        return 1;
    }
    if(wysokosc < 1 || szerokosc < 1)
    {
        printf("Incorrect input data\n");
        return 2;
    }

    blad = create_array_2d_2(&dane, szerokosc, wysokosc);
    if(blad == 2)
    {
        printf("Failed to allocate memory");
        return 8;
    }

    printf("Podaj liczby: ");
    for (int i = 0; i < wysokosc; ++i)
    {
        for (int j = 0; j < szerokosc; ++j)
        {
            if(scanf("%d", *(dane + i) + j) != 1)
            {
                destroy_array_2d(&dane, wysokosc);
                printf("Incorrect input\n");
                return 1;
            }
        }
    }

    display_array_2d(dane, szerokosc, wysokosc);

    for (int i = 0; i < wysokosc; ++i)
    {
        printf("%d\n", sum_row(*(dane + i), szerokosc));
    }

    printf("%d\n", sum_array_2d(dane, szerokosc, wysokosc));

    destroy_array_2d(&dane,wysokosc);
    return 0;
}

int create_array_2d_2(int ***tablica, int szerokosc, int wysokosc)
{
    if(wysokosc < 1 || szerokosc < 1 || tablica == NULL) return 1;

    *tablica = malloc(wysokosc * sizeof(int*));
    if(*tablica == NULL)
    {
        return 2;
    }

    for (int i = 0; i < wysokosc; ++i)
    {
        *(*tablica + i) = malloc(szerokosc * sizeof(int));
        if(*(*tablica+i) == NULL)
        {
            for (int j = 0; j < i ; ++j)
            {
                free(*(*tablica + j));
            }
            free(*tablica);
            *tablica=NULL;
            return 2;
        }
    }

    return 0;
}

void destroy_array_2d(int ***tablica, int wysokosc)
{
    if(tablica == NULL || wysokosc < 1) return;

    for (int i = 0; i < wysokosc; ++i) {
        free(*(*tablica+i));
    }
    free(*tablica);
    *tablica = NULL;
}

void display_array_2d(int **tablica, int szerokosc, int wysokosc)
{
    if(tablica == NULL || wysokosc < 1 || szerokosc < 1) return;

    for (int i = 0; i < wysokosc; ++i)
    {
        for (int j = 0; j < szerokosc; ++j)
        {
            printf("%3d ", *(*(tablica + i) + j));
        }
        printf("\n");
    }
}

int sum_array_2d(int **tablica, int szerokosc, int wysokosc)
{
    if(tablica == NULL || wysokosc < 1 || szerokosc < 1) return -1;

    int sum = 0;

    for (int i = 0; i < wysokosc; ++i)
    {
        for (int j = 0; j < szerokosc; ++j)
        {
            sum += *(*(tablica + i) + j);
        }
    }

    return sum;
}

int sum_row(int *tablica, int szerokosc)
{
    if(tablica == NULL || szerokosc < 1) return -1;

    int sum = 0;
    for (int i = 0; i < szerokosc; ++i)
    {
        sum += *(tablica + i);
    }

    return sum;
}
