/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Alokacja pamięci na tablicę 2D II
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 20:38:21.142160
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji destroy_array_2d
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji destroy_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr = NULL;

            printf("#####START#####");
            destroy_array_2d(&ptr, 0);
            printf("#####END#####");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji destroy_array_2d
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji destroy_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr = NULL;

            printf("#####START#####");
            destroy_array_2d(&ptr, -16);
            printf("#####END#####");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji destroy_array_2d
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji destroy_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            destroy_array_2d(NULL, 13);
            printf("#####END#####");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int width = 2, height = 12;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                if (!0)
                {
                    test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                    printf("#####START#####");
                    destroy_array_2d(&ptr, height);
                    printf("#####END#####");
                    
                    test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int width = 20, height = 3;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                if (!0)
                {
                    test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                    printf("#####START#####");
                    destroy_array_2d(&ptr, height);
                    printf("#####END#####");
                    
                    test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int width = 596, height = 979;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                if (!0)
                {
                    test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                    printf("#####START#####");
                    destroy_array_2d(&ptr, height);
                    printf("#####END#####");
                    
                    test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int width = 0, height = 20;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja create_array_2d() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                if (!1)
                {
                    test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                    printf("#####START#####");
                    destroy_array_2d(&ptr, height);
                    printf("#####END#####");
                    
                    test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int width = 3, height = 0;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja create_array_2d() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                if (!1)
                {
                    test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                    printf("#####START#####");
                    destroy_array_2d(&ptr, height);
                    printf("#####END#####");
                    
                    test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int width = 10, height = -11;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja create_array_2d() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                if (!1)
                {
                    test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                    printf("#####START#####");
                    destroy_array_2d(&ptr, height);
                    printf("#####END#####");
                    
                    test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int width = -7, height = 15;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja create_array_2d() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                if (!1)
                {
                    test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                    printf("#####START#####");
                    destroy_array_2d(&ptr, height);
                    printf("#####END#####");
                    
                    test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int width = -1, height = -14;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja create_array_2d() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                if (!1)
                {
                    test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                    printf("#####START#####");
                    destroy_array_2d(&ptr, height);
                    printf("#####END#####");
                    
                    test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int width = 0, height = 0;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja create_array_2d() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
        
                if (!1)
                {
                    test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                    printf("#####START#####");
                    destroy_array_2d(&ptr, height);
                    printf("#####END#####");
                    
                    test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 836 bajtów)
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 836 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(836);
    
    //
    // -----------
    //
    

                int width = 9, height = 19;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                    
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 616 bajtów)
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 616 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(616);
    
    //
    // -----------
    //
    

                int width = 20, height = 7;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                    
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 1360680 bajtów)
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 1360680 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1360680);
    
    //
    // -----------
    //
    

                int width = 868, height = 391;        
                int **ptr;

                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr != NULL, "Funkcja create_array_2d_2() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                    
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 0 bajtów)
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 128 bajtów)
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 128 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(128);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 136 bajtów)
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 136 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(136);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 144 bajtów)
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 144 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(144);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 152 bajtów)
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 152 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(152);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 160 bajtów)
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 160 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(160);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 168 bajtów)
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 168 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(168);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 176 bajtów)
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 176 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(176);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 184 bajtów)
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 184 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(184);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 192 bajtów)
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 192 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(192);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 200 bajtów)
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 200 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(200);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 208 bajtów)
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 208 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(208);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 216 bajtów)
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 216 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(216);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 224 bajtów)
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 224 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(224);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 232 bajtów)
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 232 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(232);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 240 bajtów)
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 240 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(240);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 248 bajtów)
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 248 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(248);
    
    //
    // -----------
    //
    

                int **ptr;
                int width = 868, height = 391;        
                
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja create_array_2d() powinna zwrócić 2");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int width = 5, height = 13;        

            printf("#####START#####");
            int res = create_array_2d_2(NULL, width, height);
            printf("#####END#####");

            test_error(res == 1, "Funkcja create_array_2d() powinna zwrócić 1");
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[10][6] = {
    { 6, 9, 4, 4, 7, 8},

    { 3, 8, -7, 6, -7, -4},

    { -9, 1, 0, 1, -8, 3},

    { 9, -5, -1, 8, -6, 6},

    { 9, 1, -4, 10, 2, -8},

    { 10, 3, -4, 3, -4, 5},

    { -10, -7, -2, 9, -10, -5},

    { -10, -7, -10, 0, -8, -3},

    { -1, 1, -10, 1, -5, -6},

    { 6, 5, -1, -5, 9, 10}};

                int width = 6, height = 10;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, 6, 10);
                printf("#####END#####");

                test_error(sum == 0, "Funkcja sum_array_2d() powinna zwrócić 0, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[16][9] = {
    { -1, -1, -6, -8, -1, -6, -7, -10, -7},

    { -1, 1, -7, -7, 10, -4, 4, -5, -10},

    { -1, 8, 0, 1, -4, 3, -5, -3, 3},

    { -8, -4, -5, -1, 10, 5, -9, -10, -1},

    { 8, 10, 9, -10, -1, -4, 10, 5, -9},

    { -2, -5, 2, -10, 5, -8, -8, 9, 4},

    { 5, -3, -9, 8, 4, 4, 5, -5, 1},

    { 7, -2, 10, 0, -1, -2, 8, 9, -4},

    { 5, 4, -9, -6, -1, -5, -6, -5, -5},

    { 3, 3, -6, 6, 0, 3, -10, -3, 2},

    { 9, 2, -6, -2, 10, 8, -4, 5, -10},

    { -5, -5, 9, 5, -7, 2, -5, -1, 6},

    { 2, -2, -2, 10, -9, 0, 3, -2, -8},

    { 3, -9, -8, 8, -2, 0, -10, -7, -10},

    { -1, -7, -3, -4, 8, 6, 4, 1, 6},

    { 10, 8, -2, -10, -2, 1, -7, 1, 8}};

                int width = 9, height = 16;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, 9, 16);
                printf("#####END#####");

                test_error(sum == -92, "Funkcja sum_array_2d() powinna zwrócić -92, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[19][1] = {
    { 7},

    { 4},

    { -3},

    { -9},

    { -7},

    { 6},

    { -6},

    { 10},

    { -9},

    { 9},

    { 2},

    { 0},

    { -4},

    { -3},

    { -1},

    { 3},

    { 5},

    { 0},

    { -8}};

                int width = 1, height = 19;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, 1, 19);
                printf("#####END#####");

                test_error(sum == -4, "Funkcja sum_array_2d() powinna zwrócić -4, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[1][5] = {
    { -3, -3, 8, 4, -2}};

                int width = 5, height = 1;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, 5, 1);
                printf("#####END#####");

                test_error(sum == 4, "Funkcja sum_array_2d() powinna zwrócić 4, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[1][1] = {
    { -3}};

                int width = 1, height = 1;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, 1, 1);
                printf("#####END#####");

                test_error(sum == -3, "Funkcja sum_array_2d() powinna zwrócić -3, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[15][7] = {
    { 2, -9, 4, -2, -1, -4, 0},

    { 4, -9, -7, 10, -5, -10, 0},

    { 0, 4, -3, -10, 5, 10, 8},

    { -10, -2, -4, 1, 1, -7, -8},

    { -3, -2, 1, 4, -6, 3, -4},

    { -3, 5, 8, 6, 0, 5, 1},

    { -5, -3, 10, 6, 1, 9, -10},

    { 3, 8, -10, -8, 8, -3, -9},

    { -7, -7, -9, -3, -8, 3, 7},

    { 9, 4, -2, 3, -3, -1, 2},

    { -5, 9, -2, -1, -1, 6, 6},

    { 7, -4, -6, -8, 0, 5, -7},

    { 6, -6, -3, -9, 5, 3, 5},

    { -1, -8, -5, 5, 10, -10, 8},

    { 10, 2, 8, 0, -9, 8, -9}};

                int width = 7, height = 15;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, 7, -15);
                printf("#####END#####");

                test_error(sum == -1, "Funkcja sum_array_2d() powinna zwrócić -1, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[15][7] = {
    { 6, -7, -8, 5, 7, 0, 2},

    { -8, 4, 0, -8, 1, 3, 6},

    { 3, -6, 2, 9, 10, 1, 10},

    { 6, -7, 3, 0, -1, 9, 5},

    { -3, -6, 7, -10, 6, -7, -7},

    { -3, 3, 5, 8, -5, 9, 9},

    { 0, -5, -8, 5, 5, 2, 8},

    { -8, 2, -7, 7, -10, -7, -9},

    { 8, -4, 1, -6, 0, 1, -5},

    { 5, -1, 6, -3, -4, 5, -3},

    { -7, 10, 2, 8, -7, -9, 6},

    { 5, -5, -9, 9, -10, -6, -6},

    { 1, 2, -4, -8, 6, 0, 8},

    { 4, 8, -10, 4, -1, 2, -6},

    { -3, 2, 4, 8, -5, 0, 0}};

                int width = 7, height = 15;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, -7, -15);
                printf("#####END#####");

                test_error(sum == -1, "Funkcja sum_array_2d() powinna zwrócić -1, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[15][7] = {
    { -2, -5, 5, 6, 5, -10, -8},

    { 1, 10, 5, -5, -9, -10, -4},

    { 3, 1, 0, 10, -10, -9, 2},

    { -9, 4, 9, 9, 7, 5, 3},

    { 10, -5, 9, 2, -4, -7, 1},

    { -2, 10, 9, 8, -5, -4, 2},

    { 4, 3, 8, -2, -9, 0, 5},

    { -7, 8, -1, 1, 5, 8, -1},

    { 6, -1, 5, -3, 4, -8, -3},

    { 3, -10, -7, -10, 6, -7, 6},

    { 3, -9, -8, 7, -7, -10, 7},

    { 3, 5, 8, 4, 9, -3, 10},

    { 8, -2, -6, 1, 7, 9, 8},

    { -10, -5, -2, 5, -10, 0, 4},

    { 2, 9, -9, 9, 10, 5, 4}};

                int width = 7, height = 15;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, -7, 15);
                printf("#####END#####");

                test_error(sum == -1, "Funkcja sum_array_2d() powinna zwrócić -1, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[1][7] = {
    { -2}};

                int width = 7, height = 1;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, 7, 0);
                printf("#####END#####");

                test_error(sum == -1, "Funkcja sum_array_2d() powinna zwrócić -1, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[15][1] = {
    { 2}};

                int width = 1, height = 15;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, 0, 15);
                printf("#####END#####");

                test_error(sum == -1, "Funkcja sum_array_2d() powinna zwrócić -1, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int array[1][1] = {
    { 8}};

                int width = 1, height = 1;        
                int **ptr;
        
                printf("#####START#####");
                int res = create_array_2d_2(&ptr, width, height);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
                test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                for (int i = 0; i < height; ++i)
                    for (int j = 0; j < width; ++j)
                        ptr[i][j] = array[i][j];

                printf("#####START#####");                            
                int sum = sum_array_2d(ptr, 0, 0);
                printf("#####END#####");

                test_error(sum == -1, "Funkcja sum_array_2d() powinna zwrócić -1, a zwróciła %d", sum);

                printf("#####START#####");
                destroy_array_2d(&ptr, height);
                printf("#####END#####");
                
                test_error(ptr == NULL, "Funkcja destroy_array_2d() powinna przypisać pod ptr NULL");
                                
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");                            
            int sum = sum_array_2d(NULL, 7, 7);
            printf("#####END#####");

            test_error(sum == -1, "Funkcja sum_array_2d() powinna zwrócić -1, a zwróciła %d", sum);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie poprawności działania funkcji sum_row
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie poprawności działania funkcji sum_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int input_array[] = {-10, 0, -1, -1, 0, -2, -6, -3, -7, -2, -2, -1};

                printf("#####START#####");
                int res = sum_row(input_array, 12);           
                printf("#####END#####");

                test_error(res == -35, "Funkcja sum_row() powinna zwrócić wartość -35; a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie poprawności działania funkcji sum_row
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie poprawności działania funkcji sum_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int input_array[] = {4, 2, 9, 8, 3, 6, 9, 0, 0, 1, 5, 0, 8};

                printf("#####START#####");
                int res = sum_row(input_array, 13);           
                printf("#####END#####");

                test_error(res == 55, "Funkcja sum_row() powinna zwrócić wartość 55; a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie poprawności działania funkcji sum_row
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie poprawności działania funkcji sum_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int input_array[] = {5, -9, 5, -8, -9, 6, 7, 7, -9, 0, 10, -7};

                printf("#####START#####");
                int res = sum_row(input_array, 12);           
                printf("#####END#####");

                test_error(res == -2, "Funkcja sum_row() powinna zwrócić wartość -2; a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie poprawności działania funkcji sum_row
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie poprawności działania funkcji sum_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int input_array[] = {-10};

                printf("#####START#####");
                int res = sum_row(input_array, 1);           
                printf("#####END#####");

                test_error(res == -10, "Funkcja sum_row() powinna zwrócić wartość -10; a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 50: Sprawdzanie poprawności działania funkcji sum_row
//
void UTEST50(void)
{
    // informacje o teście
    test_start(50, "Sprawdzanie poprawności działania funkcji sum_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int input_array[] = {24, 85, 18, -22, -46, -83, 96, 75, 9, 87, -43, 96, -92, -78, 39, 67, 9, -13, 71, 64, 72, -29, -1, -83, 43, -27, -76, 59, 39, 56, 53, 95, 99, -85, -69, -7, -32, -7, 48, -34, -7, 25, -39, 51, 63, -14, -19, -38, 86, -51, -42, 46, -95, 91, -20, -19, 74, -85, 22, 94, -16, -41, 33, -61, -83, 58, 77, 37, -89, 97, 41, 13, 30, -78, -67, -15, 97, 58, 25, -21, 64, -23, 17, -64, -68, 20, 70, 9, -39, -44, 73, 74, -60, -42, -26, -3, 8, 87, 14, 97, 35, -6, -72, 49, -47, -91, 84, 4, 28, -93, 70, -49, 39, -92, 47, -64, 77, -97, -25, 12, 26, -72, -49, 19, -77, -24, 18, 56, -21, 17, -24, 100, -42, -62, 49, -12, 20, 44, -97, -75, 66, -54, 49, -59, 48, -32, 97, -69, 48, -53, -16, 92, 79, 28, 19, -95, 55, -34, 36, -92, -47, 10, 48, -43, 6, -46, 99, -14, 38, 90, 92, -24, -3, 80, -100, 54, -91, 91, -30, -75, 12};

                printf("#####START#####");
                int res = sum_row(input_array, 181);           
                printf("#####END#####");

                test_error(res == 722, "Funkcja sum_row() powinna zwrócić wartość 722; a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 51: Sprawdzanie poprawności działania funkcji sum_row
//
void UTEST51(void)
{
    // informacje o teście
    test_start(51, "Sprawdzanie poprawności działania funkcji sum_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int input_array[] = {-9, -4, 4, 4, 8, -5, -1, -3, 5, -6, -4, -2, -1, -6, 5, -2, -6, -8};

                printf("#####START#####");
                int res = sum_row(input_array, -18);           
                printf("#####END#####");

                test_error(res == -1, "Funkcja sum_row() powinna zwrócić wartość -1; a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 52: Sprawdzanie poprawności działania funkcji sum_row
//
void UTEST52(void)
{
    // informacje o teście
    test_start(52, "Sprawdzanie poprawności działania funkcji sum_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int input_array[] = {-6, 0, -3, 0, 4, -5, -4, 0, 9, 9, -5, -4, 9, -8, -6};

                printf("#####START#####");
                int res = sum_row(input_array, 0);           
                printf("#####END#####");

                test_error(res == -1, "Funkcja sum_row() powinna zwrócić wartość -1; a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 53: Sprawdzanie poprawności działania funkcji sum_row
//
void UTEST53(void)
{
    // informacje o teście
    test_start(53, "Sprawdzanie poprawności działania funkcji sum_row", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            int res = sum_row(NULL, 7);           
            printf("#####END#####");

            test_error(res == -1, "Funkcja sum_row() powinna zwrócić wartość -1; a zwróciła %d", res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 54: Sprawdzanie poprawności działania funkcji create_array_2d
//
void UTEST54(void)
{
    // informacje o teście
    test_start(54, "Sprawdzanie poprawności działania funkcji create_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int **ptr;
            
            int res = create_array_2d_2(&ptr, 9, 18);
            int array[18][9] = {
    { 4, 9, -9, 5, 2, 8, 9, 3, 4},

    { 2, -5, -10, -9, 0, 6, -4, 8, -2},

    { 2, 0, -9, 0, 2, -9, 8, -7, 7},

    { 2, -6, 6, -4, 5, 9, -5, -2, 4},

    { -6, -3, 7, -3, -7, -9, -10, 5, -8},

    { 9, -4, 10, -4, -9, 0, 7, 6, 5},

    { -9, 6, -6, 3, -5, 0, 0, 1, 10},

    { -10, -10, 8, 6, -2, 5, 7, 3, 10},

    { 10, 8, -9, -5, -3, 1, 0, 4, 0},

    { -7, -10, 9, 7, 0, 7, 1, 10, -7},

    { 5, -7, -10, 8, 7, 5, 1, -8, -3},

    { 6, 7, 4, 7, 1, 9, 10, -10, 0},

    { -3, 3, -2, 6, -10, 0, 1, -2, -1},

    { -1, -8, 1, -5, 10, -10, 3, 9, -10},

    { -10, 2, 6, 10, 6, 3, -4, 0, 6},

    { -6, -9, 6, 2, 1, -6, -5, 3, 0},

    { 1, 5, -4, 8, 8, 1, -6, -7, -4},

    { -5, -7, 6, 2, -10, 8, 5, 5, 3}};

            test_error(res == 0, "Funkcja create_array_2d() powinna zwrócić 0");
            test_error(ptr != NULL, "Funkcja create_array_2d() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            for (int i = 0; i < 18; ++i)
                for (int j = 0; j < 9; ++j)
                    ptr[i][j] = array[i][j];

            printf("\n***TEST 1***\n\n");
            printf("***START***\n");
            display_array_2d(ptr, 0, 18);
            printf("***END***\n");

            printf("\n***TEST 2***\n\n");
            printf("***START***\n");
            display_array_2d(ptr, 9, 0);
            printf("***END***\n");

            printf("\n***TEST 3***\n\n");
            printf("***START***\n");
            display_array_2d(ptr, 0, 0);
            printf("***END***\n");

            printf("\n***TEST 4***\n\n");
            printf("***START***\n");
            display_array_2d(ptr, 9, -18);
            printf("***END***\n");

            printf("\n***TEST 5***\n\n");
            printf("***START***\n");
            display_array_2d(ptr, -9, 18);
            printf("***END***\n");

            printf("\n***TEST 6***\n\n");
            printf("***START***\n");
            display_array_2d(ptr, -9, -18);
            printf("***END***\n");

            printf("\n***TEST 7***\n\n");
            printf("***START***\n");
            display_array_2d(NULL, 9, 18);
            printf("***END***\n");

            printf("\n***TEST 8***\n\n");
            printf("***START***\n");
            display_array_2d(ptr, 9, 18);
            printf("***END***\n");

            destroy_array_2d(&ptr, 18);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci - limit ustawiony na 0 bajtów
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci - limit ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
            printf("***START***\n");
            int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
            printf("\n***END***\n");
            test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci - limit ustawiony na 144 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci - limit ustawiony na 144 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(144);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci - limit ustawiony na 180 bajtów
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci - limit ustawiony na 180 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(180);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na brak pamięci - limit ustawiony na 216 bajtów
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na brak pamięci - limit ustawiony na 216 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(216);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Reakcja na brak pamięci - limit ustawiony na 252 bajtów
//
void MTEST5(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(5, "Reakcja na brak pamięci - limit ustawiony na 252 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(252);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Reakcja na brak pamięci - limit ustawiony na 288 bajtów
//
void MTEST6(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(6, "Reakcja na brak pamięci - limit ustawiony na 288 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(288);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Reakcja na brak pamięci - limit ustawiony na 324 bajtów
//
void MTEST7(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(7, "Reakcja na brak pamięci - limit ustawiony na 324 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(324);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Reakcja na brak pamięci - limit ustawiony na 360 bajtów
//
void MTEST8(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(8, "Reakcja na brak pamięci - limit ustawiony na 360 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(360);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Reakcja na brak pamięci - limit ustawiony na 396 bajtów
//
void MTEST9(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(9, "Reakcja na brak pamięci - limit ustawiony na 396 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(396);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Reakcja na brak pamięci - limit ustawiony na 432 bajtów
//
void MTEST10(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(10, "Reakcja na brak pamięci - limit ustawiony na 432 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(432);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Reakcja na brak pamięci - limit ustawiony na 468 bajtów
//
void MTEST11(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(11, "Reakcja na brak pamięci - limit ustawiony na 468 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(468);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Reakcja na brak pamięci - limit ustawiony na 504 bajtów
//
void MTEST12(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(12, "Reakcja na brak pamięci - limit ustawiony na 504 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(504);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Reakcja na brak pamięci - limit ustawiony na 540 bajtów
//
void MTEST13(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(13, "Reakcja na brak pamięci - limit ustawiony na 540 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(540);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Reakcja na brak pamięci - limit ustawiony na 576 bajtów
//
void MTEST14(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(14, "Reakcja na brak pamięci - limit ustawiony na 576 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(576);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Reakcja na brak pamięci - limit ustawiony na 612 bajtów
//
void MTEST15(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(15, "Reakcja na brak pamięci - limit ustawiony na 612 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(612);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Reakcja na brak pamięci - limit ustawiony na 648 bajtów
//
void MTEST16(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(16, "Reakcja na brak pamięci - limit ustawiony na 648 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(648);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Reakcja na brak pamięci - limit ustawiony na 684 bajtów
//
void MTEST17(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(17, "Reakcja na brak pamięci - limit ustawiony na 684 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(684);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Reakcja na brak pamięci - limit ustawiony na 720 bajtów
//
void MTEST18(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(18, "Reakcja na brak pamięci - limit ustawiony na 720 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(720);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Reakcja na brak pamięci - limit ustawiony na 756 bajtów
//
void MTEST19(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(19, "Reakcja na brak pamięci - limit ustawiony na 756 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(756);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji destroy_array_2d
            UTEST2, // Sprawdzanie poprawności działania funkcji destroy_array_2d
            UTEST3, // Sprawdzanie poprawności działania funkcji destroy_array_2d
            UTEST4, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST5, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST6, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST7, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST8, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST9, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST10, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST11, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST12, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST13, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 836 bajtów)
            UTEST14, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 616 bajtów)
            UTEST15, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 1360680 bajtów)
            UTEST16, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 0 bajtów)
            UTEST17, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 128 bajtów)
            UTEST18, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 136 bajtów)
            UTEST19, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 144 bajtów)
            UTEST20, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 152 bajtów)
            UTEST21, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 160 bajtów)
            UTEST22, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 168 bajtów)
            UTEST23, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 176 bajtów)
            UTEST24, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 184 bajtów)
            UTEST25, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 192 bajtów)
            UTEST26, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 200 bajtów)
            UTEST27, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 208 bajtów)
            UTEST28, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 216 bajtów)
            UTEST29, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 224 bajtów)
            UTEST30, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 232 bajtów)
            UTEST31, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 240 bajtów)
            UTEST32, // Sprawdzanie reakcji funkcji create_array_2d na limit pamięci (limit sterty ustawiono na 248 bajtów)
            UTEST33, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST34, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST35, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST36, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST37, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST38, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST39, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST40, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST41, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST42, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST43, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST44, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST45, // Sprawdzanie poprawności działania funkcji create_array_2d
            UTEST46, // Sprawdzanie poprawności działania funkcji sum_row
            UTEST47, // Sprawdzanie poprawności działania funkcji sum_row
            UTEST48, // Sprawdzanie poprawności działania funkcji sum_row
            UTEST49, // Sprawdzanie poprawności działania funkcji sum_row
            UTEST50, // Sprawdzanie poprawności działania funkcji sum_row
            UTEST51, // Sprawdzanie poprawności działania funkcji sum_row
            UTEST52, // Sprawdzanie poprawności działania funkcji sum_row
            UTEST53, // Sprawdzanie poprawności działania funkcji sum_row
            UTEST54, // Sprawdzanie poprawności działania funkcji create_array_2d
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(54); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci - limit ustawiony na 0 bajtów
            MTEST2, // Reakcja na brak pamięci - limit ustawiony na 144 bajtów
            MTEST3, // Reakcja na brak pamięci - limit ustawiony na 180 bajtów
            MTEST4, // Reakcja na brak pamięci - limit ustawiony na 216 bajtów
            MTEST5, // Reakcja na brak pamięci - limit ustawiony na 252 bajtów
            MTEST6, // Reakcja na brak pamięci - limit ustawiony na 288 bajtów
            MTEST7, // Reakcja na brak pamięci - limit ustawiony na 324 bajtów
            MTEST8, // Reakcja na brak pamięci - limit ustawiony na 360 bajtów
            MTEST9, // Reakcja na brak pamięci - limit ustawiony na 396 bajtów
            MTEST10, // Reakcja na brak pamięci - limit ustawiony na 432 bajtów
            MTEST11, // Reakcja na brak pamięci - limit ustawiony na 468 bajtów
            MTEST12, // Reakcja na brak pamięci - limit ustawiony na 504 bajtów
            MTEST13, // Reakcja na brak pamięci - limit ustawiony na 540 bajtów
            MTEST14, // Reakcja na brak pamięci - limit ustawiony na 576 bajtów
            MTEST15, // Reakcja na brak pamięci - limit ustawiony na 612 bajtów
            MTEST16, // Reakcja na brak pamięci - limit ustawiony na 648 bajtów
            MTEST17, // Reakcja na brak pamięci - limit ustawiony na 684 bajtów
            MTEST18, // Reakcja na brak pamięci - limit ustawiony na 720 bajtów
            MTEST19, // Reakcja na brak pamięci - limit ustawiony na 756 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(19); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}