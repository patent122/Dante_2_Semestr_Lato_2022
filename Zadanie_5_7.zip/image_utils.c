#include "image_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tested_declarations.h"
#include "rdebug.h"

#define GLEBIA_MAKSYMALNA 255

struct image_t* load_image_t(const char* filename, int* err_code)
{
    if (filename == NULL)
    {
        if (err_code != NULL) *err_code = 1;
        return NULL;
    }
    FILE* plik;
    struct image_t* obraz = malloc(sizeof(struct image_t));
    if (obraz == NULL)
    {
        if (err_code != NULL) *err_code = 4;
        return NULL;
    }
    if ((plik = fopen(filename, "r")) == NULL)
    {
        free(obraz);
        if (err_code != NULL) *err_code = 2;
        return NULL;
    }
    char* kod = malloc(3 * sizeof(char));
    fscanf(plik, "%2s", kod);
    if (strcmp(kod, "P2") != 0)
    {
        if (err_code != NULL) *err_code = 3;
        free(obraz);
        free(kod);
        fclose(plik);
        return NULL;
    }
    strcpy(obraz->type, kod);
    free(kod);
    if (fscanf(plik, "%d %d", &obraz->width, &obraz->height) != 2)
    {
        if (err_code != NULL) *err_code = 3;
        free(obraz);
        fclose(plik);
        return NULL;
    }
    if (obraz->width < 1 || obraz->height < 1)
    {
        if (err_code != NULL) *err_code = 3;
        free(obraz);
        fclose(plik);
        return NULL;
    }
    int maximum;
    if (fscanf(plik, "%d", &maximum) != 1)
    {
        if (err_code != NULL) *err_code = 3;
        free(obraz);
        fclose(plik);
        return NULL;
    }
    if (maximum > 255)
    {
        if (err_code != NULL) *err_code = 3;
        free(obraz);
        fclose(plik);
        return NULL;
    }
    obraz->ptr = malloc(obraz->height * sizeof(int*));
    if (obraz->ptr == NULL)
    {
        if (err_code != NULL) *err_code = 4;
        free(obraz);
        fclose(plik);
        return NULL;
    }
    for (int i = 0; i < obraz->height; ++i)
    {
        *(obraz->ptr + i) = malloc(obraz->width * sizeof(int));
        if (*(obraz->ptr + i) == NULL)
        {
            for (int j = 0; j < i; ++j)
            {
                free(*(obraz->ptr + j));
            }
            if (err_code != NULL) *err_code = 4;
            free(obraz->ptr);
            free(obraz);
            fclose(plik);
            return NULL;
        }
    }
    for (int i = 0; i < obraz->height; ++i)
    {
        for (int j = 0; j < obraz->width; ++j)
        {
            if (fscanf(plik, "%d", *(obraz->ptr + i) + j) != 1)
            {
                if (err_code != NULL) *err_code = 3;
                for (int k = 0; k < obraz->height; ++k)
                {
                    free(*(obraz->ptr + k));
                }
                free(obraz->ptr);
                free(obraz);
                fclose(plik);
                return NULL;
            }
            if (*(*(obraz->ptr + i) + j) < 0)
            {
                if (err_code != NULL) *err_code = 3;
                for (int k = 0; k < obraz->height; ++k)
                {
                    free(*(obraz->ptr + k));
                }
                free(obraz->ptr);
                free(obraz);
                fclose(plik);
                return NULL;
            }
        }
    }
    fclose(plik);
    if (err_code != NULL) *err_code = 0;
    return obraz;
}

int save_image_t(const char* filename, const struct image_t* m1)
{
    if (filename == NULL || m1 == NULL || m1->width < 1 || m1->height < 1 || m1->ptr == NULL)
    {
        return 1;
    }

    FILE* plik;
    int wysokosc, szerokosc;

    if ((plik = fopen(filename, "w")) == NULL)
    {
        return 2;
    }
    wysokosc = m1->height;
    szerokosc = m1->width;
    fprintf(plik, "%s\n", m1->type);
    fprintf(plik, "%d %d\n", m1->width, m1->height);
    fprintf(plik, "%d\n", GLEBIA_MAKSYMALNA);
    for (int i = 0; i < wysokosc; ++i)
    {
        for (int j = 0; j < szerokosc; ++j)
        {
            if (fprintf(plik, "%d ", *(*(m1->ptr + i) + j)) < 0)
            {
                fclose(plik);
                return 3;
            }
        }
        if (fprintf(plik, "\n") < 0)
        {
            fclose(plik);
            return 3;
        }
    }
    fclose(plik);
    return 0;
}

void destroy_image(struct image_t** m)
{
    if (*m == NULL || (*m)->ptr == NULL || (*m)->height < 1)
    {
        return;
    }
    for (int i = 0; i < (*m)->height; ++i)
    {
        free(*((*m)->ptr + i));
    }
    free((*m)->ptr);
    free(*m);
    *m = NULL;
}

struct image_t* image_flip_horizontal(const struct image_t* m1)
{
    if (m1 == NULL || m1->ptr == NULL || m1->width < 1 || m1->height < 1)
    {
        return NULL;
    }
    struct image_t* obraz = malloc(sizeof(struct image_t));
    if (obraz == NULL)
    {
        return NULL;
    }
    obraz->height = m1->height;
    obraz->width = m1->width;
    strcpy(obraz->type, m1->type);
    obraz->ptr = malloc(obraz->height * sizeof(int*));
    if (obraz->ptr == NULL)
    {
        free(obraz);
        return NULL;
    }
    for (int i = 0; i < obraz->height; ++i)
    {
        *(obraz->ptr + i) = malloc(obraz->width * sizeof(int));
        if (*(obraz->ptr + i) == NULL)
        {
            for (int j = 0; j < i; ++j)
            {
                free(*(obraz->ptr + j));
            }
            free(obraz->ptr);
            free(obraz);
            return NULL;
        }
    }
    for (int i = 0; i < m1->height; ++i)
    {
        for (int j = 0; j < m1->width; ++j)
        {
            *(*(obraz->ptr + i) + j) = *(*(m1->ptr + m1->height - i - 1) + j);
        }
    }
    return obraz;
}

struct image_t* image_flip_vertical(const struct image_t* m1)
{
    if (m1 == NULL || m1->ptr == NULL || m1->width < 1 || m1->height < 1)
    {
        return NULL;
    }
    struct image_t* obraz = malloc(sizeof(struct image_t));
    if (obraz == NULL)
    {
        return NULL;
    }
    obraz->height = m1->height;
    obraz->width = m1->width;
    strcpy(obraz->type, m1->type);
    obraz->ptr = malloc(obraz->height * sizeof(int*));
    if (obraz->ptr == NULL)
    {
        free(obraz);
        return NULL;
    }
    for (int i = 0; i < obraz->height; ++i)
    {
        *(obraz->ptr + i) = malloc(obraz->width * sizeof(int));
        if (*(obraz->ptr + i) == NULL)
        {
            for (int j = 0; j < i; ++j)
            {
                free(*(obraz->ptr + j));
            }
            free(obraz->ptr);
            free(obraz);
            return NULL;
        }
    }
    for (int i = 0; i < m1->height; ++i)
    {
        for (int j = 0; j < m1->width; ++j)
        {
            *(*(obraz->ptr + i) + j) = *(*(m1->ptr + i) + m1->width - j - 1);
        }
    }
    return obraz;
}

struct image_t* image_negate(const struct image_t* m1)
{
    if (m1 == NULL || m1->ptr == NULL || m1->width < 1 || m1->height < 1)
    {
        return NULL;
    }
    struct image_t* obraz = malloc(sizeof(struct image_t));
    if (obraz == NULL)
    {
        return NULL;
    }
    obraz->height = m1->height;
    obraz->width = m1->width;
    strcpy(obraz->type, m1->type);
    obraz->ptr = malloc(obraz->height * sizeof(int*));
    if (obraz->ptr == NULL)
    {
        free(obraz);
        return NULL;
    }
    for (int i = 0; i < obraz->height; ++i)
    {
        *(obraz->ptr + i) = malloc(obraz->width * sizeof(int));
        if (*(obraz->ptr + i) == NULL)
        {
            for (int j = 0; j < i; ++j)
            {
                free(*(obraz->ptr + j));
            }
            free(obraz->ptr);
            free(obraz);
            return NULL;
        }
    }
    for (int i = 0; i < m1->height; ++i)
    {
        for (int j = 0; j < m1->width; ++j)
        {
            *(*(obraz->ptr + i) + j) = GLEBIA_MAKSYMALNA - *(*(m1->ptr + i) + j);
        }
    }
    return obraz;
}

const int* image_get_pixel(const struct image_t* obraz, int x, int y)
{
    if (obraz == NULL || obraz->ptr == NULL || obraz->width < 1 || obraz->height < 1 ||
        x < 0 || y < 0 || x > obraz->width - 1 || y > obraz->height - 1)
    {
        return NULL;
    }
    return *(obraz->ptr + y) + x;
}

int* image_set_pixel(struct image_t* obraz, int x, int y)
{
    if (obraz == NULL ||
        obraz->ptr == NULL ||
        obraz->width < 1 ||
        obraz->height < 1 ||
        x < 0 ||
        y < 0 ||
        x > obraz->width - 1 ||
        y > obraz->height - 1)
    {
        return NULL;
    }
    return *(obraz->ptr + y) + x;
}

int image_draw_rectangle(struct image_t* obraz, const struct rectangle_t* prostokat, int value)
{
    if (obraz == NULL ||
        obraz->ptr == NULL ||
        obraz->height < 1 ||
        obraz->width < 1 ||
        prostokat == NULL ||
        prostokat->width < 1 ||
        prostokat->height < 1 ||
        value < 0 ||
        value > GLEBIA_MAKSYMALNA)
    {
        return 1;
    }
    if (prostokat->p.x + prostokat->width > obraz->width ||
        prostokat->p.y + prostokat->height > obraz->height ||
        prostokat->p.x >= obraz->width ||
        prostokat->p.x < 0 ||
        prostokat->p.y >= obraz->height ||
        prostokat->p.y < 0)
    {
        return 1;
    }
    for (int i = 0; i < prostokat->width; ++i)
    {
        int* pixel = image_set_pixel(obraz, prostokat->p.x + i, prostokat->p.y);

        if (pixel != NULL)
            *pixel = value;
    }

    for (int i = 0; i < prostokat->width; ++i)
    {
        int* pixel = image_set_pixel(
            obraz, prostokat->p.x + i, prostokat->p.y + prostokat->height - 1);

        if (pixel != NULL)
        {
            *pixel = value;
        }
    }
    for (int i = 0; i < prostokat->height; ++i)
    {
        int* pixel = image_set_pixel(obraz, prostokat->p.x, prostokat->p.y + i);

        if (pixel != NULL)
        {
            *pixel = value;
        }
    }
    for (int i = 0; i < prostokat->height; ++i)
    {
        int* pixel = image_set_pixel(
            obraz, prostokat->p.x + prostokat->width - 1, prostokat->p.y + i);

        if (pixel != NULL)
        {
            *pixel = value;
        }
    }

    return 0;
}

int draw_image(struct image_t* cel, const struct image_t* zrodlo, int x, int y)
{
    if (cel == NULL || cel->ptr == NULL || zrodlo == NULL || zrodlo->ptr == NULL || x < 0 || y < 0 ||
        cel->width < 1 || cel->height < 1 || zrodlo->width < 1 || zrodlo->height < 1)
    {
        return 1;
    }    
    if (x + zrodlo->width > cel->width || y + zrodlo->height > cel->height)
    {
        return 1;
    }
    for (int i = 0; i < zrodlo->height; ++i)
    {
        for (int j = 0; j < zrodlo->width; ++j)
        {
            int* pixel_cel = image_set_pixel(cel, x + j, y + i);

            if (pixel_cel != NULL)
            {
                const int* pixel_zrodlo = image_get_pixel(zrodlo, j, i);

                if (*pixel_zrodlo < 0)
                {
                    return 1;
                }
                *pixel_cel = *pixel_zrodlo;
            }
        }
    }

    return 0;
}

