#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "image_utils.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
    int bload;
    int rezultat;
    char* sciezka = malloc(40 * sizeof(char));
    if (sciezka == NULL)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }
    printf("Enter destination image file name: ");
    scanf("%39s", sciezka);
    while (getchar() != '\n')
    {
    }
    struct image_t* obraz = load_image_t(sciezka, &bload);
    if (bload == 2)
    {
        free(sciezka);
        printf("Couldn't open file\n");
        return 4;
    }
    if (bload == 3)
    {
        free(sciezka);
        printf("File corrupted\n");
        return 6;
    }
    if (bload == 4)
    {
        free(sciezka);
        printf("Failed to allocate memory\n");
        return 8;
    }
    printf("How many subimages you want to draw: ");
    if (scanf("%d", &rezultat) != 1)
    {
        printf("Incorrect input\n");
        free(sciezka);
        destroy_image(&obraz);
        return 1;
    }
    if (rezultat < 1)
    {
        printf("Incorrect input data\n");
        free(sciezka);
        destroy_image(&obraz);
        return 2;
    }
    for (int i = 0; i < rezultat; ++i)
    {
        char* sciezka2 = malloc(40 * sizeof(char));
        if (sciezka2 == NULL)
        {
            printf("Failed to allocate memory\n");
            free(sciezka);
            destroy_image(&obraz);
            return 8;
        }

        printf("Enter a name of a subimage: ");
        scanf("%39s", sciezka2);
        struct image_t* obraz2 = load_image_t(sciezka2, &bload);
        if (bload == 2)
        {
            free(sciezka2);
            printf("Couldn't open file\n");
            continue;
        }
        if (bload == 3)
        {
            free(sciezka2);
            printf("File corrupted\n");
            continue;
        }
        if (bload == 4)
        {
            free(sciezka);
            free(sciezka2);
            destroy_image(&obraz);
            printf("Failed to allocate memory\n");
            return 8;
        }

        int px, py;
        printf("Enter coordinates (x, y): ");
        if (scanf("%d %d", &px, &py) != 2)
        {
            free(sciezka);
            free(sciezka2);
            destroy_image(&obraz2);
            destroy_image(&obraz);
            printf("Incorrect input\n");
            return 1;
        }
        if (px < 0
            || py < 0
            || px + obraz2->width - 1 > obraz->width
            || py + obraz2->height - 1 > obraz->height)
        {
            printf("Incorrect input data\n");
            free(sciezka2);
            destroy_image(&obraz2);
            continue;
        }
        draw_image(obraz, obraz2, px, py);
        free(sciezka2);
        destroy_image(&obraz2);
    }
    char* sciezka3 = malloc(40 + 9 * sizeof(char));
    int ile = 0;
    for (int i = 0; i < (int)strlen(sciezka); ++i)
    {
        if (*(sciezka + i) == 46) ile++;
    }
    char* bufor = strtok(sciezka, ".");
    int flaga = 0;
    while (bufor != NULL)
    {
        if (flaga == 0)
        {
            strcpy(sciezka3, bufor);
            flaga++;
            bufor = strtok(NULL, ".");
            continue;
        }
        if (flaga == ile)
        {
            strcat(sciezka3, "_modified");
            strcat(sciezka3, ".");
            strcat(sciezka3, bufor);
            bufor = strtok(NULL, ".");
            continue;
        }
        strcat(sciezka3, ".");
        strcat(sciezka3, bufor);
        bufor = strtok(NULL, ".");
        flaga++;
    }
    bload = save_image_t(sciezka3, obraz);
    if (bload == 0)
    {
        free(sciezka);
        free(sciezka3);
        destroy_image(&obraz);
        printf("File saved\n");
    }
    else
    {
        free(sciezka);
        free(sciezka3);
        destroy_image(&obraz);
        printf("Couldn't create file");
        return 5;
    }
    return 0;
}
