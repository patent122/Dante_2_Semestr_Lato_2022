/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Obraz w obrazie
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-17 16:01:04.653863
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][6] = {{ 5, 8, 8, -3, 3, 9}, { -1, -8, -6, 5, -1, 2}, { 9, 8, -44, 2, 3, -7}, { -5, -3, -3, -8, 6, 7}, { -3, 5, -7, 5, 10, 6}, { 1, 4, 1, 3, 4, 4}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("well.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                        test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 6; ++i)
                            for (int j = 0; j < 6; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[20][6] = {{ -3, -6, -4, -9, 9, 0}, { 7, -1, -8, -8, -1, -1}, { -6, 3, -44, 7, -2, -6}, { -9, -9, -10, 6, 1, 8}, { -10, 0, 3, -2, 2, 4}, { 10, 10, 1, 8, 9, -8}, { 6, -10, -1, -5, -3, -6}, { 1, 3, -1, 10, -2, 3}, { 10, -3, 4, 7, 4, -6}, { -8, -3, 1, -4, 9, -10}, { 0, 5, -5, -1, 10, 2}, { 1, 6, -10, 3, 10, -7}, { 4, -4, -4, -2, -10, 6}, { 10, 10, 3, -3, 1, -3}, { -6, -5, -2, -8, -10, -6}, { -10, -1, -1, -6, 9, 0}, { 6, -6, -9, 10, -10, 6}, { 8, 6, -7, -6, 4, -1}, { -1, 6, 6, -3, -9, -6}, { 2, 4, -10, -8, 8, -8}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("simple.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                        test_error(arr->height == 20, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 20, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 20; ++i)
                            for (int j = 0; j < 6; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][1] = {{ 3}, { 10}, { 8}, { 7}, { 0}, { 3}, { 9}, { 3}, { 1}, { 6}, { 10}, { 5}, { 9}, { 5}, { 4}, { 0}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("at.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][6] = {{ 2, 10, 1, 1, 8, 7}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("string.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 6; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 1}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("example.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("found.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("go.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("collect.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("here.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("state.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("unit.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("listen.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("cent.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("about.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("syllable.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bell.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 3, "Funkcja load_image_t() powinna zwrócić kod błędu 3, a zwróciła %d", err_code);
                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("soldier.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 2, "Funkcja load_image_t() powinna zwrócić kod błędu 2, a zwróciła %d", err_code);
                    if (!2)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][6] = {{ 5, 8, 8, -3, 3, 9}, { -1, -8, -6, 5, -1, 2}, { 9, 8, -44, 2, 3, -7}, { -5, -3, -3, -8, 6, 7}, { -3, 5, -7, 5, 10, 6}, { 1, 4, 1, 3, 4, 4}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("well.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                        test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 6; ++i)
                            for (int j = 0; j < 6; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[20][6] = {{ -3, -6, -4, -9, 9, 0}, { 7, -1, -8, -8, -1, -1}, { -6, 3, -44, 7, -2, -6}, { -9, -9, -10, 6, 1, 8}, { -10, 0, 3, -2, 2, 4}, { 10, 10, 1, 8, 9, -8}, { 6, -10, -1, -5, -3, -6}, { 1, 3, -1, 10, -2, 3}, { 10, -3, 4, 7, 4, -6}, { -8, -3, 1, -4, 9, -10}, { 0, 5, -5, -1, 10, 2}, { 1, 6, -10, 3, 10, -7}, { 4, -4, -4, -2, -10, 6}, { 10, 10, 3, -3, 1, -3}, { -6, -5, -2, -8, -10, -6}, { -10, -1, -1, -6, 9, 0}, { 6, -6, -9, 10, -10, 6}, { 8, 6, -7, -6, 4, -1}, { -1, 6, 6, -3, -9, -6}, { 2, 4, -10, -8, 8, -8}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("simple.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                        test_error(arr->height == 20, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 20, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 20; ++i)
                            for (int j = 0; j < 6; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][1] = {{ 3}, { 10}, { 8}, { 7}, { 0}, { 3}, { 9}, { 3}, { 1}, { 6}, { 10}, { 5}, { 9}, { 5}, { 4}, { 0}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("at.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][6] = {{ 2, 10, 1, 1, 8, 7}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("string.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 6; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 1}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("example.txt", NULL);
                    printf("#####END#####");

                    if (!0)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                        test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 1; ++i)
                            for (int j = 0; j < 1; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("found.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("go.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("collect.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("here.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("state.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("unit.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("listen.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("cent.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("about.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("syllable.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bell.txt", NULL);
                    printf("#####END#####");

                    if (!3)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[9][9] = {{ 6, 7, 10, 9, 5, 3, 5, 2, 8}, { 4, 7, 8, 4, 7, 3, 9, 8, 2}, { 2, 0, 6, 5, 5, 9, 4, 0, 2}, { 5, 8, 9, 6, 1, 8, 10, 5, 9}, { 3, 1, 6, 7, 4, 7, 10, 2, 8}, { 8, 2, 7, 5, 1, 1, 6, 6, 7}, { 5, 0, 2, 5, 3, 3, 8, 0, 6}, { 8, 4, 1, 8, 3, 2, 2, 6, 6}, { 7, 3, 4, 10, 1, 9, 4, 5, 9}};

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("soldier.txt", NULL);
                    printf("#####END#####");

                    if (!2)
                    {
                        test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                        test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                        test_error(arr->height == 9, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 9, a ustawiła na %d", arr->height);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        for (int i = 0; i < 9; ++i)
                            for (int j = 0; j < 9; ++j)
                                test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


                        printf("#####START#####");
                        destroy_image(&arr);
                        printf("#####END#####");

                        test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");
                    }
                    else
                        test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 147 bajtów)
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 147 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(147);
    
    //
    // -----------
    //
    

            int array[3][8] = {{ 10, 6, 6, 8, 10, 9, 2, 6}, { 9, 5, 2, 1, 9, 5, 0, 4}, { 0, 4, 2, 2, 9, 1, 0, 4}};

            printf("#####START#####");                            
            struct image_t *arr = load_image_t("bit.bin", NULL);
            printf("#####END#####");

            test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
            test_error(arr->width == 8, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr->width);
            test_error(arr->height == 3, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 3, a ustawiła na %d", arr->height);

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 8; ++j)
                    test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);


            printf("#####START#####");
            destroy_image(&arr);
            printf("#####END#####");

            test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(27);
    
    //
    // -----------
    //
    

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(51);
    
    //
    // -----------
    //
    

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(83);
    
    //
    // -----------
    //
    

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(115);
    
    //
    // -----------
    //
    

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 4, "Funkcja load_image_t() powinna zwrócić kod błędu 4, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(27);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(51);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(83);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(115);
    
    //
    // -----------
    //
    


                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("bit.bin", NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t(NULL, &err_code);
                    printf("#####END#####");

                    test_error(err_code == 1, "Funkcja load_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", err_code);
                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie poprawności działania funkcji load_image_t
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie poprawności działania funkcji load_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t(NULL, NULL);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja load_image_t() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 50: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST50(void)
{
    // informacje o teście
    test_start(50, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[7][10] = {{ 40, 82, 64, 93, 54, 73, 88, 11, 75, 43}, { 39, 84, 96, 94, 14, 86, 56, 97, 21, 73}, { 26, 19, 70, 96, 98, 16, 95, 15, 50, 81}, { 97, 42, 25, 20, 3, 36, 76, 33, 41, 12}, { 59, 64, 18, 15, 89, 17, 87, 29, 79, 99}, { 100, 46, 39, 1, 100, 54, 35, 4, 62, 40}, { 70, 78, 76, 9, 42, 9, 98, 57, 12, 24}};
                    int small_array[7][10] = {{ 100, 23, 69, 68, 85, 87, 87, 9, 57, 48}, { 5, 17, 16, 45, 73, 46, 58, 7, 82, 67}, { 24, 99, 88, 89, 10, 6, 80, 88, 89, 53}, { 23, 16, 37, 9, 76, 19, 22, 84, 61, 54}, { 7, 75, 34, 5, 45, 68, 88, 7, 38, 31}, { 63, 48, 98, 49, 45, 27, 100, 44, 50, 64}, { 65, 67, 67, 97, 22, 95, 32, 77, 26, 1}};
                    
                    int array_draw_rectangle[7][10] = {{ 100, 23, 69, 68, 85, 87, 87, 9, 57, 48}, { 5, 17, 16, 45, 73, 46, 58, 7, 82, 67}, { 24, 99, 88, 89, 10, 6, 80, 88, 89, 53}, { 23, 16, 37, 9, 76, 19, 22, 84, 61, 54}, { 7, 75, 34, 5, 45, 68, 88, 7, 38, 31}, { 63, 48, 98, 49, 45, 27, 100, 44, 50, 64}, { 65, 67, 67, 97, 22, 95, 32, 77, 26, 1}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("moon.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", arr->width);
                    test_error(arr->height == 7, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 7, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 7; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("more.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 10, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 10, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 7, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 7, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 7; ++i)
                        for (int j = 0; j < 10; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 10;
                    small_arr->height = 7;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 10;
                    small_arr->height = 7;   

                    if (!0)
                    {
                        for (int i = 0; i < 7; ++i)
                            for (int j = 0; j < 10; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 51: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST51(void)
{
    // informacje o teście
    test_start(51, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][7] = {{ 58, 81, 18, 73, 25, 51, 23}, { 29, 3, 25, 18, 78, 82, 68}, { 11, 96, 10, 5, 14, 35, 80}, { 9, 65, 62, 99, 89, 71, 100}, { 7, 52, 77, 99, 66, 63, 43}, { 55, 70, 40, 93, 90, 58, 49}, { 85, 78, 43, 70, 49, 8, 11}, { 56, 87, 82, 85, 58, 50, 47}, { 22, 34, 30, 71, 22, 63, 55}, { 30, 27, 23, 56, 53, 47, 27}, { 28, 73, 34, 50, 13, 9, 5}, { 78, 14, 79, 49, 13, 53, 90}, { 94, 92, 51, 30, 90, 36, 24}, { 40, 75, 1, 99, 21, 7, 27}, { 20, 46, 27, 72, 12, 43, 40}, { 99, 89, 88, 56, 92, 95, 10}};
                    int small_array[16][7] = {{ 32, 23, 41, 22, 67, 59, 16}, { 98, 6, 62, 37, 40, 34, 7}, { 17, 80, 96, 97, 54, 41, 78}, { 1, 68, 17, 33, 94, 39, 44}, { 28, 66, 29, 3, 47, 54, 62}, { 68, 5, 99, 19, 4, 1, 52}, { 16, 9, 25, 82, 7, 85, 16}, { 42, 15, 80, 79, 13, 94, 13}, { 13, 39, 80, 20, 57, 30, 50}, { 53, 31, 93, 67, 9, 81, 40}, { 28, 40, 81, 96, 1, 56, 58}, { 60, 70, 21, 41, 22, 73, 71}, { 56, 84, 33, 1, 92, 94, 13}, { 70, 88, 54, 67, 81, 80, 93}, { 52, 73, 63, 34, 95, 14, 82}, { 44, 60, 82, 34, 27, 66, 80}};
                    
                    int array_draw_rectangle[16][7] = {{ 32, 23, 41, 22, 67, 59, 16}, { 98, 6, 62, 37, 40, 34, 7}, { 17, 80, 96, 97, 54, 41, 78}, { 1, 68, 17, 33, 94, 39, 44}, { 28, 66, 29, 3, 47, 54, 62}, { 68, 5, 99, 19, 4, 1, 52}, { 16, 9, 25, 82, 7, 85, 16}, { 42, 15, 80, 79, 13, 94, 13}, { 13, 39, 80, 20, 57, 30, 50}, { 53, 31, 93, 67, 9, 81, 40}, { 28, 40, 81, 96, 1, 56, 58}, { 60, 70, 21, 41, 22, 73, 71}, { 56, 84, 33, 1, 92, 94, 13}, { 70, 88, 54, 67, 81, 80, 93}, { 52, 73, 63, 34, 95, 14, 82}, { 44, 60, 82, 34, 27, 66, 80}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("it.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("twenty.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 7;
                    small_arr->height = 16;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 7;
                    small_arr->height = 16;   

                    if (!0)
                    {
                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 7; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 52: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST52(void)
{
    // informacje o teście
    test_start(52, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[59][47] = {{ 32, 55, 97, 48, 95, 92, 15, 80, 95, 85, 27, 62, 50, 21, 83, 99, 71, 27, 99, 38, 53, 60, 31, 3, 15, 62, 27, 12, 42, 50, 19, 18, 18, 56, 35, 56, 95, 52, 85, 15, 10, 63, 98, 24, 10, 100, 2}, { 1, 87, 43, 45, 58, 15, 89, 90, 82, 96, 37, 7, 85, 21, 59, 53, 29, 17, 69, 65, 29, 90, 65, 39, 82, 53, 94, 62, 42, 52, 52, 73, 8, 96, 12, 56, 2, 1, 31, 84, 66, 84, 66, 78, 11, 58, 75}, { 14, 85, 18, 95, 7, 82, 1, 80, 66, 24, 16, 20, 83, 41, 27, 25, 69, 48, 57, 90, 15, 33, 100, 47, 17, 84, 7, 7, 67, 69, 41, 22, 88, 96, 94, 40, 80, 42, 99, 75, 63, 51, 25, 10, 87, 69, 58}, { 46, 51, 52, 76, 28, 89, 54, 14, 63, 27, 7, 42, 6, 33, 19, 29, 44, 81, 48, 18, 89, 64, 86, 89, 89, 38, 17, 40, 25, 66, 24, 17, 91, 96, 86, 4, 63, 31, 33, 80, 41, 83, 7, 60, 27, 56, 16}, { 27, 76, 11, 21, 14, 1, 32, 6, 52, 58, 54, 54, 88, 55, 27, 64, 4, 20, 67, 67, 91, 62, 33, 27, 16, 7, 16, 16, 60, 71, 43, 21, 40, 28, 9, 73, 2, 4, 90, 57, 81, 14, 88, 30, 3, 4, 4}, { 6, 92, 32, 13, 78, 77, 59, 6, 6, 1, 9, 89, 8, 83, 26, 20, 52, 62, 69, 46, 95, 31, 3, 52, 89, 36, 2, 85, 90, 40, 53, 67, 70, 10, 1, 22, 100, 49, 54, 62, 22, 71, 15, 33, 45, 59, 22}, { 22, 74, 83, 92, 9, 23, 99, 91, 80, 62, 24, 82, 21, 87, 14, 6, 91, 83, 54, 45, 24, 35, 85, 65, 27, 94, 71, 12, 27, 2, 49, 79, 70, 65, 5, 86, 36, 78, 65, 53, 63, 39, 68, 74, 44, 100, 7}, { 29, 23, 2, 71, 2, 84, 56, 20, 5, 16, 92, 65, 21, 27, 73, 37, 69, 20, 25, 61, 38, 2, 91, 57, 7, 36, 13, 27, 63, 74, 87, 69, 82, 93, 32, 53, 14, 13, 12, 65, 34, 45, 100, 62, 28, 97, 27}, { 23, 59, 19, 66, 78, 98, 90, 57, 40, 40, 45, 62, 64, 58, 92, 76, 12, 81, 95, 62, 31, 21, 95, 34, 48, 90, 64, 74, 43, 97, 29, 66, 36, 39, 28, 73, 81, 29, 72, 43, 28, 69, 75, 90, 46, 46, 24}, { 53, 52, 22, 90, 82, 70, 72, 58, 48, 76, 100, 100, 43, 29, 96, 4, 10, 1, 76, 90, 82, 93, 61, 14, 2, 46, 34, 9, 87, 21, 25, 58, 96, 46, 2, 17, 35, 33, 49, 60, 80, 48, 84, 70, 12, 91, 45}, { 86, 45, 34, 2, 32, 11, 1, 35, 4, 85, 72, 34, 27, 90, 80, 96, 22, 34, 30, 90, 14, 84, 8, 78, 54, 79, 36, 96, 70, 55, 30, 19, 28, 29, 65, 78, 82, 20, 74, 40, 93, 94, 53, 73, 97, 71, 52}, { 61, 10, 22, 42, 99, 5, 84, 80, 93, 50, 67, 1, 51, 20, 74, 48, 53, 61, 8, 29, 32, 73, 36, 1, 75, 58, 26, 14, 72, 81, 70, 91, 43, 33, 33, 4, 99, 30, 88, 69, 54, 33, 42, 27, 56, 51, 64}, { 37, 54, 87, 68, 92, 61, 70, 91, 66, 87, 38, 24, 89, 96, 41, 28, 64, 20, 45, 38, 85, 84, 51, 33, 99, 1, 3, 87, 100, 48, 97, 88, 61, 65, 47, 49, 30, 7, 40, 48, 54, 19, 89, 1, 2, 99, 75}, { 48, 8, 15, 11, 17, 50, 49, 36, 29, 57, 64, 49, 91, 95, 77, 52, 3, 49, 61, 70, 28, 84, 33, 59, 46, 73, 61, 6, 27, 53, 58, 81, 12, 79, 65, 76, 63, 40, 54, 19, 77, 12, 63, 92, 31, 18, 5}, { 57, 80, 68, 90, 32, 10, 41, 65, 63, 26, 62, 21, 94, 30, 53, 84, 43, 17, 8, 20, 53, 89, 80, 91, 1, 91, 88, 38, 68, 24, 12, 46, 37, 65, 25, 83, 87, 66, 75, 24, 23, 14, 45, 22, 3, 43, 26}, { 71, 98, 27, 97, 19, 49, 73, 81, 2, 61, 13, 88, 94, 22, 16, 67, 67, 52, 100, 30, 38, 78, 61, 29, 94, 86, 53, 1, 57, 4, 82, 8, 94, 94, 94, 55, 27, 33, 5, 96, 82, 20, 62, 32, 59, 52, 10}, { 20, 67, 37, 46, 49, 39, 67, 81, 58, 17, 28, 33, 84, 38, 90, 54, 56, 5, 62, 31, 70, 29, 14, 26, 9, 1, 93, 75, 31, 70, 78, 65, 80, 49, 51, 86, 47, 99, 71, 54, 55, 64, 17, 19, 86, 36, 23}, { 16, 85, 91, 41, 96, 21, 18, 77, 53, 97, 58, 76, 68, 62, 82, 99, 13, 74, 7, 14, 64, 89, 18, 58, 67, 85, 83, 96, 27, 77, 89, 25, 65, 72, 73, 82, 11, 28, 85, 50, 13, 29, 49, 86, 12, 50, 48}, { 47, 78, 85, 95, 48, 95, 59, 39, 21, 33, 35, 70, 33, 73, 70, 47, 1, 88, 53, 9, 54, 8, 85, 21, 63, 5, 78, 51, 49, 13, 100, 33, 70, 21, 81, 15, 39, 61, 90, 61, 76, 32, 94, 15, 2, 79, 4}, { 60, 44, 29, 60, 83, 63, 82, 51, 22, 69, 35, 27, 8, 27, 10, 66, 5, 8, 18, 43, 7, 48, 52, 71, 63, 71, 32, 79, 33, 100, 75, 30, 40, 46, 14, 1, 10, 2, 41, 81, 43, 4, 77, 86, 3, 89, 96}, { 45, 14, 7, 55, 34, 78, 38, 84, 77, 21, 79, 7, 58, 39, 11, 37, 64, 94, 71, 34, 82, 82, 64, 48, 30, 97, 21, 26, 22, 95, 95, 69, 89, 57, 62, 34, 92, 42, 16, 11, 8, 37, 57, 16, 41, 32, 61}, { 22, 31, 96, 17, 95, 83, 61, 91, 93, 68, 78, 86, 41, 45, 70, 12, 68, 66, 57, 49, 10, 87, 32, 100, 100, 44, 95, 52, 83, 56, 7, 63, 100, 60, 97, 74, 58, 45, 54, 2, 96, 84, 43, 14, 89, 23, 81}, { 6, 22, 62, 71, 59, 67, 25, 5, 47, 24, 97, 51, 22, 100, 42, 36, 18, 44, 42, 74, 19, 87, 78, 36, 43, 25, 4, 11, 85, 35, 53, 99, 74, 24, 11, 86, 81, 14, 94, 21, 55, 60, 10, 88, 33, 94, 4}, { 25, 93, 84, 23, 4, 26, 18, 35, 40, 91, 26, 14, 18, 26, 27, 58, 79, 93, 49, 30, 73, 20, 93, 2, 54, 68, 59, 70, 33, 22, 74, 46, 89, 86, 100, 79, 62, 14, 58, 43, 37, 16, 28, 60, 93, 65, 51}, { 63, 76, 75, 4, 69, 99, 22, 91, 90, 9, 44, 64, 28, 5, 42, 53, 5, 100, 90, 94, 46, 67, 63, 30, 92, 11, 25, 54, 13, 40, 53, 57, 17, 54, 9, 53, 21, 26, 18, 88, 76, 56, 32, 81, 75, 77, 67}, { 61, 74, 37, 93, 98, 11, 84, 63, 87, 53, 97, 1, 96, 45, 26, 26, 32, 51, 16, 30, 69, 22, 83, 41, 97, 48, 88, 85, 22, 79, 21, 80, 45, 61, 85, 31, 5, 33, 5, 51, 93, 16, 37, 99, 4, 62, 31}, { 85, 48, 39, 32, 40, 3, 3, 67, 25, 82, 66, 28, 84, 48, 45, 72, 4, 32, 36, 85, 93, 69, 33, 25, 74, 85, 19, 82, 62, 60, 10, 73, 13, 62, 72, 36, 98, 18, 12, 78, 73, 81, 19, 60, 46, 59, 59}, { 42, 100, 16, 30, 23, 39, 2, 41, 37, 96, 5, 99, 13, 69, 71, 45, 37, 39, 51, 46, 29, 34, 76, 72, 47, 25, 84, 94, 43, 46, 88, 32, 5, 45, 9, 7, 36, 83, 28, 60, 39, 71, 6, 42, 98, 86, 7}, { 74, 40, 27, 82, 95, 99, 25, 45, 8, 53, 94, 87, 76, 84, 61, 21, 70, 17, 25, 27, 32, 16, 87, 100, 36, 44, 59, 73, 56, 4, 91, 58, 48, 57, 90, 21, 97, 55, 59, 75, 13, 38, 31, 22, 21, 89, 67}, { 67, 48, 33, 42, 93, 53, 4, 70, 86, 93, 16, 22, 40, 95, 73, 66, 2, 44, 46, 92, 32, 87, 78, 49, 5, 59, 13, 61, 94, 6, 34, 53, 25, 35, 73, 37, 4, 15, 51, 32, 78, 62, 39, 55, 49, 90, 19}, { 21, 33, 46, 94, 8, 47, 46, 7, 96, 19, 51, 98, 61, 70, 7, 6, 57, 64, 52, 2, 65, 39, 23, 61, 35, 1, 34, 92, 29, 16, 66, 60, 80, 80, 19, 27, 99, 59, 58, 74, 28, 40, 81, 53, 20, 14, 79}, { 90, 68, 16, 57, 19, 80, 93, 56, 62, 40, 16, 24, 73, 84, 69, 75, 7, 87, 48, 4, 95, 60, 70, 7, 53, 13, 70, 90, 36, 18, 54, 90, 85, 85, 53, 12, 85, 82, 79, 87, 85, 57, 36, 1, 57, 34, 1}, { 24, 64, 54, 65, 18, 67, 28, 9, 40, 69, 36, 55, 91, 18, 67, 51, 72, 5, 42, 39, 30, 4, 22, 44, 6, 77, 50, 97, 50, 47, 75, 46, 14, 30, 77, 69, 66, 100, 80, 45, 80, 90, 42, 68, 35, 27, 56}, { 14, 66, 62, 58, 19, 86, 16, 98, 23, 43, 100, 35, 75, 2, 59, 12, 83, 92, 84, 91, 5, 2, 53, 25, 38, 53, 36, 24, 73, 15, 18, 47, 94, 4, 47, 21, 62, 64, 78, 95, 78, 79, 22, 48, 29, 33, 37}, { 61, 12, 100, 14, 64, 66, 67, 100, 53, 12, 48, 98, 38, 69, 30, 80, 48, 16, 37, 61, 75, 47, 2, 61, 70, 86, 92, 42, 17, 55, 78, 75, 8, 99, 86, 32, 46, 79, 40, 98, 26, 80, 15, 40, 93, 57, 81}, { 97, 25, 88, 13, 33, 35, 23, 45, 48, 24, 30, 36, 38, 65, 25, 17, 3, 60, 59, 10, 27, 1, 75, 50, 11, 92, 72, 85, 56, 70, 82, 63, 20, 15, 92, 7, 30, 45, 95, 13, 93, 99, 57, 60, 2, 65, 20}, { 93, 64, 34, 80, 76, 3, 5, 79, 92, 95, 100, 48, 43, 66, 86, 11, 71, 30, 96, 25, 85, 13, 90, 95, 14, 77, 44, 43, 86, 7, 87, 61, 7, 91, 35, 28, 80, 51, 52, 42, 96, 96, 8, 26, 59, 80, 9}, { 62, 30, 50, 76, 32, 74, 34, 32, 7, 67, 59, 82, 40, 62, 81, 25, 16, 32, 71, 51, 52, 36, 50, 30, 4, 52, 88, 90, 55, 15, 24, 21, 41, 70, 5, 26, 18, 76, 41, 46, 56, 2, 41, 92, 94, 21, 100}, { 90, 6, 99, 39, 27, 95, 63, 20, 34, 92, 45, 48, 83, 18, 68, 12, 89, 64, 50, 27, 85, 29, 46, 99, 58, 66, 98, 9, 24, 1, 39, 49, 62, 87, 93, 77, 74, 66, 34, 60, 6, 15, 31, 37, 62, 78, 2}, { 47, 65, 81, 20, 58, 68, 96, 90, 80, 67, 68, 9, 77, 8, 97, 67, 77, 63, 16, 99, 55, 100, 16, 50, 57, 7, 87, 71, 100, 98, 97, 13, 77, 29, 66, 64, 93, 87, 35, 38, 10, 71, 29, 47, 15, 91, 89}, { 21, 96, 23, 6, 7, 46, 75, 78, 33, 81, 76, 65, 6, 37, 44, 84, 76, 5, 61, 80, 28, 48, 35, 51, 91, 25, 74, 66, 44, 80, 7, 78, 52, 2, 82, 32, 6, 58, 92, 44, 78, 85, 16, 41, 66, 85, 87}, { 64, 71, 94, 20, 42, 40, 69, 22, 52, 63, 83, 5, 61, 33, 54, 41, 54, 45, 68, 79, 44, 25, 58, 10, 81, 35, 37, 32, 83, 36, 36, 48, 48, 7, 35, 7, 83, 69, 41, 100, 66, 51, 63, 83, 30, 58, 56}, { 80, 61, 59, 68, 56, 89, 41, 30, 58, 24, 37, 55, 5, 97, 6, 23, 49, 43, 5, 1, 38, 8, 25, 28, 85, 4, 25, 58, 72, 41, 91, 23, 65, 89, 91, 74, 17, 24, 41, 67, 26, 18, 45, 16, 34, 57, 9}, { 52, 7, 89, 82, 9, 72, 44, 26, 27, 70, 80, 78, 13, 59, 47, 31, 7, 96, 61, 34, 60, 18, 77, 89, 50, 50, 83, 88, 93, 6, 7, 53, 71, 12, 76, 34, 35, 66, 72, 77, 57, 75, 78, 20, 47, 10, 60}, { 7, 10, 37, 65, 60, 19, 11, 85, 63, 32, 56, 85, 38, 46, 64, 86, 62, 25, 30, 42, 79, 33, 30, 17, 67, 89, 50, 90, 59, 39, 65, 18, 64, 42, 25, 73, 97, 82, 73, 68, 50, 61, 78, 36, 16, 45, 7}, { 55, 1, 51, 39, 17, 83, 58, 89, 33, 44, 20, 16, 95, 1, 7, 88, 68, 25, 29, 23, 63, 74, 82, 56, 26, 36, 49, 36, 30, 6, 42, 61, 89, 96, 35, 74, 47, 95, 94, 25, 2, 27, 27, 45, 91, 3, 23}, { 23, 99, 86, 27, 77, 31, 32, 76, 3, 71, 2, 100, 88, 16, 67, 16, 47, 5, 19, 31, 73, 95, 35, 27, 31, 74, 12, 20, 77, 38, 40, 68, 91, 27, 27, 11, 45, 21, 67, 94, 48, 41, 59, 35, 14, 21, 66}, { 98, 51, 15, 33, 34, 6, 43, 68, 45, 97, 4, 41, 38, 80, 18, 92, 60, 36, 25, 20, 69, 10, 19, 79, 57, 85, 61, 72, 90, 69, 59, 78, 13, 39, 69, 37, 45, 15, 43, 30, 21, 66, 55, 100, 47, 15, 55}, { 89, 75, 60, 100, 63, 81, 63, 22, 16, 96, 78, 68, 76, 91, 78, 85, 19, 40, 79, 39, 83, 31, 6, 16, 64, 46, 69, 91, 17, 50, 83, 65, 46, 40, 22, 87, 77, 54, 88, 39, 31, 10, 72, 68, 99, 7, 30}, { 48, 65, 24, 93, 98, 19, 11, 5, 73, 41, 4, 58, 7, 38, 32, 51, 5, 37, 41, 68, 17, 91, 38, 17, 49, 12, 55, 9, 38, 28, 31, 98, 16, 81, 86, 88, 89, 93, 79, 24, 58, 47, 100, 48, 84, 19, 2}, { 44, 27, 16, 89, 1, 98, 38, 27, 93, 67, 93, 14, 8, 98, 52, 63, 12, 4, 63, 24, 60, 18, 10, 85, 53, 59, 26, 49, 79, 25, 74, 97, 13, 97, 2, 79, 86, 69, 33, 20, 60, 57, 98, 61, 66, 30, 91}, { 21, 49, 40, 10, 38, 80, 83, 14, 9, 28, 64, 10, 22, 92, 14, 41, 79, 29, 16, 27, 48, 7, 25, 85, 5, 67, 74, 66, 36, 66, 76, 74, 6, 8, 67, 96, 90, 20, 82, 71, 46, 48, 7, 76, 31, 68, 9}, { 71, 92, 13, 41, 1, 48, 53, 91, 55, 45, 100, 16, 84, 7, 42, 28, 35, 2, 16, 69, 80, 3, 9, 26, 20, 49, 92, 71, 88, 87, 54, 10, 47, 93, 75, 89, 90, 76, 97, 33, 84, 68, 49, 77, 55, 10, 31}, { 88, 20, 25, 25, 90, 13, 78, 51, 53, 79, 75, 96, 74, 1, 61, 36, 43, 59, 31, 22, 93, 88, 98, 64, 11, 42, 65, 35, 5, 58, 62, 11, 4, 5, 56, 90, 70, 34, 13, 54, 88, 49, 56, 86, 41, 55, 46}, { 14, 96, 6, 30, 77, 44, 60, 14, 32, 96, 37, 93, 38, 84, 20, 41, 94, 59, 11, 91, 74, 63, 88, 4, 15, 41, 61, 8, 49, 10, 98, 59, 20, 35, 89, 76, 82, 14, 48, 25, 35, 87, 75, 87, 35, 77, 92}, { 1, 72, 68, 52, 95, 7, 5, 88, 12, 28, 49, 32, 63, 35, 4, 48, 34, 99, 92, 29, 14, 5, 1, 17, 2, 74, 26, 74, 86, 11, 8, 65, 93, 80, 5, 50, 18, 77, 34, 23, 70, 46, 13, 11, 94, 44, 43}, { 95, 64, 95, 31, 84, 32, 28, 71, 1, 90, 2, 70, 88, 80, 17, 53, 78, 44, 88, 57, 92, 76, 8, 10, 44, 81, 57, 78, 29, 95, 77, 54, 95, 82, 2, 36, 50, 16, 57, 7, 87, 38, 14, 15, 3, 20, 8}, { 14, 27, 87, 12, 13, 91, 62, 17, 23, 59, 41, 99, 61, 86, 78, 27, 63, 34, 28, 93, 61, 72, 85, 6, 31, 79, 60, 9, 74, 2, 58, 43, 48, 5, 52, 47, 98, 82, 82, 18, 99, 64, 80, 2, 79, 37, 66}, { 71, 71, 15, 88, 34, 51, 28, 68, 98, 6, 65, 70, 4, 7, 72, 2, 66, 1, 20, 23, 35, 16, 26, 30, 26, 97, 79, 6, 21, 19, 37, 8, 55, 30, 85, 36, 20, 77, 58, 4, 42, 22, 47, 100, 53, 17, 33}};
                    int small_array[59][47] = {{ 54, 79, 6, 84, 32, 28, 5, 50, 2, 13, 32, 22, 91, 19, 12, 91, 65, 62, 11, 10, 96, 4, 72, 19, 45, 18, 96, 16, 39, 52, 34, 73, 69, 75, 24, 94, 33, 13, 26, 27, 13, 38, 3, 11, 13, 36, 43}, { 30, 96, 90, 2, 21, 83, 76, 11, 41, 81, 40, 22, 8, 16, 23, 9, 80, 51, 49, 50, 49, 12, 61, 46, 76, 56, 52, 47, 60, 39, 36, 54, 39, 28, 23, 29, 64, 42, 70, 81, 1, 86, 23, 18, 29, 50, 93}, { 81, 56, 35, 42, 15, 94, 94, 20, 11, 97, 15, 28, 3, 13, 33, 14, 77, 34, 32, 6, 86, 62, 25, 20, 48, 4, 6, 11, 5, 50, 16, 61, 90, 29, 5, 94, 50, 2, 34, 20, 28, 88, 39, 24, 77, 7, 60}, { 86, 99, 10, 39, 61, 30, 12, 47, 74, 93, 95, 4, 23, 77, 44, 3, 47, 59, 17, 84, 46, 79, 45, 71, 100, 63, 4, 29, 20, 18, 5, 87, 51, 68, 69, 50, 22, 47, 91, 87, 42, 98, 96, 85, 73, 98, 14}, { 88, 33, 71, 38, 19, 47, 43, 98, 88, 54, 73, 73, 71, 68, 12, 97, 89, 67, 63, 47, 21, 94, 34, 82, 77, 27, 77, 46, 2, 85, 30, 78, 81, 47, 39, 65, 78, 53, 51, 79, 89, 62, 56, 74, 19, 97, 46}, { 45, 70, 39, 26, 18, 31, 52, 54, 44, 57, 50, 77, 36, 2, 33, 92, 63, 27, 64, 65, 86, 43, 19, 45, 32, 77, 1, 5, 60, 59, 1, 48, 75, 77, 21, 23, 78, 49, 25, 38, 17, 21, 45, 42, 3, 90, 46}, { 69, 19, 13, 91, 8, 52, 28, 21, 18, 44, 86, 49, 1, 48, 43, 4, 74, 24, 75, 41, 47, 81, 8, 22, 58, 20, 20, 25, 37, 43, 27, 85, 43, 19, 6, 93, 75, 27, 65, 60, 29, 35, 71, 1, 24, 26, 22}, { 17, 30, 23, 35, 56, 77, 97, 18, 63, 62, 22, 90, 65, 73, 32, 95, 48, 12, 92, 78, 23, 19, 41, 16, 27, 17, 34, 32, 25, 40, 30, 97, 13, 45, 33, 14, 100, 57, 14, 56, 50, 18, 34, 76, 22, 61, 30}, { 55, 15, 77, 47, 14, 51, 24, 41, 60, 50, 43, 98, 17, 88, 21, 40, 94, 70, 4, 72, 68, 47, 38, 88, 79, 98, 64, 43, 23, 91, 59, 90, 91, 56, 60, 65, 80, 20, 79, 32, 93, 73, 56, 16, 62, 99, 35}, { 24, 2, 77, 86, 46, 74, 24, 92, 94, 44, 87, 33, 1, 31, 18, 83, 16, 75, 53, 47, 42, 90, 81, 75, 36, 55, 9, 61, 93, 86, 100, 43, 56, 24, 62, 26, 82, 33, 48, 25, 85, 14, 77, 71, 55, 37, 29}, { 64, 13, 72, 62, 28, 8, 81, 18, 13, 74, 50, 77, 14, 72, 14, 4, 8, 73, 84, 27, 3, 100, 16, 28, 79, 28, 65, 53, 38, 20, 81, 73, 89, 14, 96, 41, 31, 99, 34, 73, 50, 64, 8, 84, 100, 7, 30}, { 34, 3, 59, 73, 12, 44, 75, 13, 56, 30, 51, 2, 47, 15, 74, 51, 65, 25, 96, 69, 94, 46, 36, 84, 10, 93, 73, 30, 94, 78, 80, 90, 22, 56, 8, 19, 81, 24, 33, 7, 9, 36, 13, 51, 25, 49, 38}, { 22, 57, 18, 51, 23, 2, 6, 56, 43, 74, 84, 7, 41, 63, 1, 21, 39, 63, 94, 59, 1, 32, 76, 50, 12, 69, 91, 48, 40, 5, 72, 40, 33, 58, 93, 44, 59, 40, 87, 57, 11, 76, 31, 89, 15, 30, 99}, { 60, 84, 7, 33, 58, 64, 40, 100, 76, 85, 78, 70, 45, 47, 64, 53, 75, 91, 35, 76, 38, 97, 30, 75, 51, 22, 71, 88, 24, 21, 88, 21, 48, 7, 34, 19, 69, 72, 63, 28, 83, 68, 100, 77, 61, 46, 47}, { 28, 80, 1, 91, 80, 57, 59, 59, 54, 84, 66, 68, 32, 8, 79, 79, 37, 88, 32, 98, 45, 59, 30, 69, 75, 36, 45, 17, 6, 59, 77, 2, 98, 67, 32, 9, 65, 36, 41, 90, 64, 65, 85, 20, 45, 6, 48}, { 88, 68, 39, 84, 51, 41, 33, 75, 51, 32, 11, 96, 7, 16, 72, 21, 18, 46, 20, 100, 93, 57, 44, 55, 93, 19, 90, 26, 77, 31, 18, 92, 57, 63, 64, 64, 38, 20, 55, 55, 37, 16, 34, 49, 50, 57, 45}, { 10, 19, 77, 82, 52, 35, 11, 55, 18, 47, 34, 64, 9, 40, 16, 13, 83, 13, 61, 79, 94, 44, 75, 12, 46, 65, 79, 28, 85, 14, 71, 30, 2, 95, 78, 77, 4, 85, 39, 30, 56, 60, 50, 45, 83, 53, 3}, { 84, 41, 78, 80, 18, 90, 56, 50, 50, 8, 74, 93, 15, 33, 68, 44, 93, 16, 66, 18, 85, 12, 24, 51, 61, 54, 11, 64, 71, 17, 46, 87, 9, 91, 2, 16, 30, 38, 74, 14, 13, 52, 24, 70, 28, 60, 88}, { 21, 95, 21, 42, 52, 69, 96, 96, 91, 52, 97, 97, 19, 22, 26, 62, 50, 48, 100, 91, 8, 22, 41, 38, 71, 59, 100, 77, 21, 52, 12, 89, 75, 64, 96, 36, 63, 2, 59, 94, 32, 83, 80, 99, 26, 57, 52}, { 58, 31, 14, 51, 68, 11, 49, 55, 85, 41, 27, 91, 16, 41, 20, 11, 92, 39, 49, 9, 14, 66, 14, 83, 90, 100, 33, 54, 60, 52, 38, 67, 56, 28, 47, 87, 5, 2, 19, 85, 62, 19, 23, 48, 75, 9, 84}, { 26, 63, 66, 72, 6, 10, 71, 30, 25, 82, 65, 93, 14, 96, 59, 41, 34, 98, 78, 92, 40, 76, 47, 57, 23, 51, 49, 46, 57, 74, 66, 82, 83, 4, 66, 43, 34, 25, 88, 90, 13, 96, 17, 7, 96, 50, 70}, { 22, 85, 53, 5, 4, 17, 39, 91, 95, 62, 15, 90, 73, 39, 79, 24, 91, 34, 98, 14, 63, 31, 89, 77, 64, 85, 98, 25, 73, 30, 19, 11, 67, 77, 16, 94, 87, 55, 78, 99, 30, 57, 46, 13, 40, 67, 14}, { 48, 12, 33, 60, 98, 4, 95, 60, 48, 21, 32, 74, 4, 59, 15, 30, 1, 14, 13, 93, 100, 88, 57, 74, 84, 65, 15, 5, 5, 15, 97, 35, 94, 53, 18, 10, 60, 43, 69, 78, 67, 12, 89, 45, 87, 76, 98}, { 56, 84, 84, 15, 75, 45, 6, 17, 45, 8, 49, 31, 73, 65, 56, 78, 39, 33, 14, 9, 72, 93, 83, 34, 12, 40, 77, 28, 11, 68, 22, 98, 86, 86, 12, 46, 42, 17, 18, 90, 72, 70, 55, 89, 41, 95, 30}, { 88, 17, 13, 33, 62, 15, 79, 53, 39, 8, 26, 14, 16, 100, 37, 67, 17, 34, 94, 25, 73, 18, 6, 16, 2, 93, 36, 62, 38, 55, 59, 40, 29, 13, 45, 84, 88, 91, 4, 14, 34, 97, 58, 100, 97, 57, 10}, { 29, 27, 19, 7, 80, 19, 19, 75, 40, 55, 11, 14, 51, 31, 72, 70, 35, 45, 19, 68, 2, 6, 70, 88, 4, 68, 20, 52, 94, 71, 12, 83, 7, 18, 17, 30, 54, 88, 4, 63, 10, 77, 71, 17, 59, 98, 5}, { 83, 63, 30, 53, 77, 90, 58, 87, 95, 54, 39, 12, 38, 72, 86, 54, 96, 27, 72, 91, 53, 57, 85, 47, 73, 31, 42, 28, 7, 52, 56, 61, 72, 8, 70, 81, 39, 21, 9, 45, 19, 52, 58, 39, 52, 24, 43}, { 96, 11, 80, 50, 27, 46, 62, 32, 6, 63, 97, 67, 11, 46, 42, 92, 41, 72, 70, 58, 67, 24, 54, 20, 89, 6, 58, 72, 100, 55, 93, 38, 87, 49, 27, 63, 43, 78, 50, 69, 66, 87, 79, 91, 65, 54, 100}, { 100, 19, 91, 87, 64, 74, 8, 83, 95, 63, 89, 2, 81, 88, 3, 94, 10, 21, 71, 64, 90, 44, 10, 62, 5, 47, 10, 100, 23, 64, 6, 17, 75, 94, 68, 79, 26, 17, 97, 14, 41, 32, 18, 85, 44, 7, 46}, { 5, 75, 35, 70, 98, 17, 95, 75, 55, 32, 24, 84, 83, 26, 40, 97, 28, 28, 57, 55, 87, 75, 67, 24, 69, 39, 6, 80, 84, 22, 92, 13, 95, 53, 10, 55, 46, 94, 44, 58, 41, 12, 58, 42, 71, 21, 26}, { 9, 60, 70, 88, 26, 88, 74, 79, 65, 54, 41, 27, 4, 50, 30, 64, 97, 58, 70, 23, 69, 30, 100, 55, 22, 82, 6, 88, 9, 96, 8, 94, 93, 40, 37, 74, 31, 71, 83, 72, 81, 33, 60, 91, 82, 28, 81}, { 81, 89, 55, 97, 4, 35, 25, 12, 46, 22, 30, 97, 63, 46, 88, 67, 51, 67, 40, 61, 1, 51, 46, 65, 54, 57, 36, 31, 46, 59, 26, 35, 37, 81, 37, 8, 52, 15, 40, 100, 37, 25, 71, 69, 53, 75, 55}, { 24, 61, 39, 60, 43, 28, 38, 56, 6, 93, 33, 95, 37, 57, 54, 13, 21, 52, 74, 25, 89, 47, 51, 74, 19, 96, 9, 63, 84, 75, 18, 90, 77, 56, 34, 96, 92, 84, 75, 87, 12, 44, 96, 89, 97, 37, 45}, { 71, 80, 28, 96, 53, 22, 20, 66, 74, 3, 70, 14, 88, 67, 99, 1, 54, 62, 65, 72, 40, 98, 93, 39, 4, 16, 65, 15, 84, 36, 84, 93, 59, 7, 3, 42, 54, 17, 83, 47, 84, 63, 4, 87, 37, 71, 79}, { 61, 41, 10, 3, 23, 34, 80, 70, 19, 45, 31, 88, 84, 86, 84, 1, 80, 51, 28, 57, 9, 43, 88, 56, 37, 28, 65, 85, 89, 40, 75, 12, 98, 3, 11, 43, 89, 63, 49, 45, 69, 7, 90, 65, 88, 62, 71}, { 57, 36, 39, 16, 33, 87, 23, 15, 8, 19, 68, 71, 50, 91, 13, 34, 99, 6, 24, 33, 29, 47, 39, 4, 40, 12, 13, 18, 36, 85, 58, 64, 42, 21, 7, 62, 51, 94, 78, 66, 30, 45, 52, 26, 2, 100, 4}, { 97, 86, 78, 27, 80, 2, 5, 13, 43, 5, 86, 27, 95, 31, 52, 9, 11, 41, 49, 33, 95, 51, 59, 80, 35, 90, 36, 8, 73, 22, 67, 84, 13, 100, 14, 35, 21, 81, 80, 30, 54, 16, 25, 81, 42, 94, 48}, { 59, 24, 30, 63, 16, 89, 34, 89, 71, 91, 21, 42, 84, 6, 79, 61, 86, 28, 23, 72, 71, 20, 75, 29, 81, 93, 67, 31, 20, 81, 50, 2, 5, 80, 30, 44, 37, 62, 56, 21, 43, 86, 83, 72, 94, 24, 59}, { 53, 63, 63, 60, 78, 94, 20, 77, 30, 77, 35, 33, 80, 62, 97, 60, 58, 86, 94, 70, 31, 3, 83, 30, 62, 79, 83, 22, 33, 32, 35, 48, 87, 25, 47, 38, 43, 60, 39, 30, 70, 81, 2, 92, 81, 22, 7}, { 94, 56, 33, 18, 65, 80, 92, 52, 69, 75, 48, 30, 94, 49, 32, 2, 6, 27, 30, 91, 62, 87, 39, 32, 3, 75, 6, 4, 1, 74, 93, 55, 64, 98, 26, 14, 25, 32, 88, 7, 15, 86, 26, 68, 20, 26, 70}, { 93, 87, 96, 56, 12, 42, 32, 8, 86, 93, 11, 97, 5, 100, 14, 31, 46, 92, 94, 63, 69, 88, 98, 51, 14, 29, 70, 64, 57, 11, 72, 15, 16, 96, 15, 59, 4, 88, 37, 52, 71, 93, 9, 79, 13, 68, 56}, { 21, 64, 5, 88, 98, 3, 56, 22, 81, 81, 26, 90, 96, 86, 82, 6, 72, 24, 47, 33, 96, 32, 65, 19, 100, 25, 98, 57, 28, 4, 44, 12, 14, 67, 17, 58, 34, 33, 70, 70, 37, 80, 77, 13, 22, 15, 10}, { 32, 94, 92, 34, 99, 41, 97, 12, 16, 30, 27, 9, 69, 33, 92, 52, 49, 87, 82, 55, 23, 64, 35, 100, 84, 60, 71, 51, 35, 53, 8, 63, 84, 20, 78, 55, 47, 31, 22, 78, 99, 3, 58, 15, 75, 57, 46}, { 50, 79, 29, 54, 68, 92, 90, 53, 32, 42, 92, 57, 6, 89, 1, 7, 29, 11, 83, 70, 58, 66, 79, 28, 85, 76, 25, 53, 50, 16, 55, 60, 96, 11, 23, 58, 81, 83, 53, 84, 53, 51, 7, 51, 77, 52, 6}, { 7, 2, 82, 29, 79, 91, 93, 44, 65, 12, 80, 74, 29, 15, 18, 95, 74, 47, 74, 13, 70, 56, 81, 40, 59, 32, 15, 87, 32, 94, 81, 63, 36, 25, 56, 82, 31, 46, 53, 15, 9, 62, 36, 40, 63, 73, 33}, { 64, 23, 23, 68, 42, 14, 53, 3, 82, 99, 6, 94, 38, 47, 71, 11, 63, 12, 89, 23, 75, 72, 11, 91, 26, 48, 99, 72, 90, 22, 91, 12, 12, 68, 80, 30, 64, 82, 97, 28, 2, 33, 7, 61, 64, 32, 40}, { 28, 19, 45, 99, 14, 1, 98, 15, 21, 79, 29, 61, 98, 3, 36, 28, 73, 97, 56, 1, 73, 70, 4, 31, 15, 39, 2, 19, 92, 46, 4, 30, 47, 90, 30, 80, 18, 19, 25, 98, 31, 26, 82, 17, 49, 96, 20}, { 86, 71, 4, 32, 93, 39, 41, 43, 42, 24, 93, 69, 73, 4, 23, 87, 23, 83, 13, 42, 40, 72, 39, 12, 77, 55, 64, 99, 6, 10, 77, 27, 21, 16, 47, 11, 54, 7, 93, 63, 31, 66, 5, 98, 70, 31, 52}, { 10, 37, 99, 49, 61, 1, 76, 92, 1, 20, 86, 60, 3, 70, 12, 95, 46, 27, 7, 81, 34, 65, 7, 67, 44, 32, 36, 99, 21, 45, 18, 95, 9, 56, 34, 64, 98, 35, 2, 59, 10, 60, 48, 46, 92, 58, 84}, { 17, 70, 95, 88, 20, 11, 18, 82, 66, 79, 56, 2, 7, 45, 71, 45, 47, 72, 50, 47, 40, 49, 10, 59, 46, 51, 44, 71, 81, 41, 90, 79, 4, 83, 99, 5, 31, 65, 83, 85, 56, 43, 70, 71, 1, 96, 79}, { 73, 3, 56, 35, 7, 4, 34, 83, 83, 70, 27, 3, 48, 40, 75, 4, 8, 41, 59, 70, 11, 39, 29, 15, 97, 1, 93, 25, 19, 40, 52, 48, 67, 4, 64, 38, 6, 81, 51, 51, 13, 58, 31, 98, 33, 4, 20}, { 27, 30, 26, 64, 44, 74, 15, 1, 68, 17, 65, 90, 100, 29, 49, 34, 90, 20, 47, 29, 91, 29, 7, 14, 95, 73, 6, 92, 10, 3, 29, 83, 4, 55, 39, 84, 49, 77, 25, 46, 21, 41, 82, 68, 29, 63, 73}, { 34, 62, 98, 48, 30, 3, 33, 26, 31, 18, 74, 49, 31, 96, 27, 41, 1, 51, 50, 92, 71, 64, 52, 35, 11, 87, 37, 34, 35, 15, 21, 93, 75, 55, 93, 75, 26, 82, 91, 47, 27, 68, 22, 11, 79, 37, 50}, { 13, 43, 58, 13, 7, 51, 77, 46, 73, 11, 82, 31, 23, 72, 42, 46, 92, 85, 67, 44, 13, 77, 60, 51, 40, 88, 34, 8, 75, 92, 99, 75, 98, 3, 52, 9, 73, 94, 6, 96, 95, 26, 45, 64, 10, 25, 72}, { 23, 36, 40, 70, 4, 25, 6, 38, 26, 63, 87, 38, 98, 52, 2, 7, 1, 81, 76, 47, 80, 91, 97, 64, 98, 78, 40, 87, 59, 34, 22, 9, 98, 15, 33, 25, 62, 80, 63, 41, 6, 52, 97, 75, 95, 98, 85}, { 83, 96, 60, 24, 100, 70, 71, 29, 36, 85, 88, 6, 68, 91, 49, 7, 97, 95, 53, 84, 76, 40, 51, 83, 36, 3, 47, 99, 28, 67, 19, 4, 53, 90, 17, 54, 12, 49, 67, 18, 49, 91, 88, 25, 67, 70, 44}, { 33, 17, 47, 94, 34, 17, 70, 65, 1, 36, 34, 93, 97, 20, 25, 16, 46, 96, 74, 48, 50, 10, 87, 99, 11, 5, 97, 42, 7, 54, 60, 72, 99, 38, 24, 45, 61, 32, 75, 66, 82, 55, 11, 63, 87, 48, 85}, { 67, 54, 81, 42, 71, 13, 35, 10, 51, 62, 95, 89, 16, 95, 46, 45, 64, 68, 29, 34, 29, 83, 23, 43, 27, 47, 81, 56, 85, 19, 97, 17, 16, 61, 67, 56, 22, 15, 44, 77, 70, 6, 12, 91, 32, 2, 27}, { 23, 12, 66, 37, 97, 52, 49, 16, 63, 92, 30, 55, 16, 89, 17, 1, 53, 80, 46, 33, 30, 84, 9, 95, 70, 81, 100, 54, 18, 49, 95, 97, 34, 41, 2, 61, 11, 50, 13, 95, 31, 26, 22, 6, 7, 17, 49}};
                    
                    int array_draw_rectangle[59][47] = {{ 54, 79, 6, 84, 32, 28, 5, 50, 2, 13, 32, 22, 91, 19, 12, 91, 65, 62, 11, 10, 96, 4, 72, 19, 45, 18, 96, 16, 39, 52, 34, 73, 69, 75, 24, 94, 33, 13, 26, 27, 13, 38, 3, 11, 13, 36, 43}, { 30, 96, 90, 2, 21, 83, 76, 11, 41, 81, 40, 22, 8, 16, 23, 9, 80, 51, 49, 50, 49, 12, 61, 46, 76, 56, 52, 47, 60, 39, 36, 54, 39, 28, 23, 29, 64, 42, 70, 81, 1, 86, 23, 18, 29, 50, 93}, { 81, 56, 35, 42, 15, 94, 94, 20, 11, 97, 15, 28, 3, 13, 33, 14, 77, 34, 32, 6, 86, 62, 25, 20, 48, 4, 6, 11, 5, 50, 16, 61, 90, 29, 5, 94, 50, 2, 34, 20, 28, 88, 39, 24, 77, 7, 60}, { 86, 99, 10, 39, 61, 30, 12, 47, 74, 93, 95, 4, 23, 77, 44, 3, 47, 59, 17, 84, 46, 79, 45, 71, 100, 63, 4, 29, 20, 18, 5, 87, 51, 68, 69, 50, 22, 47, 91, 87, 42, 98, 96, 85, 73, 98, 14}, { 88, 33, 71, 38, 19, 47, 43, 98, 88, 54, 73, 73, 71, 68, 12, 97, 89, 67, 63, 47, 21, 94, 34, 82, 77, 27, 77, 46, 2, 85, 30, 78, 81, 47, 39, 65, 78, 53, 51, 79, 89, 62, 56, 74, 19, 97, 46}, { 45, 70, 39, 26, 18, 31, 52, 54, 44, 57, 50, 77, 36, 2, 33, 92, 63, 27, 64, 65, 86, 43, 19, 45, 32, 77, 1, 5, 60, 59, 1, 48, 75, 77, 21, 23, 78, 49, 25, 38, 17, 21, 45, 42, 3, 90, 46}, { 69, 19, 13, 91, 8, 52, 28, 21, 18, 44, 86, 49, 1, 48, 43, 4, 74, 24, 75, 41, 47, 81, 8, 22, 58, 20, 20, 25, 37, 43, 27, 85, 43, 19, 6, 93, 75, 27, 65, 60, 29, 35, 71, 1, 24, 26, 22}, { 17, 30, 23, 35, 56, 77, 97, 18, 63, 62, 22, 90, 65, 73, 32, 95, 48, 12, 92, 78, 23, 19, 41, 16, 27, 17, 34, 32, 25, 40, 30, 97, 13, 45, 33, 14, 100, 57, 14, 56, 50, 18, 34, 76, 22, 61, 30}, { 55, 15, 77, 47, 14, 51, 24, 41, 60, 50, 43, 98, 17, 88, 21, 40, 94, 70, 4, 72, 68, 47, 38, 88, 79, 98, 64, 43, 23, 91, 59, 90, 91, 56, 60, 65, 80, 20, 79, 32, 93, 73, 56, 16, 62, 99, 35}, { 24, 2, 77, 86, 46, 74, 24, 92, 94, 44, 87, 33, 1, 31, 18, 83, 16, 75, 53, 47, 42, 90, 81, 75, 36, 55, 9, 61, 93, 86, 100, 43, 56, 24, 62, 26, 82, 33, 48, 25, 85, 14, 77, 71, 55, 37, 29}, { 64, 13, 72, 62, 28, 8, 81, 18, 13, 74, 50, 77, 14, 72, 14, 4, 8, 73, 84, 27, 3, 100, 16, 28, 79, 28, 65, 53, 38, 20, 81, 73, 89, 14, 96, 41, 31, 99, 34, 73, 50, 64, 8, 84, 100, 7, 30}, { 34, 3, 59, 73, 12, 44, 75, 13, 56, 30, 51, 2, 47, 15, 74, 51, 65, 25, 96, 69, 94, 46, 36, 84, 10, 93, 73, 30, 94, 78, 80, 90, 22, 56, 8, 19, 81, 24, 33, 7, 9, 36, 13, 51, 25, 49, 38}, { 22, 57, 18, 51, 23, 2, 6, 56, 43, 74, 84, 7, 41, 63, 1, 21, 39, 63, 94, 59, 1, 32, 76, 50, 12, 69, 91, 48, 40, 5, 72, 40, 33, 58, 93, 44, 59, 40, 87, 57, 11, 76, 31, 89, 15, 30, 99}, { 60, 84, 7, 33, 58, 64, 40, 100, 76, 85, 78, 70, 45, 47, 64, 53, 75, 91, 35, 76, 38, 97, 30, 75, 51, 22, 71, 88, 24, 21, 88, 21, 48, 7, 34, 19, 69, 72, 63, 28, 83, 68, 100, 77, 61, 46, 47}, { 28, 80, 1, 91, 80, 57, 59, 59, 54, 84, 66, 68, 32, 8, 79, 79, 37, 88, 32, 98, 45, 59, 30, 69, 75, 36, 45, 17, 6, 59, 77, 2, 98, 67, 32, 9, 65, 36, 41, 90, 64, 65, 85, 20, 45, 6, 48}, { 88, 68, 39, 84, 51, 41, 33, 75, 51, 32, 11, 96, 7, 16, 72, 21, 18, 46, 20, 100, 93, 57, 44, 55, 93, 19, 90, 26, 77, 31, 18, 92, 57, 63, 64, 64, 38, 20, 55, 55, 37, 16, 34, 49, 50, 57, 45}, { 10, 19, 77, 82, 52, 35, 11, 55, 18, 47, 34, 64, 9, 40, 16, 13, 83, 13, 61, 79, 94, 44, 75, 12, 46, 65, 79, 28, 85, 14, 71, 30, 2, 95, 78, 77, 4, 85, 39, 30, 56, 60, 50, 45, 83, 53, 3}, { 84, 41, 78, 80, 18, 90, 56, 50, 50, 8, 74, 93, 15, 33, 68, 44, 93, 16, 66, 18, 85, 12, 24, 51, 61, 54, 11, 64, 71, 17, 46, 87, 9, 91, 2, 16, 30, 38, 74, 14, 13, 52, 24, 70, 28, 60, 88}, { 21, 95, 21, 42, 52, 69, 96, 96, 91, 52, 97, 97, 19, 22, 26, 62, 50, 48, 100, 91, 8, 22, 41, 38, 71, 59, 100, 77, 21, 52, 12, 89, 75, 64, 96, 36, 63, 2, 59, 94, 32, 83, 80, 99, 26, 57, 52}, { 58, 31, 14, 51, 68, 11, 49, 55, 85, 41, 27, 91, 16, 41, 20, 11, 92, 39, 49, 9, 14, 66, 14, 83, 90, 100, 33, 54, 60, 52, 38, 67, 56, 28, 47, 87, 5, 2, 19, 85, 62, 19, 23, 48, 75, 9, 84}, { 26, 63, 66, 72, 6, 10, 71, 30, 25, 82, 65, 93, 14, 96, 59, 41, 34, 98, 78, 92, 40, 76, 47, 57, 23, 51, 49, 46, 57, 74, 66, 82, 83, 4, 66, 43, 34, 25, 88, 90, 13, 96, 17, 7, 96, 50, 70}, { 22, 85, 53, 5, 4, 17, 39, 91, 95, 62, 15, 90, 73, 39, 79, 24, 91, 34, 98, 14, 63, 31, 89, 77, 64, 85, 98, 25, 73, 30, 19, 11, 67, 77, 16, 94, 87, 55, 78, 99, 30, 57, 46, 13, 40, 67, 14}, { 48, 12, 33, 60, 98, 4, 95, 60, 48, 21, 32, 74, 4, 59, 15, 30, 1, 14, 13, 93, 100, 88, 57, 74, 84, 65, 15, 5, 5, 15, 97, 35, 94, 53, 18, 10, 60, 43, 69, 78, 67, 12, 89, 45, 87, 76, 98}, { 56, 84, 84, 15, 75, 45, 6, 17, 45, 8, 49, 31, 73, 65, 56, 78, 39, 33, 14, 9, 72, 93, 83, 34, 12, 40, 77, 28, 11, 68, 22, 98, 86, 86, 12, 46, 42, 17, 18, 90, 72, 70, 55, 89, 41, 95, 30}, { 88, 17, 13, 33, 62, 15, 79, 53, 39, 8, 26, 14, 16, 100, 37, 67, 17, 34, 94, 25, 73, 18, 6, 16, 2, 93, 36, 62, 38, 55, 59, 40, 29, 13, 45, 84, 88, 91, 4, 14, 34, 97, 58, 100, 97, 57, 10}, { 29, 27, 19, 7, 80, 19, 19, 75, 40, 55, 11, 14, 51, 31, 72, 70, 35, 45, 19, 68, 2, 6, 70, 88, 4, 68, 20, 52, 94, 71, 12, 83, 7, 18, 17, 30, 54, 88, 4, 63, 10, 77, 71, 17, 59, 98, 5}, { 83, 63, 30, 53, 77, 90, 58, 87, 95, 54, 39, 12, 38, 72, 86, 54, 96, 27, 72, 91, 53, 57, 85, 47, 73, 31, 42, 28, 7, 52, 56, 61, 72, 8, 70, 81, 39, 21, 9, 45, 19, 52, 58, 39, 52, 24, 43}, { 96, 11, 80, 50, 27, 46, 62, 32, 6, 63, 97, 67, 11, 46, 42, 92, 41, 72, 70, 58, 67, 24, 54, 20, 89, 6, 58, 72, 100, 55, 93, 38, 87, 49, 27, 63, 43, 78, 50, 69, 66, 87, 79, 91, 65, 54, 100}, { 100, 19, 91, 87, 64, 74, 8, 83, 95, 63, 89, 2, 81, 88, 3, 94, 10, 21, 71, 64, 90, 44, 10, 62, 5, 47, 10, 100, 23, 64, 6, 17, 75, 94, 68, 79, 26, 17, 97, 14, 41, 32, 18, 85, 44, 7, 46}, { 5, 75, 35, 70, 98, 17, 95, 75, 55, 32, 24, 84, 83, 26, 40, 97, 28, 28, 57, 55, 87, 75, 67, 24, 69, 39, 6, 80, 84, 22, 92, 13, 95, 53, 10, 55, 46, 94, 44, 58, 41, 12, 58, 42, 71, 21, 26}, { 9, 60, 70, 88, 26, 88, 74, 79, 65, 54, 41, 27, 4, 50, 30, 64, 97, 58, 70, 23, 69, 30, 100, 55, 22, 82, 6, 88, 9, 96, 8, 94, 93, 40, 37, 74, 31, 71, 83, 72, 81, 33, 60, 91, 82, 28, 81}, { 81, 89, 55, 97, 4, 35, 25, 12, 46, 22, 30, 97, 63, 46, 88, 67, 51, 67, 40, 61, 1, 51, 46, 65, 54, 57, 36, 31, 46, 59, 26, 35, 37, 81, 37, 8, 52, 15, 40, 100, 37, 25, 71, 69, 53, 75, 55}, { 24, 61, 39, 60, 43, 28, 38, 56, 6, 93, 33, 95, 37, 57, 54, 13, 21, 52, 74, 25, 89, 47, 51, 74, 19, 96, 9, 63, 84, 75, 18, 90, 77, 56, 34, 96, 92, 84, 75, 87, 12, 44, 96, 89, 97, 37, 45}, { 71, 80, 28, 96, 53, 22, 20, 66, 74, 3, 70, 14, 88, 67, 99, 1, 54, 62, 65, 72, 40, 98, 93, 39, 4, 16, 65, 15, 84, 36, 84, 93, 59, 7, 3, 42, 54, 17, 83, 47, 84, 63, 4, 87, 37, 71, 79}, { 61, 41, 10, 3, 23, 34, 80, 70, 19, 45, 31, 88, 84, 86, 84, 1, 80, 51, 28, 57, 9, 43, 88, 56, 37, 28, 65, 85, 89, 40, 75, 12, 98, 3, 11, 43, 89, 63, 49, 45, 69, 7, 90, 65, 88, 62, 71}, { 57, 36, 39, 16, 33, 87, 23, 15, 8, 19, 68, 71, 50, 91, 13, 34, 99, 6, 24, 33, 29, 47, 39, 4, 40, 12, 13, 18, 36, 85, 58, 64, 42, 21, 7, 62, 51, 94, 78, 66, 30, 45, 52, 26, 2, 100, 4}, { 97, 86, 78, 27, 80, 2, 5, 13, 43, 5, 86, 27, 95, 31, 52, 9, 11, 41, 49, 33, 95, 51, 59, 80, 35, 90, 36, 8, 73, 22, 67, 84, 13, 100, 14, 35, 21, 81, 80, 30, 54, 16, 25, 81, 42, 94, 48}, { 59, 24, 30, 63, 16, 89, 34, 89, 71, 91, 21, 42, 84, 6, 79, 61, 86, 28, 23, 72, 71, 20, 75, 29, 81, 93, 67, 31, 20, 81, 50, 2, 5, 80, 30, 44, 37, 62, 56, 21, 43, 86, 83, 72, 94, 24, 59}, { 53, 63, 63, 60, 78, 94, 20, 77, 30, 77, 35, 33, 80, 62, 97, 60, 58, 86, 94, 70, 31, 3, 83, 30, 62, 79, 83, 22, 33, 32, 35, 48, 87, 25, 47, 38, 43, 60, 39, 30, 70, 81, 2, 92, 81, 22, 7}, { 94, 56, 33, 18, 65, 80, 92, 52, 69, 75, 48, 30, 94, 49, 32, 2, 6, 27, 30, 91, 62, 87, 39, 32, 3, 75, 6, 4, 1, 74, 93, 55, 64, 98, 26, 14, 25, 32, 88, 7, 15, 86, 26, 68, 20, 26, 70}, { 93, 87, 96, 56, 12, 42, 32, 8, 86, 93, 11, 97, 5, 100, 14, 31, 46, 92, 94, 63, 69, 88, 98, 51, 14, 29, 70, 64, 57, 11, 72, 15, 16, 96, 15, 59, 4, 88, 37, 52, 71, 93, 9, 79, 13, 68, 56}, { 21, 64, 5, 88, 98, 3, 56, 22, 81, 81, 26, 90, 96, 86, 82, 6, 72, 24, 47, 33, 96, 32, 65, 19, 100, 25, 98, 57, 28, 4, 44, 12, 14, 67, 17, 58, 34, 33, 70, 70, 37, 80, 77, 13, 22, 15, 10}, { 32, 94, 92, 34, 99, 41, 97, 12, 16, 30, 27, 9, 69, 33, 92, 52, 49, 87, 82, 55, 23, 64, 35, 100, 84, 60, 71, 51, 35, 53, 8, 63, 84, 20, 78, 55, 47, 31, 22, 78, 99, 3, 58, 15, 75, 57, 46}, { 50, 79, 29, 54, 68, 92, 90, 53, 32, 42, 92, 57, 6, 89, 1, 7, 29, 11, 83, 70, 58, 66, 79, 28, 85, 76, 25, 53, 50, 16, 55, 60, 96, 11, 23, 58, 81, 83, 53, 84, 53, 51, 7, 51, 77, 52, 6}, { 7, 2, 82, 29, 79, 91, 93, 44, 65, 12, 80, 74, 29, 15, 18, 95, 74, 47, 74, 13, 70, 56, 81, 40, 59, 32, 15, 87, 32, 94, 81, 63, 36, 25, 56, 82, 31, 46, 53, 15, 9, 62, 36, 40, 63, 73, 33}, { 64, 23, 23, 68, 42, 14, 53, 3, 82, 99, 6, 94, 38, 47, 71, 11, 63, 12, 89, 23, 75, 72, 11, 91, 26, 48, 99, 72, 90, 22, 91, 12, 12, 68, 80, 30, 64, 82, 97, 28, 2, 33, 7, 61, 64, 32, 40}, { 28, 19, 45, 99, 14, 1, 98, 15, 21, 79, 29, 61, 98, 3, 36, 28, 73, 97, 56, 1, 73, 70, 4, 31, 15, 39, 2, 19, 92, 46, 4, 30, 47, 90, 30, 80, 18, 19, 25, 98, 31, 26, 82, 17, 49, 96, 20}, { 86, 71, 4, 32, 93, 39, 41, 43, 42, 24, 93, 69, 73, 4, 23, 87, 23, 83, 13, 42, 40, 72, 39, 12, 77, 55, 64, 99, 6, 10, 77, 27, 21, 16, 47, 11, 54, 7, 93, 63, 31, 66, 5, 98, 70, 31, 52}, { 10, 37, 99, 49, 61, 1, 76, 92, 1, 20, 86, 60, 3, 70, 12, 95, 46, 27, 7, 81, 34, 65, 7, 67, 44, 32, 36, 99, 21, 45, 18, 95, 9, 56, 34, 64, 98, 35, 2, 59, 10, 60, 48, 46, 92, 58, 84}, { 17, 70, 95, 88, 20, 11, 18, 82, 66, 79, 56, 2, 7, 45, 71, 45, 47, 72, 50, 47, 40, 49, 10, 59, 46, 51, 44, 71, 81, 41, 90, 79, 4, 83, 99, 5, 31, 65, 83, 85, 56, 43, 70, 71, 1, 96, 79}, { 73, 3, 56, 35, 7, 4, 34, 83, 83, 70, 27, 3, 48, 40, 75, 4, 8, 41, 59, 70, 11, 39, 29, 15, 97, 1, 93, 25, 19, 40, 52, 48, 67, 4, 64, 38, 6, 81, 51, 51, 13, 58, 31, 98, 33, 4, 20}, { 27, 30, 26, 64, 44, 74, 15, 1, 68, 17, 65, 90, 100, 29, 49, 34, 90, 20, 47, 29, 91, 29, 7, 14, 95, 73, 6, 92, 10, 3, 29, 83, 4, 55, 39, 84, 49, 77, 25, 46, 21, 41, 82, 68, 29, 63, 73}, { 34, 62, 98, 48, 30, 3, 33, 26, 31, 18, 74, 49, 31, 96, 27, 41, 1, 51, 50, 92, 71, 64, 52, 35, 11, 87, 37, 34, 35, 15, 21, 93, 75, 55, 93, 75, 26, 82, 91, 47, 27, 68, 22, 11, 79, 37, 50}, { 13, 43, 58, 13, 7, 51, 77, 46, 73, 11, 82, 31, 23, 72, 42, 46, 92, 85, 67, 44, 13, 77, 60, 51, 40, 88, 34, 8, 75, 92, 99, 75, 98, 3, 52, 9, 73, 94, 6, 96, 95, 26, 45, 64, 10, 25, 72}, { 23, 36, 40, 70, 4, 25, 6, 38, 26, 63, 87, 38, 98, 52, 2, 7, 1, 81, 76, 47, 80, 91, 97, 64, 98, 78, 40, 87, 59, 34, 22, 9, 98, 15, 33, 25, 62, 80, 63, 41, 6, 52, 97, 75, 95, 98, 85}, { 83, 96, 60, 24, 100, 70, 71, 29, 36, 85, 88, 6, 68, 91, 49, 7, 97, 95, 53, 84, 76, 40, 51, 83, 36, 3, 47, 99, 28, 67, 19, 4, 53, 90, 17, 54, 12, 49, 67, 18, 49, 91, 88, 25, 67, 70, 44}, { 33, 17, 47, 94, 34, 17, 70, 65, 1, 36, 34, 93, 97, 20, 25, 16, 46, 96, 74, 48, 50, 10, 87, 99, 11, 5, 97, 42, 7, 54, 60, 72, 99, 38, 24, 45, 61, 32, 75, 66, 82, 55, 11, 63, 87, 48, 85}, { 67, 54, 81, 42, 71, 13, 35, 10, 51, 62, 95, 89, 16, 95, 46, 45, 64, 68, 29, 34, 29, 83, 23, 43, 27, 47, 81, 56, 85, 19, 97, 17, 16, 61, 67, 56, 22, 15, 44, 77, 70, 6, 12, 91, 32, 2, 27}, { 23, 12, 66, 37, 97, 52, 49, 16, 63, 92, 30, 55, 16, 89, 17, 1, 53, 80, 46, 33, 30, 84, 9, 95, 70, 81, 100, 54, 18, 49, 95, 97, 34, 41, 2, 61, 11, 50, 13, 95, 31, 26, 22, 6, 7, 17, 49}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("captain.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 47, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 47, a ustawiła na %d", arr->width);
                    test_error(arr->height == 59, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 59, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 59; ++i)
                        for (int j = 0; j < 47; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("solution.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 47, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 47, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 59, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 59, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 59; ++i)
                        for (int j = 0; j < 47; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 47;
                    small_arr->height = 59;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 47;
                    small_arr->height = 59;   

                    if (!0)
                    {
                        for (int i = 0; i < 59; ++i)
                            for (int j = 0; j < 47; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 53: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST53(void)
{
    // informacje o teście
    test_start(53, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 44, 92, 66, 6, 29, 81, 41, 17, 74, 2, 43, 30, 63, 87, 68, 51, 36, 16, 12, 69, 90, 41, 63, 56}, { 65, 39, 95, 91, 45, 37, 68, 95, 40, 43, 31, 79, 79, 7, 35, 5, 63, 80, 21, 44, 79, 36, 67, 91}, { 96, 34, 50, 100, 80, 63, 55, 6, 91, 86, 30, 46, 39, 60, 51, 28, 54, 15, 53, 23, 23, 85, 69, 54}, { 20, 8, 65, 78, 64, 46, 26, 47, 37, 51, 69, 1, 34, 64, 48, 75, 19, 87, 73, 13, 51, 50, 26, 26}, { 88, 5, 47, 73, 17, 69, 18, 28, 26, 54, 57, 4, 90, 96, 48, 84, 73, 10, 87, 7, 67, 75, 70, 41}, { 47, 52, 48, 13, 14, 2, 89, 14, 66, 22, 58, 17, 33, 38, 3, 17, 31, 41, 91, 40, 85, 84, 37, 19}, { 43, 64, 28, 96, 64, 67, 31, 91, 42, 68, 99, 100, 78, 49, 66, 16, 70, 91, 52, 32, 19, 96, 34, 58}, { 90, 18, 23, 97, 86, 84, 87, 91, 30, 99, 90, 1, 46, 97, 17, 94, 24, 71, 50, 31, 42, 43, 42, 42}, { 82, 45, 86, 68, 60, 4, 98, 29, 7, 71, 90, 65, 52, 68, 32, 91, 71, 61, 85, 43, 29, 100, 84, 30}, { 26, 95, 63, 59, 64, 16, 91, 100, 26, 99, 55, 98, 19, 80, 4, 33, 82, 42, 3, 37, 93, 71, 63, 80}, { 53, 20, 74, 38, 16, 93, 89, 33, 16, 31, 59, 64, 20, 76, 11, 31, 9, 23, 57, 83, 16, 16, 14, 27}, { 9, 90, 54, 74, 89, 32, 71, 74, 74, 90, 93, 32, 58, 33, 47, 16, 60, 64, 96, 29, 30, 43, 47, 56}, { 99, 44, 96, 53, 8, 29, 84, 44, 97, 28, 46, 65, 38, 55, 63, 20, 32, 97, 12, 39, 62, 52, 5, 3}, { 94, 8, 47, 70, 29, 4, 14, 6, 47, 16, 55, 100, 12, 6, 7, 41, 53, 90, 88, 76, 72, 66, 2, 59}, { 100, 85, 82, 98, 75, 16, 66, 93, 54, 69, 44, 36, 10, 96, 91, 46, 3, 67, 61, 52, 84, 100, 60, 17}, { 71, 87, 15, 45, 9, 37, 23, 51, 13, 31, 86, 7, 83, 65, 75, 47, 55, 85, 72, 76, 11, 85, 80, 26}, { 74, 67, 76, 79, 3, 90, 51, 83, 64, 47, 76, 50, 21, 54, 59, 79, 62, 27, 17, 57, 40, 81, 80, 60}};
                    
                    int array_draw_rectangle[17][24] = {{ 44, 92, 66, 6, 29, 81, 41, 17, 74, 2, 43, 30, 63, 87, 68, 51, 36, 16, 12, 69, 90, 41, 63, 56}, { 65, 39, 95, 91, 45, 37, 68, 95, 40, 43, 31, 79, 79, 7, 35, 5, 63, 80, 21, 44, 79, 36, 67, 91}, { 96, 34, 50, 100, 80, 63, 55, 6, 91, 86, 30, 46, 39, 60, 51, 28, 54, 15, 53, 23, 23, 85, 69, 54}, { 20, 8, 65, 78, 64, 46, 26, 47, 37, 51, 69, 1, 34, 64, 48, 75, 19, 87, 73, 13, 51, 50, 26, 26}, { 88, 5, 47, 73, 17, 69, 18, 28, 26, 54, 57, 4, 90, 96, 48, 84, 73, 10, 87, 7, 67, 75, 70, 41}, { 47, 52, 48, 13, 14, 2, 89, 14, 66, 22, 58, 17, 33, 38, 3, 17, 31, 41, 91, 40, 85, 84, 37, 19}, { 43, 64, 28, 96, 64, 67, 31, 91, 42, 68, 99, 100, 78, 49, 66, 16, 70, 91, 52, 32, 19, 96, 34, 58}, { 90, 18, 23, 97, 86, 84, 87, 91, 30, 99, 90, 1, 46, 97, 17, 94, 24, 71, 50, 31, 42, 43, 42, 42}, { 82, 45, 86, 68, 60, 4, 98, 29, 7, 71, 90, 65, 52, 68, 32, 91, 71, 61, 85, 43, 29, 100, 84, 30}, { 26, 95, 63, 59, 64, 16, 91, 100, 26, 99, 55, 98, 19, 80, 4, 33, 82, 42, 3, 37, 93, 71, 63, 80}, { 53, 20, 74, 38, 16, 93, 89, 33, 16, 31, 59, 64, 20, 76, 11, 31, 9, 23, 57, 83, 16, 16, 14, 27}, { 9, 90, 54, 74, 89, 32, 71, 74, 74, 90, 93, 32, 58, 33, 47, 16, 60, 64, 96, 29, 30, 43, 47, 56}, { 99, 44, 96, 53, 8, 29, 84, 44, 97, 28, 46, 65, 38, 55, 63, 20, 32, 97, 12, 39, 62, 52, 5, 3}, { 94, 8, 47, 70, 29, 4, 14, 6, 47, 16, 55, 100, 12, 6, 7, 41, 53, 90, 88, 76, 72, 66, 2, 59}, { 100, 85, 82, 98, 75, 16, 66, 93, 54, 69, 44, 36, 10, 96, 91, 46, 3, 67, 61, 52, 84, 100, 60, 17}, { 71, 87, 15, 45, 9, 37, 23, 51, 13, 31, 86, 7, 83, 65, 75, 47, 55, 85, 72, 76, 11, 85, 80, 26}, { 74, 67, 76, 79, 3, 90, 51, 83, 64, 47, 76, 50, 21, 54, 59, 79, 62, 27, 17, 57, 40, 81, 80, 60}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("gave.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!0)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 54: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST54(void)
{
    // informacje o teście
    test_start(54, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[1][1] = {{ 71}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 71, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("find.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 1;
                    small_arr->height = 1;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 22, 15);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 1;
                    small_arr->height = 1;   

                    if (!0)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 55: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST55(void)
{
    // informacje o teście
    test_start(55, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[1][1] = {{ 71}};
                    
                    int array_draw_rectangle[17][24] = {{ 71, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("find.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 1;
                    small_arr->height = 1;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 1;
                    small_arr->height = 1;   

                    if (!0)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 56: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST56(void)
{
    // informacje o teście
    test_start(56, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[7][21] = {{ 64, 94, 58, 73, 34, 69, 58, 67, 62, 27, 66, 36, 98, 94, 5, 7, 25, 49, 75, 3, 6}, { 26, 22, 64, 65, 55, 37, 30, 77, 61, 90, 4, 42, 53, 72, 86, 2, 38, 95, 4, 20, 90}, { 12, 93, 37, 35, 43, 85, 72, 84, 79, 15, 74, 35, 87, 67, 93, 31, 24, 46, 79, 52, 54}, { 24, 93, 76, 92, 39, 29, 13, 94, 62, 45, 44, 75, 63, 49, 25, 52, 1, 93, 4, 45, 64}, { 73, 27, 2, 67, 53, 8, 71, 95, 25, 55, 20, 37, 91, 37, 91, 91, 64, 48, 40, 65, 11}, { 81, 53, 81, 18, 55, 92, 10, 13, 57, 24, 6, 27, 35, 23, 10, 47, 100, 36, 41, 56, 13}, { 22, 15, 62, 52, 26, 22, 71, 34, 26, 56, 37, 7, 13, 77, 11, 2, 46, 97, 70, 55, 39}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 64, 94, 58, 73, 34, 69, 58, 67, 62, 27, 66, 36, 98, 94, 5, 7, 25, 49, 75, 3, 6, 4, 72, 22}, { 26, 22, 64, 65, 55, 37, 30, 77, 61, 90, 4, 42, 53, 72, 86, 2, 38, 95, 4, 20, 90, 59, 65, 18}, { 12, 93, 37, 35, 43, 85, 72, 84, 79, 15, 74, 35, 87, 67, 93, 31, 24, 46, 79, 52, 54, 57, 62, 21}, { 24, 93, 76, 92, 39, 29, 13, 94, 62, 45, 44, 75, 63, 49, 25, 52, 1, 93, 4, 45, 64, 99, 75, 49}, { 73, 27, 2, 67, 53, 8, 71, 95, 25, 55, 20, 37, 91, 37, 91, 91, 64, 48, 40, 65, 11, 84, 74, 30}, { 81, 53, 81, 18, 55, 92, 10, 13, 57, 24, 6, 27, 35, 23, 10, 47, 100, 36, 41, 56, 13, 95, 5, 58}, { 22, 15, 62, 52, 26, 22, 71, 34, 26, 56, 37, 7, 13, 77, 11, 2, 46, 97, 70, 55, 39, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("letter.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 21, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 21, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 7, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 7, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 7; ++i)
                        for (int j = 0; j < 21; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 21;
                    small_arr->height = 7;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 1);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 21;
                    small_arr->height = 7;   

                    if (!0)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 57: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST57(void)
{
    // informacje o teście
    test_start(57, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[4][3] = {{ 97, 97, 90}, { 25, 77, 61}, { 36, 26, 87}, { 76, 66, 72}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 97, 97, 90, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 25, 77, 61, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 36, 26, 87, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 76, 66, 72, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("front.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 3, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 3, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 4, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 4, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 4; ++i)
                        for (int j = 0; j < 3; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 3;
                    small_arr->height = 4;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 17, 1);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 3;
                    small_arr->height = 4;   

                    if (!0)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 58: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST58(void)
{
    // informacje o teście
    test_start(58, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 1;
                    small_arr->height = 10;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 24, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 59: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST59(void)
{
    // informacje o teście
    test_start(59, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 6;
                    small_arr->height = 4;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 24, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 60: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST60(void)
{
    // informacje o teście
    test_start(60, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 3;
                    small_arr->height = 1;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 17);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 61: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST61(void)
{
    // informacje o teście
    test_start(61, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 8;
                    small_arr->height = 17;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 17);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 62: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST62(void)
{
    // informacje o teście
    test_start(62, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 0;
                    small_arr->height = 7;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 63: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST63(void)
{
    // informacje o teście
    test_start(63, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 13;
                    small_arr->height = 0;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 64: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST64(void)
{
    // informacje o teście
    test_start(64, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 1;
                    small_arr->height = -8;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 65: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST65(void)
{
    // informacje o teście
    test_start(65, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = -11;
                    small_arr->height = 1;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 66: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST66(void)
{
    // informacje o teście
    test_start(66, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 1;
                    small_arr->height = 17;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, -14);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 67: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST67(void)
{
    // informacje o teście
    test_start(67, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 9;
                    small_arr->height = 1;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, -10, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 68: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST68(void)
{
    // informacje o teście
    test_start(68, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 4;
                    small_arr->height = 14;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 14);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 69: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST69(void)
{
    // informacje o teście
    test_start(69, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 47;
                    small_arr->height = 2;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 4, 14);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 70: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST70(void)
{
    // informacje o teście
    test_start(70, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 9;
                    small_arr->height = 1;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 0, 22);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 71: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST71(void)
{
    // informacje o teście
    test_start(71, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};
                    int small_array[17][24] = {{ 35, 16, 59, 98, 48, 14, 46, 93, 9, 1, 28, 20, 92, 10, 100, 99, 66, 29, 81, 44, 86, 71, 61, 27}, { 9, 79, 18, 9, 85, 61, 29, 87, 69, 72, 60, 65, 96, 64, 45, 85, 83, 4, 35, 83, 53, 29, 57, 9}, { 79, 79, 51, 46, 41, 3, 19, 8, 98, 24, 94, 21, 16, 51, 95, 87, 31, 35, 50, 59, 77, 100, 64, 34}, { 98, 92, 47, 17, 3, 97, 82, 33, 9, 20, 57, 70, 40, 88, 47, 46, 40, 70, 86, 64, 63, 68, 37, 51}, { 91, 36, 78, 41, 48, 88, 59, 88, 68, 9, 87, 52, 70, 6, 73, 97, 56, 52, 43, 93, 97, 1, 85, 55}, { 65, 76, 28, 93, 53, 87, 66, 95, 30, 68, 57, 63, 96, 34, 10, 46, 56, 99, 16, 13, 57, 55, 18, 97}, { 28, 63, 94, 86, 66, 43, 6, 41, 77, 13, 71, 94, 14, 26, 27, 12, 38, 100, 96, 45, 81, 73, 47, 71}, { 90, 14, 2, 97, 93, 5, 6, 60, 15, 22, 2, 36, 56, 40, 42, 50, 20, 45, 29, 82, 99, 77, 15, 42}, { 100, 51, 30, 70, 81, 64, 12, 46, 3, 29, 8, 32, 55, 23, 28, 72, 22, 11, 67, 19, 29, 74, 1, 85}, { 70, 78, 47, 60, 40, 80, 97, 33, 100, 63, 74, 66, 63, 33, 43, 65, 29, 93, 71, 2, 6, 3, 34, 70}, { 61, 70, 41, 29, 31, 96, 86, 60, 10, 97, 37, 38, 54, 79, 1, 42, 62, 99, 34, 24, 26, 15, 58, 58}, { 5, 85, 67, 53, 87, 91, 28, 64, 42, 53, 47, 18, 68, 52, 3, 58, 18, 43, 58, 14, 72, 15, 28, 94}, { 98, 92, 30, 1, 16, 20, 20, 49, 96, 95, 81, 72, 10, 46, 89, 82, 27, 15, 66, 81, 1, 64, 8, 49}, { 64, 65, 74, 34, 22, 34, 60, 49, 61, 87, 29, 19, 30, 36, 71, 98, 79, 84, 50, 34, 67, 56, 14, 86}, { 2, 36, 64, 9, 52, 33, 92, 44, 59, 73, 62, 76, 15, 17, 23, 97, 19, 13, 52, 69, 59, 51, 98, 98}, { 26, 6, 33, 26, 81, 33, 88, 9, 33, 72, 13, 20, 79, 75, 54, 9, 82, 86, 40, 38, 70, 34, 10, 14}, { 99, 86, 14, 7, 87, 95, 97, 90, 19, 97, 77, 24, 83, 41, 59, 23, 24, 36, 8, 49, 83, 26, 66, 50}};
                    
                    int array_draw_rectangle[17][24] = {{ 30, 81, 12, 44, 35, 8, 30, 92, 80, 99, 94, 69, 81, 12, 91, 38, 13, 67, 4, 27, 18, 99, 55, 27}, { 94, 45, 82, 29, 61, 33, 53, 53, 46, 86, 13, 42, 34, 51, 40, 99, 21, 27, 72, 99, 32, 4, 72, 22}, { 12, 26, 65, 85, 48, 25, 66, 17, 51, 79, 54, 20, 56, 54, 24, 82, 73, 87, 73, 27, 87, 59, 65, 18}, { 61, 78, 6, 20, 58, 74, 53, 53, 87, 16, 5, 4, 12, 25, 95, 10, 87, 78, 50, 55, 39, 57, 62, 21}, { 91, 80, 60, 99, 56, 28, 88, 36, 57, 82, 9, 86, 23, 84, 20, 59, 51, 91, 80, 20, 15, 99, 75, 49}, { 5, 14, 54, 58, 38, 81, 19, 35, 81, 70, 94, 7, 2, 67, 52, 27, 9, 78, 87, 86, 66, 84, 74, 30}, { 100, 6, 80, 19, 78, 66, 56, 6, 43, 76, 9, 58, 73, 3, 54, 89, 45, 19, 76, 84, 32, 95, 5, 58}, { 73, 30, 81, 32, 12, 66, 24, 61, 40, 98, 61, 54, 98, 86, 81, 7, 73, 49, 40, 27, 13, 29, 24, 34}, { 91, 54, 1, 68, 43, 48, 61, 96, 42, 73, 92, 84, 32, 79, 11, 71, 93, 31, 31, 75, 61, 13, 53, 35}, { 9, 25, 74, 28, 18, 86, 87, 29, 73, 10, 34, 80, 13, 32, 38, 52, 90, 14, 41, 18, 54, 64, 49, 41}, { 17, 28, 82, 15, 73, 42, 59, 42, 57, 64, 40, 97, 82, 65, 88, 14, 43, 36, 76, 86, 71, 31, 77, 36}, { 99, 91, 45, 74, 65, 50, 36, 93, 50, 37, 75, 36, 69, 16, 32, 72, 69, 34, 51, 13, 41, 17, 66, 82}, { 63, 90, 98, 27, 90, 19, 16, 92, 79, 87, 33, 16, 18, 44, 4, 30, 75, 38, 22, 22, 57, 97, 84, 37}, { 47, 44, 53, 72, 20, 76, 93, 93, 47, 31, 96, 40, 62, 44, 93, 73, 10, 54, 83, 47, 81, 31, 43, 5}, { 8, 8, 46, 93, 51, 31, 14, 83, 80, 11, 4, 67, 69, 11, 99, 6, 95, 55, 14, 78, 55, 86, 18, 83}, { 49, 61, 20, 9, 87, 68, 85, 63, 86, 87, 61, 46, 5, 42, 82, 23, 82, 49, 22, 87, 54, 21, 17, 61}, { 54, 83, 69, 41, 32, 70, 30, 40, 1, 47, 97, 83, 41, 1, 20, 7, 70, 92, 5, 66, 82, 19, 63, 32}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("particular.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    struct image_t *small_arr = load_image_t("some.txt", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_arr->width == 24, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 24, a ustawiła na %d", small_arr->width);
                    test_error(small_arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", small_arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 24; ++j)
                            test_error(small_arr->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 23;
                    small_arr->height = 1;

                    printf("#####START#####");
                    int res = draw_image(arr, small_arr, 38, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    small_arr->width = 24;
                    small_arr->height = 17;   

                    if (!1)
                    {
                        for (int i = 0; i < 17; ++i)
                            for (int j = 0; j < 24; ++j)
                                test_error(arr->ptr[i][j] == array_draw_rectangle[i][j], "Funkcja image_draw_rectangle() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array_draw_rectangle[i][j], arr->ptr[i][j]);
                    }

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    printf("#####START#####");
                    destroy_image(&small_arr);
                    printf("#####END#####");

                    test_error(small_arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 72: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST72(void)
{
    // informacje o teście
    test_start(72, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[8][9] = {{ 75, 48, 75, 7, 28, 18, 77, 20, 54}, { 62, 13, 90, 95, 13, 95, 95, 28, 18}, { 2, 20, 30, 82, 99, 7, 92, 61, 18}, { 31, 19, 65, 82, 72, 19, 28, 39, 83}, { 36, 91, 9, 60, 83, 80, 54, 66, 14}, { 55, 79, 32, 16, 22, 90, 64, 22, 55}, { 21, 4, 65, 21, 6, 6, 78, 94, 88}, { 6, 78, 90, 75, 51, 40, 56, 8, 27}};

                int err_code = 3;

                printf("#####START#####");
                struct image_t *arr = load_image_t("neighbor.txt", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                test_error(arr->height == 8, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 8, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 8; ++i)
                    for (int j = 0; j < 9; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                printf("#####START#####");
                int res = draw_image(NULL, arr, 0, 0);
                printf("#####END#####");

                test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_error(arr == NULL, "Funkcja destroy_image() powinna przypisać NULL pod wskaźnik przekazany w parametrze");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 73: Sprawdzanie poprawności działania funkcji draw_image
//
void UTEST73(void)
{
    // informacje o teście
    test_start(73, "Sprawdzanie poprawności działania funkcji draw_image", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = draw_image(NULL, NULL, 0, 0);
                printf("#####END#####");

                test_error(res == 1, "Funkcja draw_image() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 74: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST74(void)
{
    // informacje o teście
    test_start(74, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};
                    int small_array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    struct image_t *small_ar = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_ar != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_ar->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_ar->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", small_ar->width);
                    test_error(small_ar->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", small_ar->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(small_ar->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_ar->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    arr->width = 9;
                    arr->height = -19;

                    printf("#####START#####");
                    int res = draw_image(arr, small_ar, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 9;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&small_ar);
                    printf("#####END#####");


                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 75: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST75(void)
{
    // informacje o teście
    test_start(75, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};
                    int small_array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    struct image_t *small_ar = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_ar != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_ar->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_ar->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", small_ar->width);
                    test_error(small_ar->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", small_ar->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(small_ar->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_ar->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    arr->width = -9;
                    arr->height = -19;

                    printf("#####START#####");
                    int res = draw_image(arr, small_ar, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 9;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&small_ar);
                    printf("#####END#####");


                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 76: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST76(void)
{
    // informacje o teście
    test_start(76, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};
                    int small_array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    struct image_t *small_ar = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_ar != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_ar->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_ar->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", small_ar->width);
                    test_error(small_ar->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", small_ar->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(small_ar->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_ar->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    arr->width = -9;
                    arr->height = 19;

                    printf("#####START#####");
                    int res = draw_image(arr, small_ar, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 9;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&small_ar);
                    printf("#####END#####");


                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 77: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST77(void)
{
    // informacje o teście
    test_start(77, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};
                    int small_array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    struct image_t *small_ar = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_ar != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_ar->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_ar->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", small_ar->width);
                    test_error(small_ar->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", small_ar->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(small_ar->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_ar->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    arr->width = 9;
                    arr->height = 0;

                    printf("#####START#####");
                    int res = draw_image(arr, small_ar, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 9;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&small_ar);
                    printf("#####END#####");


                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 78: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST78(void)
{
    // informacje o teście
    test_start(78, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};
                    int small_array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    struct image_t *small_ar = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_ar != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_ar->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_ar->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", small_ar->width);
                    test_error(small_ar->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", small_ar->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(small_ar->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_ar->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    arr->width = 0;
                    arr->height = 19;

                    printf("#####START#####");
                    int res = draw_image(arr, small_ar, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 9;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&small_ar);
                    printf("#####END#####");


                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 79: Sprawdzanie poprawności działania funkcji image_draw_rectangle
//
void UTEST79(void)
{
    // informacje o teście
    test_start(79, "Sprawdzanie poprawności działania funkcji image_draw_rectangle", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};
                    int small_array[19][9] = {{ 9, 3, 3, 8, 7, 2, 9, 2, 3}, { 1, 7, 2, 6, 3, 8, 9, 5, 9}, { 3, 3, 4, 7, 7, 2, 7, 9, 4}, { 2, 8, 5, 0, 6, 10, 10, 4, 0}, { 2, 2, 1, 3, 0, 10, 5, 2, 3}, { 4, 4, 2, 1, 4, 3, 1, 2, 4}, { 5, 10, 3, 8, 7, 4, 8, 8, 5}, { 8, 9, 3, 0, 2, 2, 7, 0, 9}, { 0, 4, 5, 6, 6, 5, 2, 2, 1}, { 10, 4, 9, 9, 3, 2, 8, 7, 7}, { 7, 4, 5, 8, 2, 9, 6, 7, 8}, { 6, 6, 4, 3, 2, 10, 1, 3, 10}, { 1, 7, 6, 3, 1, 2, 6, 9, 5}, { 1, 8, 2, 1, 2, 10, 8, 0, 1}, { 10, 9, 10, 6, 3, 3, 2, 4, 1}, { 10, 4, 3, 7, 9, 4, 2, 7, 7}, { 3, 4, 9, 5, 1, 1, 6, 10, 9}, { 2, 9, 1, 2, 8, 3, 8, 7, 9}, { 2, 7, 8, 7, 4, 2, 5, 7, 8}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    printf("#####START#####");
                    struct image_t *small_ar = load_image_t("plane.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(small_ar != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(small_ar->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(small_ar->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", small_ar->width);
                    test_error(small_ar->height == 19, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 19, a ustawiła na %d", small_ar->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 19; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(small_ar->ptr[i][j] == small_array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, small_array[i][j], small_ar->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");
                    int res = draw_image(arr, small_ar, 0, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja image_draw_rectangle() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                    arr->width = 9;
                    arr->height = 19;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    printf("#####START#####");
                    destroy_image(&small_ar);
                    printf("#####END#####");


                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 80: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST80(void)
{
    // informacje o teście
    test_start(80, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};

                int err_code = 2;

                printf("#####START#####");
                struct image_t *arr = load_image_t("stretch.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 17; ++i)
                    for (int j = 0; j < 7; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 17; ++i)
                    for (int j = 0; j < 7; ++j)
                    {
                        printf("#####START#####");
                        const int *res = image_get_pixel(arr, j, i);
                        printf("#####END#####");
                        test_error(res != NULL, "Funkcja image_get_pixel() powinna zwrócić adres komórki (%d, %d) w tablicy, a zwróciła NULL", j, i);
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(*res == array[i][j], "Funkcja image_get_pixel() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], *res);
                        
                    }
                    
                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 81: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST81(void)
{
    // informacje o teście
    test_start(81, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};
        
                    int err_code = 2;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 17);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 82: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST82(void)
{
    // informacje o teście
    test_start(82, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};
        
                    int err_code = 4;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 7, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 83: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST83(void)
{
    // informacje o teście
    test_start(83, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};
        
                    int err_code = 2;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 7, 17);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 84: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST84(void)
{
    // informacje o teście
    test_start(84, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};
        
                    int err_code = 1;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 8, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 85: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST85(void)
{
    // informacje o teście
    test_start(85, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};
        
                    int err_code = 2;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 28);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 86: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST86(void)
{
    // informacje o teście
    test_start(86, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};
        
                    int err_code = 4;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, -6, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 87: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST87(void)
{
    // informacje o teście
    test_start(87, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};
        
                    int err_code = 3;
        
                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");
        
                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);
        
                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, -5);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");
        
                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");
        
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 88: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST88(void)
{
    // informacje o teście
    test_start(88, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 7;
                    arr->height = -17;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 7;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 89: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST89(void)
{
    // informacje o teście
    test_start(89, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -7;
                    arr->height = -17;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 7;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 90: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST90(void)
{
    // informacje o teście
    test_start(90, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -7;
                    arr->height = 17;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 7;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 91: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST91(void)
{
    // informacje o teście
    test_start(91, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 7;
                    arr->height = 0;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 7;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 92: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST92(void)
{
    // informacje o teście
    test_start(92, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 17;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 7;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 93: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST93(void)
{
    // informacje o teście
    test_start(93, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][7] = {{ 5, 6, 10, 9, 10, 2, 1}, { 2, 1, 6, 10, 7, 10, 4}, { 2, 1, 8, 1, 10, 1, 3}, { 8, 2, 2, 8, 1, 4, 0}, { 10, 8, 9, 10, 8, 4, 10}, { 4, 6, 2, 4, 6, 5, 3}, { 6, 9, 7, 9, 2, 6, 9}, { 7, 2, 9, 7, 5, 7, 9}, { 1, 1, 6, 8, 2, 10, 2}, { 9, 10, 6, 6, 7, 0, 0}, { 2, 2, 5, 5, 0, 10, 9}, { 3, 2, 6, 8, 4, 7, 3}, { 7, 7, 6, 0, 6, 4, 6}, { 8, 2, 1, 1, 8, 0, 9}, { 3, 10, 8, 4, 4, 1, 10}, { 2, 6, 10, 0, 7, 9, 2}, { 5, 9, 4, 3, 6, 10, 2}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("stretch.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");
                    const int *res = image_get_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                    arr->width = 7;
                    arr->height = 17;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 94: Sprawdzanie poprawności działania funkcji image_get_pixel
//
void UTEST94(void)
{
    // informacje o teście
    test_start(94, "Sprawdzanie poprawności działania funkcji image_get_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


                printf("#####START#####");
                const int *res = image_get_pixel(NULL, 0, 0);
                printf("#####END#####");

                test_error(res == NULL, "Funkcja image_get_pixel() powinna zwrócić NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 95: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST95(void)
{
    // informacje o teście
    test_start(95, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                int err_code = 3;

                printf("#####START#####");
                struct image_t *arr = load_image_t("lot.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 16; ++i)
                    for (int j = 0; j < 6; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 16; ++i)
                    for (int j = 0; j < 6; ++j)
                    {
                        printf("#####START#####");
                        int *res = image_set_pixel(arr, j, i);
                        printf("#####END#####");
                        test_error(res != NULL, "Funkcja image_set_pixel() powinna zwrócić adres komórki (%d, %d) w tablicy, a zwróciła NULL", j, i);
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                        test_error(res == &arr->ptr[i][j], "Funkcja image_set_pixel() zwróciła niepoprawny adres komórki, powinna zwrócić adres komórki (%d, %d)", i, j);

                    }

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 96: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST96(void)
{
    // informacje o teście
    test_start(96, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 16);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 97: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST97(void)
{
    // informacje o teście
    test_start(97, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 6, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 98: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST98(void)
{
    // informacje o teście
    test_start(98, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 6, 16);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 99: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST99(void)
{
    // informacje o teście
    test_start(99, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 3;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 8, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 100: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST100(void)
{
    // informacje o teście
    test_start(100, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 26);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 101: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST101(void)
{
    // informacje o teście
    test_start(101, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, -4, 0);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 102: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST102(void)
{
    // informacje o teście
    test_start(102, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, -10);
                    printf("#####END#####");
                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 103: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST103(void)
{
    // informacje o teście
    test_start(103, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 2;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 6;
                    arr->height = -16;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 16;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 104: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST104(void)
{
    // informacje o teście
    test_start(104, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 0;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -6;
                    arr->height = -16;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 16;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 105: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST105(void)
{
    // informacje o teście
    test_start(105, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -6;
                    arr->height = 16;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 16;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 106: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST106(void)
{
    // informacje o teście
    test_start(106, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 1;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 6;
                    arr->height = 0;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 16;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 107: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST107(void)
{
    // informacje o teście
    test_start(107, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 16;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 16;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 108: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST108(void)
{
    // informacje o teście
    test_start(108, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[16][6] = {{ 7, 9, 8, 8, 6, 9}, { 10, 3, 6, 5, 9, 3}, { 9, 2, 7, 1, 3, 9}, { 7, 6, 10, 1, 2, 0}, { 9, 8, 1, 5, 2, 4}, { 6, 4, 8, 3, 6, 1}, { 1, 7, 4, 0, 4, 0}, { 9, 9, 3, 8, 7, 8}, { 1, 8, 4, 1, 5, 6}, { 4, 4, 0, 7, 1, 5}, { 6, 0, 5, 7, 10, 2}, { 3, 2, 3, 1, 8, 9}, { 4, 1, 3, 10, 6, 6}, { 9, 5, 0, 8, 3, 1}, { 4, 9, 2, 4, 0, 8}, { 3, 4, 4, 4, 9, 9}};

                    int err_code = 4;

                    printf("#####START#####");
                    struct image_t *arr = load_image_t("lot.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 6, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 6, a ustawiła na %d", arr->width);
                    test_error(arr->height == 16, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 16, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 16; ++i)
                        for (int j = 0; j < 6; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");
                    const int *res = image_set_pixel(arr, 0, 0);
                    printf("#####END#####");

                    test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                    arr->width = 6;
                    arr->height = 16;

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 109: Sprawdzanie poprawności działania funkcji image_set_pixel
//
void UTEST109(void)
{
    // informacje o teście
    test_start(109, "Sprawdzanie poprawności działania funkcji image_set_pixel", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


                printf("#####START#####");
                const int *res = image_set_pixel(NULL, 0, 0);
                printf("#####END#####");

                test_error(res == NULL, "Funkcja image_set_pixel() powinna zwrócić NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 110: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST110(void)
{
    // informacje o teście
    test_start(110, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[8][9] = {{ 8, 8, 2, 10, 10, 0, 10, 3, 0}, { 2, 8, 10, 1, 3, 8, 8, 9, 8}, { 2, 9, 6, 3, 6, 10, 6, 4, 0}, { 0, 1, 5, 8, 2, 0, 1, 6, 7}, { 4, 10, 6, 8, 5, 6, 3, 4, 3}, { 4, 6, 9, 10, 6, 4, 9, 2, 4}, { 7, 2, 10, 1, 9, 9, 7, 1, 9}, { 6, 10, 6, 8, 10, 0, 10, 10, 0}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("thought.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 8, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 8, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 8; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("appear.bin", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 111: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST111(void)
{
    // informacje o teście
    test_start(111, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[18][9] = {{ 10, 0, 0, 0, 10, 10, 10, 9, 9}, { 8, 3, 4, 1, 2, 2, 7, 3, 8}, { 4, 1, 5, 8, 1, 5, 4, 5, 1}, { 3, 0, 8, 7, 1, 5, 4, 4, 4}, { 1, 4, 2, 8, 9, 5, 9, 7, 1}, { 8, 1, 0, 1, 5, 1, 0, 1, 1}, { 2, 3, 8, 7, 8, 4, 2, 1, 2}, { 7, 9, 0, 2, 7, 10, 9, 3, 0}, { 8, 2, 9, 10, 3, 5, 9, 2, 2}, { 6, 10, 5, 1, 7, 0, 0, 1, 6}, { 3, 4, 6, 5, 6, 3, 7, 1, 10}, { 5, 10, 10, 0, 8, 3, 3, 7, 6}, { 0, 5, 10, 5, 0, 7, 4, 6, 8}, { 9, 1, 8, 5, 10, 8, 5, 5, 2}, { 3, 5, 3, 9, 7, 4, 2, 4, 8}, { 2, 4, 9, 4, 1, 5, 4, 6, 9}, { 3, 8, 9, 8, 0, 2, 2, 2, 2}, { 3, 4, 4, 1, 3, 9, 4, 10, 4}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("song.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 9, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 9, a ustawiła na %d", arr->width);
                    test_error(arr->height == 18, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 18, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 18; ++i)
                        for (int j = 0; j < 9; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("went.txt", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 112: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST112(void)
{
    // informacje o teście
    test_start(112, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[17][1] = {{ 10}, { 5}, { 9}, { 9}, { 4}, { 6}, { 5}, { 0}, { 6}, { 6}, { 2}, { 6}, { 4}, { 7}, { 7}, { 9}, { 2}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("room.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 17, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 17, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 17; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("againsttxt", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 113: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST113(void)
{
    // informacje o teście
    test_start(113, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][7] = {{ 6, 2, 2, 6, 4, 9, 2}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("raise.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 7, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 7; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("us", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 114: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST114(void)
{
    // informacje o teście
    test_start(114, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[1][1] = {{ 8}};

                    int err_code = 1;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("safe.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 1, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr->width);
                    test_error(arr->height == 1, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 1, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                        for (int j = 0; j < 1; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    printf("#####START#####");                            
                    int res = save_image_t("melodyslipworldanimaldistanteyeshallcoatdeterminewonder", arr);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja save_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", res);

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 115: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST115(void)
{
    // informacje o teście
    test_start(115, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][4] = {{ 6, 3, 7, 10}, { 2, 5, 7, 3}, { 6, 7, 2, 7}, { 7, 8, 6, 5}, { 2, 10, 9, 9}, { 6, 5, 5, 1}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 4, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 4, a ustawiła na %d", arr->width);
                    test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 6; ++i)
                        for (int j = 0; j < 4; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 4;
                    arr->height = -6;

                    printf("#####START#####");                            
                    int res = save_image_t("safe.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 4;
                    arr->height = 6;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 116: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST116(void)
{
    // informacje o teście
    test_start(116, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][4] = {{ 6, 3, 7, 10}, { 2, 5, 7, 3}, { 6, 7, 2, 7}, { 7, 8, 6, 5}, { 2, 10, 9, 9}, { 6, 5, 5, 1}};

                    int err_code = 0;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 4, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 4, a ustawiła na %d", arr->width);
                    test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 6; ++i)
                        for (int j = 0; j < 4; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -4;
                    arr->height = -6;

                    printf("#####START#####");                            
                    int res = save_image_t("safe.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 4;
                    arr->height = 6;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 117: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST117(void)
{
    // informacje o teście
    test_start(117, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][4] = {{ 6, 3, 7, 10}, { 2, 5, 7, 3}, { 6, 7, 2, 7}, { 7, 8, 6, 5}, { 2, 10, 9, 9}, { 6, 5, 5, 1}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 4, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 4, a ustawiła na %d", arr->width);
                    test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 6; ++i)
                        for (int j = 0; j < 4; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = -4;
                    arr->height = 6;

                    printf("#####START#####");                            
                    int res = save_image_t("safe.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 4;
                    arr->height = 6;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 118: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST118(void)
{
    // informacje o teście
    test_start(118, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][4] = {{ 6, 3, 7, 10}, { 2, 5, 7, 3}, { 6, 7, 2, 7}, { 7, 8, 6, 5}, { 2, 10, 9, 9}, { 6, 5, 5, 1}};

                    int err_code = 4;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 4, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 4, a ustawiła na %d", arr->width);
                    test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 6; ++i)
                        for (int j = 0; j < 4; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 4;
                    arr->height = 0;

                    printf("#####START#####");                            
                    int res = save_image_t("safe.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 4;
                    arr->height = 6;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 119: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST119(void)
{
    // informacje o teście
    test_start(119, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][4] = {{ 6, 3, 7, 10}, { 2, 5, 7, 3}, { 6, 7, 2, 7}, { 7, 8, 6, 5}, { 2, 10, 9, 9}, { 6, 5, 5, 1}};

                    int err_code = 3;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 4, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 4, a ustawiła na %d", arr->width);
                    test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 6; ++i)
                        for (int j = 0; j < 4; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 6;

                    printf("#####START#####");                            
                    int res = save_image_t("safe.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 4;
                    arr->height = 6;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 120: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST120(void)
{
    // informacje o teście
    test_start(120, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    int array[6][4] = {{ 6, 3, 7, 10}, { 2, 5, 7, 3}, { 6, 7, 2, 7}, { 7, 8, 6, 5}, { 2, 10, 9, 9}, { 6, 5, 5, 1}};

                    int err_code = 2;

                    printf("#####START#####");                            
                    struct image_t *arr = load_image_t("hit.bin", &err_code);
                    printf("#####END#####");

                    test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                    test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                    test_error(arr->width == 4, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 4, a ustawiła na %d", arr->width);
                    test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 6; ++i)
                        for (int j = 0; j < 4; ++j)
                            test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    arr->width = 0;
                    arr->height = 0;

                    printf("#####START#####");                            
                    int res = save_image_t("safe.bin", arr);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                    arr->width = 4;
                    arr->height = 6;            

                    printf("#####START#####");
                    destroy_image(&arr);
                    printf("#####END#####");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 121: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST121(void)
{
    // informacje o teście
    test_start(121, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[6][4] = {{ 6, 3, 7, 10}, { 2, 5, 7, 3}, { 6, 7, 2, 7}, { 7, 8, 6, 5}, { 2, 10, 9, 9}, { 6, 5, 5, 1}};

                int err_code = 2;

                printf("#####START#####");                            
                struct image_t *arr = load_image_t("hit.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 4, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 4, a ustawiła na %d", arr->width);
                test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                    for (int j = 0; j < 4; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                arr->width = 0;
                arr->height = 0;

                printf("#####START#####");                            
                int res = save_image_t(NULL, arr);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);


                arr->width = 4;
                arr->height = 6;            

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 122: Reakcja funkcji save_image_t na brak możliwości utworzenia pliku (fopen zwróci NULL przy drugim wywołaniu)
//
void UTEST122(void)
{
    // informacje o teście
    test_start(122, "Reakcja funkcji save_image_t na brak możliwości utworzenia pliku (fopen zwróci NULL przy drugim wywołaniu)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 1);
    
    //
    // -----------
    //
    

                int array[6][4] = {{ 6, 3, 7, 10}, { 2, 5, 7, 3}, { 6, 7, 2, 7}, { 7, 8, 6, 5}, { 2, 10, 9, 9}, { 6, 5, 5, 1}};

                int err_code = 4;

                printf("#####START#####");                            
                struct image_t *arr = load_image_t("hit.bin", &err_code);
                printf("#####END#####");

                test_error(err_code == 0, "Funkcja load_image_t() powinna zwrócić kod błędu 0, a zwróciła %d", err_code);

                test_error(arr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr->ptr != NULL, "Funkcja load_image_t() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
                test_error(arr->width == 4, "Funkcja load_image_t() powinna ustawić szerokość macierzy na 4, a ustawiła na %d", arr->width);
                test_error(arr->height == 6, "Funkcja load_image_t() powinna ustawić pojemność tablicy na 6, a ustawiła na %d", arr->height);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                    for (int j = 0; j < 4; ++j)
                        test_error(arr->ptr[i][j] == array[i][j], "Funkcja load_image_t() niepoprawnie wczytała dane w komórce (%d, %d) powinno być %d, a jest %d", i, j, array[i][j], arr->ptr[i][j]);

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                printf("#####START#####");                            
                int res = save_image_t("safe.bin", arr);
                printf("#####END#####");

                test_error(res == 2, "Funkcja save_image_t() powinna zwrócić kod błędu 2, a zwróciła %d", res);

                printf("#####START#####");
                destroy_image(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 123: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST123(void)
{
    // informacje o teście
    test_start(123, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct image_t arr = {.ptr = NULL, .width = 6, .height = 7, .type = "P2" };

                printf("#####START#####");
                int res = save_image_t("hit.bin", &arr);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 124: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST124(void)
{
    // informacje o teście
    test_start(124, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = save_image_t("hit.bin", NULL);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 125: Sprawdzanie poprawności działania funkcji save_image_t
//
void UTEST125(void)
{
    // informacje o teście
    test_start(125, "Sprawdzanie poprawności działania funkcji save_image_t", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = save_image_t(NULL, NULL);
                printf("#####END#####");

                test_error(res == 1, "Funkcja save_image_t() powinna zwrócić kod błędu 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja bład funkcji fopen (dozwolone dwukrotne wywołanie fopen)
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja bład funkcji fopen (dozwolone dwukrotne wywołanie fopen)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_set_function_success_limit(HFC_FOPEN, 2);
    
    //
    // -----------
    //
    
            //printf("Kolejny test pamięci");
            printf("***START***\n");
            int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
            printf("\n***END***\n");
            test_error(ret_code == 5, "Funkcja main zakończyła się kodem %d a powinna 5", ret_code);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci - limit ustawiony na 0 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci - limit ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci - limit ustawiony na 40 bajtów
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci - limit ustawiony na 40 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(40);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na brak pamięci - limit ustawiony na 216 bajtów
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na brak pamięci - limit ustawiony na 216 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(216);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST2, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST3, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST4, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST5, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST6, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST7, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST8, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST9, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST10, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST11, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST12, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST13, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST14, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST15, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST16, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST17, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST18, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST19, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST20, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST21, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST22, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST23, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST24, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST25, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST26, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST27, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST28, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST29, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST30, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST31, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST32, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST33, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST34, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST35, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 147 bajtów)
            UTEST36, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
            UTEST37, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
            UTEST38, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
            UTEST39, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)
            UTEST40, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)
            UTEST41, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)
            UTEST42, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 0 bajtów)
            UTEST43, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 3 bajtów)
            UTEST44, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 27 bajtów)
            UTEST45, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 51 bajtów)
            UTEST46, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 83 bajtów)
            UTEST47, // Sprawdzanie reakcji funkcji load_image_t na limit pamięci (limit sterty ustawiono na 115 bajtów)
            UTEST48, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST49, // Sprawdzanie poprawności działania funkcji load_image_t
            UTEST50, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST51, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST52, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST53, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST54, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST55, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST56, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST57, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST58, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST59, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST60, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST61, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST62, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST63, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST64, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST65, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST66, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST67, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST68, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST69, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST70, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST71, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST72, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST73, // Sprawdzanie poprawności działania funkcji draw_image
            UTEST74, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST75, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST76, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST77, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST78, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST79, // Sprawdzanie poprawności działania funkcji image_draw_rectangle
            UTEST80, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST81, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST82, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST83, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST84, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST85, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST86, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST87, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST88, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST89, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST90, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST91, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST92, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST93, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST94, // Sprawdzanie poprawności działania funkcji image_get_pixel
            UTEST95, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST96, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST97, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST98, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST99, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST100, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST101, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST102, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST103, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST104, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST105, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST106, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST107, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST108, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST109, // Sprawdzanie poprawności działania funkcji image_set_pixel
            UTEST110, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST111, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST112, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST113, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST114, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST115, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST116, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST117, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST118, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST119, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST120, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST121, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST122, // Reakcja funkcji save_image_t na brak możliwości utworzenia pliku (fopen zwróci NULL przy drugim wywołaniu)
            UTEST123, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST124, // Sprawdzanie poprawności działania funkcji save_image_t
            UTEST125, // Sprawdzanie poprawności działania funkcji save_image_t
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(125); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja bład funkcji fopen (dozwolone dwukrotne wywołanie fopen)
            MTEST2, // Reakcja na brak pamięci - limit ustawiony na 0 bajtów
            MTEST3, // Reakcja na brak pamięci - limit ustawiony na 40 bajtów
            MTEST4, // Reakcja na brak pamięci - limit ustawiony na 216 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(4); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}