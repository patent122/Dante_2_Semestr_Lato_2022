#ifndef INC_6_1_INT_OPERATIONS_H
#define INC_6_1_INT_OPERATIONS_H

int add_int(int a, int b);
int sub_int(int a, int b);
int div_int(int a, int b);
int mul_int(int a, int b);
int calculate(int a, int b, int(*function)(int, int));

#endif //INC_6_1_INT_OPERATIONS_H