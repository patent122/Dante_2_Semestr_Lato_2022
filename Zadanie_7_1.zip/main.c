#include <stdio.h>
#include "int_operations.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
    int a, b, opcje, wyniczek;
    printf("Dawaj liczby: ");
    if(scanf("%d %d", &a,&b) != 2)
    {
        printf("Incorrect input\n");
        return 1;
    }

    printf("Choose an operation: ");
    if(scanf("%d", &opcje) != 1)
    {
        printf("Incorrect input\n");
        return 1;
    }

    switch (opcje)

    {
        case 0:
            wyniczek = calculate(a, b, add_int);
            break;
        case 1:
            wyniczek = calculate(a, b, sub_int);
            break;
        case 2:
            wyniczek = calculate(a, b, div_int);
            break;
        case 3:
            wyniczek = calculate(a, b, mul_int);
            break;
        default:
            printf("Incorrect input data\n");
            return 2;
    }

    printf("Result: %d", wyniczek);
    return 0;
}
