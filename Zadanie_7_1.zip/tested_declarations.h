/*
 * Test dla zadania Funkcja przyjmująca wskaźnik do funkcji
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 22:27:44.308203
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta



        #include "int_operations.h"
        
        

#endif // _TESTED_DECLARATIONS_H_