#include "circular_buffer.h"
#include <stdlib.h>
#include <stdio.h>
#include "tested_declarations.h"
#include "rdebug.h"

#define INVALID(b) (b == NULL \
    || b->ptr == NULL \
    || b->capacity <= 0 \
    || b->begin < 0 \
    || b->end < 0 \
    || b->begin > b->capacity \
    || b->end > b->capacity)
#define SET_ERROR_CODE(e, v) if (e != NULL) *e = v

int circular_buffer_create(struct circular_buffer_t* a, int N)
{
    if (a == NULL || N <= 0)
    {
        return 1;
    }
    if ((a->ptr = malloc(N * sizeof(int))) == NULL)
    {
        return 2;
    }
    a->begin = a->end = 0;
    a->capacity = N;
    a->full = 0;
    return 0;
}

int circular_buffer_create_struct(struct circular_buffer_t** cb, int N)
{
    if (cb == NULL || N <= 0)
    {
        return 1;
    }
    if ((*cb = malloc(sizeof(struct circular_buffer_t))) == NULL)
    {
        return 2;
    }
    if (circular_buffer_create(*cb, N) != 0)
    {
        free(*cb);
        return 2;
    }
    return 0;
}

void circular_buffer_destroy(struct circular_buffer_t* a)
{
    if (a == NULL || a->ptr == NULL)
    {
        return;
    }
    free(a->ptr);
}

void circular_buffer_destroy_struct(struct circular_buffer_t** a)
{
    if (a == NULL)
    {
        return;
    }
    circular_buffer_destroy(*a);
    free(*a);
}

int circular_buffer_push_back(struct circular_buffer_t* cb, int value)
{
    if (INVALID(cb))
    {
        return 1;
    }
    *(cb->ptr + cb->end++) = value;
    cb->end %= cb->capacity;
    if (cb->begin == cb->end)
    {
        cb->full = 1;
    }
    if (cb->full)
    {
        cb->begin = cb->end;
    }
    return 0;
}

int circular_buffer_pop_front(struct circular_buffer_t* a, int* err_code)
{
    if (INVALID(a))
    {
        SET_ERROR_CODE(err_code, 1);
        return 1;
    }
    if (circular_buffer_empty(a))
    {
        SET_ERROR_CODE(err_code, 2);
        return 2;
    }
    int item = *(a->ptr + a->begin++);
    a->begin %= a->capacity;
    if (a->begin != a->end)
    {
        a->full = 0;
    }
    SET_ERROR_CODE(err_code, 0);
    return item;
}

int circular_buffer_pop_back(struct circular_buffer_t* a, int* err_code)
{
    if (INVALID(a))
    {
        SET_ERROR_CODE(err_code, 1);
        return 1;
    }
    if (circular_buffer_empty(a))
    {
        SET_ERROR_CODE(err_code, 2);
        return 2;
    }
    if (--a->end < 0)
    {
        a->end = a->capacity - 1;
    }
    int item = *(a->ptr + a->end);
    if (a->begin != a->end)
    {
        a->full = 0;
    }
    SET_ERROR_CODE(err_code, 0);
    return item;
}

int circular_buffer_empty(const struct circular_buffer_t* a)
{
    if (INVALID(a))
    {
        return -1;
    }
    return (!a->full && a->begin == a->end);
}

int circular_buffer_full(const struct circular_buffer_t* a)
{
    if (INVALID(a))
    {
        return -1;
    }
    return (a->full && a->begin == a->end);
}

void circular_buffer_display(const struct circular_buffer_t* a)
{
    int index;

    if (INVALID(a))
    {
        return;
    }
    if (circular_buffer_empty(a))
    {
        return;
    }
    index = a->begin;
    while (1)
    {
        printf("%d ", *(a->ptr + index++));
        if (index == a->capacity)
        {
            index = 0;
        }
        if (index == a->end)
        {
            break;
        }
    }
}

