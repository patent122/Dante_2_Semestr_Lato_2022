#include <stdio.h>
#include "circular_buffer.h"
#include "tested_declarations.h"
#include "rdebug.h"

#define CLEAR_INPUT(void);

int main()
{
    struct circular_buffer_t* cb;
    int buffer_size, err_code, answer;

    printf("Podaj rozmiar bufora: ");
    if (scanf("%d", &buffer_size) != 1)
    {
        printf("Incorrect input\n");
        return 1;
    }
    if (buffer_size < 1)
    {
        printf("Incorrect input data\n");
        return 2;
    }
    err_code = circular_buffer_create_struct(&cb, buffer_size);
    if (err_code == 2)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }
    while (1)
    {
        CLEAR_INPUT();
        printf("Co chcesz zrobic: ");
        if (scanf("%d", &answer) != 1)
        {
            printf("Incorrect input\n");
            circular_buffer_destroy_struct(&cb);
            return 1;
        }
        if (answer == 0)
        {
            circular_buffer_destroy_struct(&cb);
            break;
        }
        else if (answer == 1)
        {
            CLEAR_INPUT();
            printf("Podaj liczbe: ");
            if (scanf("%d", &answer) != 1)
            {
                printf("Incorrect input\n");
                circular_buffer_destroy_struct(&cb);
                return 1;
            }
            circular_buffer_push_back(cb, answer);
        }
        else if (answer == 2)
        {
            answer = circular_buffer_pop_back(cb, &err_code);
            if (err_code == 0)
            {
                printf("%d\n", answer);
            }
            else if (err_code == 2)
            {
                printf("Buffer is empty\n");
            }
        }
        else if (answer == 3)
        {
            answer = circular_buffer_pop_front(cb, &err_code);
            if (err_code == 0)
            {
                printf("%d\n", answer);
            }
            else if (err_code == 2)
            {
                printf("Buffer is empty\n");
            }
        }
        else if (answer == 4)
        {
            if (!circular_buffer_empty(cb))
            {
                circular_buffer_display(cb);
            }
            else
            {
                printf("Buffer is empty");
            }
            printf("\n");
        }
        else if (answer == 5)
        {
            printf("%d\n", circular_buffer_empty(cb));
        }
        else if (answer == 6)
        {
            printf("%d\n", circular_buffer_full(cb));
        }
        else
        {
            printf("Incorrect input data\n");
        }
    }
    return 0;
}

