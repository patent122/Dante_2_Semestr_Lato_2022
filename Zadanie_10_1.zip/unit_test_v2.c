/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Stos - podejście pierwsze
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 12:42:38.349667
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji stack_init
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji stack_init", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    struct stack_t *ptr;

                    printf("#####START#####");
                    int res = stack_init(&ptr, -61);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja stack_init() powinna zwrócić wartość 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {           

                        test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                        test_error(ptr->capacity == -61, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na -61, a ustawiła na %d", ptr->capacity);
                        test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");

                        stack_free(ptr);
                        
                        test_no_heap_leakage();
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                    }
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji stack_init
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji stack_init", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    struct stack_t *ptr;

                    printf("#####START#####");
                    int res = stack_init(&ptr, 0);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja stack_init() powinna zwrócić wartość 1, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!1)
                    {           

                        test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                        test_error(ptr->capacity == 0, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 0, a ustawiła na %d", ptr->capacity);
                        test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");

                        stack_free(ptr);
                        
                        test_no_heap_leakage();
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                    }
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji stack_init
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji stack_init", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    struct stack_t *ptr;

                    printf("#####START#####");
                    int res = stack_init(&ptr, 67);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {           

                        test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                        test_error(ptr->capacity == 67, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 67, a ustawiła na %d", ptr->capacity);
                        test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");

                        stack_free(ptr);
                        
                        test_no_heap_leakage();
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                    }
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji stack_init
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji stack_init", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    struct stack_t *ptr;

                    printf("#####START#####");
                    int res = stack_init(&ptr, 1301);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    if (!0)
                    {           

                        test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                        test_error(ptr->capacity == 1301, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 1301, a ustawiła na %d", ptr->capacity);
                        test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");

                        stack_free(ptr);
                        
                        test_no_heap_leakage();
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                    }
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 332 bajtów)
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 332 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(332);
    
    //
    // -----------
    //
    

                    struct stack_t *ptr;

                    printf("#####START#####");
                    int res = stack_init(&ptr, 79);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                    test_error(ptr->capacity == 79, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 79, a ustawiła na %d", ptr->capacity);
                    test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");

                    stack_free(ptr);
                    
                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 0 bajtów)
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
        

                    struct stack_t *ptr;

                    printf("#####START#####");
                    int res = stack_init(&ptr, 79);
                    printf("#####END#####");

                    test_error(res == 2, "Funkcja stack_init() powinna zwrócić wartość 2, a zwróciła %d", res);
                    test_error(ptr == NULL, "Funkcja stack_init() powinna przypisać NULL pod ptr przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                    
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 16 bajtów)
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 16 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(16);
    
    //
    // -----------
    //
    
        

                    struct stack_t *ptr;

                    printf("#####START#####");
                    int res = stack_init(&ptr, 79);
                    printf("#####END#####");

                    test_error(res == 2, "Funkcja stack_init() powinna zwrócić wartość 2, a zwróciła %d", res);
                    test_error(ptr == NULL, "Funkcja stack_init() powinna przypisać NULL pod ptr przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                    
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 104 bajtów)
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 104 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(104);
    
    //
    // -----------
    //
    
        

                    struct stack_t *ptr;

                    printf("#####START#####");
                    int res = stack_init(&ptr, 79);
                    printf("#####END#####");

                    test_error(res == 2, "Funkcja stack_init() powinna zwrócić wartość 2, a zwróciła %d", res);
                    test_error(ptr == NULL, "Funkcja stack_init() powinna przypisać NULL pod ptr przekazany w parametrze");

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                    
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji stack_init
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji stack_init", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                    printf("#####START#####");
                    int res = stack_init(NULL, 79);
                    printf("#####END#####");

                    test_error(res == 1, "Funkcja stack_init() powinna zwrócić wartość 1, a zwróciła %d", res);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                const int array[] = {54, -62, -21, -51, 66, 87, 9, -65, -93, -58};
        
                struct stack_t *ptr;

                printf("#####START#####");
                int res = stack_init(&ptr, 10);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 10, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 10, a ustawiła na %d", ptr->capacity);
                test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");

                for (int i = 0; i < 10; ++i)
                {
                        printf("#####START#####");
                        res = stack_push(ptr, array[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr->head == i + 1, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i + 1, ptr->head);
                        test_error(ptr->capacity == 10, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 10, a ustawiła na %d", ptr->capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
        
                int additional = -76;
                printf("#####START#####");
                res = stack_push(ptr, additional);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                test_error(ptr->head == 11, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na 11, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 20, "Funkcja stack_push() powinna ustawić wartość pola size w strukturze na 20, a ustawiła na %d", ptr->capacity);
        
                int j;
        
                for (j = 0; j < 10; ++j)
                    test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);
        
                test_error(ptr->data[j] == additional, "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, additional, ptr->data[j]);
        
                stack_free(ptr);
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                const int array[] = {-99, 79, -33, -45, -48, 96, -29, 6, 20, 86, 22, -15, 52, -78, 54, -15, 58, 91, 40, 12, -36, 35, 99, -23, -53, -64, -87, -27, 10, 10, -52, 90, -52, -23, -62, -50, -85, -78, -17, 91, -9, 3, -22, 2, 4, 10, -6, 32, 84, 85, 86, 79, -81, -52, 26};
        
                struct stack_t *ptr;

                printf("#####START#####");
                int res = stack_init(&ptr, 55);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 55, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 55, a ustawiła na %d", ptr->capacity);
                test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");

                for (int i = 0; i < 55; ++i)
                {
                        printf("#####START#####");
                        res = stack_push(ptr, array[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr->head == i + 1, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i + 1, ptr->head);
                        test_error(ptr->capacity == 55, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 55, a ustawiła na %d", ptr->capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
        
                int additional = -96;
                printf("#####START#####");
                res = stack_push(ptr, additional);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                test_error(ptr->head == 56, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na 56, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 110, "Funkcja stack_push() powinna ustawić wartość pola size w strukturze na 110, a ustawiła na %d", ptr->capacity);
        
                int j;
        
                for (j = 0; j < 55; ++j)
                    test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);
        
                test_error(ptr->data[j] == additional, "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, additional, ptr->data[j]);
        
                stack_free(ptr);
        
                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie reakcji funkcji stack_push na limit pamięci (limit sterty ustawiono na 100 bajtów)
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie reakcji funkcji stack_push na limit pamięci (limit sterty ustawiono na 100 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(100);
    
    //
    // -----------
    //
    

            const int array[] = {-85, -50, -57, 98, -53, 99, 96, 6, 50, 93, -63, 28, -14, 12};

            struct stack_t *ptr;

            printf("#####START#####");
            int res = stack_init(&ptr, 7);
            printf("#####END#####");

            test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
            test_error(ptr->capacity == 7, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 7, a ustawiła na %d", ptr->capacity);
            test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");

            for (int i = 0; i < 7; ++i)
            {
                    printf("#####START#####");
                    res = stack_push(ptr, array[i]);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                    test_error(ptr->head == i + 1, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i + 1, ptr->head);
                    test_error(ptr->capacity == 7, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 7, a ustawiła na %d", ptr->capacity);

                    for (int j = 0; j <= i; ++j)
                        test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            }

            for (int i = 7; i < 2 * 7; ++i)
            {
                    printf("#####START#####");
                    res = stack_push(ptr, array[i]);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                    test_error(ptr->head == i + 1, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i + 1, ptr->head);
                    test_error(ptr->capacity == 14, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 14, a ustawiła na %d", ptr->capacity);

                    for (int j = 0; j <= i; ++j)
                        test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            }


            stack_free(ptr);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie reakcji funkcji array_push_back na limit pamięci (limit sterty ustawiono na 44 bajtów)
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie reakcji funkcji array_push_back na limit pamięci (limit sterty ustawiono na 44 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(44);
    
    //
    // -----------
    //
    

            const int array[] = {-85, -50, -57, 98, -53, 99, 96, 6, 50, 93, -63, 28, -14, 12};

            struct stack_t *ptr;

            printf("#####START#####");
            int res = stack_init(&ptr, 7);
            printf("#####END#####");

            test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
            test_error(ptr->capacity == 7, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 7, a ustawiła na %d", ptr->capacity);
            test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");

            int i = 0;

            for (; i < 7; ++i)
            {
                    printf("#####START#####");
                    res = stack_push(ptr, array[i]);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                    test_error(ptr->head == i + 1, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i + 1, ptr->head);
                    test_error(ptr->capacity == 7, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 7, a ustawiła na %d", ptr->capacity);

                    for (int j = 0; j <= i; ++j)
                        test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            }
            
            printf("#####START#####");
            res = stack_push(ptr, array[i]);
            printf("#####END#####");

            test_error(res == 2, "Funkcja stack_push() powinna zwrócić wartość 2, a zwróciła %d", res);
            test_error(ptr->head == i, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i, ptr->head);
            test_error(ptr->capacity == 7, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 7, a ustawiła na %d", ptr->capacity);

            for (int j = 0; j < i; ++j)
                test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            stack_free(ptr);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-60, 19, 70, -96, -25, -68, 22, -42, 68, 49, -88, 30};
                struct stack_t ptr = { .data = array, .head = -6, .capacity = 7 };

                printf("#####START#####");
                int res = stack_push(&ptr, -38);
                printf("#####END#####");

                test_error(res == 1, "Funkcja stack_push() powinna zwrócić wartość 1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-60, 19, 70, -96, -25, -68, 22, -42, 68, 49, -88, 30};
                struct stack_t ptr = { .data = array, .head = 0, .capacity = -9 };

                printf("#####START#####");
                int res = stack_push(&ptr, 67);
                printf("#####END#####");

                test_error(res == 1, "Funkcja stack_push() powinna zwrócić wartość 1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-60, 19, 70, -96, -25, -68, 22, -42, 68, 49, -88, 30};
                struct stack_t ptr = { .data = array, .head = 14, .capacity = 6 };

                printf("#####START#####");
                int res = stack_push(&ptr, 28);
                printf("#####END#####");

                test_error(res == 1, "Funkcja stack_push() powinna zwrócić wartość 1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-60, 19, 70, -96, -25, -68, 22, -42, 68, 49, -88, 30};
                struct stack_t ptr = { .data = array, .head = 0, .capacity = 0 };

                printf("#####START#####");
                int res = stack_push(&ptr, -5);
                printf("#####END#####");

                test_error(res == 1, "Funkcja stack_push() powinna zwrócić wartość 1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-60, 19, 70, -96, -25, -68, 22, -42, 68, 49, -88, 30};
                struct stack_t ptr = { .data = array, .head = 20, .capacity = -4 };

                printf("#####START#####");
                int res = stack_push(&ptr, 26);
                printf("#####END#####");

                test_error(res == 1, "Funkcja stack_push() powinna zwrócić wartość 1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-60, 19, 70, -96, -25, -68, 22, -42, 68, 49, -88, 30};
                struct stack_t ptr = { .data = array, .head = -15, .capacity = -3 };

                printf("#####START#####");
                int res = stack_push(&ptr, 40);
                printf("#####END#####");

                test_error(res == 1, "Funkcja stack_push() powinna zwrócić wartość 1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct stack_t ptr = { .data = NULL, .head = 5, .capacity = 15 };

            printf("#####START#####");
            int res = stack_push(&ptr, 95);
            printf("#####END#####");

            test_error(res == 1, "Funkcja stack_push() powinna zwrócić wartość 1, a zwróciła %d", res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            int res = stack_push(NULL, -38);
            printf("#####END#####");

            test_error(res == 1, "Funkcja stack_push() powinna zwrócić wartość 1, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int array[] = {15, -12, 85, -64, 7, -23, -15, -65, -79, -92, 59, 4, -54, -33, -75, -48, -4, -98, -17};

                struct stack_t *ptr;

                printf("#####START#####");
                int res = stack_init(&ptr, 19);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 19, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 19, a ustawiła na %d", ptr->capacity);
                test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                int err_code = 1;

                stack_pop(ptr, &err_code);

                test_error(err_code == 2, "Funkcja stack_pop() powinna ustawić kod błędu na 2, a zwróciła %d", err_code);

                for (int i = 0; i < 19; ++i)
                {
                        printf("#####START#####");
                        res = stack_push(ptr, array[i]);
                        printf("#####END#####");

                        test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr->head == i + 1, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i + 1, ptr->head);
                        test_error(ptr->capacity == 19, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 19, a ustawiła na %d", ptr->capacity);

                        for (int j = 0; j <= i; ++j)
                            test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                int additional = 12;
                printf("#####START#####");
                res = stack_push(ptr, additional);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                test_error(ptr->head == 20, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na 20, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 38, "Funkcja stack_push() powinna ustawić wartość pola size w strukturze na 38, a ustawiła na %d", ptr->capacity);

                int j;

                for (j = 0; j < 19; ++j)
                    test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                test_error(ptr->data[j] == additional, "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, additional, ptr->data[j]);

                err_code = 2;

                res = stack_pop(ptr, &err_code);

                test_error(res == additional, "Funkcja stack_pop zwróciła nieprawidłową wartość; powinna zwrócić %d, a jest %d", additional, res);
                test_error(err_code == 0, "Funkcja stack_pop() powinna ustawić kod błędu na 0, a zwróciła %d", err_code);

                for (j = 18; j >= 0; --j)
                {

                    int err_code = 1;
        
                    res = stack_pop(ptr, &err_code);
        
                    test_error(res == array[j], "Funkcja stack_pop zwróciła nieprawidłową wartość; powinna zwrócić %d, a jest %d", j, array[j], res);
                    test_error(ptr->head == j, "Funkcja stack_pop() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", j, ptr->head);
                    test_error(ptr->capacity == 38, "Funkcja stack_pop() powinna ustawić wartość pola size w strukturze na 38, a ustawiła na %d", ptr->capacity);
                    test_error(err_code == 0, "Funkcja stack_pop() powinna ustawić kod błędu na 0, a zwróciła %d", err_code);
                }

                err_code = 3;

                stack_pop(ptr, &err_code);

                test_error(err_code == 2, "Funkcja stack_pop() powinna ustawić kod błędu na 2, a zwróciła %d", err_code);

                stack_free(ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int array[] = {-53, -1, -39, -84, 17, -14, -81, 54, 25, -64, -57, 39, -40, -56, -67, 66, 90, -27, -7, 40, 24, 18, 91, 33, -54, -25, -70, 27, -42, -62, 65, -34, -85, -33, -14, -40, 77, 41, -66, -35, 47, 72, -44, -71, 22, 84, -41, -98, -99, -51, -51, -6, 10, -49, 11, -99, 63, -100, -74, -61, -84, 11, 73};

                struct stack_t *ptr;

                printf("#####START#####");
                int res = stack_init(&ptr, 63);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 63, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 63, a ustawiła na %d", ptr->capacity);
                test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                int err_code = 2;

                stack_pop(ptr, &err_code);

                test_error(err_code == 2, "Funkcja stack_pop() powinna ustawić kod błędu na 2, a zwróciła %d", err_code);

                for (int i = 0; i < 63; ++i)
                {
                        printf("#####START#####");
                        res = stack_push(ptr, array[i]);
                        printf("#####END#####");

                        test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr->head == i + 1, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i + 1, ptr->head);
                        test_error(ptr->capacity == 63, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 63, a ustawiła na %d", ptr->capacity);

                        for (int j = 0; j <= i; ++j)
                            test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                int additional = -27;
                printf("#####START#####");
                res = stack_push(ptr, additional);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                test_error(ptr->head == 64, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na 64, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 126, "Funkcja stack_push() powinna ustawić wartość pola size w strukturze na 126, a ustawiła na %d", ptr->capacity);

                int j;

                for (j = 0; j < 63; ++j)
                    test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                test_error(ptr->data[j] == additional, "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, additional, ptr->data[j]);

                err_code = 3;

                res = stack_pop(ptr, &err_code);

                test_error(res == additional, "Funkcja stack_pop zwróciła nieprawidłową wartość; powinna zwrócić %d, a jest %d", additional, res);
                test_error(err_code == 0, "Funkcja stack_pop() powinna ustawić kod błędu na 0, a zwróciła %d", err_code);

                for (j = 62; j >= 0; --j)
                {

                    int err_code = 3;
        
                    res = stack_pop(ptr, &err_code);
        
                    test_error(res == array[j], "Funkcja stack_pop zwróciła nieprawidłową wartość; powinna zwrócić %d, a jest %d", j, array[j], res);
                    test_error(ptr->head == j, "Funkcja stack_pop() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", j, ptr->head);
                    test_error(ptr->capacity == 126, "Funkcja stack_pop() powinna ustawić wartość pola size w strukturze na 126, a ustawiła na %d", ptr->capacity);
                    test_error(err_code == 0, "Funkcja stack_pop() powinna ustawić kod błędu na 0, a zwróciła %d", err_code);
                }

                err_code = 2;

                stack_pop(ptr, &err_code);

                test_error(err_code == 2, "Funkcja stack_pop() powinna ustawić kod błędu na 2, a zwróciła %d", err_code);

                stack_free(ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int array[] = {15, -12, 85, -64, 7, -23, -15, -65, -79, -92, 59, 4, -54, -33, -75, -48, -4, -98, -17};

                struct stack_t *ptr;

                printf("#####START#####");
                int res = stack_init(&ptr, 19);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 19, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 19, a ustawiła na %d", ptr->capacity);
                test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                stack_pop(ptr, NULL);

                for (int i = 0; i < 19; ++i)
                {
                        printf("#####START#####");
                        res = stack_push(ptr, array[i]);
                        printf("#####END#####");

                        test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr->head == i + 1, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i + 1, ptr->head);
                        test_error(ptr->capacity == 19, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 19, a ustawiła na %d", ptr->capacity);

                        for (int j = 0; j <= i; ++j)
                            test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                int additional = 58;
                printf("#####START#####");
                res = stack_push(ptr, additional);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                test_error(ptr->head == 20, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na 20, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 38, "Funkcja stack_push() powinna ustawić wartość pola size w strukturze na 38, a ustawiła na %d", ptr->capacity);

                int j;

                for (j = 0; j < 19; ++j)
                    test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                test_error(ptr->data[j] == additional, "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, additional, ptr->data[j]);

                res = stack_pop(ptr, NULL);

                test_error(res == additional, "Funkcja stack_pop zwróciła nieprawidłową wartość; powinna zwrócić %d, a jest %d", additional, res);

                for (j = 18; j >= 0; --j)
                {
                    res = stack_pop(ptr, NULL);

                    test_error(res == array[j], "Funkcja stack_pop zwróciła nieprawidłową wartość; powinna zwrócić %d, a jest %d", j, array[j], res);
                    test_error(ptr->head == j, "Funkcja stack_pop() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", j, ptr->head);
                    test_error(ptr->capacity == 38, "Funkcja stack_pop() powinna ustawić wartość pola size w strukturze na 38, a ustawiła na %d", ptr->capacity);
                }

                stack_pop(ptr, NULL);

                stack_free(ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji stack_push
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji stack_push", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int array[] = {-53, -1, -39, -84, 17, -14, -81, 54, 25, -64, -57, 39, -40, -56, -67, 66, 90, -27, -7, 40, 24, 18, 91, 33, -54, -25, -70, 27, -42, -62, 65, -34, -85, -33, -14, -40, 77, 41, -66, -35, 47, 72, -44, -71, 22, 84, -41, -98, -99, -51, -51, -6, 10, -49, 11, -99, 63, -100, -74, -61, -84, 11, 73};

                struct stack_t *ptr;

                printf("#####START#####");
                int res = stack_init(&ptr, 63);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_init() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->head == 0, "Funkcja stack_init() powinna ustawić wartość pola head w strukturze na 0, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 63, "Funkcja stack_init() powinna ustawić wartość pola capacity w strukturze na 63, a ustawiła na %d", ptr->capacity);
                test_error(ptr->data != NULL, "Funkcja stack_init() powinna przypisać adres przydzielonej pamięci pod pole data w strukturze, a przypisała NULL");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                stack_pop(ptr, NULL);

                for (int i = 0; i < 63; ++i)
                {
                        printf("#####START#####");
                        res = stack_push(ptr, array[i]);
                        printf("#####END#####");

                        test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr->head == i + 1, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", i + 1, ptr->head);
                        test_error(ptr->capacity == 63, "Funkcja stack_push() powinna ustawić wartość pola capacity w strukturze na 63, a ustawiła na %d", ptr->capacity);

                        for (int j = 0; j <= i; ++j)
                            test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                int additional = 86;
                printf("#####START#####");
                res = stack_push(ptr, additional);
                printf("#####END#####");

                test_error(res == 0, "Funkcja stack_push() powinna zwrócić wartość 0, a zwróciła %d", res);
                test_error(ptr->head == 64, "Funkcja stack_push() powinna ustawić wartość pola head w strukturze na 64, a ustawiła na %d", ptr->head);
                test_error(ptr->capacity == 126, "Funkcja stack_push() powinna ustawić wartość pola size w strukturze na 126, a ustawiła na %d", ptr->capacity);

                int j;

                for (j = 0; j < 63; ++j)
                    test_error(ptr->data[j] == array[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, array[j], ptr->data[j]);

                test_error(ptr->data[j] == additional, "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, additional, ptr->data[j]);

                res = stack_pop(ptr, NULL);

                test_error(res == additional, "Funkcja stack_pop zwróciła nieprawidłową wartość; powinna zwrócić %d, a jest %d", additional, res);

                for (j = 62; j >= 0; --j)
                {
                    res = stack_pop(ptr, NULL);

                    test_error(res == array[j], "Funkcja stack_pop zwróciła nieprawidłową wartość; powinna zwrócić %d, a jest %d", j, array[j], res);
                    test_error(ptr->head == j, "Funkcja stack_pop() powinna ustawić wartość pola head w strukturze na %d, a ustawiła na %d", j, ptr->head);
                    test_error(ptr->capacity == 126, "Funkcja stack_pop() powinna ustawić wartość pola size w strukturze na 126, a ustawiła na %d", ptr->capacity);
                }

                stack_pop(ptr, NULL);

                stack_free(ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = -8, .capacity = 5 };
                
                int err_code = 2;

                printf("#####START#####");
                stack_pop(&ptr, &err_code);
                printf("#####END#####");

                test_error(err_code == 1, "Funkcja stack_pop() powinna ustawić kod błędu na 1, a zwróciła %d", err_code);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = 0, .capacity = -6 };
                
                int err_code = 0;

                printf("#####START#####");
                stack_pop(&ptr, &err_code);
                printf("#####END#####");

                test_error(err_code == 1, "Funkcja stack_pop() powinna ustawić kod błędu na 1, a zwróciła %d", err_code);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = 15, .capacity = 9 };
                
                int err_code = 0;

                printf("#####START#####");
                stack_pop(&ptr, &err_code);
                printf("#####END#####");

                test_error(err_code == 1, "Funkcja stack_pop() powinna ustawić kod błędu na 1, a zwróciła %d", err_code);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = 0, .capacity = 0 };
                
                int err_code = 3;

                printf("#####START#####");
                stack_pop(&ptr, &err_code);
                printf("#####END#####");

                test_error(err_code == 1, "Funkcja stack_pop() powinna ustawić kod błędu na 1, a zwróciła %d", err_code);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = 12, .capacity = -5 };
                
                int err_code = 0;

                printf("#####START#####");
                stack_pop(&ptr, &err_code);
                printf("#####END#####");

                test_error(err_code == 1, "Funkcja stack_pop() powinna ustawić kod błędu na 1, a zwróciła %d", err_code);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = -13, .capacity = -7 };
                
                int err_code = 1;

                printf("#####START#####");
                stack_pop(&ptr, &err_code);
                printf("#####END#####");

                test_error(err_code == 1, "Funkcja stack_pop() powinna ustawić kod błędu na 1, a zwróciła %d", err_code);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct stack_t ptr = { .data = NULL, .head = 1, .capacity = 11 };

            int err_code = 2;

            printf("#####START#####");
            stack_pop(&ptr, &err_code);
            printf("#####END#####");

            test_error(err_code == 1, "Funkcja stack_pop() powinna ustawić kod błędu na 1, a zwróciła %d", err_code);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int err_code = 2;

            printf("#####START#####");
            stack_pop(NULL, &err_code);
            printf("#####END#####");

            test_error(err_code == 1, "Funkcja stack_pop() powinna ustawić kod błędu na 1, a zwróciła %d", err_code);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = -8, .capacity = 5 };

                printf("#####START#####");
                stack_pop(&ptr, NULL);
                printf("#####END#####");

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = 0, .capacity = -6 };

                printf("#####START#####");
                stack_pop(&ptr, NULL);
                printf("#####END#####");

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = 15, .capacity = 9 };

                printf("#####START#####");
                stack_pop(&ptr, NULL);
                printf("#####END#####");

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = 0, .capacity = 0 };

                printf("#####START#####");
                stack_pop(&ptr, NULL);
                printf("#####END#####");

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = 12, .capacity = -5 };

                printf("#####START#####");
                stack_pop(&ptr, NULL);
                printf("#####END#####");

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {96, 22, -25, 49, -1, -66, -59, -69, 21, 44, 90, 90, -22, 4, 19, -94, 40, -50};
                struct stack_t ptr = { .data = array, .head = -13, .capacity = -7 };

                printf("#####START#####");
                stack_pop(&ptr, NULL);
                printf("#####END#####");

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct stack_t ptr = { .data = NULL, .head = 3, .capacity = 20 };


            printf("#####START#####");
            stack_pop(&ptr, NULL);
            printf("#####END#####");


        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji stack_pop
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji stack_pop", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


            printf("#####START#####");
            stack_pop(NULL, NULL);
            printf("#####END#####");

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji stack_free
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji stack_free", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            stack_free(NULL);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji array_display
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji array_display", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int array[] = {-58, 51, -86, -32, 62, 56, -85, -37, -40, 28, -49, -79, 90, -10, 64, 0, -24, 36, -54};

                struct stack_t arr;
                arr.data = array;

        //-------------1-----------------------

                printf("***START***\n");
                stack_display(NULL);
                printf("***END***\n");


        //-------------2-----------------------

                arr.capacity = 18;
                arr.head = 19;

                printf("***START***\n");
                stack_display(&arr);
                printf("***END***\n");


        //-------------3-----------------------

                arr.capacity = 19;
                arr.head = -19;

                printf("***START***\n");
                stack_display(&arr);
                printf("***END***\n");


        //-------------4-----------------------

                arr.capacity = 19;
                arr.head = 0;

                printf("***START***\n");
                stack_display(&arr);
                printf("***END***\n");

        //-------------5-----------------------

                arr.capacity = 19;
                arr.head = 19;
                arr.data = NULL;

                printf("***START***\n");
                stack_display(&arr);
                printf("***END***\n");

        //-------------6-----------------------

                arr.capacity = 19;
                arr.head = 19;
                arr.data = array;

                printf("***START***\n");
                stack_display(&arr);
                printf("***END***\n");

        //-------------7-----------------------

                arr.capacity = 19;
                arr.head = 19 - 1;

                printf("***START***\n");
                stack_display(&arr);
                printf("***END***\n");

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci (limit sterty ustawiono na 16 bajtów)
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci (limit sterty ustawiono na 16 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(16);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci (limit sterty ustawiono na 56 bajtów)
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci (limit sterty ustawiono na 56 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(56);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji stack_init
            UTEST2, // Sprawdzanie poprawności działania funkcji stack_init
            UTEST3, // Sprawdzanie poprawności działania funkcji stack_init
            UTEST4, // Sprawdzanie poprawności działania funkcji stack_init
            UTEST5, // Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 332 bajtów)
            UTEST6, // Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 0 bajtów)
            UTEST7, // Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 16 bajtów)
            UTEST8, // Sprawdzanie reakcji funkcji stack_init na limit pamięci (limit sterty ustawiono na 104 bajtów)
            UTEST9, // Sprawdzanie poprawności działania funkcji stack_init
            UTEST10, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST11, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST12, // Sprawdzanie reakcji funkcji stack_push na limit pamięci (limit sterty ustawiono na 100 bajtów)
            UTEST13, // Sprawdzanie reakcji funkcji array_push_back na limit pamięci (limit sterty ustawiono na 44 bajtów)
            UTEST14, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST15, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST16, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST17, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST18, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST19, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST20, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST21, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST22, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST23, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST24, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST25, // Sprawdzanie poprawności działania funkcji stack_push
            UTEST26, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST27, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST28, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST29, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST30, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST31, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST32, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST33, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST34, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST35, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST36, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST37, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST38, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST39, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST40, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST41, // Sprawdzanie poprawności działania funkcji stack_pop
            UTEST42, // Sprawdzanie poprawności działania funkcji stack_free
            UTEST43, // Sprawdzanie poprawności działania funkcji array_display
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(43); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)
            MTEST2, // Reakcja na brak pamięci (limit sterty ustawiono na 16 bajtów)
            MTEST3, // Reakcja na brak pamięci (limit sterty ustawiono na 56 bajtów)
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(3); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}