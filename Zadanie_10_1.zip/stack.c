#include "stack.h"
#include <stdlib.h>
#include <stdio.h>
#include "tested_declarations.h"
#include "rdebug.h"

int stack_init(struct stack_t** stos, int N) {
    if (stos == NULL) return 1;
    if (N < 1)return 1;
    *stos = malloc(sizeof(struct stack_t));
    if (*stos == NULL) {
        return 2;
    }
    (*stos)->capacity = N;
    (*stos)->data = malloc(N * sizeof(int));
    if ((*stos)->data == NULL) {
        free(*stos);
        *stos = NULL;
        return 2;
    }
    (*stos)->head = 0;
    return 0;
}

int stack_push(struct stack_t* stos, int value) {
    if (stos == NULL) return 1;
    if (stos->data == NULL) return 1;
    if (stos->head > stos->capacity) return 1;
    if (stos->head < 0) return 1;
    if (stos->capacity <= 0)return 1;
    if (stos->head == stos->capacity) {
        int* wskaznik = realloc(stos->data, sizeof(int) * stos->capacity * 2);
        if (wskaznik == NULL) {
            return 2;
        }
        stos->data = wskaznik;
        stos->capacity *= 2;
    }
    *(stos->data + stos->head) = value;
    stos->head++;
    return 0;
}

int stack_pop(struct stack_t* stos, int* kod_wyjscia) {
    if (stos == NULL) {
        if (kod_wyjscia != NULL) *kod_wyjscia = 1;
        return 1;
    }
    if (stos->data == NULL) {
        if (kod_wyjscia != NULL) *kod_wyjscia = 1;
        return 1;
    }
    if (stos->head > stos->capacity) {
        if (kod_wyjscia != NULL) *kod_wyjscia = 1;
        return 1;
    }
    if (stos->head < 0) {
        if (kod_wyjscia != NULL) *kod_wyjscia = 1;
        return 1;
    }
    if (stos->capacity <= 0) {
        if (kod_wyjscia != NULL) *kod_wyjscia = 1;
        return 1;
    }
    if (stos->head == 0) {
        if (kod_wyjscia != NULL) *kod_wyjscia = 2;
        return 1;
    }
    if (kod_wyjscia != NULL) *kod_wyjscia = 0;
    stos->head--;

    return *(stos->data + stos->head);

}

void stack_display(const struct stack_t* stos) {
    if (stos == NULL) {
        return;
    }
    if (stos->data == NULL) {
        return;
    }
    if (stos->head > stos->capacity) {
        return;
    }
    if (stos->head < 0) {
        return;
    }
    if (stos->capacity <= 0) {
        return;
    }
    if (stos->head == 0) {
        return;
    }
    int i;
    for (i = stos->head - 1; i >= 0; i--) {
        printf("%d ", *(stos->data + i));
    }
}

void stack_free(struct stack_t* stos) {
    if (stos != NULL) {
        if (stos->data != NULL) {
            free(stos->data);
        }
        free(stos);
    }
}
