#include <stdio.h>
#include "stack.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main() {
    struct stack_t* stos;
    if (stack_init(&stos, 10) == 2) {
        printf("Failed to allocate memory");
        return 8;
    }
    while (1) {
        printf("Co chcesz zrobic? ");
        int litera;
        if (scanf("%d", &litera) != 1) {
            printf("Incorrect input");
            stack_free(stos);
            return 1;
        }
        int kod_wyjscia;
        switch (litera) {
        case 0:
            stack_free(stos);
            return 0;
            break;
        case 1:
            printf("Podaj liczbe: ");
            if (scanf("%d", &litera) != 1) {
                printf("Incorrect input");
                stack_free(stos);
                return 1;
            }
            if (stack_push(stos, litera)) {
                printf("Failed to allocate memory");
                stack_free(stos);
                return 8;
            }
            break;
        case 2:
            litera = stack_pop(stos, &kod_wyjscia);
            if (kod_wyjscia != 0) {
                printf("Stack is empty\n");
            }
            else {
                printf("%d\n", litera);
            }
            break;
        case 3:
            if (stos->head == 0) {
                printf("Stack is empty\n");
            }
            else {
                stack_display(stos);
                printf("\n");
            }
            break;
        default:
            printf("Incorrect input data\n");
        }
    }
    return 0;
}
