#include "matrix_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int matrix_create(struct matrix_t *macierz, int width, int height)
{
    if (macierz == NULL || height < 1 || width < 1)
        return 1;

    macierz->width = width;
    macierz->height = height;

    macierz->ptr = malloc(height * sizeof(int*));
    if (macierz->ptr == NULL)
    {
        return 2;
    }

    for (int i = 0; i < height; ++i)
    {
        *(macierz->ptr + i) = malloc(width * sizeof(int));
        if (*(macierz->ptr + i) == NULL)
        {
            for (int j = 0; j < i; ++j)
            {
                free(*(macierz->ptr + j));
            }
            free(macierz->ptr);
            return 2;
        }
    }

    return SUCCES;
}

int matrix_read(struct matrix_t *macierz)
{
    if (macierz == NULL || macierz->ptr == NULL || macierz->height < 1 || macierz->width < 1)
        return 1;

    int _width = macierz->width;
    int _height = macierz->height;

    for (int i = 0; i < _height; ++i)
    {
        for (int j = 0; j < _width; ++j)
        {
            int num;
            if(scanf("%d", &num) != 1)
            {
                return 2;
            }
            *(*(macierz->ptr + i) + j) = num;
        }
    }

    return SUCCES;
}
void matrix_display(const struct matrix_t *macierz)
{
    if (macierz == NULL || macierz->ptr == NULL || macierz->height < 1 || macierz->width < 1) return;

    int _width = macierz->width;
    int _height = macierz->height;

    for (int i = 0; i < _height; ++i)
    {
        for (int j = 0; j < _width; ++j)
        {
            printf("%d ", *(*(macierz->ptr + i) + j));
        }
        printf("\n");
    }
}
void matrix_destroy(struct matrix_t *macierz)
{
    if (macierz == NULL ||macierz->height < 1 || macierz->width < 1) return;

    for (int i = 0; i < macierz->height; i++)
    {
        free(*(macierz->ptr + i));
    }
    free(macierz->ptr);
}

struct matrix_t* matrix_create_struct(int width, int height)
{
    if (width < 1 || height < 1) return NULL;

    struct matrix_t *macierz = malloc(sizeof(struct matrix_t));
    if (macierz == NULL) return NULL;

    int error = matrix_create(macierz, width, height);
    if (error == 1 || error == 2)
    {
        free(macierz);
        return NULL;
    }

    return macierz;
}
void matrix_destroy_struct(struct matrix_t **macierz)
{
    if (*macierz == NULL) return;

    matrix_destroy(*macierz);
    free(*macierz);
    *macierz = NULL;
}
struct matrix_t* matrix_transpose(const struct matrix_t *macierz)
{
    if (macierz == NULL || macierz->ptr == NULL || macierz->height < 1 || macierz->width < 1) return NULL;


    struct matrix_t *matrixTranspose = matrix_create_struct(macierz->height, macierz->width);
    if (matrixTranspose == NULL)
        return NULL;

    for (int i = 0; i < matrixTranspose->height; ++i)
    {
        for (int j = 0; j < matrixTranspose->width; ++j)
        {
            int num = *(*(macierz->ptr + j) + i);
            *(*(matrixTranspose->ptr + i) + j) = num;
        }
    }

    return matrixTranspose;
}
int matrix_save_b(const struct matrix_t *macierz, const char *filename)
{
    if (macierz == NULL || macierz->ptr == NULL || filename == NULL || macierz->width < 1 || macierz->height < 1) return 1;

    FILE *file = NULL;
    int _width = macierz->width;
    int _height = macierz->height;

    if ((file = fopen(filename, "wb")) == NULL) return 2;

    //Save width and height
    fwrite(&_width, sizeof(int), 1, file);
    if(ferror(file) != 0)
    {
        fclose(file);
        return 3;
    }
    fwrite(&_height, sizeof(int), 1, file);
    if(ferror(file) != 0)
    {
        fclose(file);
        return 3;
    }

    for (int i = 0; i < _height; ++i)
    {
        for (int j = 0; j < _width; ++j)
        {
            int num = *(*(macierz->ptr + i) + j);
            fwrite(&num, sizeof(int), 1, file);
            if(ferror(file) != 0)
            {
                fclose(file);
                return 3;
            }
        }
    }

    fclose(file);
    return 0;
}
int matrix_save_t(const struct matrix_t *macierz, const char *filename)
{
    if (macierz == NULL || macierz->ptr == NULL || filename == NULL || macierz->width < 1 || macierz->height < 1) return 1;

    FILE *file = NULL;
    int _width = macierz->width;
    int _height = macierz->height;

    if ((file = fopen(filename, "w")) == NULL) return 2;

    //Save width and height
    if (fprintf(file, "%d %d\n", _width, _height) < 0)
    {
        fclose(file);
        return 3;
    }

    for (int i = 0; i < _height; ++i)
    {
        for (int j = 0; j < _width; ++j)
        {
            int num = *(*(macierz->ptr + i) + j);
            if (fprintf(file, "%d ", num) < 0)
            {
                fclose(file);
                return 3;
            }
        }
        fprintf(file, "\n");
    }

    fclose(file);
    return 0;
}
