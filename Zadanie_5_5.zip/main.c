#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "matrix_utils.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
    int wysokosc, szerokosc, blad;
    char *sciezka;
    printf("Podaj szerokość i wysokość: ");
    if (scanf("%d %d", &szerokosc, &wysokosc) != 2)
    {
        printf("Incorrect input\n");
        return INCORECT_INPUT;
    }

    if (szerokosc < 1 || wysokosc < 1)
    {
        printf("Incorrect input data\n");
        return INCORECT_INPUT_DATA;
    }

    struct matrix_t *matrix = matrix_create_struct(szerokosc, wysokosc);
    if (matrix == NULL)
    {
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }

    printf("Podaj liczby: ");
    blad = matrix_read(matrix);
    if (blad == 1 || blad == 2)
    {
        matrix_destroy_struct(&matrix);
        printf("Incorrect input\n");
        return INCORECT_INPUT;
    }

    sciezka = malloc(40 * sizeof(char));
    if (sciezka == NULL)
    {
        matrix_destroy_struct(&matrix);
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }

    printf("Podaj sciezke do pliku: ");
    scanf("%39s", sciezka);

    struct matrix_t *matrixTranspose = matrix_transpose(matrix);
    if (matrixTranspose == NULL)
    {
        matrix_destroy_struct(&matrix);
        free(sciezka);
        printf("Failed to allocate memory\n");
        return FAILED_TO_ALLOCATE_MEMORY;
    }

    char *extension = sciezka + strlen(sciezka) - 4;

    if (strcmp(extension, ".txt") == 0)
    {
        blad = matrix_save_t(matrixTranspose, sciezka);
    }
    else if (strcmp(extension, ".bin") == 0)
    {
        blad = matrix_save_b(matrixTranspose, sciezka);
    }
    else
    {
        matrix_destroy_struct(&matrix);
        matrix_destroy_struct(&matrixTranspose);
        free(sciezka);
        printf("Unsupported file format\n");
        return UNSUPPORTED_FILE_TYPE;
    }
    switch (blad)
    {
        case 0:
            printf("File saved\n");
            break;
        case 2:
            matrix_destroy_struct(&matrix);
            matrix_destroy_struct(&matrixTranspose);
            free(sciezka);
            printf("Couldn't create file\n");
            return COULDNT_CREATE_FILE;
        default:
            break;
    }

    matrix_destroy_struct(&matrix);
    matrix_destroy_struct(&matrixTranspose);
    free(sciezka);
    return 0;
}
