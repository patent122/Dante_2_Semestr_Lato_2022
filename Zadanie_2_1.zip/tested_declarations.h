/*
 * Test dla zadania W punkt
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-09 10:38:59.457198
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta


        struct point_t;

        struct point_t* set(struct point_t* p, int x, int y);
        struct point_t* read(struct point_t* p);
        float distance(const struct point_t* p1, const struct point_t* p2, int *err_code);
        void show(const struct point_t* p);
        

#endif // _TESTED_DECLARATIONS_H_