#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "tested_declarations.h"
#include "rdebug.h"

struct point_t 
{
	int x;
	int y;
};

struct point_t* set(struct point_t* p, int x, int y);
void show(const struct point_t* p);
struct point_t* read(struct point_t* p);
float distance(const struct point_t* p1, const struct point_t* p2, int* err_code);

int main()
{
	struct point_t p1, p2;

	srand(time(NULL));
	if (!read(&p1))
	{
		printf("Incorrect input\n");
		return 1;
	}
	set(&p2, rand() % 20 - 10, rand() % 20 - 10);
	show(&p1);
	show(&p2);
	printf("%.2f\n", distance(&p1, &p2, NULL));

	return 0;
}

struct point_t* set(struct point_t* p, int x, int y)
{
	if (p == NULL)
	{
		return NULL;
	}
	p->x = x;
	p->y = y;
	return p;
}

void show(const struct point_t* p)
{
	if (p == NULL)
	{
		return;
	}

	printf("x = %d; y = %d\n", p->x, p->y);
}

struct point_t* read(struct point_t* p)
{
	if (p == NULL)
	{
		return NULL;
	}
	printf("Podaj wspolrzedna x: ");
	if (scanf("%d", &p->x) != 1)
	{
		return NULL;
	}
	printf("Podaj wspolrzedna y: ");
	if (scanf("%d", &p->y) != 1)
	{
		return NULL;
	}
	return p;
}

float distance(const struct point_t* p1, const struct point_t* p2, int* err_code)
{
	if (p1 == NULL || p2 == NULL)
	{
		if (err_code != NULL)
		{
			*err_code = 1;
		}
		return -1.0f;
	}

	if (err_code != NULL)
	{
		*err_code = 0;
	}

	float dx = p1->x - p2->x;
	float dy = p1->y - p2->y;

	return sqrt(dx * dx + dy * dy);
}

