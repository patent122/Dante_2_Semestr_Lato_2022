/*
 * Test dla zadania Podział na zdania i słowa
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-19 18:40:06.776245
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta


        int split_sentences(const char *text, char ****output);
        int sort_sentences(char ***output);
        void destroy(char ***words);

    

#endif // _TESTED_DECLARATIONS_H_