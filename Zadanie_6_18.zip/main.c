#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdbool.h>
#include "tested_declarations.h"
#include "rdebug.h"

int sort_sentences(char*** wyjscie);

int sort_words(char** slowa);

int split_sentences(const char* tekst, char**** wyjscie);

char** split_words(const char* tekst, unsigned dlugosc);

void destroy(char*** slowa);

void destroy2d(char** slowa);

int length_comparator(const void* aa, const void* bb);

int comparator(const void* aa, const void* bb);

int length_comparator(const void* aa, const void* bb) {
    const char** px1 = *(const char***)aa;
    const char** px2 = *(const char***)bb;

    size_t dlugosc1, dlugosc2;
    dlugosc1 = dlugosc2 = 0;

    for (size_t i = 0; *(px1 + i) != NULL; i++)
        dlugosc1++;

    for (size_t i = 0; *(px2 + i) != NULL; i++)
        dlugosc2++;

    if (dlugosc1 == dlugosc2)
        return 0;

    return dlugosc1 < dlugosc2 ? -1 : 1;
}

int comparator(const void* aa, const void* bb) {
    const char* px1 = *(const char**)aa;
    const char* px2 = *(const char**)bb;

    if (isupper(*px1) && !isupper(*px2))
        return -1;
    else if (!isupper(*px1) && isupper(*px2))
        return 1;

    return strcmp(px1, px2);
}

char** failed_to_allocate_memory(char** pamiec, char* bb, size_t rozmiar) {
    free(bb);
    if (rozmiar)
        for (size_t i = 0; i < rozmiar; i++)
            free(*(pamiec + i));
    free(pamiec);
    return NULL;
}

int failed_to_allocate_sentence(char*** pamiec, size_t rozmiar, char**** wyjscie) {
    if (pamiec) {
        for (size_t k = 0; k < rozmiar; k++) {
            char** wskaznik = *(pamiec + k);
            size_t i = 0;
            for (char* ptr2 = *wskaznik; ptr2 != NULL; ptr2 = *(wskaznik + (++i)))
                free(ptr2);

            free(wskaznik);
        }
    }

    free(pamiec);
    *wyjscie = NULL;
    return 3;
}

char** split_words(const char* tekst, unsigned dlugosc) {
    if (tekst == NULL)
        return NULL;

    char* bufor = NULL;
    char** rezultat = NULL;
    size_t result_size = 0;
    size_t buffer_size = 0;

    while (dlugosc--) {
        char znak = *(tekst++);
        if (isalpha(znak)) {
            if (!buffer_size) 
            {
                char* tymczasowy = NULL;
                if ((tymczasowy = realloc(bufor, sizeof(char) * 2)) == NULL)
                    return failed_to_allocate_memory(rezultat, bufor, result_size);
                else bufor = tymczasowy;

                buffer_size += 2;
            }
            else {
                char* tymczasowy = NULL;
                if ((tymczasowy = realloc(bufor, sizeof(char) * (++buffer_size))) == NULL)
                    return failed_to_allocate_memory(rezultat, bufor, result_size);
                else bufor = tymczasowy;
            }

            *(bufor + (buffer_size - 2)) = znak;
            *(bufor + (buffer_size - 1)) = '\0';
        }
        else {
            if (!buffer_size)
                continue;

            char** tymczasowy = NULL;
            if ((tymczasowy = realloc(rezultat, sizeof(char*) * (++result_size))) == NULL)
                return failed_to_allocate_memory(rezultat, bufor, --result_size);
            else rezultat = tymczasowy;

            *(rezultat + result_size - 1) = bufor;
            bufor = NULL;
            buffer_size = 0;
        }
    }

    if (result_size) {
        char** tymczasowy = NULL;
        if ((tymczasowy = realloc(rezultat, sizeof(char*) * (++result_size))) == NULL)
            return failed_to_allocate_memory(rezultat, bufor, --result_size);
        else rezultat = tymczasowy;

        *(rezultat + result_size - 1) = NULL;
    }

    if (!rezultat) {
        char** tymczasowy = NULL;
        if ((tymczasowy = malloc(sizeof(char*))) == NULL)
            return NULL;
        else rezultat = tymczasowy;
        *rezultat = NULL;
    }
    return rezultat;
}

int split_sentences(const char* tekst, char**** wyjscie) {
    if (wyjscie == NULL)
        return 1;

    if (!strchr(tekst, '.')) {
        *wyjscie = NULL;
        return 2;
    }

    char*** zdania = NULL;
    size_t sentences_size = 0;
    char* poprzedni = (char*)tekst;

    for (char* pchr = strchr(tekst, '.'); pchr != NULL; pchr = strchr(pchr + 1, '.')) {
        char** slowa = NULL;
        if ((pchr - poprzedni) > 1 || (poprzedni == tekst && poprzedni != pchr)) {
            slowa = split_words(poprzedni, (pchr - poprzedni) + 1);
            if (!slowa)
                return failed_to_allocate_sentence(zdania, sentences_size, wyjscie);
        }
        else {
            slowa = malloc(sizeof(char*));
            if (slowa)
                *slowa = NULL;
            else
                return failed_to_allocate_sentence(zdania, sentences_size, wyjscie);
        }
        char*** tymczasowy = realloc(zdania, sizeof(char**) * (sentences_size + 1));

        if (!tymczasowy) {
            destroy2d(slowa);
            return failed_to_allocate_sentence(zdania, sentences_size, wyjscie);
        }
        else zdania = tymczasowy;

        *(zdania + (sentences_size++)) = slowa;
        poprzedni = pchr;
    }

    if (sentences_size) {
        char*** tymczasowy = realloc(zdania, sizeof(char**) * (sentences_size + 1));

        if (!tymczasowy)
            return failed_to_allocate_sentence(zdania, sentences_size, wyjscie);
        else zdania = tymczasowy;

        *(zdania + (sentences_size++)) = NULL;
    }

    *wyjscie = zdania;
    return 0;
}

int sort_sentences(char*** wyjscie) {
    if (wyjscie == NULL)
        return 1;

    size_t dlugosc = 0;
    char*** pamiec = wyjscie;
    while (*(pamiec++) != NULL)
        dlugosc++;

    if (dlugosc > 1) {
        qsort(wyjscie, dlugosc, sizeof(*wyjscie), length_comparator);
    }
    for (size_t i = 0; i < dlugosc; i++) {
        size_t words_num = 0;
        char** slowa = *(wyjscie + i);
        while (*(slowa++) != NULL)
            words_num++;

        qsort(*(wyjscie + i), words_num, sizeof(char*), comparator);
    }

    return 0;
}

int sort_words(char** slowa) {
    if (slowa == NULL)
        return 1;

    size_t dlugosc = 0;
    char** pamiec = slowa;
    while (*(pamiec++) != NULL)
        dlugosc++;

    if (dlugosc > 1)
        qsort(slowa, dlugosc, sizeof(*slowa), comparator);
    return 0;
}

void destroy2d(char** slowa) {
    char** pamiec = slowa;

    while (*(pamiec++) != NULL)
        free(*(pamiec - 1));

    free(slowa);
}

void destroy(char*** slowa) {
    for (size_t i = 0; *(slowa + i) != NULL; i++)
        destroy2d(*(slowa + i));

    free(slowa);
}

int main() {
    char* bufor = malloc(1000);
    if (bufor == NULL) {
        printf("Failed to allocate memory");
        return 8;
    }
    printf("Enter text:");
    scanf("%999[^\n]", bufor);

    char*** kod_wyjscia = NULL;
    int r = split_sentences(bufor, &kod_wyjscia);
    if (r == 3) {
        free(bufor);
        printf("Failed to allocate memory");
        return 8;
    }
    else if (r != 0) {
        printf("Nothing to show");
        free(bufor);
        return 0;
    }

    if (!kod_wyjscia) {
        free(bufor);
        return 0;
    }
    char*** w = kod_wyjscia;
    sort_sentences(w);
    int ok = 0;
    for (size_t i = 0; *(w + i) != NULL; i++) {
        if (*(*(w + i) + 0) != NULL)
            ok = 1;
    }
    if (ok == 0) {
        printf("Nothing to show\n");
    }
    else {
        for (size_t i = 0; *(w + i) != NULL; i++) {
            if (*(*(w + i) + 0) == NULL)
                printf("Nothing to show");
            for (size_t j = 0; *(*(w + i) + j) != NULL; j++) {
                printf("%s ", *(*(w + i) + j));
            }
            printf("\n");
        }
    }

    destroy(kod_wyjscia);
    free(bufor);
    return 0;
}
