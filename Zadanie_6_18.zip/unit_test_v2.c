/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Podział na zdania i słowa
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-19 18:40:06.769189
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 8 bajtów
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 8 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(8);
    
    //
    // -----------
    //
    

                const char *expected_array[][1] = { {" "} };
                const int lenghts[] = { 0 };

                char ***words;
                 
                int res = split_sentences("", &words);
                test_error(res == 2, "Funkcja split_sentences() powinna zwrócić wartość 2, a zwróciła %d", res);

                if (!0)
                    test_error(words == NULL, "Funkcja split_sentences() powinna zwrócić NULL");
                else
                {
                    test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 0; ++i)
                    {    
                        int j;
                        for (j = 0; j < lenghts[i]; ++j)
                            test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                        if (lenghts[i])       
                            test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                    }  
                    test_error(*(words + 0) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 24 bajtów
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 24 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const char *expected_array[][0 + 1] = {{" "}};
                const int lenghts[] = {  0};

                char ***words;
                 
                int res = split_sentences("\"       ,                  -   . \" -      ", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                if (!1)
                    test_error(words == NULL, "Funkcja split_sentences() powinna zwrócić NULL");
                else
                {
                    test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                    {    
                        int j;
                        for (j = 0; j < lenghts[i]; ++j)
                            test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                        if (lenghts[i])       
                            test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                    }  
                    test_error(*(words + 1) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 219 bajtów
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 219 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const char *expected_array[][12 + 1] = {{"Humanity", "is", "acquiring", "all", "the", "right", "technology", "for", "all", "the", "wrong", "reasons"}, {"R"}};
                const int lenghts[] = {  12,  1};

                char ***words;
                 
                int res = split_sentences("Humanity is acquiring all the right technology for all the wrong reasons.-R. Buckminster Fuller", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                if (!1)
                    test_error(words == NULL, "Funkcja split_sentences() powinna zwrócić NULL");
                else
                {
                    test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 2; ++i)
                    {    
                        int j;
                        for (j = 0; j < lenghts[i]; ++j)
                            test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                        if (lenghts[i])       
                            test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                    }  
                    test_error(*(words + 2) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 35 bajtów
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 35 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const char *expected_array[][1 + 1] = {{"It"}};
                const int lenghts[] = {  1};

                char ***words;
                 
                int res = split_sentences("It.", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                if (!1)
                    test_error(words == NULL, "Funkcja split_sentences() powinna zwrócić NULL");
                else
                {
                    test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 1; ++i)
                    {    
                        int j;
                        for (j = 0; j < lenghts[i]; ++j)
                            test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                        if (lenghts[i])       
                            test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                    }  
                    test_error(*(words + 1) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1086 bajtów
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1086 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const char *expected_array[][36 + 1] = {{"The", "things", "you", "do", "for", "yourself", "are", "gone", "when", "you", "are", "gone", "but", "the", "things", "you", "do", "for", "others", "remain", "as", "your", "legacy"}, {"Kalu", "Ndukwe", "Kalu", "In", "three", "words", "I", "can", "sum", "up", "everything", "I", "ve", "learned", "about", "life", "it", "goes", "on"}, {"Robert", "Frost", "Have", "you", "ever", "noticed", "how", "What", "the", "hell", "is", "always", "the", "right", "decision", "to", "make", "Terry", "Johnson", "Happiness", "is", "not", "something", "you", "postpone", "for", "the", "future", "it", "is", "something", "you", "design", "for", "the", "present"}};
                const int lenghts[] = {  23,  19,  36};

                char ***words;
                 
                int res = split_sentences("The things you do for yourself are gone when you are gone, but the things you do for others remain as your legacy. - Kalu Ndukwe Kalu\nIn three words I can sum up everything I\'ve learned about life: it goes on. - Robert Frost\nHave you ever noticed how \'What the hell\' is always the right decision to make? - Terry Johnson\nHappiness is not something you postpone for the future; it is something you design for the present. - Jim Rohn", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                if (!1)
                    test_error(words == NULL, "Funkcja split_sentences() powinna zwrócić NULL");
                else
                {
                    test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 3; ++i)
                    {    
                        int j;
                        for (j = 0; j < lenghts[i]; ++j)
                            test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                        if (lenghts[i])       
                            test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                    }  
                    test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 5105 bajtów
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 5105 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const char *expected_array[][25 + 1] = {{"I", "absolutely", "don", "t", "think", "a", "sentient", "artificial", "intelligence", "is", "going", "to", "wage", "war", "against", "the", "human", "species"}, {"Daniel", "H"}, {"Wilson", "Artificial", "intelligence", "in", "fact", "is", "obviously", "an", "intelligence", "transmitted", "by", "conscious", "subjects", "an", "intelligence", "placed", "in", "equipment"}, {"It", "has", "a", "clear", "origin", "in", "fact", "in", "the", "intelligence", "of", "the", "human", "creators", "of", "such", "equipment"}, {"Pope", "Benedict", "XVI", "As", "he", "read", "I", "fell", "in", "love", "the", "way", "you", "fall", "asleep", "slowly", "and", "then", "all", "at", "once"}, {"John", "Green", "A", "computer", "is", "like", "a", "violin"}, {"You", "can", "imagine", "a", "novice", "trying", "first", "a", "phonograph", "and", "then", "a", "violin"}, {"The", "latter", "he", "says", "sounds", "terrible"}, {"That", "is", "the", "argument", "we", "have", "heard", "from", "our", "humanists", "and", "most", "of", "our", "computer", "scientists"}, {"Computer", "programs", "are", "good", "they", "say", "for", "particular", "purposes", "but", "they", "aren", "t", "flexible"}, {"Neither", "is", "a", "violin", "or", "a", "typewriter", "until", "you", "learn", "how", "to", "use", "it"}, {"Marvin", "Minsky", "The", "unexamined", "life", "is", "not", "worth", "living"}, {"Socrates", "Twenty", "years", "from", "now", "you", "will", "be", "more", "disappointed", "by", "the", "things", "that", "you", "didn", "t", "do", "than", "by", "the", "ones", "you", "did", "do"}, {"So", "throw", "off", "the", "bowlines"}, {"Sail", "away", "from", "the", "safe", "harbor"}, {"Catch", "the", "trade", "winds", "in", "your", "sails"}, {"Explore"}, {"Dream"}, {"Discover"}, {"H"}, {"Jackson", "Brown", "Jr"}, {"Today", "billions", "of", "mobile", "devices", "with", "extraordinary", "power", "are", "uniting", "with", "advancements", "in", "robotics", "artificial", "intelligence", "nanotechnology", "and", "so", "much", "more"}, {"Steve", "Mollenkopf", "Fake", "it", "until", "you", "make", "it", "Act", "as", "if", "you", "had", "all", "the", "confidence", "you", "require", "until", "it", "becomes", "your", "reality"}, {"Brian", "Tracy", "The", "human", "spirit", "must", "prevail", "over", "technology"}, {"Albert", "Einstein", "This", "is", "why", "I", "loved", "technology", "if", "you", "used", "it", "right", "it", "could", "give", "you", "power", "and", "privacy"}, {"Cory", "Doctorow", "In", "a", "time", "of", "deceit", "telling", "the", "truth", "is", "a", "revolutionary", "act"}, {"George", "Orwell", "Perfection", "in", "design", "is", "achieved", "not", "when", "there", "is", "nothing", "more", "to", "add", "but", "when", "there", "is", "nothing", "left", "to", "take", "away"}, {"Antoine", "de", "Saint", "Exupery", "Sometimes", "it", "pays", "to", "stay", "in", "bed", "on", "Monday", "rather", "than", "spending", "the", "rest", "of", "the", "week", "debugging", "Monday", "s", "code"}};
                const int lenghts[] = {  18,  2,  18,  17,  21,  8,  13,  6,  16,  14,  14,  9,  25,  5,  6,  7,  1,  1,  1,  1,  3,  21,  23,  9,  20,  14,  24,  25};

                char ***words;
                 
                int res = split_sentences("I absolutely don\'t think a sentient artificial intelligence is going to wage war against the human species. - Daniel H. Wilson\nArtificial intelligence, in fact, is obviously an intelligence transmitted by conscious subjects, an intelligence placed in equipment. It has a clear origin, in fact, in the intelligence of the human creators of such equipment. - Pope Benedict XVI\nAs he read, I fell in love the way you fall asleep: slowly, and then all at once. - John Green\nA computer is like a violin. You can imagine a novice trying first a phonograph and then a violin. The latter, he says, sounds terrible. That is the argument we have heard from our humanists and most of our computer scientists. Computer programs are good, they say, for particular purposes, but they aren\'t flexible. Neither is a violin, or a typewriter, until you learn how to use it. - Marvin Minsky\nThe unexamined life is not worth living. - Socrates\nTwenty years from now you will be more disappointed by the things that you didn\'t do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.\nToday, billions of mobile devices with extraordinary power are uniting with advancements in robotics artificial intelligence, nanotechnology, and so much more. - Steve Mollenkopf\n\"Fake it until you make it! Act as if you had all the confidence you require until it becomes your reality.\"- Brian Tracy\nThe human spirit must prevail over technology.-Albert Einstein\nThis is why I loved technology: if you used it right, it could give you power and privacy.-Cory Doctorow\nIn a time of deceit telling the truth is a revolutionary act. - George Orwell\n\"Perfection [in design] is achieved, not when there is nothing more to add, but when there is nothing left to take away.\" - Antoine de Saint-Exupery\n\"Sometimes it pays to stay in bed on Monday, rather than spending the rest of the week debugging Monday\'s code.\" - Christopher Thompson", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                if (!1)
                    test_error(words == NULL, "Funkcja split_sentences() powinna zwrócić NULL");
                else
                {
                    test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                    for (int i = 0; i < 28; ++i)
                    {    
                        int j;
                        for (j = 0; j < lenghts[i]; ++j)
                            test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                        if (lenghts[i])       
                            test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                    }  
                    test_error(*(words + 28) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 476 bajtów
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 476 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(476);
    
    //
    // -----------
    //
    


                const char *expected_array[][14 + 1] = {{"Whether", "you", "think", "you", "can", "or", "think", "you", "cant", "youre", "right"}, {"Henry", "Ford"}, {"Technology"}, {" "}, {" "}, {"the", "knack", "of", "so", "arranging", "the", "world", "hat", "we", "dont", "have", "to", "experience", "it"}};
                const int lenghts[] = {  11,  2,  1,  0,  0,  14};

                char ***words;
                 
                int res = split_sentences("Whether you think you can or think you cant, youre right.- Henry Ford.Technology... the knack of so arranging the world +hat we dont have to experience it.  - Max Frisch", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 6) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 787 bajtów
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 787 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(787);
    
    //
    // -----------
    //
    


                const char *expected_array[][22 + 1] = {{"Nobody", "phrases", "it", "this", "way", "but", "I", "think", "that", "artificial", "intelligence", "is", "almost", "a", "humanities", "discipline"}, {"Its", "really", "an", "attempt", "to", "understand", "human", "intelligence", "and", "human", "cognition"}, {"Sebastian", "Thrun"}, {"We", "delight", "in", "the", "beauty", "of", "the", "butterfly", "but", "rarely", "admit", "the", "changes", "it", "has", "gone", "through", "to", "achieve", "that", "beau", "y"}};
                const int lenghts[] = {  16,  11,  2,  22};

                char ***words;
                 
                int res = split_sentences("Nobody phrases it this way, but I think that artificial intelligence is almost a humanities discipline. Its really an attempt to understand human intelligence and human cognition. - Sebastian Thrun.We delight in the beauty of the butterfly, but rarely admit the changes it has gone through to achieve that beau+y. - Maya Angelou", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 368 bajtów
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 368 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(368);
    
    //
    // -----------
    //
    


                const char *expected_array[][12 + 1] = {{"It", "does", "not", "do", "to", "dwell", "on", "dreams", "and", "forget", "to", "live"}, {"J"}, {"K"}, {"Rowling"}, {"Todays", "accomplishments", "were", "yesterdays", "impossibilities"}};
                const int lenghts[] = {  12,  1,  1,  1,  5};

                char ***words;
                 
                int res = split_sentences("It does not do to dwell on dreams and forget to live. - J.K. Rowling.Todays accomplishments were yesterdays impossibilities. - Robert H+ Schuller", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 484 bajtów
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 484 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(484);
    
    //
    // -----------
    //
    


                const char *expected_array[][12 + 1] = {{"The", "future", "belongs", "to", "the", "competent"}, {"Get", "ood", "get", "better", "be", "the", "best", "Success", "Quote", "by", "Brian", "Tracy"}, {"If", "you", "dont", "stand", "for", "something", "you", "will", "fall", "for", "anything"}, {"Gordon", "A"}};
                const int lenghts[] = {  6,  12,  11,  2};

                char ***words;
                 
                int res = split_sentences("The future belongs to the competent. Get +ood, get better, be the best!- Success Quote by Brian Tracy.If you dont stand for something you will fall for anything. - Gordon A. Eadie", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 495 bajtów
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 495 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(495);
    
    //
    // -----------
    //
    


                const char *expected_array[][12 + 1] = {{"The", "truth", "is", "rarely", "pure", "and", "never", "simple"}, {"scar", "Wilde"}, {"Think", "left", "and", "think", "right", "and", "think", "low", "and", "think", "high"}, {"Oh", "the", "thinks", "you", "can", "think", "up", "if", "only", "you", "try", "Dr"}};
                const int lenghts[] = {  8,  2,  11,  12};

                char ***words;
                 
                int res = split_sentences("The truth is rarely pure and never simple. - +scar Wilde.Think left and think right and think low and think high. Oh, the thinks you can think up if only you try! - Dr. Seuss", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 984 bajtów
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 984 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(984);
    
    //
    // -----------
    //
    


                const char *expected_array[][16 + 1] = {{"The", "factory", "of", "the", "future", "will", "have", "only", "two", "employees", "a", "man", "and", "a", "dog"}, {"The", "man", "will", "be", "there", "to", "feed", "the", "dog"}, {"The", "dog", "will", "be", "there", "to", "keep", "the", "man", "from", "touching", "the", "equipment"}, {"Warren", "G"}, {"Bennis"}, {"The", "most", "beautiful", "experience", "we", "can", "have", "is", "the", "mysterious"}, {"It", "is", "the", "fundamental", "emotion", "that", "stands", "at", "the", "cradle", "of", "true", "art", "and", "true", "science"}};
                const int lenghts[] = {  15,  9,  13,  2,  1,  10,  16};

                char ***words;
                 
                int res = split_sentences("The factory of the future will have only two employees,+a man, and a dog.  The man will be there to feed the dog.  The dog will be there to keep the man from touching the equipment.  - Warren G. Bennis.The most beautiful experience we can have is the mysterious. It is the fundamental emotion that stands at the cradle of true art and true science. - Albert Einstein", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 7; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 7) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1166 bajtów
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1166 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1166);
    
    //
    // -----------
    //
    


                const char *expected_array[][16 + 1] = {{"There", "was", "a", "time", "in", "the", "s", "when", "magazine", "writers", "could", "actually", "make", "a", "good", "living"}, {"The", "Saturday", "Evening", "Post", "and", "Colliers", "both", "had", "three", "stories", "in", "each", "issue"}, {"These", "were", "usually", "entertaining", "and", "people", "really", "went", "for", "them"}, {"B", "t", "then", "television", "came", "along", "and", "now", "of", "course", "information", "technology"}, {" "}, {" "}, {"the", "new", "way", "of", "killing", "time"}, {"Tom", "Wolfe"}, {"Hold", "fast", "to", "dreams", "For", "if", "dreams", "dieLife", "is", "a", "broken", "winged", "bird", "That", "cannot", "fly"}};
                const int lenghts[] = {  16,  13,  10,  12,  0,  0,  6,  2,  16};

                char ***words;
                 
                int res = split_sentences("There was a time in the 1930s when magazine writers could actually make a good living. The Saturday Evening Post and Colliers both had three stories in each issue. These were usually entertaining, and people really went for them. B+t then television came along, and now of course, information technology... the new way of killing time. - Tom Wolfe.Hold fast to dreams,For if dreams dieLife is a broken-winged bird,That cannot fly. - Langston Hughes", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 9; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 9) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 941 bajtów
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 941 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(941);
    
    //
    // -----------
    //
    


                const char *expected_array[][21 + 1] = {{"TV", "and", "the", "Internet", "are", "good", "because", "they", "keep", "stupid", "people", "from", "spending", "too", "much", "time", "out", "in", "public"}, {"Douglas", "Coupland"}, {"When", "I", "despair", "I", "remember", "tha", "all", "through", "history", "the", "way", "of", "truth", "and", "love", "have", "always", "won"}, {"There", "have", "been", "tyrants", "and", "murderers", "and", "for", "a", "time", "they", "can", "seem", "invincible", "but", "in", "the", "end", "they", "always", "fall"}, {"Think", "of", "it", "always"}};
                const int lenghts[] = {  19,  2,  18,  21,  4};

                char ***words;
                 
                int res = split_sentences("TV and the Internet are good because they keep stupid people from spending too much time out in public.-Douglas Coupland.When I despair, I remember tha+ all through history the way of truth and love have always won. There have been tyrants and murderers, and for a time, they can seem invincible, but in the end, they always fall. Think of it--always. - Mahatma Gandhi", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 711 bajtów
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 711 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(711);
    
    //
    // -----------
    //
    


                const char *expected_array[][23 + 1] = {{"The", "real", "danger", "is", "not", "that", "computers", "will", "begin", "to", "think", "like", "men", "but", "that", "men", "will", "begin", "to", "t", "ink", "like", "computers"}, {"Sydney", "J"}, {"Harris"}, {"The", "most", "important", "property", "of", "a", "program", "is", "whether", "it", "accomplishes", "the", "intention", "of", "its", "user"}, {"C"}, {"A"}, {"R"}};
                const int lenghts[] = {  23,  2,  1,  16,  1,  1,  1};

                char ***words;
                 
                int res = split_sentences("The real danger is not that computers will begin to think like men, but that men will begin to t+ink like computers.-Sydney J. Harris.The most important property of a program is whether it accomplishes the intention of its user. - C.A.R. Hoare", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 7; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 7) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 798 bajtów
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 798 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(798);
    
    //
    // -----------
    //
    


                const char *expected_array[][20 + 1] = {{"Im", "selfish", "impatient", "and", "a", "little", "insecure"}, {"I", "make", "mistakes", "I", "am", "out", "of", "control", "and", "at", "times", "hard", "to", "handle"}, {"But", "if", "you", "cant", "handle", "me", "at", "my", "worst", "then", "you", "sure", "as", "hell", "dont", "deserve", "me", "at", "my", "best"}, {"Marilyn", "Monroe"}, {"There", "is", "nothing", "either", "good", "or", "bad", "but", "thinking", "makes", "it", "so"}};
                const int lenghts[] = {  7,  14,  20,  2,  12};

                char ***words;
                 
                int res = split_sentences("Im selfish, impatient and a little insecure. I make mistakes, I am out of control and at times hard to+handle. But if you cant handle me at my worst, then you sure as hell dont deserve me at my best. - Marilyn Monroe.There is nothing either good or bad, but thinking makes it so. - William Shakespeare", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 716 bajtów
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 716 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(716);
    
    //
    // -----------
    //
    


                const char *expected_array[][28 + 1] = {{"Computers", "are", "useless"}, {"They", "can", "only", "give", "you", "answers"}, {"Pablo", "Picasso"}, {"Programming", "today", "is", "a", "race", "between", "software", "engineers", "st", "iving", "to", "build", "bigger", "and", "better", "idiot", "proof", "programs", "and", "the", "universe", "trying", "to", "build", "bigger", "and", "better", "idiots"}, {"So", "far", "the", "universe", "is", "winning"}};
                const int lenghts[] = {  3,  6,  2,  28,  6};

                char ***words;
                 
                int res = split_sentences("Computers are useless. They can only give you answers.-Pablo Picasso.Programming today is a race between software engineers st+iving to build bigger and better idiot-proof programs, and the universe trying to build bigger and better idiots. So far, the universe is winning. - Rick Cook", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 669 bajtów
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 669 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(669);
    
    //
    // -----------
    //
    


                const char *expected_array[][17 + 1] = {{"Technology", "makes", "it", "possible", "for", "people", "to", "gain", "control", "over", "everything", "except", "over", "technology"}, {"John", "Tudor"}, {"The", "story", "so", "far", "In", "the", "beginning", "the", "Universe", "was", "created"}, {"This", "has", "made", "a", "lot", "of", "people", "very", "angry", "and", "been", "widely", "regarded", "as", "a", "bad", "move"}};
                const int lenghts[] = {  14,  2,  11,  17};

                char ***words;
                 
                int res = split_sentences("Technology makes it possible for people to gain control over everything, except over technology. - John Tudor.The story so far: In the beginning the Universe was created. This has made a lot of people very angry and been widely regarded as a bad move. - Douglas Adams, The Resta+rant at the End of the Universe", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1149 bajtów
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1149 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1149);
    
    //
    // -----------
    //
    


                const char *expected_array[][56 + 1] = {{"The", "flower", "that", "blooms", "in", "adversity", "is", "the", "rarest", "and", "most", "beautiful", "of", "all"}, {"Walt", "Disney", "Company"}, {"I", "love", "you", "without", "knowing", "how", "or", "when", "or", "from", "where"}, {"I", "love", "you", "simply", "without", "problems", "or", "pride", "I", "love", "you", "in", "this", "way", "because", "I", "do", "not", "know", "any", "other", "way", "of", "loving", "but", "this", "in", "which", "there", "is", "no", "I", "or", "you", "so", "intimate", "that", "your", "hand", "upon", "my", "chest", "is", "my", "hand", "so", "intimate", "that", "when", "I", "fall", "asleep", "your", "e", "es", "close"}};
                const int lenghts[] = {  14,  3,  11,  56};

                char ***words;
                 
                int res = split_sentences("The flower that blooms in adversity is the rarest and most beautiful of all. - Walt Disney Company.I love you without knowing how, or when, or from where. I love you simply, without problems or pride: I love you in this way because I do not know any other way of loving but this, in which there is no I or you, so intimate that your hand upon my chest is my hand, so intimate that when I fall asleep your e+es close. - Pablo Neruda", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 406 bajtów
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 406 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(406);
    
    //
    // -----------
    //
    


                const char *expected_array[][19 + 1] = {{"This", "is", "why", "I", "loved", "technol", "gy", "if", "you", "used", "it", "right", "it", "could", "give", "you", "power", "and", "privacy"}, {"Cory", "Doctorow"}, {"Love", "is", "the", "absence", "of", "judgment"}};
                const int lenghts[] = {  19,  2,  6};

                char ***words;
                 
                int res = split_sentences("This is why I loved technol+gy: if you used it right, it could give you power and privacy.-Cory Doctorow.Love is the absence of judgment. - Dalai Lama XIV", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 417 bajtów
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 417 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(417);
    
    //
    // -----------
    //
    


                const char *expected_array[][13 + 1] = {{"The", "art", "challenges", "the", "technology", "and", "the", "technology", "inspires", "the", "art"}, {"John", "Lasseter"}, {"The", "man", "who", "has", "confidence", "in", "himself", "gains", "the", "confidence", "of", "oth", "rs"}};
                const int lenghts[] = {  11,  2,  13};

                char ***words;
                 
                int res = split_sentences("The art challenges the technology, and the technology inspires the art.-John Lasseter.The man who has confidence in himself gains the confidence of oth+rs.- Hasidic Proverb", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 841 bajtów
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 841 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(841);
    
    //
    // -----------
    //
    


                const char *expected_array[][39 + 1] = {{"A", "variety", "of", "national", "and", "international", "studies", "indicate", "that", "the", "broad", "based", "deployment", "of", "information", "technology", "can", "have", "a", "substantial", "impact", "on", "our", "nations", "economic", "productivity", "and", "growth", "as", "ell", "as", "the", "educational", "and", "social", "success", "of", "our", "citizens"}, {"Tim", "Holden"}, {"Things", "work", "out", "best", "for", "those", "who", "make", "the", "best", "of", "how", "things", "work", "out"}};
                const int lenghts[] = {  39,  2,  15};

                char ***words;
                 
                int res = split_sentences("A variety of national and international studies indicate that the broad-based deployment of information technology can have a substantial impact on our nations economic productivity and growth as +ell as the educational and social success of our citizens. - Tim Holden.Things work out best for those who make the best of how things work out. - Positive Quote by John Wooden", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 430 bajtów
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 430 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(430);
    
    //
    // -----------
    //
    


                const char *expected_array[][12 + 1] = {{"Humanity", "is", "acquiring", "all", "the", "right", "technology", "for", "all", "the", "wrong", "reasons"}, {"R"}, {"Buckminster", "Fuller"}, {"Whether", "you", "think", "you", "can", "or", "think", "you", "cant", "youre", "right"}};
                const int lenghts[] = {  12,  1,  2,  11};

                char ***words;
                 
                int res = split_sentences("Humanity is acquiring all the right technology for all the wrong reasons.  - R. Buckminster Fuller.Whether you think you can or think you cant, youre right.+ Henry Ford", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1346 bajtów
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1346 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1346);
    
    //
    // -----------
    //
    


                const char *expected_array[][30 + 1] = {{"And", "now", "here", "is", "my", "secret", "a", "very", "simple", "secret", "It", "is", "only", "with", "the", "heart", "that", "one", "can", "see", "rightly", "what", "is", "essential", "is", "invisible", "to", "the", "eye"}, {"Antoine", "de", "Saint", "Exupery"}, {"All", "that", "is", "gold", "does", "not", "glitter", "Not", "all", "those", "who", "wander", "are", "lost", "The", "old", "that", "is", "strong", "does", "not", "wither", "Deep", "roots", "are", "not", "reached", "by", "the", "frost"}, {"From", "the", "ashes", "a", "fire", "shall", "be", "woken", "A", "light", "from", "the", "shadows", "shall", "spring", "Renewed", "shall", "be", "blade", "that", "was", "broken", "The", "crownless", "ag", "in", "shall", "be", "king"}, {"J"}, {"R"}, {"R"}};
                const int lenghts[] = {  29,  4,  30,  29,  1,  1,  1};

                char ***words;
                 
                int res = split_sentences("And now here is my secret, a very simple secret: It is only with the heart that one can see rightly; what is essential is invisible to the eye. - Antoine de Saint-Exupery.All that is gold does not glitter,Not all those who wander are lost;The old that is strong does not wither,Deep roots are not reached by the frost.From the ashes a fire shall be woken,A light from the shadows shall spring;Renewed shall be blade that was broken,The crownless ag+in shall be king. - J.R.R. Tolkien", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 7; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 7) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1405 bajtów
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1405 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1405);
    
    //
    // -----------
    //
    


                const char *expected_array[][33 + 1] = {{"Fantasy", "is", "escapist", "and", "that", "is", "its", "glory"}, {"If", "a", "soldier", "is", "imprisioned", "by", "the", "enemy", "dont", "we", "consider", "it", "his", "duty", "to", "escape"}, {" "}, {" "}, {"If", "we", "value", "the", "freedom", "of", "mind", "and", "soul", "if", "were", "partisans", "of", "liberty", "then", "its", "our", "plain", "duty", "to", "escape", "and", "to", "take", "as", "many", "people", "with", "us", "as", "we", "can", "J"}, {"R"}, {"R"}, {"Tolkien"}, {"Im", "fascinated", "by", "the", "idea", "that", "ge", "etics", "is", "digital"}, {"A", "gene", "is", "a", "long", "sequence", "of", "coded", "letters", "like", "computer", "information"}, {"Modern", "biology", "is", "becoming", "very", "much", "a", "branch", "of", "information", "technology"}};
                const int lenghts[] = {  8,  16,  0,  0,  33,  1,  1,  1,  10,  12,  11};

                char ***words;
                 
                int res = split_sentences("Fantasy is escapist, and that is its glory. If a soldier is imprisioned by the enemy, dont we consider it his duty to escape?. . .If we value the freedom of mind and soul, if were partisans of liberty, then its our plain duty to escape, and to take as many people with us as we can! - J.R.R. Tolkien.Im fascinated by the idea that ge+etics is digital. A gene is a long sequence of coded letters, like computer information. Modern biology is becoming very much a branch of information technology. - Richard Dawkins", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 11; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 11) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 662 bajtów
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 662 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(662);
    
    //
    // -----------
    //
    


                const char *expected_array[][14 + 1] = {{"Never", "doubt", "that", "a", "small", "group", "of", "thoughtful", "committe", "citizens", "can", "change", "the", "world"}, {"Indeed", "it", "is", "the", "only", "thing", "that", "ever", "has"}, {"Margaret", "Mead"}, {"Technology"}, {" "}, {" "}, {"the", "knack", "of", "so", "arranging", "the", "world", "that", "we", "dont", "have", "to", "experience", "it"}};
                const int lenghts[] = {  14,  9,  2,  1,  0,  0,  14};

                char ***words;
                 
                int res = split_sentences("Never doubt that a small group of thoughtful, committe+, citizens can change the world. Indeed, it is the only thing that ever has. - Margaret Mead.Technology... the knack of so arranging the world that we dont have to experience it.  - Max Frisch", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 7; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 7) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1301 bajtów
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1301 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1301);
    
    //
    // -----------
    //
    


                const char *expected_array[][17 + 1] = {{"Im", "fascinated", "by", "the", "idea", "that", "genetics", "is", "digital"}, {"A", "gene", "is", "a", "long", "sequence", "of", "coded", "letters", "like", "computer", "information"}, {"Modern", "biology", "is", "becoming", "very", "much", "a", "branch", "of", "information", "technology"}, {"Richard", "D", "wkins"}, {"As", "a", "technology", "the", "book", "is", "like", "a", "hammer"}, {"That", "is", "to", "say", "it", "is", "perfect", "a", "tool", "ideally", "suited", "to", "its", "task"}, {"Hammers", "can", "be", "tweaked", "and", "varied", "but", "will", "never", "go", "obsolete"}, {"Even", "when", "builders", "pound", "nails", "by", "the", "thousand", "with", "pneumatic", "nail", "guns", "every", "household", "needs", "a", "hammer"}};
                const int lenghts[] = {  9,  12,  11,  3,  9,  14,  11,  17};

                char ***words;
                 
                int res = split_sentences("Im fascinated by the idea that genetics is digital. A gene is a long sequence of coded letters, like computer information. Modern biology is becoming very much a branch of information technology. - Richard D+wkins.As a technology, the book is like a hammer. That is to say, it is perfect: a tool ideally suited to its task. Hammers can be tweaked and varied but will never go obsolete. Even when builders pound nails by the thousand with pneumatic nail guns, every household needs a hammer.-James Gleick", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 8; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 8) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 837 bajtów
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 837 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(837);
    
    //
    // -----------
    //
    


                const char *expected_array[][14 + 1] = {{"Our", "intuition", "about", "the", "future", "is", "linear"}, {"But", "the", "reality", "of", "information", "technology", "is", "exponential", "and", "that", "makes", "a", "profound", "difference"}, {"I", "I", "take", "steps", "linearly", "I", "get", "to"}, {"If", "I", "take", "steps", "exponentially", "I", "get", "to", "a", "billion"}, {"Ray", "Kurzweil"}, {"Its", "not", "the", "load", "that", "breaks", "you", "down", "its", "the", "way", "you", "carry", "it"}};
                const int lenghts[] = {  7,  14,  8,  10,  2,  14};

                char ***words;
                 
                int res = split_sentences("Our intuition about the future is linear. But the reality of information technology is exponential, and that makes a profound difference. I+ I take 30 steps linearly, I get to 30. If I take 30 steps exponentially, I get to a billion. - Ray Kurzweil.Its not the load that breaks you down, its the way you carry it. - Lou Holtz", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 6) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 289 bajtów
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 289 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(289);
    
    //
    // -----------
    //
    


                const char *expected_array[][7 + 1] = {{"Healthcare", "is", "becoming", "part", "of", "information", "technology"}, {"Bill", "Maris"}, {"The", "unexamined", "life", "is", "not", "worth", "living"}};
                const int lenghts[] = {  7,  2,  7};

                char ***words;
                 
                int res = split_sentences("Healthcare is becoming part of information technology. - Bill Maris.The unexamined life+is not worth living. - Socrates", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 404 bajtów
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 404 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(404);
    
    //
    // -----------
    //
    


                const char *expected_array[][13 + 1] = {{"Never", "interrupt", "your", "enemy", "when", "he", "is", "making", "a", "mistake"}, {"Napoleon", "Bonaparte"}, {"Perl", "The", "only", "language", "that", "ooks", "the", "same", "before", "and", "after", "RSA", "encryption"}};
                const int lenghts[] = {  10,  2,  13};

                char ***words;
                 
                int res = split_sentences("Never interrupt your enemy when he is making a mistake. - Napoleon Bonaparte.Perl - The only language that +ooks the same before and after RSA encryption. - Keith Bostic", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 657 bajtów
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 657 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(657);
    
    //
    // -----------
    //
    


                const char *expected_array[][16 + 1] = {{"Imperfection", "is", "beauty", "madness", "is", "genius", "and", "its", "better", "to", "be", "absolutely", "ridiculous", "than", "absolutely", "boring"}, {"Marilyn", "Monroe"}, {"Change", "is", "the", "law", "of", "life"}, {"And", "those", "who", "look", "only", "to", "the", "past", "or", "present", "are", "certain", "to", "miss", "the", "future"}, {"John", "F"}};
                const int lenghts[] = {  16,  2,  6,  16,  2};

                char ***words;
                 
                int res = split_sentences("Imperfection is beauty, madness is genius and its better to be absolutely ridiculous than absolutely boring. - Marilyn Monroe.Change is the law of life. And those who look only to the past or present are certain+to miss the future. - John F. Kennedy", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 754 bajtów
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 754 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(754);
    
    //
    // -----------
    //
    


                const char *expected_array[][18 + 1] = {{"Microsoft", "has", "a", "new", "version", "out", "Windows", "XP", "which", "according", "to", "everybody", "is", "the", "most", "reliable", "Windows", "ever"}, {"To", "me", "this", "is", "like", "saying", "that", "asparagus", "is", "the", "most", "articulate", "vegetable", "ever"}, {"Dave", "Barry"}, {"The", "real", "problem", "is", "not", "whether", "machines", "think", "but", "whether", "men", "do"}, {"B"}, {"F"}};
                const int lenghts[] = {  18,  14,  2,  12,  1,  1};

                char ***words;
                 
                int res = split_sentences("Microsoft has a new version out, Windows XP, which according to everybody is the most reliable Windows ever.  To me, this is like+saying that asparagus is the most articulate vegetable ever. - Dave Barry.The real problem is not whether machines think but whether men do.-B.F. Skinner", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 6) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 411 bajtów
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 411 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(411);
    
    //
    // -----------
    //
    


                const char *expected_array[][12 + 1] = {{"Technology", "is", "like", "a", "fish"}, {"The", "longer", "it", "stays", "on", "the", "shelf", "the", "less", "desirable", "it", "becomes"}, {"Andrew", "Heller", "May", "you", "live", "every", "day", "of", "your", "life"}};
                const int lenghts[] = {  5,  12,  10};

                char ***words;
                 
                int res = split_sentences("Technology is like a fish. The longer it stays on the shelf, the less desirable it becomes. - Andrew Heller+May you live every day of your life. - Jonathan Swift", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 331 bajtów
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 331 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(331);
    
    //
    // -----------
    //
    


                const char *expected_array[][8 + 1] = {{"C", "is", "quirky", "flawed", "and", "an", "enormous", "success"}, {"Dennis", "M"}, {"Ritchie"}, {" "}, {"The", "unexamined", "life", "is", "not", "worth", "iving"}};
                const int lenghts[] = {  8,  2,  1,  0,  7};

                char ***words;
                 
                int res = split_sentences("C is quirky, flawed, and an enormous success. - Dennis M. Ritchie..The unexamined life is not worth +iving. - Socrates", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 424 bajtów
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 424 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(424);
    
    //
    // -----------
    //
    


                const char *expected_array[][13 + 1] = {{"You", "only", "live", "once", "but", "if", "you", "do", "it", "righ", "once", "is", "enough"}, {"Mae", "West"}, {"Failure", "will", "never", "overtake", "me", "if", "my", "determination", "to", "succeed", "is", "strong", "enough"}};
                const int lenghts[] = {  13,  2,  13};

                char ***words;
                 
                int res = split_sentences("You only live once, but if you do it righ+, once is enough. - Mae West.Failure will never overtake me if my determination to succeed is strong enough.- Og Mandino", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 411 bajtów
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 411 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(411);
    
    //
    // -----------
    //
    


                const char *expected_array[][16 + 1] = {{"The", "man", "who", "does", "not", "read", "has", "no", "advantage", "o", "er", "the", "man", "who", "cannot", "read"}, {"Mark", "Twain"}, {"Always", "forgive", "your", "enemies", "nothing", "annoys", "them", "so", "much"}};
                const int lenghts[] = {  16,  2,  9};

                char ***words;
                 
                int res = split_sentences("The man who does not read has no advantage o+er the man who cannot read. - Mark Twain.Always forgive your enemies; nothing annoys them so much. - Oscar Wilde", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 403 bajtów
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 403 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(403);
    
    //
    // -----------
    //
    


                const char *expected_array[][7 + 1] = {{"Love", "is", "the", "absence", "of", "judgment"}, {"Dalai", "Lama", "XIV"}, {"The", "pessimist", "sees", "difficulty", "in", "every", "opportunity"}, {"The", "optimist", "sees", "pportunity", "in", "every", "difficulty"}};
                const int lenghts[] = {  6,  3,  7,  7};

                char ***words;
                 
                int res = split_sentences("Love is the absence of judgment. - Dalai Lama XIV.The pessimist sees difficulty in every opportunity. The optimist sees +pportunity in every difficulty. -Winston Churchill", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 789 bajtów
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 789 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(789);
    
    //
    // -----------
    //
    


                const char *expected_array[][23 + 1] = {{"A", "comp", "ter", "will", "do", "what", "you", "tell", "it", "to", "do", "but", "that", "may", "be", "much", "different", "from", "what", "you", "had", "in", "mind"}, {"Joseph", "Weizenbaum"}, {"Friendship"}, {" "}, {" "}, {"is", "born", "at", "the", "moment", "when", "one", "man", "says", "to", "another", "What", "You", "too", "I", "thought", "that", "no", "one", "but", "myself"}, {" "}, {" "}, {"C"}, {"S"}};
                const int lenghts[] = {  23,  2,  1,  0,  0,  21,  0,  0,  1,  1};

                char ***words;
                 
                int res = split_sentences("A comp+ter will do what you tell it to do, but that may be much different from what you had in mind.  - Joseph Weizenbaum.Friendship ... is born at the moment when one man says to another What! You too? I thought that no one but myself . . . - C.S. Lewis", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 10; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 10) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 474 bajtów
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 474 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(474);
    
    //
    // -----------
    //
    


                const char *expected_array[][15 + 1] = {{"Getting", "information", "off", "the", "Internet", "is", "like", "taking", "a", "drink", "from", "a", "fire", "hyd", "ant"}, {"Mitchell", "Kapor"}, {"Youve", "baked", "a", "really", "lovely", "cake", "but", "then", "youve", "used", "dog", "shit", "for", "frosting"}};
                const int lenghts[] = {  15,  2,  14};

                char ***words;
                 
                int res = split_sentences("Getting information off the Internet is like taking a drink from a fire hyd+ant.-Mitchell Kapor.Youve baked a really lovely cake, but then youve used dog shit for frosting. - Steve Jobs", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 657 bajtów
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 657 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(657);
    
    //
    // -----------
    //
    


                const char *expected_array[][17 + 1] = {{"Never", "trust", "anything", "that", "can", "think", "for", "itself", "if", "you", "cant", "see", "where", "it", "keeps", "its", "brain"}, {"J"}, {"K"}, {"Rowling", "author", "of", "The", "Harry", "Potter", "books"}, {"The", "only", "limit", "to", "our", "realization", "of", "tomorro", "will", "be", "our", "doubts", "of", "today"}, {"Franklin", "D"}};
                const int lenghts[] = {  17,  1,  1,  7,  14,  2};

                char ***words;
                 
                int res = split_sentences("Never trust anything that can think for itself if you cant see where it keeps its brain.  - J.K. Rowling, author of The Harry Potter books.The only limit to our realization of tomorro+ will be our doubts of today.- Franklin D. Roosevelt", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 6) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 643 bajtów
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 643 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(643);
    
    //
    // -----------
    //
    


                const char *expected_array[][25 + 1] = {{"I", "invented", "the", "term", "Object", "Oriented", "and", "I", "can", "tell", "yo", "I", "did", "not", "have", "C", "in", "mind"}, {"Alan", "Kay"}, {"I", "worked", "in", "information", "technology", "and", "academia", "for", "a", "long", "time", "and", "met", "many", "people", "who", "were", "better", "with", "things", "and", "ideas", "than", "with", "people"}};
                const int lenghts[] = {  18,  2,  25};

                char ***words;
                 
                int res = split_sentences("I invented the term Object-Oriented, and I can tell yo+ I did not have C++ in mind. - Alan Kay.I worked in information technology and academia for a long time and met many people who were better with things and ideas than with people. - Graeme Simsion", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 519 bajtów
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 519 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(519);
    
    //
    // -----------
    //
    


                const char *expected_array[][17 + 1] = {{"We", "have", "to", "dare", "to", "be", "ourselves", "however", "frightening", "or", "strange", "that", "self", "may", "prove", "to", "be"}, {"May", "Sarton"}, {"The", "fool", "doth", "think", "he", "is", "wise", "but", "the", "wise", "man", "knows", "himself", "to", "be", "a", "fool"}};
                const int lenghts[] = {  17,  2,  17};

                char ***words;
                 
                int res = split_sentences("We have to dare to be ourselves, however frightening or strange that+self may prove to be. - May Sarton.The fool doth think he is wise, but the wise man knows himself to be a fool. - William Shakespeare", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1156 bajtów
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1156 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1156);
    
    //
    // -----------
    //
    


                const char *expected_array[][23 + 1] = {{"Change", "is", "the", "law", "of", "life"}, {"And", "those", "who", "look", "only", "to", "the", "past", "or", "present", "are", "certain", "to", "miss", "the", "future"}, {"John"}, {"Kennedy"}, {"Twenty", "years", "from", "now", "you", "will", "be", "more", "disappointed", "by", "the", "things", "that", "you", "didnt", "do", "than", "by", "the", "ones", "you", "did", "do"}, {"So", "throw", "off", "the", "bowlines"}, {"Sail", "away", "from", "the", "safe", "harbor"}, {"Catch", "the", "trade", "winds", "in", "your", "sails"}, {"Explore"}, {"Dream"}, {"Discover"}, {"H"}, {"Jackson", "Brown", "Jr"}};
                const int lenghts[] = {  6,  16,  1,  1,  23,  5,  6,  7,  1,  1,  1,  1,  3};

                char ***words;
                 
                int res = split_sentences("Change is the law of life. And those who look only to the past or present are certain to miss the future. - John +. Kennedy.Twenty years from now you will be more disappointed by the things that you didnt do than by the ones you did do. So throw off the bowlines. Sail away from the safe harbor. Catch the trade winds in your sails. Explore. Dream. Discover. - H. Jackson Brown Jr.", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 13; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 13) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 485 bajtów
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 485 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(485);
    
    //
    // -----------
    //
    


                const char *expected_array[][17 + 1] = {{"Man", "the", "living", "creature", "the", "creating", "individual", "is", "always", "more", "important", "than", "any", "established", "style", "or", "system"}, {"Bruce", "Lee"}, {"The", "art", "challenges", "the", "technology", "and", "the", "echnology", "inspires", "the", "art"}};
                const int lenghts[] = {  17,  2,  11};

                char ***words;
                 
                int res = split_sentences("Man, the living creature, the creating individual, is always more important than any established style or system. - Bruce Lee.The art challenges the technology, and the +echnology inspires the art.-John Lasseter", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1831 bajtów
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1831 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1831);
    
    //
    // -----------
    //
    


                const char *expected_array[][17 + 1] = {{"You", "cant", "connect", "the", "dots", "looking", "forward", "you", "can", "only", "connect", "them", "looking", "backwards"}, {"So", "you", "have", "to", "trust", "that", "the", "dots", "will", "somehow", "connect", "in", "your", "future"}, {"You", "have", "to", "trust", "in", "something", "your", "gut", "destiny", "life", "karma", "whatever"}, {"This", "approac", "has", "never", "let", "me", "down", "and", "it", "has", "made", "all", "the", "difference", "in", "my", "life"}, {"Steve", "Jobs"}, {"When", "they", "first", "built", "the", "University", "of", "California", "at", "Irvine", "they", "just", "put", "the", "buildings", "in"}, {"They", "did", "not", "put", "any", "sidewalks", "they", "just", "planted", "grass"}, {"The", "next", "year", "they", "came", "back", "and", "put", "the", "sidewalks", "where", "the", "trails", "were", "in", "the", "grass"}, {"Perl", "is", "just", "that", "kind", "of", "language"}, {"It", "is", "not", "designed", "from", "first", "principles"}, {"Perl", "is", "those", "sidewalks", "in", "the", "grass"}};
                const int lenghts[] = {  14,  14,  12,  17,  2,  16,  10,  17,  7,  7,  7};

                char ***words;
                 
                int res = split_sentences("You cant connect the dots looking forward; you can only connect them looking backwards. So you have to trust that the dots will somehow connect in your future. You have to trust in something - your gut, destiny, life, karma, whatever. This approac+ has never let me down, and it has made all the difference in my life. - Steve Jobs.When they first built the University of California at Irvine they just put the buildings in. They did not put any sidewalks, they just planted grass. The next year, they came back and put the sidewalks where the trails were in the grass. Perl is just that kind of language. It is not designed from first principles. Perl is those sidewalks in the grass. - Larry Wall", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 11; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 11) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 918 bajtów
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 918 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(918);
    
    //
    // -----------
    //
    


                const char *expected_array[][19 + 1] = {{"Never", "be", "afraid", "to", "raise", "your", "voice", "for", "honesty", "and", "truth", "and", "compassion", "against", "injustice", "and", "lying", "and", "greed"}, {"If", "peo", "le", "all", "over", "the", "world"}, {" "}, {" "}, {"would", "do", "this", "it", "would", "change", "the", "earth"}, {"William", "Faulkner"}, {"Object", "oriented", "programming", "offers", "a", "sustainable", "way", "to", "write", "spaghetti", "code"}, {"It", "lets", "you", "accrete", "programs", "as", "a", "series", "of", "patches"}};
                const int lenghts[] = {  19,  7,  0,  0,  8,  2,  11,  10};

                char ***words;
                 
                int res = split_sentences("Never be afraid to raise your voice for honesty and truth and compassion against injustice and lying and greed. If peo+le all over the world...would do this, it would change the earth. - William Faulkner.Object-oriented programming offers a sustainable way to write spaghetti code. It lets you accrete programs as a series of patches. - Paul Graham", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 8; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 8) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 882 bajtów
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 882 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(882);
    
    //
    // -----------
    //
    


                const char *expected_array[][23 + 1] = {{"You", "know", "youre", "in", "love", "when", "you", "cant", "fall", "asleep", "because", "reality", "is", "finally", "better", "than", "your", "dreams"}, {"Dr"}, {"Seuss"}, {"The", "first", "rule", "of", "any", "technology", "used", "in", "a", "business", "is", "that", "automati", "n", "applied", "to", "an", "efficient", "operation", "will", "magnify", "the", "efficiency"}, {"The", "second", "is", "that", "automation", "applied", "to", "an", "inefficient", "operation", "will", "magnify", "the", "inefficiency"}};
                const int lenghts[] = {  18,  1,  1,  23,  14};

                char ***words;
                 
                int res = split_sentences("You know youre in love when you cant fall asleep because reality is finally better than your dreams. - Dr. Seuss.The first rule of any technology used in a business is that automati+n applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency. - Bill Gates", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 458 bajtów
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 458 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(458);
    
    //
    // -----------
    //
    


                const char *expected_array[][16 + 1] = {{"Education", "is", "the", "foundation", "upon", "which", "we", "build", "our", "future"}, {"Chris", "ine", "Gregoire"}, {"Two", "things", "are", "infinite", "the", "universe", "and", "human", "stupidity", "and", "Im", "not", "sure", "about", "the", "universe"}};
                const int lenghts[] = {  10,  3,  16};

                char ***words;
                 
                int res = split_sentences("Education is the foundation upon which we build our future. - Chris+ine Gregoire.Two things are infinite: the universe and human stupidity; and Im not sure about the universe. - Albert Einstein", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 643 bajtów
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 643 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(643);
    
    //
    // -----------
    //
    


                const char *expected_array[][19 + 1] = {{"A", "woman", "is", "like", "a", "tea", "bag", "you", "never", "know", "how", "strong", "i", "is", "until", "its", "in", "hot", "water"}, {"Eleanor", "Roosevelt"}, {"The", "only", "way", "to", "do", "great", "work", "is", "to", "love", "what", "you", "do"}, {"If", "you", "havent", "found", "it", "yet", "keep", "looking"}, {"Dont", "settle"}};
                const int lenghts[] = {  19,  2,  13,  8,  2};

                char ***words;
                 
                int res = split_sentences("A woman is like a tea bag; you never know how strong i+ is until its in hot water. - Eleanor Roosevelt.The only way to do great work is to love what you do. If you havent found it yet, keep looking. Dont settle. - Steve Jobs", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 50: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1020 bajtów
//
void UTEST50(void)
{
    // informacje o teście
    test_start(50, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1020 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1020);
    
    //
    // -----------
    //
    


                const char *expected_array[][26 + 1] = {{"I", "believe", "in", "everything", "until", "its", "disproved"}, {"So", "I", "believe", "in", "fairies", "the", "myths", "dragons"}, {"It", "all", "exists", "even", "if", "its", "in", "your", "mind"}, {"Whos", "to", "say", "that", "dreams", "and", "nightmares", "arent", "as", "real", "as", "the", "here", "and", "now", "John", "Lennon"}, {"Youve", "gotta", "dance", "like", "theres", "nobody", "watching", "Love", "like", "youll", "never", "be", "hurt", "Sing", "l", "ke", "theres", "nobody", "listening", "And", "live", "like", "its", "heaven", "on", "earth"}, {"William", "W"}};
                const int lenghts[] = {  7,  8,  9,  17,  26,  2};

                char ***words;
                 
                int res = split_sentences("I believe in everything until its disproved. So I believe in fairies, the myths, dragons. It all exists, even if its in your mind. Whos to say that dreams and nightmares arent as real as the here and now? - John Lennon.Youve gotta dance like theres nobody watching,Love like youll never be hurt,Sing l+ke theres nobody listening,And live like its heaven on earth. - William W. Purkey", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 6) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 51: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 503 bajtów
//
void UTEST51(void)
{
    // informacje o teście
    test_start(51, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 503 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(503);
    
    //
    // -----------
    //
    


                const char *expected_array[][18 + 1] = {{"Man", "the", "living", "creature", "the", "creat", "ng", "individual", "is", "always", "more", "important", "than", "any", "established", "style", "or", "system"}, {"Bruce", "Lee"}, {"Computers", "are", "like", "bikinis"}, {"They", "save", "people", "a", "lot", "of", "guesswork"}};
                const int lenghts[] = {  18,  2,  4,  7};

                char ***words;
                 
                int res = split_sentences("Man, the living creature, the creat+ng individual, is always more important than any established style or system. - Bruce Lee.Computers are like bikinis. They save people a lot of guesswork.-Sam Ewing", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 52: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1088 bajtów
//
void UTEST52(void)
{
    // informacje o teście
    test_start(52, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1088 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1088);
    
    //
    // -----------
    //
    


                const char *expected_array[][39 + 1] = {{"A", "variety", "of", "national", "and", "international", "studies", "indicate", "that", "the", "broad", "based", "deployment", "of", "information", "technology", "can", "have", "a", "substantial", "impact", "on", "our", "nations", "economic", "productivity", "and", "growth", "as", "well", "as", "the", "educational", "and", "social", "success", "of", "our", "citizens"}, {"Tim", "Holden"}, {"If", "McDonalds", "were", "run", "like", "a", "software", "company", "one", "out", "of", "every", "hundred", "Big", "Macs", "would", "give", "you", "food", "poisoning", "and", "the", "response", "would", "be", "Were", "sorry", "heres", "a", "coupon", "for", "wo", "more"}};
                const int lenghts[] = {  39,  2,  33};

                char ***words;
                 
                int res = split_sentences("A variety of national and international studies indicate that the broad-based deployment of information technology can have a substantial impact on our nations economic productivity and growth as well as the educational and social success of our citizens. - Tim Holden.If McDonalds were run like a software company, one out of every hundred Big Macs would give you food poisoning, and the response would be, Were sorry, heres a coupon for +wo more.  - Mark Minasi", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 53: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 855 bajtów
//
void UTEST53(void)
{
    // informacje o teście
    test_start(53, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 855 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(855);
    
    //
    // -----------
    //
    


                const char *expected_array[][32 + 1] = {{"It", "is", "good", "to", "love", "many", "things", "for", "therein", "lies", "the", "true", "strength", "and", "whosoever", "loves", "much", "performs", "much", "and", "can", "accomplish", "much", "and", "what", "is", "done", "in", "love", "is", "well", "done"}, {"Vincent", "van", "Gogh"}, {"Friendship", "is", "everything"}, {"Friendship", "is", "more", "tha", "talent"}, {"It", "is", "more", "than", "the", "government"}, {"It", "is", "almost", "the", "equal", "of", "family"}};
                const int lenghts[] = {  32,  3,  3,  5,  6,  7};

                char ***words;
                 
                int res = split_sentences("It is good to love many things, for therein lies the true strength, and whosoever loves much performs much, and can accomplish much, and what is done in love is well done. - Vincent van Gogh.Friendship is everything. Friendship is more tha+ talent. It is more than the government. It is almost the equal of family.- Don Corleone - Mario Puzo, The Godfather", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 6) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 54: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1646 bajtów
//
void UTEST54(void)
{
    // informacje o teście
    test_start(54, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1646 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1646);
    
    //
    // -----------
    //
    


                const char *expected_array[][19 + 1] = {{"First", "we", "thought", "the", "PC", "was", "a", "calculator"}, {"Then", "we", "found", "out", "how", "to", "turn", "numbers", "into", "letter", "with", "ASCII", "and", "we", "thought", "it", "was", "a", "typewriter"}, {"Then", "we", "discovered", "graphics", "and", "we", "thought", "it", "was", "a", "television"}, {"With", "the", "World", "Wide", "Web", "weve", "realized", "its", "a", "brochure"}, {"Douglas", "Adams"}, {"We", "live", "in", "a", "world", "where", "finding", "fault", "in", "others", "seems", "to", "be", "the", "favorite", "blood", "sport"}, {"It", "has", "long", "been", "the", "basis", "of", "political", "campaign", "strategy"}, {"It", "is", "the", "theme", "of", "much", "television", "programming", "across", "the", "world"}, {"It", "sells", "newspapers"}, {"Whenever", "we", "meet", "anyone", "our", "first", "almost", "unconscious", "reaction", "may", "be", "to", "look", "for", "imperfections"}, {"Henry", "B"}};
                const int lenghts[] = {  8,  19,  11,  10,  2,  17,  10,  11,  3,  15,  2};

                char ***words;
                 
                int res = split_sentences("First we thought the PC was a calculator. Then we found out how to turn numbers into letter+ with ASCII - and we thought it was a typewriter. Then we discovered graphics, and we thought it was a television. With the World Wide Web, weve realized its a brochure.-Douglas Adams.We live in a world where finding fault in others seems to be the favorite blood sport. It has long been the basis of political campaign strategy. It is the theme of much television programming across the world. It sells newspapers. Whenever we meet anyone, our first, almost unconscious reaction may be to look for imperfections. - Henry B. Eyring", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 11; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 11) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 55: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 610 bajtów
//
void UTEST55(void)
{
    // informacje o teście
    test_start(55, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 610 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(610);
    
    //
    // -----------
    //
    


                const char *expected_array[][14 + 1] = {{"Security", "is", "mostly", "a", "superstition"}, {"Life", "is", "either", "a", "daring", "adventure", "or", "nothing"}, {"Helen", "Keller"}, {"Never", "doubt", "that", "a", "small", "group", "of", "thoughtful", "committed", "citizens", "can", "change", "the", "world"}, {"Indeed", "it", "is", "the", "only", "hing", "that", "ever", "has"}};
                const int lenghts[] = {  5,  8,  2,  14,  9};

                char ***words;
                 
                int res = split_sentences("Security is mostly a superstition. Life is either a daring adventure or nothing.- Helen Keller.Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only +hing that ever has. - Margaret Mead", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 56: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 498 bajtów
//
void UTEST56(void)
{
    // informacje o teście
    test_start(56, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 498 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(498);
    
    //
    // -----------
    //
    


                const char *expected_array[][13 + 1] = {{"Develop", "an", "Attitude", "of", "Gratitude"}, {"Say", "thank", "you", "to", "everyone", "you", "meet", "for", "everything", "they", "do", "for", "you"}, {"Brian", "Tracy"}, {"Trust", "yours", "lf"}, {"You", "know", "more", "than", "you", "think", "you", "do"}};
                const int lenghts[] = {  5,  13,  2,  3,  8};

                char ***words;
                 
                int res = split_sentences("Develop an Attitude of Gratitude. Say thank you to everyone you meet for everything they do for you.- Brian Tracy.Trust yours+lf. You know more than you think you do. - Benjamin Spock", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 5; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 5) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 57: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 367 bajtów
//
void UTEST57(void)
{
    // informacje o teście
    test_start(57, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 367 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(367);
    
    //
    // -----------
    //
    


                const char *expected_array[][12 + 1] = {{"It", "has", "become", "appallingly", "obvious", "that", "our", "technology", "has", "exceeded", "our", "humanity"}, {"Albert", "Einstein"}, {"Do", "one", "thing", "every", "day", "that", "scares", "you"}};
                const int lenghts[] = {  12,  2,  8};

                char ***words;
                 
                int res = split_sentences("It has become appallingly obvious that our technology has exceeded our humanity.-Albert Einstein.Do one thing every day that scares you. - Eleanor+Roosevelt", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 58: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1081 bajtów
//
void UTEST58(void)
{
    // informacje o teście
    test_start(58, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1081 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1081);
    
    //
    // -----------
    //
    


                const char *expected_array[][17 + 1] = {{"We", "live", "in", "a", "world", "where", "finding", "fault", "in", "others", "seems", "to", "be", "the", "favorite", "blood", "sport"}, {"It", "has", "long", "been", "he", "basis", "of", "political", "campaign", "strategy"}, {"It", "is", "the", "theme", "of", "much", "television", "programming", "across", "the", "world"}, {"It", "sells", "newspapers"}, {"Whenever", "we", "meet", "anyone", "our", "first", "almost", "unconscious", "reaction", "may", "be", "to", "look", "for", "imperfections"}, {"Henry", "B"}, {"Eyring"}, {"Be", "the", "change", "that", "you", "wish", "to", "see", "in", "the", "world"}};
                const int lenghts[] = {  17,  10,  11,  3,  15,  2,  1,  11};

                char ***words;
                 
                int res = split_sentences("We live in a world where finding fault in others seems to be the favorite blood sport. It has long been +he basis of political campaign strategy. It is the theme of much television programming across the world. It sells newspapers. Whenever we meet anyone, our first, almost unconscious reaction may be to look for imperfections. - Henry B. Eyring.Be the change that you wish to see in the world. - Mahatma Gandhi", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 8; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 8) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 59: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 501 bajtów
//
void UTEST59(void)
{
    // informacje o teście
    test_start(59, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 501 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(501);
    
    //
    // -----------
    //
    


                const char *expected_array[][21 + 1] = {{"Rather", "than", "love", "than", "money", "than", "fame", "give", "me", "truth"}, {"Henry", "David", "Thoreau"}, {"Yesterday", "is", "history", "tomorrow", "is", "a", "mystery", "today", "is", "a", "gift", "of", "God", "which", "is", "wh", "we", "call", "it", "the", "present"}};
                const int lenghts[] = {  10,  3,  21};

                char ***words;
                 
                int res = split_sentences("Rather than love, than money, than fame, give me truth. - Henry David Thoreau.Yesterday is history, tomorrow is a mystery, today is a gift of God, which is wh+ we call it the present. - Bil Keane", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 60: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 671 bajtów
//
void UTEST60(void)
{
    // informacje o teście
    test_start(60, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 671 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(671);
    
    //
    // -----------
    //
    


                const char *expected_array[][19 + 1] = {{"Programs", "must", "be", "written", "for", "people", "to", "read", "and", "only", "incidentally", "for", "machines", "to", "execute"}, {"Harold", "Abelson"}, {"Computing", "should", "be", "tau", "ht", "as", "a", "rigorous", "but", "fun", "discipline", "covering", "topics", "like", "programming", "database", "structures", "and", "algorithms"}, {"That", "doesnt", "have", "to", "be", "boring"}};
                const int lenghts[] = {  15,  2,  19,  6};

                char ***words;
                 
                int res = split_sentences("Programs must be written for people to read, and only incidentally for machines to execute. - Harold Abelson.Computing should be tau+ht as a rigorous - but fun - discipline covering topics like programming, database structures, and algorithms. That doesnt have to be boring. - Geoff Mulgan", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 61: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 567 bajtów
//
void UTEST61(void)
{
    // informacje o teście
    test_start(61, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 567 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(567);
    
    //
    // -----------
    //
    


                const char *expected_array[][21 + 1] = {{"I", "think", "goals", "should", "never", "be", "easy", "they", "should", "force", "you", "to", "work", "even", "if", "they", "are", "uncomfortable", "at", "the", "time"}, {"Michael", "Phelps"}, {"The", "biotechnology", "wave", "is", "similar", "to", "the", "information", "technology", "wave", "of", "the", "s", "and", "s"}};
                const int lenghts[] = {  21,  2,  15};

                char ***words;
                 
                int res = split_sentences("I think goals should never be easy, they should force you to work, even if they are uncomfortable at the time. - Michael Phelps.The biotechnology wave is similar to the information technology wave of the 1980s and 1990s. - Dietmar +opp", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 62: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1705 bajtów
//
void UTEST62(void)
{
    // informacje o teście
    test_start(62, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1705 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1705);
    
    //
    // -----------
    //
    


                const char *expected_array[][44 + 1] = {{"Three", "Rings", "for", "the", "Elven", "kings", "under", "the", "sky", "Seven", "for", "the", "Dwarf", "lords", "in", "their", "halls", "of", "stone", "Nine", "for", "Mortal", "Men", "doomed", "to", "die", "One", "for", "the", "Dark", "Lord", "on", "his", "dark", "throne", "In", "the", "Land", "of", "Mordor", "where", "the", "Shadows", "lie"}, {"One", "Ring", "to", "rule", "them", "all", "One", "Ring", "to", "find", "them", "One", "Ring", "to", "bring", "them", "all", "and", "in", "the", "darkness", "bind", "them", "In", "the", "Land", "of", "Mordor", "wh", "re", "the", "Shadows", "lie"}, {"J"}, {"R"}, {"R"}, {"Tolkien", "The", "Lord", "of", "the", "Rings"}, {"The", "First", "Industrial", "Revolution", "used", "water", "and", "steam", "power", "to", "mechanize", "production"}, {"The", "Second", "used", "electric", "power", "to", "create", "mass", "production"}, {"The", "Third", "used", "electronics", "and", "information", "technology", "to", "automate", "production"}};
                const int lenghts[] = {  44,  33,  1,  1,  1,  6,  12,  9,  10};

                char ***words;
                 
                int res = split_sentences("Three Rings for the Elven-kings under the sky, Seven for the Dwarf-lords in their halls of stone, Nine for Mortal Men doomed to die, One for the Dark Lord on his dark throne In the Land of Mordor where the Shadows lie. One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them In the Land of Mordor wh+re the Shadows lie. - J. R. R. Tolkien, The Lord of the Rings.The First Industrial Revolution used water and steam power to mechanize production. The Second used electric power to create mass production. The Third used electronics and information technology to automate production. - Klaus Schwab", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 9; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 9) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 63: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 633 bajtów
//
void UTEST63(void)
{
    // informacje o teście
    test_start(63, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 633 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(633);
    
    //
    // -----------
    //
    


                const char *expected_array[][22 + 1] = {{"Develop", "an", "Attitude", "of", "Gratitude"}, {"Say", "thank", "you", "to", "everyone", "you", "meet", "for", "everything", "they", "do", "for", "you"}, {"Brian", "Tracy"}, {"Perfection", "in", "esign", "is", "achieved", "not", "when", "there", "is", "nothing", "more", "to", "add", "but", "when", "there", "is", "nothing", "left", "to", "take", "away"}};
                const int lenghts[] = {  5,  13,  2,  22};

                char ***words;
                 
                int res = split_sentences("Develop an Attitude of Gratitude. Say thank you to everyone you meet for everything they do for you.- Brian Tracy.Perfection [in +esign] is achieved, not when there is nothing more to add, but when there is nothing left to take away. - Antoine de Saint-Exupery", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 64: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 542 bajtów
//
void UTEST64(void)
{
    // informacje o teście
    test_start(64, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 542 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(542);
    
    //
    // -----------
    //
    


                const char *expected_array[][13 + 1] = {{"The", "future", "belongs", "to", "those", "who", "believe", "in", "the", "beauty", "of", "their", "dreams"}, {"Eleanor", "Roosevelt"}, {"Any", "fool", "can", "write", "code", "that", "a", "computer", "can", "understand"}, {"Good", "programmers", "write", "code", "that", "huma", "s", "can", "understand"}};
                const int lenghts[] = {  13,  2,  10,  9};

                char ***words;
                 
                int res = split_sentences("The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt.Any fool can write code that a computer can understand. Good programmers write code that huma+s can understand. - Martin Fowler", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 65: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 804 bajtów
//
void UTEST65(void)
{
    // informacje o teście
    test_start(65, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 804 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(804);
    
    //
    // -----------
    //
    


                const char *expected_array[][22 + 1] = {{"The", "ultimate", "promise", "of", "technology", "is", "to", "make", "us", "master", "of", "a", "world", "that", "we", "command", "by", "the", "push", "of", "a", "button"}, {"Volker", "Grassmuck"}, {"The", "evolution", "of", "languages", "FORTRAN", "is", "a", "non", "typed", "language"}, {"C", "is", "a", "weakly", "typed", "language"}, {"Ada", "is", "a", "strongly", "typed", "lang", "age"}, {"C", "is", "a", "strongly", "hyped", "language"}};
                const int lenghts[] = {  22,  2,  10,  6,  7,  6};

                char ***words;
                 
                int res = split_sentences("The ultimate promise of technology is to make us master of a world that we command by the push of a button.-Volker Grassmuck.The evolution of languages: FORTRAN is a non-typed language. C is a weakly typed language. Ada is a strongly typed lang+age. C++ is a strongly hyped language. - Ron Sercely", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 6) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 66: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 476 bajtów
//
void UTEST66(void)
{
    // informacje o teście
    test_start(66, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 476 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(476);
    
    //
    // -----------
    //
    


                const char *expected_array[][23 + 1] = {{"Without", "music", "life", "would", "be", "a", "mistake"}, {"Friedrich", "Nietzsche"}, {"It", "is", "better", "to", "remain", "silent", "at", "the", "risk", "of", "being", "thought", "a", "fool", "than", "to", "talk", "and", "remove", "all", "doubt", "of", "it"}};
                const int lenghts[] = {  7,  2,  23};

                char ***words;
                 
                int res = split_sentences("Without music, life would be a mistake. - Friedrich Nietzsche.It is better to remain silent at the risk of being thought a fool, than to talk and remove all doubt of it. + Maurice Switzer", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 67: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 409 bajtów
//
void UTEST67(void)
{
    // informacje o teście
    test_start(67, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 409 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(409);
    
    //
    // -----------
    //
    


                const char *expected_array[][14 + 1] = {{"Let", "us", "make", "our", "future", "now", "and", "let", "us", "make", "our", "dreams", "tomorrows", "reality"}, {"Malala", "Yousafzai"}, {"Be", "the", "change", "that", "you", "wish", "to", "see", "in", "the", "world"}};
                const int lenghts[] = {  14,  2,  11};

                char ***words;
                 
                int res = split_sentences("Let us make our future now, and let us make our dreams tomorrows reality. - Malala Yousafzai.Be the change that you wish to see in the world.+- Mahatma Gandhi", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 68: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 540 bajtów
//
void UTEST68(void)
{
    // informacje o teście
    test_start(68, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 540 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(540);
    
    //
    // -----------
    //
    


                const char *expected_array[][12 + 1] = {{"Man", "is", "least", "himself", "when", "he", "talks", "in", "his", "own", "person"}, {"Give", "him", "a", "mask", "and", "he", "will", "tell", "you", "the", "truth"}, {"Oscar", "Wil", "e"}, {"Its", "not", "whether", "you", "get", "knocked", "down", "its", "whether", "you", "get", "up"}};
                const int lenghts[] = {  11,  11,  3,  12};

                char ***words;
                 
                int res = split_sentences("Man is least himself when he talks in his own person. Give him a mask, and he will tell you the truth. - Oscar Wil+e.Its not whether you get knocked down, its whether you get up. - Inspirational Quote by Vince Lombardi", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 69: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 522 bajtów
//
void UTEST69(void)
{
    // informacje o teście
    test_start(69, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 522 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(522);
    
    //
    // -----------
    //
    


                const char *expected_array[][18 + 1] = {{"We", "are", "what", "we", "pretend", "to", "be", "so", "we", "must", "be", "careful", "bout", "what", "we", "pretend", "to", "be"}, {"Kurt", "Vonnegut"}, {"I", "just", "invent"}, {"Then", "I", "wait", "until", "man", "comes", "around", "to", "needing", "what", "Ive", "invented"}};
                const int lenghts[] = {  18,  2,  3,  12};

                char ***words;
                 
                int res = split_sentences("We are what we pretend to be, so we must be careful +bout what we pretend to be. - Kurt Vonnegut.I just invent. Then I wait until man comes around to needing what Ive invented. - Richard Buckminster Fuller", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 70: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 538 bajtów
//
void UTEST70(void)
{
    // informacje o teście
    test_start(70, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 538 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(538);
    
    //
    // -----------
    //
    


                const char *expected_array[][19 + 1] = {{"Books", "are", "mirrors", "you", "only", "see", "in", "them", "what", "you", "already", "have", "inside", "you"}, {"Carlos", "Ruiz", "Zaf", "n"}, {"There", "are", "no", "limi", "s", "to", "what", "you", "can", "accomplish", "except", "the", "limits", "you", "place", "on", "your", "own", "thinking"}};
                const int lenghts[] = {  14,  4,  19};

                char ***words;
                 
                int res = split_sentences("Books are mirrors: you only see in them what you already have inside you. - Carlos Ruiz Zafón.There are no limi+s to what you can accomplish, except the limits you place on your own thinking. - Brian Tracy", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 71: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 536 bajtów
//
void UTEST71(void)
{
    // informacje o teście
    test_start(71, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 536 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(536);
    
    //
    // -----------
    //
    


                const char *expected_array[][21 + 1] = {{"The", "future", "belongs", "to", "those", "who", "believe", "in", "the", "beauty", "of", "their", "dreams"}, {"Eleanor", "Roosevelt"}, {"Fake", "i", "until", "you", "make", "it", "Act", "as", "if", "you", "had", "all", "the", "confidence", "you", "require", "until", "it", "becomes", "your", "reality"}};
                const int lenghts[] = {  13,  2,  21};

                char ***words;
                 
                int res = split_sentences("The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt.Fake i+ until you make it! Act as if you had all the confidence you require until it becomes your reality.- Brian Tracy", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 72: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1231 bajtów
//
void UTEST72(void)
{
    // informacje o teście
    test_start(72, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1231 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1231);
    
    //
    // -----------
    //
    


                const char *expected_array[][16 + 1] = {{"Technology", "is", "a", "u", "eful", "servant", "but", "a", "dangerous", "master"}, {"Christian", "Lous", "Lange"}, {"A", "computer", "is", "like", "a", "violin"}, {"You", "can", "imagine", "a", "novice", "trying", "first", "a", "phonograph", "and", "then", "a", "violin"}, {"The", "latter", "he", "says", "sounds", "terrible"}, {"That", "is", "the", "argument", "we", "have", "heard", "from", "our", "humanists", "and", "most", "of", "our", "computer", "scientists"}, {"Computer", "programs", "are", "good", "they", "say", "for", "particular", "purposes", "but", "they", "arent", "flexible"}, {"Neither", "is", "a", "violin", "or", "a", "typewriter", "until", "you", "learn", "how", "to", "use", "it"}};
                const int lenghts[] = {  10,  3,  6,  13,  6,  16,  13,  14};

                char ***words;
                 
                int res = split_sentences("Technology is a u+eful servant but a dangerous master.-Christian Lous Lange.A computer is like a violin. You can imagine a novice trying first a phonograph and then a violin. The latter, he says, sounds terrible. That is the argument we have heard from our humanists and most of our computer scientists. Computer programs are good, they say, for particular purposes, but they arent flexible. Neither is a violin, or a typewriter, until you learn how to use it. - Marvin Minsky", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 8; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 8) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 73: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1469 bajtów
//
void UTEST73(void)
{
    // informacje o teście
    test_start(73, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1469 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1469);
    
    //
    // -----------
    //
    


                const char *expected_array[][44 + 1] = {{"Perfection", "in", "design", "is", "achieved", "not", "when", "there", "is", "nothing", "more", "to", "add", "but", "when", "there", "is", "nothing", "left", "to", "take", "away"}, {"Antoine", "de", "Saint", "Exupery"}, {"Three", "Rings", "for", "the", "Elven", "kings", "under", "he", "sky", "Seven", "for", "the", "Dwarf", "lords", "in", "their", "halls", "of", "stone", "Nine", "for", "Mortal", "Men", "doomed", "to", "die", "One", "for", "the", "Dark", "Lord", "on", "his", "dark", "throne", "In", "the", "Land", "of", "Mordor", "where", "the", "Shadows", "lie"}, {"One", "Ring", "to", "rule", "them", "all", "One", "Ring", "to", "find", "them", "One", "Ring", "to", "bring", "them", "all", "and", "in", "the", "darkness", "bind", "them", "In", "the", "Land", "of", "Mordor", "where", "the", "Shadows", "lie"}, {"J"}, {"R"}, {"R"}};
                const int lenghts[] = {  22,  4,  44,  32,  1,  1,  1};

                char ***words;
                 
                int res = split_sentences("Perfection [in design] is achieved, not when there is nothing more to add, but when there is nothing left to take away. - Antoine de Saint-Exupery.Three Rings for the Elven-kings under +he sky, Seven for the Dwarf-lords in their halls of stone, Nine for Mortal Men doomed to die, One for the Dark Lord on his dark throne In the Land of Mordor where the Shadows lie. One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them In the Land of Mordor where the Shadows lie. - J. R. R. Tolkien, The Lord of the Rings", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 7; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 7) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 74: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 443 bajtów
//
void UTEST74(void)
{
    // informacje o teście
    test_start(74, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 443 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(443);
    
    //
    // -----------
    //
    


                const char *expected_array[][20 + 1] = {{"Pythons", "drop", "in", "replacement", "for", "BASIC", "in", "the", "sense", "that", "Optimus", "Prime", "is", "a", "drop", "in", "replacement", "for", "a", "truck"}, {"Cory", "Dodt"}, {"Without", "music", "life", "would", "be", "a", "mistake"}};
                const int lenghts[] = {  20,  2,  7};

                char ***words;
                 
                int res = split_sentences("Pythons + drop-in replacement for BASIC in the sense that Optimus Prime is a drop-in replacement for a truck. - Cory Dodt.Without music, life would be a mistake. - Friedrich Nietzsche", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 75: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 522 bajtów
//
void UTEST75(void)
{
    // informacje o teście
    test_start(75, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 522 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(522);
    
    //
    // -----------
    //
    


                const char *expected_array[][18 + 1] = {{"A", "C", "program", "is", "like", "a", "fast", "dance", "on", "a", "newly", "waxed", "dance", "floor", "by", "people", "carrying", "razors"}, {"Waldi", "Ravens"}, {" "}, {"We", "generate", "fears", "while", "we", "sit"}, {"We", "overcome", "them", "by", "action"}, {"Dr"}};
                const int lenghts[] = {  18,  2,  0,  6,  5,  1};

                char ***words;
                 
                int res = split_sentences("A C program is like a fast dance on a newly waxed dance floor by people carrying razors. - Waldi Ravens..We generate fears while we sit.+We overcome them by action.- Dr. Henry Link", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 6) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 76: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 682 bajtów
//
void UTEST76(void)
{
    // informacje o teście
    test_start(76, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 682 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(682);
    
    //
    // -----------
    //
    


                const char *expected_array[][19 + 1] = {{"In", "the", "one", "and", "only", "true", "way"}, {"The", "object", "oriented", "version", "of", "Spaghetti", "code", "is", "of", "course", "Lasagna", "code"}, {"Too", "many", "layers"}, {"Roberto", "Waltman"}, {" "}, {"The", "trouble", "with", "programmers", "is", "that", "you", "can", "never", "tell", "what", "a", "rogrammer", "is", "doing", "until", "its", "too", "late"}};
                const int lenghts[] = {  7,  12,  3,  2,  0,  19};

                char ***words;
                 
                int res = split_sentences("In the one and only true way. The object-oriented version of Spaghetti code is, of course, Lasagna code. (Too many layers). - Roberto Waltman..The trouble with programmers is that you can never tell what a +rogrammer is doing until its too late. - Seymour Cray", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 6; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 6) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 77: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 548 bajtów
//
void UTEST77(void)
{
    // informacje o teście
    test_start(77, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 548 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(548);
    
    //
    // -----------
    //
    


                const char *expected_array[][27 + 1] = {{"Programming", "today", "is", "a", "race", "between", "software", "engineers", "striving", "to", "build", "bigger", "and", "better", "idiot", "proof", "programs", "and", "the", "Universe", "rying", "to", "produce", "bigger", "and", "better", "idiots"}, {"So", "far", "the", "Universe", "is", "winning"}, {"Rick", "Cook"}};
                const int lenghts[] = {  27,  6,  2};

                char ***words;
                 
                int res = split_sentences("Programming today is a race between software engineers striving to build bigger and better idiot-proof programs, and the Universe +rying to produce bigger and better idiots. So far, the Universe is winning. - Rick Cook.Is artificial intelligence less than our intelligence? - Spike Jonze", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 78: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 303 bajtów
//
void UTEST78(void)
{
    // informacje o teście
    test_start(78, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 303 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(303);
    
    //
    // -----------
    //
    


                const char *expected_array[][9 + 1] = {{"Talk", "is", "cheap"}, {"Show", "me", "the", "code"}, {"Linus", "Torvalds"}, {"I", "dream", "my", "painting", "and", "I", "paint", "my", "dream"}};
                const int lenghts[] = {  3,  4,  2,  9};

                char ***words;
                 
                int res = split_sentences("Talk is cheap. Show me the code. - Linus Torvalds.I dream my painting and I paint my dream. - Vincen+ van Gogh", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 4; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 4) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 79: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 0 bajtów
//
void UTEST79(void)
{
    // informacje o teście
    test_start(79, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                char ***words;
                 
                int res = split_sentences("Fine, Java MIGHT be a good example of what a programming language should be like. But Java applications are good examples of what applications SHOULDNT be like. - pixadel.", &words);
                test_error(res == 3, "Funkcja split_sentences() powinna zwrócić wartość 3, a zwróciła %d", res);

                test_error(words == NULL, "Funkcja split_sentences() powinna przypisać pod wskaźnik NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 80: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 32 bajtów
//
void UTEST80(void)
{
    // informacje o teście
    test_start(80, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 32 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    

                char ***words;
                 
                int res = split_sentences("Fine, Java MIGHT be a good example of what a programming language should be like. But Java applications are good examples of what applications SHOULDNT be like. - pixadel.", &words);
                test_error(res == 3, "Funkcja split_sentences() powinna zwrócić wartość 3, a zwróciła %d", res);

                test_error(words == NULL, "Funkcja split_sentences() powinna przypisać pod wskaźnik NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 81: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 240 bajtów
//
void UTEST81(void)
{
    // informacje o teście
    test_start(81, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 240 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(240);
    
    //
    // -----------
    //
    

                char ***words;
                 
                int res = split_sentences("Fine, Java MIGHT be a good example of what a programming language should be like. But Java applications are good examples of what applications SHOULDNT be like. - pixadel.", &words);
                test_error(res == 3, "Funkcja split_sentences() powinna zwrócić wartość 3, a zwróciła %d", res);

                test_error(words == NULL, "Funkcja split_sentences() powinna przypisać pod wskaźnik NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 82: Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 422 bajtów
//
void UTEST82(void)
{
    // informacje o teście
    test_start(82, "Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 422 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(422);
    
    //
    // -----------
    //
    

                char ***words;
                 
                int res = split_sentences("Fine, Java MIGHT be a good example of what a programming language should be like. But Java applications are good examples of what applications SHOULDNT be like. - pixadel.", &words);
                test_error(res == 3, "Funkcja split_sentences() powinna zwrócić wartość 3, a zwróciła %d", res);

                test_error(words == NULL, "Funkcja split_sentences() powinna przypisać pod wskaźnik NULL");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 83: Sprawdzanie poprawności działania funkcji sort_sentences
//
void UTEST83(void)
{
    // informacje o teście
    test_start(83, "Sprawdzanie poprawności działania funkcji sort_sentences", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const char *expected_array[][1 + 1] = {{"Ninety"}};
                const int lenghts[] = {  1};

                const char *expected_sorted_array[][1 + 1] = {{"Ninety"}};
                const int sorted_lenghts[] = {  1};

                char ***words;
                 
                int res = split_sentences("Ninety.", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 1; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 1) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                res = sort_sentences(words);

                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);


                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 1; ++i)
                {    
                    int j;
                    for (j = 0; j < sorted_lenghts[i]; ++j)
                        test_error(strcmp(expected_sorted_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_sorted_array[i][j], words[i][j]);

                    if (sorted_lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 1) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");


                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 84: Sprawdzanie poprawności działania funkcji sort_sentences
//
void UTEST84(void)
{
    // informacje o teście
    test_start(84, "Sprawdzanie poprawności działania funkcji sort_sentences", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const char *expected_array[][1 + 1] = {{"So"}, {"many"}};
                const int lenghts[] = {  1,  1};

                const char *expected_sorted_array[][1 + 1] = {{"So"}, {"many"}};
                const int sorted_lenghts[] = {  1,  1};

                char ***words;
                 
                int res = split_sentences("So.many.", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 2; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 2) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                res = sort_sentences(words);

                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);


                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 2; ++i)
                {    
                    int j;
                    for (j = 0; j < sorted_lenghts[i]; ++j)
                        test_error(strcmp(expected_sorted_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_sorted_array[i][j], words[i][j]);

                    if (sorted_lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 2) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");


                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 85: Sprawdzanie poprawności działania funkcji sort_sentences
//
void UTEST85(void)
{
    // informacje o teście
    test_start(85, "Sprawdzanie poprawności działania funkcji sort_sentences", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const char *expected_array[][10 + 1] = {{"Everyday", "life", "is", "like", "programming", "I", "guess"}, {"If", "you", "love", "something", "you", "can", "put", "beauty", "into", "it"}, {"Donald", "Knuth"}};
                const int lenghts[] = {  7,  10,  2};

                const char *expected_sorted_array[][10 + 1] = {{"Donald", "Knuth"}, {"Everyday", "I", "guess", "is", "life", "like", "programming"}, {"If", "beauty", "can", "into", "it", "love", "put", "something", "you", "you"}};
                const int sorted_lenghts[] = {  2,  7,  10};

                char ***words;
                 
                int res = split_sentences("Everyday life is like programming, I guess. If you love something you can put beauty into it. - Donald Knuth.", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                res = sort_sentences(words);

                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);


                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 3; ++i)
                {    
                    int j;
                    for (j = 0; j < sorted_lenghts[i]; ++j)
                        test_error(strcmp(expected_sorted_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_sorted_array[i][j], words[i][j]);

                    if (sorted_lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 3) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");


                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 86: Sprawdzanie poprawności działania funkcji sort_sentences
//
void UTEST86(void)
{
    // informacje o teście
    test_start(86, "Sprawdzanie poprawności działania funkcji sort_sentences", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const char *expected_array[][34 + 1] = {{"Most", "software", "today", "is", "very", "much", "like", "an", "Egyptian", "pyramid", "with", "millions", "of", "bricks", "piled", "on", "top", "of", "each", "other", "with", "no", "structural", "integrity", "but", "just", "done", "by", "brute", "force", "and", "thousands", "of", "slaves"}, {"Alan", "Kay", "When", "we", "love", "we", "always", "strive", "to", "become", "better", "than", "we", "are"}, {"When", "we", "strive", "to", "become", "better", "than", "we", "are", "everything", "around", "us", "becomes", "better", "too"}, {"Paulo", "Coelho", "It", "is", "better", "to", "remain", "silent", "at", "the", "risk", "of", "being", "thought", "a", "fool", "than", "to", "talk", "and", "remove", "all", "doubt", "of", "it"}, {"Maurice", "Switzer", "The", "real", "danger", "is", "not", "that", "computers", "will", "begin", "to", "think", "like", "men", "but", "that", "men", "will", "begin", "to", "think", "like", "computers"}, {"Sydney", "J"}, {"Harris", "All", "that", "is", "gold", "does", "not", "glitter", "Not", "all", "those", "who", "wander", "are", "lost", "The", "old", "that", "is", "strong", "does", "not", "wither", "Deep", "roots", "are", "not", "reached", "by", "the", "frost"}, {"From", "the", "ashes", "a", "fire", "shall", "be", "woken", "A", "light", "from", "the", "shadows", "shall", "spring", "Renewed", "shall", "be", "blade", "that", "was", "broken", "The", "crownless", "again", "shall", "be", "king"}, {"J"}, {"R"}, {"R"}};
                const int lenghts[] = {  34,  14,  15,  25,  24,  2,  31,  28,  1,  1,  1};

                const char *expected_sorted_array[][34 + 1] = {{"J"}, {"R"}, {"R"}, {"J", "Sydney"}, {"Alan", "Kay", "When", "always", "are", "become", "better", "love", "strive", "than", "to", "we", "we", "we"}, {"When", "are", "around", "become", "becomes", "better", "better", "everything", "strive", "than", "to", "too", "us", "we", "we"}, {"Maurice", "Switzer", "The", "begin", "begin", "but", "computers", "computers", "danger", "is", "like", "like", "men", "men", "not", "real", "that", "that", "think", "think", "to", "to", "will", "will"}, {"Coelho", "It", "Paulo", "a", "all", "and", "at", "being", "better", "doubt", "fool", "is", "it", "of", "of", "remain", "remove", "risk", "silent", "talk", "than", "the", "thought", "to", "to"}, {"A", "From", "Renewed", "The", "a", "again", "ashes", "be", "be", "be", "blade", "broken", "crownless", "fire", "from", "king", "light", "shadows", "shall", "shall", "shall", "shall", "spring", "that", "the", "the", "was", "woken"}, {"All", "Deep", "Harris", "Not", "The", "all", "are", "are", "by", "does", "does", "frost", "glitter", "gold", "is", "is", "lost", "not", "not", "not", "old", "reached", "roots", "strong", "that", "that", "the", "those", "wander", "who", "wither"}, {"Egyptian", "Most", "an", "and", "bricks", "brute", "but", "by", "done", "each", "force", "integrity", "is", "just", "like", "millions", "much", "no", "of", "of", "of", "on", "other", "piled", "pyramid", "slaves", "software", "structural", "thousands", "today", "top", "very", "with", "with"}};
                const int sorted_lenghts[] = {  1,  1,  1,  2,  14,  15,  24,  25,  28,  31,  34};

                char ***words;
                 
                int res = split_sentences("\"Most software today is very much like an Egyptian pyramid with millions of bricks piled on top of each other, with no structural integrity, but just done by brute force and thousands of slaves.\" - Alan Kay\nWhen we love, we always strive to become better than we are. When we strive to become better than we are, everything around us becomes better too. - Paulo Coelho\nIt is better to remain silent at the risk of being thought a fool, than to talk and remove all doubt of it. - Maurice Switzer\nThe real danger is not that computers will begin to think like men, but that men will begin to think like computers.-Sydney J. Harris\nAll that is gold does not glitter,Not all those who wander are lost;The old that is strong does not wither,Deep roots are not reached by the frost.From the ashes a fire shall be woken,A light from the shadows shall spring;Renewed shall be blade that was broken,The crownless again shall be king. - J.R.R. Tolkien", &words);
                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);

                test_error(words != NULL, "Funkcja split_sentences() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 11; ++i)
                {    
                    int j;
                    for (j = 0; j < lenghts[i]; ++j)
                        test_error(strcmp(expected_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_array[i][j], words[i][j]);

                    if (lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 11) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");

                res = sort_sentences(words);

                test_error(res == 0, "Funkcja split_sentences() powinna zwrócić wartość 0, a zwróciła %d", res);


                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 11; ++i)
                {    
                    int j;
                    for (j = 0; j < sorted_lenghts[i]; ++j)
                        test_error(strcmp(expected_sorted_array[i][j], words[i][j]) == 0, "Funkcja split_sentences() niepoprawnie podzieliła wyrazy, pod indeksem %d w zdaniu %d powinno być %s, a jest %s", j , i, expected_sorted_array[i][j], words[i][j]);

                    if (sorted_lenghts[i])       
                        test_error(words[i][j] == NULL, "Funkcja split_sentences() powinna przypisać na końcu tablicy pod indeksem %d wartość NULL", i);
                }  
                test_error(*(words + 11) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");


                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 87: Sprawdzanie poprawności działania funkcji sort_sentences
//
void UTEST87(void)
{
    // informacje o teście
    test_start(87, "Sprawdzanie poprawności działania funkcji sort_sentences", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int res = sort_sentences(NULL);

            test_error(res == 1, "Funkcja sort_sentences() powinna zwrócić 1, a zwróciła %d", res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 88: Sprawdzanie poprawności działania funkcji sort_sentences
//
void UTEST88(void)
{
    // informacje o teście
    test_start(88, "Sprawdzanie poprawności działania funkcji sort_sentences", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            char ***words = NULL;

            int res = sort_sentences(words);

            test_error(res == 1, "Funkcja sort_sentences() powinna zwrócić 1, a zwróciła %d", res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci; limit ustawiono na 0 bajtów
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci; limit ustawiono na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                test_no_heap_leakage();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci; limit ustawiono na 1000 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci; limit ustawiono na 1000 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1000);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                test_no_heap_leakage();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci; limit ustawiono na 2200 bajtów
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci; limit ustawiono na 2200 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(2200);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                test_no_heap_leakage();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 8 bajtów
            UTEST2, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 24 bajtów
            UTEST3, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 219 bajtów
            UTEST4, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 35 bajtów
            UTEST5, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1086 bajtów
            UTEST6, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 5105 bajtów
            UTEST7, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 476 bajtów
            UTEST8, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 787 bajtów
            UTEST9, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 368 bajtów
            UTEST10, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 484 bajtów
            UTEST11, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 495 bajtów
            UTEST12, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 984 bajtów
            UTEST13, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1166 bajtów
            UTEST14, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 941 bajtów
            UTEST15, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 711 bajtów
            UTEST16, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 798 bajtów
            UTEST17, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 716 bajtów
            UTEST18, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 669 bajtów
            UTEST19, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1149 bajtów
            UTEST20, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 406 bajtów
            UTEST21, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 417 bajtów
            UTEST22, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 841 bajtów
            UTEST23, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 430 bajtów
            UTEST24, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1346 bajtów
            UTEST25, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1405 bajtów
            UTEST26, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 662 bajtów
            UTEST27, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1301 bajtów
            UTEST28, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 837 bajtów
            UTEST29, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 289 bajtów
            UTEST30, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 404 bajtów
            UTEST31, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 657 bajtów
            UTEST32, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 754 bajtów
            UTEST33, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 411 bajtów
            UTEST34, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 331 bajtów
            UTEST35, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 424 bajtów
            UTEST36, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 411 bajtów
            UTEST37, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 403 bajtów
            UTEST38, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 789 bajtów
            UTEST39, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 474 bajtów
            UTEST40, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 657 bajtów
            UTEST41, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 643 bajtów
            UTEST42, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 519 bajtów
            UTEST43, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1156 bajtów
            UTEST44, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 485 bajtów
            UTEST45, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1831 bajtów
            UTEST46, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 918 bajtów
            UTEST47, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 882 bajtów
            UTEST48, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 458 bajtów
            UTEST49, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 643 bajtów
            UTEST50, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1020 bajtów
            UTEST51, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 503 bajtów
            UTEST52, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1088 bajtów
            UTEST53, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 855 bajtów
            UTEST54, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1646 bajtów
            UTEST55, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 610 bajtów
            UTEST56, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 498 bajtów
            UTEST57, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 367 bajtów
            UTEST58, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1081 bajtów
            UTEST59, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 501 bajtów
            UTEST60, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 671 bajtów
            UTEST61, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 567 bajtów
            UTEST62, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1705 bajtów
            UTEST63, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 633 bajtów
            UTEST64, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 542 bajtów
            UTEST65, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 804 bajtów
            UTEST66, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 476 bajtów
            UTEST67, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 409 bajtów
            UTEST68, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 540 bajtów
            UTEST69, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 522 bajtów
            UTEST70, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 538 bajtów
            UTEST71, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 536 bajtów
            UTEST72, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1231 bajtów
            UTEST73, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 1469 bajtów
            UTEST74, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 443 bajtów
            UTEST75, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 522 bajtów
            UTEST76, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 682 bajtów
            UTEST77, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 548 bajtów
            UTEST78, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 303 bajtów
            UTEST79, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 0 bajtów
            UTEST80, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 32 bajtów
            UTEST81, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 240 bajtów
            UTEST82, // Sprawdzanie poprawności działania funkcji split_sentences - limit pamięci ustawiony na 422 bajtów
            UTEST83, // Sprawdzanie poprawności działania funkcji sort_sentences
            UTEST84, // Sprawdzanie poprawności działania funkcji sort_sentences
            UTEST85, // Sprawdzanie poprawności działania funkcji sort_sentences
            UTEST86, // Sprawdzanie poprawności działania funkcji sort_sentences
            UTEST87, // Sprawdzanie poprawności działania funkcji sort_sentences
            UTEST88, // Sprawdzanie poprawności działania funkcji sort_sentences
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(88); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci; limit ustawiono na 0 bajtów
            MTEST2, // Reakcja na brak pamięci; limit ustawiono na 1000 bajtów
            MTEST3, // Reakcja na brak pamięci; limit ustawiono na 2200 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(3); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}