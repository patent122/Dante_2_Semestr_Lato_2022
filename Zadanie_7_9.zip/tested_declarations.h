/*
 * Test dla zadania Ruchomy punkt
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 22:36:59.749079
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta



        #include "board.h"
        
        

#endif // _TESTED_DECLARATIONS_H_