#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "tested_declarations.h"
#include "rdebug.h"

int stats(int* suma, float* srednia, int liczba, ...) {
    if (suma == NULL || srednia == NULL || liczba <= 0) {
        return 1;
    }
    va_list list;
    va_start(list, liczba);
    int i;
    *suma = 0;
    for (i = 0; i < liczba; i++) {
        *suma += va_arg(list, int);
    }
    *srednia = (float)*suma / (float)liczba;
    va_end(list);
    return 0;
}

int main(int argc, char** argv) {
    printf("Enter number of elements: ");
    int ile;
    if (scanf("%d", &ile) != 1) {
        printf("Incorrect input");
        return 1;
    }
    if (ile <= 0 || ile > 3) {
        printf("Incorrect input data");
        return 2;
    }
    int suma;
    float avg;
    int aa, bb, znak;
    printf("Enter numbers: ");
    if (ile == 1) {
        if (scanf("%d", &aa) != 1) {
            printf("Incorrect input");
            return 1;
        }
        stats(&suma, &avg, 1, aa);
    }
    if (ile == 2) {
        if (scanf("%d", &aa) != 1) {
            printf("Incorrect input");
            return 1;
        }
        if (scanf("%d", &bb) != 1) {
            printf("Incorrect input");
            return 1;
        }
        stats(&suma, &avg, 2, aa, bb);
    }
    if (ile == 3) {
        if (scanf("%d", &aa) != 1) {
            printf("Incorrect input");
            return 1;
        }
        if (scanf("%d", &bb) != 1) {
            printf("Incorrect input");
            return 1;
        }
        if (scanf("%d", &znak) != 1) {
            printf("Incorrect input");
            return 1;
        }
        stats(&suma, &avg, 3, aa, bb, znak);
    }
    printf("%d %f\n", suma, avg);
    return 0;
}
