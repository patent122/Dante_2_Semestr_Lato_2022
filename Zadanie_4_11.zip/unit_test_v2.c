/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Vector
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-16 21:00:03.444578
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji vector_create
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji vector_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t ptr = { .size = 9, .capacity = 2 };

                printf("#####START#####");
                int res = vector_create(&ptr, -49);
                printf("#####END#####");

                test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!1)
                {           
            
                    test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == -49, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na -49, a ustawiła na %d", ptr.capacity);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji vector_create
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji vector_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t ptr = { .size = 4, .capacity = 6 };

                printf("#####START#####");
                int res = vector_create(&ptr, 0);
                printf("#####END#####");

                test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!1)
                {           
            
                    test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.capacity);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji vector_create
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji vector_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t ptr = { .size = 3, .capacity = 0 };

                printf("#####START#####");
                int res = vector_create(&ptr, 58);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!0)
                {           
            
                    test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == 58, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 58, a ustawiła na %d", ptr.capacity);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji vector_create
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji vector_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t ptr = { .size = -2, .capacity = 10 };

                printf("#####START#####");
                int res = vector_create(&ptr, 3190);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                
                if (!0)
                {           
            
                    test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                    test_error(ptr.capacity == 3190, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 3190, a ustawiła na %d", ptr.capacity);

                    free(ptr.ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie reakcji funkcji create_vector_int na limit pamięci (limit sterty ustawiono na 200 bajtów)
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie reakcji funkcji create_vector_int na limit pamięci (limit sterty ustawiono na 200 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(200);
    
    //
    // -----------
    //
    

                struct vector_t ptr = { .size = -7, .capacity = 1 };

                printf("#####START#####");
                int res = vector_create(&ptr, 50);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 50, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 50, a ustawiła na %d", ptr.capacity);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie reakcji funkcji create_vector_int na limit pamięci (limit sterty ustawiono na 91 bajtów)
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie reakcji funkcji create_vector_int na limit pamięci (limit sterty ustawiono na 91 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(91);
    
    //
    // -----------
    //
    

                struct vector_t ptr = { .size = -10, .capacity = -6 };

                printf("#####START#####");
                int res = vector_create(&ptr, 50);
                printf("#####END#####");

                test_error(res == 2, "Funkcja vector_create() powinna zwrócić wartość 2, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji vector_create
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji vector_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = vector_create(NULL, 50);
                printf("#####END#####");

                test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji vector_create_struct
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji vector_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t *ptr;

                printf("#####START#####");
                int res = vector_create_struct(&ptr, -1);
                printf("#####END#####");

                test_error(ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę vector_t, a przypisała NULL");
                test_error(res == 1, "Funkcja vector_create_struct() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                if (!1)
                {           
        
                    test_error(ptr->ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze vector_t, a przypisała NULL");
                    test_error(ptr->size == 0, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                    test_error(ptr->capacity == -1, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na -1, a ustawiła na %d", ptr->capacity);

                    free(ptr->ptr);
                    free(ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji vector_create_struct
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji vector_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t *ptr;

                printf("#####START#####");
                int res = vector_create_struct(&ptr, 0);
                printf("#####END#####");

                test_error(ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę vector_t, a przypisała NULL");
                test_error(res == 1, "Funkcja vector_create_struct() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                if (!1)
                {           
        
                    test_error(ptr->ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze vector_t, a przypisała NULL");
                    test_error(ptr->size == 0, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                    test_error(ptr->capacity == 0, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->capacity);

                    free(ptr->ptr);
                    free(ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji vector_create_struct
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji vector_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t *ptr;

                printf("#####START#####");
                int res = vector_create_struct(&ptr, 96);
                printf("#####END#####");

                test_error(ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę vector_t, a przypisała NULL");
                test_error(res == 0, "Funkcja vector_create_struct() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                if (!0)
                {           
        
                    test_error(ptr->ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze vector_t, a przypisała NULL");
                    test_error(ptr->size == 0, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                    test_error(ptr->capacity == 96, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na 96, a ustawiła na %d", ptr->capacity);

                    free(ptr->ptr);
                    free(ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji vector_create_struct
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji vector_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t *ptr;

                printf("#####START#####");
                int res = vector_create_struct(&ptr, 3169);
                printf("#####END#####");

                test_error(ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę vector_t, a przypisała NULL");
                test_error(res == 0, "Funkcja vector_create_struct() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                if (!0)
                {           
        
                    test_error(ptr->ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze vector_t, a przypisała NULL");
                    test_error(ptr->size == 0, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                    test_error(ptr->capacity == 3169, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na 3169, a ustawiła na %d", ptr->capacity);

                    free(ptr->ptr);
                    free(ptr);

                    test_no_heap_leakage();
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie reakcji funkcji vector_create_struct na limit pamięci (limit sterty ustawiono na 348 bajtów)
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie reakcji funkcji vector_create_struct na limit pamięci (limit sterty ustawiono na 348 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(348);
    
    //
    // -----------
    //
    

                struct vector_t *ptr;

                printf("#####START#####");
                int res = vector_create_struct(&ptr, 83);
                printf("#####END#####");

         
                test_error(ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika na strukturę vector_t, a przypisała NULL");
                test_error(res == 0, "Funkcja vector_create_struct() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->ptr != NULL, "Funkcja vector_create_struct() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze vector_t, a przypisała NULL");
                test_error(ptr->size == 0, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                test_error(ptr->capacity == 83, "Funkcja vector_create_struct() powinna ustawić wartość pola size w strukturze na 83, a ustawiła na %d", ptr->capacity);

                free(ptr->ptr);
                free(ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie reakcji funkcji vector_create_struct na limit pamięci (limit sterty ustawiono na 16 bajtów)
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie reakcji funkcji vector_create_struct na limit pamięci (limit sterty ustawiono na 16 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(16);
    
    //
    // -----------
    //
    

                struct vector_t *ptr;

                printf("#####START#####");
                int res = vector_create_struct(&ptr, 83);
                printf("#####END#####");

                test_error(res == 2, "Funkcja vector_create_struct() powinna zwrócić wartość 2, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie reakcji funkcji vector_create_struct na limit pamięci (limit sterty ustawiono na 36 bajtów)
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie reakcji funkcji vector_create_struct na limit pamięci (limit sterty ustawiono na 36 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(36);
    
    //
    // -----------
    //
    

                struct vector_t *ptr;

                printf("#####START#####");
                int res = vector_create_struct(&ptr, 83);
                printf("#####END#####");

                test_error(res == 2, "Funkcja vector_create_struct() powinna zwrócić wartość 2, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji vector_create_struct
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji vector_create_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                printf("#####START#####");
                int res = vector_create_struct(NULL, 83);
                printf("#####END#####");

                test_error(res == 1, "Funkcja vector_create_struct() powinna zwrócić wartość 1, a zwróciła %d", res);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji vector_push_back
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji vector_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int vector[] = {99, -31, -98, 64, -84, -13, 21, 20, -71, -38, -44, -67, 83, -6, -14};
        
                struct vector_t ptr = { .size = 4, .capacity = -9 };

                printf("#####START#####");
                int res = vector_create(&ptr, 15);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 15, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 15, a ustawiła na %d", ptr.capacity);

                for (int i = 0; i < 15; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
                        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 15, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 15, a ustawiła na %d", ptr.capacity);
                        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                int additional = -52;
                printf("#####START#####");
                res = vector_push_back(&ptr, additional);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                test_error(ptr.size == 16, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 16, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 30, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 30, a ustawiła na %d", ptr.capacity);
                
                int j;
                
                for (j = 0; j < 15; ++j)
                    test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
                
                test_error(ptr.ptr[j] == additional, "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, additional, ptr.ptr[j]);
                
                
                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji vector_push_back
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji vector_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                const int vector[] = {-32, 25, -47, 1, -11, -45, 1, 30, 51, -90, 81, -79, 96, -91, -49, 85, 11, 36, 98, -54, 25, -99, 91, -97, 51, -47, -38, 95, 86, -80, 48, 34, -46, 17, 57, 37, -53, -12, 38, -18, -18, 55, -38, 57, -78, -32, -46, -76, 92, 77, -34, -57, 11, -9, -42, -18, 81, -46, 81, -53, -82, -44, 8, 82, -28, -78, -74, -28};
        
                struct vector_t ptr = { .size = 1, .capacity = 8 };

                printf("#####START#####");
                int res = vector_create(&ptr, 68);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 68, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 68, a ustawiła na %d", ptr.capacity);

                for (int i = 0; i < 68; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
                        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 68, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 68, a ustawiła na %d", ptr.capacity);
                        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);

                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }

                int additional = 2;
                printf("#####START#####");
                res = vector_push_back(&ptr, additional);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                test_error(ptr.size == 69, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 69, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 136, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 136, a ustawiła na %d", ptr.capacity);
                
                int j;
                
                for (j = 0; j < 68; ++j)
                    test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
                
                test_error(ptr.ptr[j] == additional, "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, additional, ptr.ptr[j]);
                
                
                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie reakcji funkcji vector_push_back na limit pamięci (limit sterty ustawiono na 64 bajtów)
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie reakcji funkcji vector_push_back na limit pamięci (limit sterty ustawiono na 64 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(64);
    
    //
    // -----------
    //
    

            const int vector[] = {-35, -57, -1, -75, -83, -55, 95, -92, 50, 55, -58, 44, 91, 24, -18, -33};

            struct vector_t ptr = { .size = -3, .capacity = 5 };

            printf("#####START#####");
            int res = vector_create(&ptr, 8);
            printf("#####END#####");

            test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
            test_error(ptr.capacity == 8, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 8, a ustawiła na %d", ptr.capacity);

            for (int i = 0; i < 8; ++i)
            {
                    printf("#####START#####");
                    res = vector_push_back(&ptr, vector[i]);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                    test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                    test_error(ptr.capacity == 8, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 8, a ustawiła na %d", ptr.capacity);

                    for (int j = 0; j <= i; ++j)
                        test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            }

            for (int i = 8; i < 16; ++i)
            {
                    printf("#####START#####");
                    res = vector_push_back(&ptr, vector[i]);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                    test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                    test_error(ptr.capacity == 16, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 16, a ustawiła na %d", ptr.capacity);

                    for (int j = 0; j <= i; ++j)
                        test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            }


            free(ptr.ptr);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie reakcji funkcji vector_push_back na limit pamięci (limit sterty ustawiono na 32 bajtów)
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie reakcji funkcji vector_push_back na limit pamięci (limit sterty ustawiono na 32 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    

            const int vector[] = {-35, -57, -1, -75, -83, -55, 95, -92, 50, 55, -58, 44, 91, 24, -18, -33};

            struct vector_t ptr = { .size = -3, .capacity = 1 };

            printf("#####START#####");
            int res = vector_create(&ptr, 8);
            printf("#####END#####");

            test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
            test_error(ptr.capacity == 8, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 8, a ustawiła na %d", ptr.capacity);

            int i;
            for (i = 0; i < 8; ++i)
            {
                    printf("#####START#####");
                    res = vector_push_back(&ptr, vector[i]);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                    test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                    test_error(ptr.capacity == 8, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 8, a ustawiła na %d", ptr.capacity);

                    for (int j = 0; j <= i; ++j)
                        test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            }

            printf("#####START#####");
            res = vector_push_back(&ptr, vector[i]);
            printf("#####END#####");

            test_error(res == 2, "Funkcja vector_push_back() powinna zwrócić wartość 2, a zwróciła %d", res);
            test_error(ptr.size == i, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i, ptr.size);
            test_error(ptr.capacity == 8, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 8, a ustawiła na %d", ptr.capacity);

            for (int j = 0; j < i; ++j)
                test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);

            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            free(ptr.ptr);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji vector_push_back
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji vector_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int vector[] = {0, 43, -19, -27, 26, -69, -42, 29, 82, -18};
                struct vector_t ptr = { .ptr = vector, .size = -10, .capacity = 4 };
                    
                printf("#####START#####");
                int res = vector_push_back(&ptr, 53);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji vector_push_back
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji vector_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int vector[] = {0, 43, -19, -27, 26, -69, -42, 29, 82, -18};
                struct vector_t ptr = { .ptr = vector, .size = 0, .capacity = -3 };
                    
                printf("#####START#####");
                int res = vector_push_back(&ptr, 18);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji vector_push_back
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji vector_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int vector[] = {0, 43, -19, -27, 26, -69, -42, 29, 82, -18};
                struct vector_t ptr = { .ptr = vector, .size = 11, .capacity = 9 };
                    
                printf("#####START#####");
                int res = vector_push_back(&ptr, 27);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji vector_push_back
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji vector_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int vector[] = {0, 43, -19, -27, 26, -69, -42, 29, 82, -18};
                struct vector_t ptr = { .ptr = vector, .size = 0, .capacity = 0 };
                    
                printf("#####START#####");
                int res = vector_push_back(&ptr, 95);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji vector_push_back
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji vector_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int vector[] = {0, 43, -19, -27, 26, -69, -42, 29, 82, -18};
                struct vector_t ptr = { .ptr = vector, .size = 17, .capacity = -6 };
                    
                printf("#####START#####");
                int res = vector_push_back(&ptr, -62);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji vector_push_back
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji vector_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                int vector[] = {0, 43, -19, -27, 26, -69, -42, 29, 82, -18};
                struct vector_t ptr = { .ptr = vector, .size = -17, .capacity = -2 };
                    
                printf("#####START#####");
                int res = vector_push_back(&ptr, 4);
                printf("#####END#####");
        
                test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);
        
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji vector_push_back
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji vector_push_back", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            int res = vector_push_back(NULL, 68);
            printf("#####END#####");

            test_error(res == 1, "Funkcja vector_create() powinna zwrócić wartość 1, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {11, -17, -3, -55, -85, -42, 31, 62, 42, 63, 89, -4, 25, -36};
                const int expected_vector[] = {-17, -3, -55, -85, -42, 31, 62, 42, 63, 89, -4, 25, -36};

                struct vector_t ptr = { .size = 14, .capacity = 14 };

                printf("#####START#####");
                int res = vector_create(&ptr, 14);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 14, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 14, a ustawiła na %d", ptr.capacity);
        
                int i;
                for (i = 0; i < 14; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 14, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 14, a ustawiła na %d", ptr.capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }


                printf("#####START#####");
                res = vector_erase(&ptr, 11);
                printf("#####END#####");

                test_error(res == 1, "Funkcja vector_erase() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 13, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 13, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 14, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 14, a ustawiła na %d", ptr.capacity);

                for (int j = 0; j < 13; ++j)
                    test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {-37};
                const int expected_vector[] = {0};

                struct vector_t ptr = { .size = 1, .capacity = 1 };

                printf("#####START#####");
                int res = vector_create(&ptr, 1);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 1, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 1, a ustawiła na %d", ptr.capacity);
        
                int i;
                for (i = 0; i < 1; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 1, a ustawiła na %d", ptr.capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }


                printf("#####START#####");
                res = vector_erase(&ptr, -37);
                printf("#####END#####");

                test_error(res == 1, "Funkcja vector_erase() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 1, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 1, a ustawiła na %d", ptr.capacity);

                for (int j = 0; j < 0; ++j)
                    test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {31};
                const int expected_vector[] = {31};

                struct vector_t ptr = { .size = 1, .capacity = 1 };

                printf("#####START#####");
                int res = vector_create(&ptr, 1);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 1, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 1, a ustawiła na %d", ptr.capacity);
        
                int i;
                for (i = 0; i < 1; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 1, a ustawiła na %d", ptr.capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }


                printf("#####START#####");
                res = vector_erase(&ptr, 32);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_erase() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 1, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 1, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 1, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 1, a ustawiła na %d", ptr.capacity);

                for (int j = 0; j < 1; ++j)
                    test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {-70, -12, -92, 46, 87, -65, -97, -46, -55, 22, 22, -85, 100, 43, -92, 12, -18, -82, 84, 59, -53, -38, 84};
                const int expected_vector[] = {-70, -12, -92, 46, 87, -65, -97, -46, -55, 22, 22, -85, 100, 43, -92, 12, -18, -82, 59, -53, -38};

                struct vector_t ptr = { .size = 23, .capacity = 23 };

                printf("#####START#####");
                int res = vector_create(&ptr, 23);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 23, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 23, a ustawiła na %d", ptr.capacity);
        
                int i;
                for (i = 0; i < 23; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 23, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 23, a ustawiła na %d", ptr.capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }


                printf("#####START#####");
                res = vector_erase(&ptr, 84);
                printf("#####END#####");

                test_error(res == 2, "Funkcja vector_erase() powinna zwrócić wartość 2, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 21, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 21, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 23, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 23, a ustawiła na %d", ptr.capacity);

                for (int j = 0; j < 21; ++j)
                    test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {-38, 100, -26, -17, 48, 45, -91, 37, -86, 84, 24, 92, -48, 76, -22, -20, 76, 29, 44, -68, 20};
                const int expected_vector[] = {-38, 100, -26, -17, 48, 45, -91, 37, -86, 84, 24, -48, 76, -22, -20, 76, 29, 44, -68, 20};

                struct vector_t ptr = { .size = 21, .capacity = 21 };

                printf("#####START#####");
                int res = vector_create(&ptr, 21);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 21, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 21, a ustawiła na %d", ptr.capacity);
        
                int i;
                for (i = 0; i < 21; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 21, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 21, a ustawiła na %d", ptr.capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }


                printf("#####START#####");
                res = vector_erase(&ptr, 92);
                printf("#####END#####");

                test_error(res == 1, "Funkcja vector_erase() powinna zwrócić wartość 1, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 20, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 20, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 21, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 21, a ustawiła na %d", ptr.capacity);

                for (int j = 0; j < 20; ++j)
                    test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {2, -8, -10, 7, 7, 7, 5, 5, -3, -2, -4, 3, 8, -4, 10, -7, -1, 10, 5, 10, 10, 0, -10, -10, -10, 8, 3, -1, -3, 4, -6, -8, 5, 4, 5, -2, -2, 2, -7, 0, -2, 3, 3, -2, 10, 10, -6, -3, 4, 6};
                const int expected_vector[] = {2, -8, -10, 7, 7, 7, 5, 5, -3, -2, -4, 3, 8, -4, 10, -7, -1, 10, 5, 10, 10, -10, -10, -10, 8, 3, -1, -3, 4, -6, -8, 5, 4, 5, -2, -2, 2, -7, -2, 3, 3, -2, 10, 10, -6, -3, 4, 6};

                struct vector_t ptr = { .size = 50, .capacity = 50 };

                printf("#####START#####");
                int res = vector_create(&ptr, 50);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 50, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 50, a ustawiła na %d", ptr.capacity);
        
                int i;
                for (i = 0; i < 50; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 50, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 50, a ustawiła na %d", ptr.capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }


                printf("#####START#####");
                res = vector_erase(&ptr, 0);
                printf("#####END#####");

                test_error(res == 2, "Funkcja vector_erase() powinna zwrócić wartość 2, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 48, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 48, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 50, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 50, a ustawiła na %d", ptr.capacity);

                for (int j = 0; j < 48; ++j)
                    test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
                const int expected_vector[] = {0};

                struct vector_t ptr = { .size = 48, .capacity = 48 };

                printf("#####START#####");
                int res = vector_create(&ptr, 48);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 48, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 48, a ustawiła na %d", ptr.capacity);
        
                int i;
                for (i = 0; i < 48; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 48, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 48, a ustawiła na %d", ptr.capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }


                printf("#####START#####");
                res = vector_erase(&ptr, 1);
                printf("#####END#####");

                test_error(res == 48, "Funkcja vector_erase() powinna zwrócić wartość 48, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 0, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 24, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 24, a ustawiła na %d", ptr.capacity);

                for (int j = 0; j < 0; ++j)
                    test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9};
                const int expected_vector[] = {9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9};

                struct vector_t ptr = { .size = 40, .capacity = 40 };

                printf("#####START#####");
                int res = vector_create(&ptr, 40);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 40, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 40, a ustawiła na %d", ptr.capacity);
        
                int i;
                for (i = 0; i < 40; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 40, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 40, a ustawiła na %d", ptr.capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }


                printf("#####START#####");
                res = vector_erase(&ptr, 6);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_erase() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 40, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 40, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 40, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 40, a ustawiła na %d", ptr.capacity);

                for (int j = 0; j < 40; ++j)
                    test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {75, 97, 43, 78, -59, -45, -90, 86, -70, -93, -31, 19, -45, -72, 9, 15, 55, -67, 91, -61, -42, -82, -81, -35, 90, -3, 24, 35, 44, 38, 8, 48, 39, -86, 49, -7, -16, -61, -62, -10, 81, -60, -23, 81, 55, 27, 55, 18};
                const int expected_vector[] = {75, 97, 43, 78, -59, -45, -90, 86, -70, -93, -31, 19, -45, -72, 9, 15, 55, -67, 91, -61, -42, -82, -81, -35, 90, -3, 24, 35, 44, 38, 8, 48, 39, -86, 49, -7, -16, -61, -62, -10, 81, -60, -23, 81, 55, 27, 55, 18};

                struct vector_t ptr = { .size = 48, .capacity = 48 };

                printf("#####START#####");
                int res = vector_create(&ptr, 48);
                printf("#####END#####");
        
                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 48, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 48, a ustawiła na %d", ptr.capacity);
        
                int i;
                for (i = 0; i < 48; ++i)
                {
                        printf("#####START#####");
                        res = vector_push_back(&ptr, vector[i]);
                        printf("#####END#####");
        
                        test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                        test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                        test_error(ptr.capacity == 48, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 48, a ustawiła na %d", ptr.capacity);
        
                        for (int j = 0; j <= i; ++j)
                            test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);
        
                        onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
                }


                printf("#####START#####");
                res = vector_erase(&ptr, 63);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_erase() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.size == 48, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 48, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 48, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 48, a ustawiła na %d", ptr.capacity);

                for (int j = 0; j < 48; ++j)
                    test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

                free(ptr.ptr);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


            struct vector_t ptr = { .size = 0, .capacity = 6 };
                    
            printf("#####START#####");
            int res = vector_create(&ptr, 6);
            printf("#####END#####");
                
            test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
            test_error(ptr.capacity == 6, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 6, a ustawiła na %d", ptr.capacity);
        
            printf("#####START#####");
            res = vector_erase(&ptr, -6);
            printf("#####END#####");

            test_error(res == 0, "Funkcja vector_erase() powinna zwrócić wartość 0, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(ptr.size == 0, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
            test_error(ptr.capacity == 3, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 3, a ustawiła na %d", ptr.capacity);

            free(ptr.ptr);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie reakcji funkcji vector_erase na limit pamięci (limit sterty ustawiono na 220 bajtów)
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie reakcji funkcji vector_erase na limit pamięci (limit sterty ustawiono na 220 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(220);
    
    //
    // -----------
    //
    

            int vector[] = {-1, -1, -1, -1, -1, -1, -6, -1, -1, -1, -6, -1, 6, -1, -1, -1, 0, -1, -1, 10, -5, -1, -1, -1, 3, -1, -1, 9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, -6, -1, -1, -1, -1, -1, -8, -1, -1, -1, -1, -1, -1};
            const int expected_vector[] = {-6, -6, 6, 0, 10, -5, 3, 9, 5, -6, -8};

            struct vector_t ptr = { .size = 55, .capacity = 55 };

            printf("#####START#####");
            int res = vector_create(&ptr, 55);
            printf("#####END#####");

            test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
            test_error(ptr.capacity == 55, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 55, a ustawiła na %d", ptr.capacity);

            int i;
            for (i = 0; i < 55; ++i)
            {
                    printf("#####START#####");
                    res = vector_push_back(&ptr, vector[i]);
                    printf("#####END#####");

                    test_error(res == 0, "Funkcja vector_push_back() powinna zwrócić wartość 0, a zwróciła %d", res);
                    test_error(ptr.size == i + 1, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na %d, a ustawiła na %d", i + 1, ptr.size);
                    test_error(ptr.capacity == 55, "Funkcja vector_push_back() powinna ustawić wartość pola size w strukturze na 55, a ustawiła na %d", ptr.capacity);

                    for (int j = 0; j <= i; ++j)
                        test_error(ptr.ptr[j] == vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, vector[j], ptr.ptr[j]);

                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            }


            printf("#####START#####");
            res = vector_erase(&ptr, -1);
            printf("#####END#####");

            test_error(res == 44, "Funkcja vector_erase() powinna zwrócić wartość 44, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            test_error(ptr.size == 11, "Funkcja vector_erase() powinna ustawić wartość pola size w strukturze na 11, a ustawiła na %d", ptr.size);
            test_error(ptr.capacity == 27, "Funkcja vector_erase() powinna ustawić wartość pola capacity w strukturze na 27, a ustawiła na %d", ptr.capacity);

            for (int j = 0; j < 11; ++j)
                test_error(ptr.ptr[j] == expected_vector[j], "Wartość pod indeksem %d jest nieprawidłowa; powinno być %d, a jest %d", j, expected_vector[j], ptr.ptr[j]);

            free(ptr.ptr);

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {-94, -27, -80, -73, 36, -16, -87, 76, -77, -34, 45, -84, 23, -53};
                struct vector_t ptr = { .ptr = vector, .size = -4, .capacity = 7 };

                printf("#####START#####");
                int res = vector_erase(&ptr, 89);
                printf("#####END#####");

                test_error(res == -1, "Funkcja vector_erase() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {-94, -27, -80, -73, 36, -16, -87, 76, -77, -34, 45, -84, 23, -53};
                struct vector_t ptr = { .ptr = vector, .size = 0, .capacity = -9 };

                printf("#####START#####");
                int res = vector_erase(&ptr, -69);
                printf("#####END#####");

                test_error(res == -1, "Funkcja vector_erase() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {-94, -27, -80, -73, 36, -16, -87, 76, -77, -34, 45, -84, 23, -53};
                struct vector_t ptr = { .ptr = vector, .size = 17, .capacity = 2 };

                printf("#####START#####");
                int res = vector_erase(&ptr, 86);
                printf("#####END#####");

                test_error(res == -1, "Funkcja vector_erase() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {-94, -27, -80, -73, 36, -16, -87, 76, -77, -34, 45, -84, 23, -53};
                struct vector_t ptr = { .ptr = vector, .size = 0, .capacity = 0 };

                printf("#####START#####");
                int res = vector_erase(&ptr, 75);
                printf("#####END#####");

                test_error(res == -1, "Funkcja vector_erase() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {-94, -27, -80, -73, 36, -16, -87, 76, -77, -34, 45, -84, 23, -53};
                struct vector_t ptr = { .ptr = vector, .size = 13, .capacity = -8 };

                printf("#####START#####");
                int res = vector_erase(&ptr, -94);
                printf("#####END#####");

                test_error(res == -1, "Funkcja vector_erase() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int vector[] = {-94, -27, -80, -73, 36, -16, -87, 76, -77, -34, 45, -84, 23, -53};
                struct vector_t ptr = { .ptr = vector, .size = -13, .capacity = -9 };

                printf("#####START#####");
                int res = vector_erase(&ptr, 48);
                printf("#####END#####");

                test_error(res == -1, "Funkcja vector_erase() powinna zwrócić wartość -1, a zwróciła %d", res);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie poprawności działania funkcji vector_erase
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie poprawności działania funkcji vector_erase", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            int res = vector_erase(NULL, -6);
            printf("#####END#####");

            test_error(res == -1, "Funkcja vector_create() powinna zwrócić wartość -1, a zwróciła %d", res);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie poprawności działania funkcji vector_destroy
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie poprawności działania funkcji vector_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t ptr;

                printf("#####START#####");
                int res = vector_create(&ptr, 14);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.ptr != NULL, "Funkcja vector_create() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze vector_t, a przypisała NULL");
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 14, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 14, a ustawiła na %d", ptr.capacity);

                printf("#####START#####");
                vector_destroy(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie poprawności działania funkcji vector_destroy
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie poprawności działania funkcji vector_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t ptr;

                printf("#####START#####");
                int res = vector_create(&ptr, 14);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr.ptr != NULL, "Funkcja vector_create() powinna przypisać adres zaalokowanej pamięci do wskaźnika ptr w strukturze vector_t, a przypisała NULL");
                test_error(ptr.size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr.size);
                test_error(ptr.capacity == 14, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 14, a ustawiła na %d", ptr.capacity);

                printf("#####START#####");
                vector_destroy(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie poprawności działania funkcji vector_destroy
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie poprawności działania funkcji vector_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


            printf("#####START#####");
            vector_destroy(NULL);
            printf("#####END#####");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie poprawności działania funkcji vector_destroy
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie poprawności działania funkcji vector_destroy", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct vector_t ptr = { .ptr = NULL, .size = 3, .capacity = 12 };

            printf("#####START#####");
            vector_destroy(&ptr);
            printf("#####END#####");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie poprawności działania funkcji vector_destroy_struct
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie poprawności działania funkcji vector_destroy_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t *ptr;

                printf("#####START#####");
                int res = vector_create_struct(&ptr, 39);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                test_error(ptr->capacity == 39, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 39, a ustawiła na %d", ptr->capacity);

                printf("#####START#####");
                vector_destroy_struct(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 50: Sprawdzanie poprawności działania funkcji vector_destroy_struct
//
void UTEST50(void)
{
    // informacje o teście
    test_start(50, "Sprawdzanie poprawności działania funkcji vector_destroy_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct vector_t *ptr;

                printf("#####START#####");
                int res = vector_create_struct(&ptr, 9110);
                printf("#####END#####");

                test_error(res == 0, "Funkcja vector_create() powinna zwrócić wartość 0, a zwróciła %d", res);
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(ptr->size == 0, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 0, a ustawiła na %d", ptr->size);
                test_error(ptr->capacity == 9110, "Funkcja vector_create() powinna ustawić wartość pola size w strukturze na 9110, a ustawiła na %d", ptr->capacity);

                printf("#####START#####");
                vector_destroy_struct(&ptr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 51: Sprawdzanie poprawności działania funkcji vector_destroy_struct
//
void UTEST51(void)
{
    // informacje o teście
    test_start(51, "Sprawdzanie poprawności działania funkcji vector_destroy_struct", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    


            printf("#####START#####");
            vector_destroy_struct(NULL);
            printf("#####END#####");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 52: Sprawdzanie poprawności działania funkcji vector_display
//
void UTEST52(void)
{
    // informacje o teście
    test_start(52, "Sprawdzanie poprawności działania funkcji vector_display", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int vector[] = {-94, -27, -80, -73, 36, -16, -87, 76, -77, -34, 45, -84, 23, -53};

            struct vector_t arr;
            arr.ptr = vector;

    //-------------1-----------------------

            printf("***START***\n");
            vector_display(NULL);
            printf("***END***\n");


    //-------------2-----------------------

            arr.capacity = 13;
            arr.size = 14;

            printf("***START***\n");
            vector_display(&arr);
            printf("***END***\n");


    //-------------3-----------------------

            arr.capacity = 14;
            arr.size = -14;

            printf("***START***\n");
            vector_display(&arr);
            printf("***END***\n");


    //-------------4-----------------------

            arr.capacity = 14;
            arr.size = 0;

            printf("***START***\n");
            vector_display(&arr);
            printf("***END***\n");

    //-------------5-----------------------

            arr.capacity = 14;
            arr.size = 14;
            arr.ptr = NULL;

            printf("***START***\n");
            vector_display(&arr);
            printf("***END***\n");

    //-------------6-----------------------

            arr.capacity = 14;
            arr.size = 14;
            arr.ptr = vector;

            printf("***START***\n");
            vector_display(&arr);
            printf("***END***\n");

    //-------------7-----------------------

            arr.capacity = 14;
            arr.size = 14 - 1;

            printf("***START***\n");
            vector_display(&arr);
            printf("***END***\n");

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci (limit sterty ustawiono na 16 bajtów)
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci (limit sterty ustawiono na 16 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(16);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(72);
    
    //
    // -----------
    //
    
            printf("***START***\n");
            int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
            printf("\n***END***\n");
            test_error(ret_code == 0, "Funkcja main zakończyła się kodem %d a powinna 0", ret_code); 
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji vector_create
            UTEST2, // Sprawdzanie poprawności działania funkcji vector_create
            UTEST3, // Sprawdzanie poprawności działania funkcji vector_create
            UTEST4, // Sprawdzanie poprawności działania funkcji vector_create
            UTEST5, // Sprawdzanie reakcji funkcji create_vector_int na limit pamięci (limit sterty ustawiono na 200 bajtów)
            UTEST6, // Sprawdzanie reakcji funkcji create_vector_int na limit pamięci (limit sterty ustawiono na 91 bajtów)
            UTEST7, // Sprawdzanie poprawności działania funkcji vector_create
            UTEST8, // Sprawdzanie poprawności działania funkcji vector_create_struct
            UTEST9, // Sprawdzanie poprawności działania funkcji vector_create_struct
            UTEST10, // Sprawdzanie poprawności działania funkcji vector_create_struct
            UTEST11, // Sprawdzanie poprawności działania funkcji vector_create_struct
            UTEST12, // Sprawdzanie reakcji funkcji vector_create_struct na limit pamięci (limit sterty ustawiono na 348 bajtów)
            UTEST13, // Sprawdzanie reakcji funkcji vector_create_struct na limit pamięci (limit sterty ustawiono na 16 bajtów)
            UTEST14, // Sprawdzanie reakcji funkcji vector_create_struct na limit pamięci (limit sterty ustawiono na 36 bajtów)
            UTEST15, // Sprawdzanie poprawności działania funkcji vector_create_struct
            UTEST16, // Sprawdzanie poprawności działania funkcji vector_push_back
            UTEST17, // Sprawdzanie poprawności działania funkcji vector_push_back
            UTEST18, // Sprawdzanie reakcji funkcji vector_push_back na limit pamięci (limit sterty ustawiono na 64 bajtów)
            UTEST19, // Sprawdzanie reakcji funkcji vector_push_back na limit pamięci (limit sterty ustawiono na 32 bajtów)
            UTEST20, // Sprawdzanie poprawności działania funkcji vector_push_back
            UTEST21, // Sprawdzanie poprawności działania funkcji vector_push_back
            UTEST22, // Sprawdzanie poprawności działania funkcji vector_push_back
            UTEST23, // Sprawdzanie poprawności działania funkcji vector_push_back
            UTEST24, // Sprawdzanie poprawności działania funkcji vector_push_back
            UTEST25, // Sprawdzanie poprawności działania funkcji vector_push_back
            UTEST26, // Sprawdzanie poprawności działania funkcji vector_push_back
            UTEST27, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST28, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST29, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST30, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST31, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST32, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST33, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST34, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST35, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST36, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST37, // Sprawdzanie reakcji funkcji vector_erase na limit pamięci (limit sterty ustawiono na 220 bajtów)
            UTEST38, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST39, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST40, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST41, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST42, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST43, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST44, // Sprawdzanie poprawności działania funkcji vector_erase
            UTEST45, // Sprawdzanie poprawności działania funkcji vector_destroy
            UTEST46, // Sprawdzanie poprawności działania funkcji vector_destroy
            UTEST47, // Sprawdzanie poprawności działania funkcji vector_destroy
            UTEST48, // Sprawdzanie poprawności działania funkcji vector_destroy
            UTEST49, // Sprawdzanie poprawności działania funkcji vector_destroy_struct
            UTEST50, // Sprawdzanie poprawności działania funkcji vector_destroy_struct
            UTEST51, // Sprawdzanie poprawności działania funkcji vector_destroy_struct
            UTEST52, // Sprawdzanie poprawności działania funkcji vector_display
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(52); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci (limit sterty ustawiono na 0 bajtów)
            MTEST2, // Reakcja na brak pamięci (limit sterty ustawiono na 16 bajtów)
            MTEST3, // Reakcja na brak pamięci (limit sterty ustawiono na 72 bajtów)
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(3); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}