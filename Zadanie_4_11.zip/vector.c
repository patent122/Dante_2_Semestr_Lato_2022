#include "vector.h"
#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int vector_create(struct vector_t* v, int N)
{
    if (v == NULL || N < 1) return 1;

    v->ptr = (int*)malloc(N * sizeof(int));
    v->size = 0;
    v->capacity = N;

    if (v->ptr == NULL) return 2;

    return 0;
}

int vector_push_back(struct vector_t* v, int value)
{
    if (v == NULL || v->size < 0 || v->capacity < 1 || v->size > v->capacity) return 1;

    void* bufor;

    if (v->size == v->capacity)
    {
        bufor = realloc(v->ptr, v->capacity * 2 * sizeof(int));

        if (bufor == NULL) return 2;

        v->ptr = (int*)bufor;

        v->capacity *= 2;
    }

    *(v->ptr + v->size) = value;
    v->size += 1;

    return 0;
}

void vector_display(const struct vector_t* v)
{
    if (v == NULL || v->size > v->capacity || v->size < 1 || v->ptr == NULL) return;

    for (int i = 0; i < v->size; ++i)
    {
        printf("%d ", *(v->ptr + i));
    }
}

void vector_destroy(struct vector_t* v)
{
    if (v == NULL || v->ptr == NULL) return;

    free(v->ptr);
}

int vector_create_struct(struct vector_t** v, int N)
{
    if (v == NULL || N < 1) return 1;

    *v = (struct vector_t*)malloc(sizeof(struct vector_t));

    if (*v == NULL) return 2;

    int blad = vector_create(*v, N);

    if (blad == 1 || blad == 2)
    {
        free(*v);
        return 2;
    }

    return 0;
}

void vector_destroy_struct(struct vector_t** v)
{
    if (v == NULL) return;
    vector_destroy(*v);
    free(*v);
}

int vector_erase(struct vector_t* v, int value)
{
    if (v == NULL || v->size < 0 || v->capacity < 1 || v->size > v->capacity || v->ptr == NULL)
    {
        return -1;
    }
    int x = 0;
    int ile = 0;

    while (x < v->size)
    {
        if (*(v->ptr + x) == value)
        {
            ile++;
            for (int i = x; i < v->size - 1; ++i)
            {
                *(v->ptr + i) = *(v->ptr + i + 1);
            }
            v->size = v->size - 1;
            x--;
        }
        x++;
    }

    if (((float)v->size / (float)v->capacity) < 0.25 && v->capacity >= 2)
    {
        void* buffer = realloc(v->ptr, v->capacity / 2 * sizeof(int));

        if (buffer == NULL) return -1;

        v->ptr = (int*)buffer;
        v->capacity /= 2;
    }

    return ile;
}
