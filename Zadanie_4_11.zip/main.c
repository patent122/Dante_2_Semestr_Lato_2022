#include <stdio.h>
#include "vector.h"
#include "tested_declarations.h"
#include "rdebug.h"

void wyczysc_wejscie(void)
{
    int znak;
    do
    {
        znak = getchar();
    } while (znak != '\n' && znak != EOF);
}

int main()
{
    struct vector_t* v;
    int ile, rozmiar, blad;

    printf("Podaj wielkosc tablicy: ");

    if (scanf("%d", &rozmiar) != 1)
    {
        printf("Incorrect input\n");
        return 1;
    }
    if (rozmiar < 1)
    {
        printf("Incorrect input data\n");
        return 2;
    }

    blad = vector_create_struct(&v, rozmiar);
    if (blad == 2)
    {
        printf("Failed to allocate memory\n");
        return 8;
    }

    do {
        int odpowiedz;
        wyczysc_wejscie();
        printf("Co chcesz zrobi�: ");
        if (scanf("%d", &odpowiedz) != 1)
        {
            printf("Incorrect input\n");
            vector_destroy_struct(&v);
            return 1;
        }
        if (odpowiedz == 0)
        {
            vector_destroy_struct(&v);
            return 0;
        }
        if (odpowiedz == 1)
        {
            printf("Podaj liczby do dodania do tablicy: ");
            int px;
            while ((px = scanf("%d", &ile)) == 1 && ile != 0)
            {
                blad = vector_push_back(v, ile);

                if (blad == 2)
                {
                    printf("Failed to allocate memory\n");
                    break;
                }
            }

            if (px != 1)
            {
                printf("Incorrect input\n");
                vector_destroy_struct(&v);
                return 1;
            }

            if (v->size != 0)
            {
                vector_display(v);
                printf("\n");
            }
        }
        if (odpowiedz == 2)
        {
            printf("Podaj liczby do usuniecia z tablicy: ");
            int px;
            while ((px = scanf("%d", &ile)) == 1 && ile != 0)
            {
                vector_erase(v, ile);

                if (v->size == 0)
                {
                    break;
                }
            }

            if (px != 1)
            {
                printf("Incorrect input\n");
                vector_destroy_struct(&v);
                return 1;
            }
            if (v->size == 0)
            {
                printf("Buffer is empty\n");
            }
            if (v->size != 0)
            {
                vector_display(v);
                printf("\n");
            }
        }
        if (odpowiedz < 0 || odpowiedz > 2)
        {
            printf("Incorrect input data\n");
        }

    } while (1);
    return 0;
}

