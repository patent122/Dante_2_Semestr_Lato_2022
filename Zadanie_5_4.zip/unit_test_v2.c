/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Macierz
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 20:50:00.541343
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//



        struct matrix_t{

          int **ptr;
          int width;
          int height;
        };

    


//
//  Test 1: Sprawdzanie poprawności działania funkcji destroy_array_2d
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji destroy_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct matrix_t arr = {.ptr = NULL, .width = -2, .height = 0};

            printf("#####START#####");
            matrix_destroy(&arr);
            printf("#####END#####");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji destroy_array_2d
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji destroy_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct matrix_t arr = {.ptr = NULL, .width = 5, .height = -8};

            printf("#####START#####");
            matrix_destroy(&arr);
            printf("#####END#####");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji destroy_array_2d
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji destroy_array_2d", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            printf("#####START#####");
            matrix_destroy(NULL);
            printf("#####END#####");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 3, .height = -1};
                int width = 1, height = 16;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja matrix_create() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                if (!0)
                {
                    test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                    test_error(arr.width == 1, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 1, a ustawiła na %d", arr.width);
                    test_error(arr.height == 16, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 16, a ustawiła na %d", arr.height);

                    printf("#####START#####");
                    matrix_destroy(&arr);
                    printf("#####END#####");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 5, .height = 9};
                int width = 17, height = 7;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja matrix_create() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                if (!0)
                {
                    test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                    test_error(arr.width == 17, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr.width);
                    test_error(arr.height == 7, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 7, a ustawiła na %d", arr.height);

                    printf("#####START#####");
                    matrix_destroy(&arr);
                    printf("#####END#####");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 0, .height = -7};
                int width = 960, height = 121;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja matrix_create() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                if (!0)
                {
                    test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                    test_error(arr.width == 960, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 960, a ustawiła na %d", arr.width);
                    test_error(arr.height == 121, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 121, a ustawiła na %d", arr.height);

                    printf("#####START#####");
                    matrix_destroy(&arr);
                    printf("#####END#####");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -3, .height = -7};
                int width = 0, height = 17;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja matrix_create() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                if (!1)
                {
                    test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                    test_error(arr.width == 0, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 0, a ustawiła na %d", arr.width);
                    test_error(arr.height == 17, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 17, a ustawiła na %d", arr.height);

                    printf("#####START#####");
                    matrix_destroy(&arr);
                    printf("#####END#####");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 6, .height = -8};
                int width = 2, height = 0;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja matrix_create() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                if (!1)
                {
                    test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                    test_error(arr.width == 2, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 2, a ustawiła na %d", arr.width);
                    test_error(arr.height == 0, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 0, a ustawiła na %d", arr.height);

                    printf("#####START#####");
                    matrix_destroy(&arr);
                    printf("#####END#####");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 0, .height = -5};
                int width = 7, height = -18;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja matrix_create() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                if (!1)
                {
                    test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                    test_error(arr.width == 7, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 7, a ustawiła na %d", arr.width);
                    test_error(arr.height == -18, "Funkcja matrix_create() powinna ustawić wysokość macierzy na -18, a ustawiła na %d", arr.height);

                    printf("#####START#####");
                    matrix_destroy(&arr);
                    printf("#####END#####");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 8, .height = -8};
                int width = -4, height = 17;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja matrix_create() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                if (!1)
                {
                    test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                    test_error(arr.width == -4, "Funkcja matrix_create() powinna ustawić szerokość macierzy na -4, a ustawiła na %d", arr.width);
                    test_error(arr.height == 17, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 17, a ustawiła na %d", arr.height);

                    printf("#####START#####");
                    matrix_destroy(&arr);
                    printf("#####END#####");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -9, .height = -6};
                int width = -8, height = -17;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja matrix_create() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                if (!1)
                {
                    test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                    test_error(arr.width == -8, "Funkcja matrix_create() powinna ustawić szerokość macierzy na -8, a ustawiła na %d", arr.width);
                    test_error(arr.height == -17, "Funkcja matrix_create() powinna ustawić wysokość macierzy na -17, a ustawiła na %d", arr.height);

                    printf("#####START#####");
                    matrix_destroy(&arr);
                    printf("#####END#####");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 6, .height = 2};
                int width = 0, height = 0;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 1, "Funkcja matrix_create() powinna zwrócić 1");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)


                if (!1)
                {
                    test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                    test_error(arr.width == 0, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 0, a ustawiła na %d", arr.width);
                    test_error(arr.height == 0, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 0, a ustawiła na %d", arr.height);

                    printf("#####START#####");
                    matrix_destroy(&arr);
                    printf("#####END#####");
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 680 bajtów)
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 680 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(680);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -9, .height = 8};
                int width = 8, height = 17;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja matrix_create() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                test_error(arr.width == 8, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 8, a ustawiła na %d", arr.width);
                test_error(arr.height == 17, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 17, a ustawiła na %d", arr.height);

                printf("#####START#####");
                matrix_destroy(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 608 bajtów)
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 608 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(608);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -6, .height = -9};
                int width = 17, height = 8;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja matrix_create() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                test_error(arr.width == 17, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 17, a ustawiła na %d", arr.width);
                test_error(arr.height == 8, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 8, a ustawiła na %d", arr.height);

                printf("#####START#####");
                matrix_destroy(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 3597780 bajtów)
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 3597780 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(3597780);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -10, .height = 0};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 0, "Funkcja matrix_create() powinna zwrócić 0");
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna przypisać pod ptr adres zaalokowanej pamięci, a przypisała NULL");
                test_error(arr.width == 981, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 981, a ustawiła na %d", arr.width);
                test_error(arr.height == 915, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 915, a ustawiła na %d", arr.height);

                printf("#####START#####");
                matrix_destroy(&arr);
                printf("#####END#####");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 0 bajtów)
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 0 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -3, .height = 10};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 96 bajtów)
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 96 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(96);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 10, .height = 2};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 120 bajtów)
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 120 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(120);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 5, .height = 5};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 144 bajtów)
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 144 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(144);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 8, .height = 0};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 168 bajtów)
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 168 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(168);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -10, .height = -1};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 192 bajtów)
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 192 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(192);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -2, .height = -2};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 216 bajtów)
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 216 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(216);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -1, .height = 10};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 240 bajtów)
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 240 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(240);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 8, .height = -2};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 264 bajtów)
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 264 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(264);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -8, .height = 6};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 288 bajtów)
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 288 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(288);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 5, .height = 7};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 312 bajtów)
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 312 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(312);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -6, .height = 7};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 336 bajtów)
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 336 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(336);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = -10, .height = 5};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 360 bajtów)
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 360 bajtów)", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(360);
    
    //
    // -----------
    //
    

                struct matrix_t arr = {.width = 10, .height = 0};
                int width = 981, height = 915;        

                printf("#####START#####");
                int res = matrix_create(&arr, width, height);
                printf("#####END#####");

                test_error(res == 2, "Funkcja matrix_create() powinna zwrócić 2");

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji matrix_create
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji matrix_create", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int width = 3, height = 18;        

            printf("#####START#####");
            int res = matrix_create(NULL, width, height);
            printf("#####END#####");

            test_error(res == 1, "Funkcja matrix_create() powinna zwrócić 1");
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji matrix_display
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji matrix_display", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct matrix_t arr = {.ptr = NULL, .width = 9, .height = 9};
        
            printf("\n***TEST 1***\n\n");
            printf("***START***\n");
            matrix_display(&arr);
            printf("***END***\n");

            printf("\n***TEST 2***\n\n");
            printf("***START***\n");
            matrix_display(NULL);
            printf("***END***\n");

        
            int res = matrix_create(&arr, 2, 17);
            int array[17][2] = {{ 1, -3}, { 5, -10}, { -2, 5}, { -4, -4}, { 2, -3}, { 6, -10}, { -9, 3}, { -7, -6}, { 6, -10}, { -9, 9}, { -10, 2}, { 9, 2}, { -10, -5}, { 10, 6}, { 8, -7}, { -8, -1}, { -6, 7}};

            test_error(res == 0, "Funkcja matrix_create() powinna zwrócić 0");
            test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
            test_error(arr.width == 2, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 2, a ustawiła na %d", arr.width);
            test_error(arr.height == 17, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 17, a ustawiła na %d", arr.height);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            for (int i = 0; i < 17; ++i)
                for (int j = 0; j < 2; ++j)
                    arr.ptr[i][j] = array[i][j];


            arr.width = 0;
            arr.height = 17;

            printf("\n***TEST 3***\n\n");
            printf("***START***\n");
            matrix_display(&arr);
            printf("***END***\n");

            arr.width = -2;
            arr.height = 17;

            printf("\n***TEST 4***\n\n");
            printf("***START***\n");
            matrix_display(&arr);
            printf("***END***\n");

            arr.width = -2;
            arr.height = -17;

            printf("\n***TEST 5***\n\n");
            printf("***START***\n");
            matrix_display(&arr);
            printf("***END***\n");

            arr.width = 2;
            arr.height = -17;

            printf("\n***TEST 6***\n\n");
            printf("***START***\n");
            matrix_display(&arr);
            printf("***END***\n");

            arr.width = 2;
            arr.height = 0;

            printf("\n***TEST 7***\n\n");
            printf("***START***\n");
            matrix_display(&arr);
            printf("***END***\n");

            arr.width = 0;
            arr.height = 0;

            printf("\n***TEST 8***\n\n");
            printf("***START***\n");
            matrix_display(&arr);
            printf("***END***\n");

            arr.width = 2;
            arr.height = 17;

            printf("\n***TEST 9***\n\n");
            printf("***START***\n");
            matrix_display(&arr);
            printf("***END***\n");

            printf("#####START#####");
            matrix_destroy(&arr);
            printf("#####END#####");
      
            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji matrix_read
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji matrix_read", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            struct matrix_t arr = {.ptr = NULL, .width = 4, .height = 4};

            printf("\n***TEST 1***\n\n");
            printf("#####START#####");
            int res = matrix_read(&arr);
            printf("#####END#####");
            test_error(res == 1, "Funkcja matrix_read() zwróciła nieprawidłową wartość, powinna zwrócić 1, a zwróciła %d", res);

            printf("\n***TEST 2***\n\n");
            printf("#####START#####");
            res = matrix_read(NULL);
            printf("#####END#####");
            test_error(res == 1, "Funkcja matrix_read() zwróciła nieprawidłową wartość, powinna zwrócić 1, a zwróciła %d", res);


            res = matrix_create(&arr, 2, 17);
            int array[17][2] = {{ 1, -3}, { 5, -10}, { -2, 5}, { -4, -4}, { 2, -3}, { 6, -10}, { -9, 3}, { -7, -6}, { 6, -10}, { -9, 9}, { -10, 2}, { 9, 2}, { -10, -5}, { 10, 6}, { 8, -7}, { -8, -1}, { -6, 7}};

            test_error(res == 0, "Funkcja matrix_create() powinna zwrócić 0");
            test_error(arr.ptr != NULL, "Funkcja matrix_create() powinna zwrócić adres zaalokowanej pamięci, a zwróciła NULL");
            test_error(arr.width == 2, "Funkcja matrix_create() powinna ustawić szerokość macierzy na 2, a ustawiła na %d", arr.width);
            test_error(arr.height == 17, "Funkcja matrix_create() powinna ustawić wysokość macierzy na 17, a ustawiła na %d", arr.height);
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem);

            arr.width = 0;
            arr.height = 17;

            printf("\n***TEST 3***\n\n");
            printf("#####START#####");
            res = matrix_read(&arr);
            printf("#####END#####");
            test_error(res == 1, "Funkcja matrix_read() zwróciła nieprawidłową wartość, powinna zwrócić 1, a zwróciła %d", res);

            arr.width = -2;
            arr.height = 17;

            printf("\n***TEST 4***\n\n");
            printf("#####START#####");
            res = matrix_read(&arr);
            printf("#####END#####");
            test_error(res == 1, "Funkcja matrix_read() zwróciła nieprawidłową wartość, powinna zwrócić 1, a zwróciła %d", res);

            arr.width = -2;
            arr.height = -17;

            printf("\n***TEST 5***\n\n");
            printf("#####START#####");
            res = matrix_read(&arr);
            printf("#####END#####");
            test_error(res == 1, "Funkcja matrix_read() zwróciła nieprawidłową wartość, powinna zwrócić 1, a zwróciła %d", res);

            arr.width = 2;
            arr.height = -17;

            printf("\n***TEST 6***\n\n");
            printf("#####START#####");
            res = matrix_read(&arr);
            printf("#####END#####");
            test_error(res == 1, "Funkcja matrix_read() zwróciła nieprawidłową wartość, powinna zwrócić 1, a zwróciła %d", res);

            arr.width = 2;
            arr.height = 0;

            printf("\n***TEST 7***\n\n");
            printf("#####START#####");
            res = matrix_read(&arr);
            printf("#####END#####");
            test_error(res == 1, "Funkcja matrix_read() zwróciła nieprawidłową wartość, powinna zwrócić 1, a zwróciła %d", res);

            arr.width = 0;
            arr.height = 0;

            printf("\n***TEST 8***\n\n");
            printf("#####START#####");
            res = matrix_read(&arr);
            printf("#####END#####");
            test_error(res == 1, "Funkcja matrix_read() zwróciła nieprawidłową wartość, powinna zwrócić 1, a zwróciła %d", res);

            arr.width = 2;
            arr.height = 17;

            printf("\n***TEST 9***\n\n");
            printf("#####START#####");
            res = matrix_read(&arr);
            printf("#####END#####");
            test_error(res == 0, "Funkcja matrix_read() zwróciła nieprawidłową wartość, powinna zwrócić 0, a zwróciła %d", res);

            int ok = 0;
            
            for (int i = 0; i < 17; ++i)
                for (int j = 0; j < 2; ++j)
                    ok += arr.ptr[i][j] != array[i][j];
                        
            if (ok)
            {
                printf("Zawartość macierzy po pobraniu danych od użytkownika\n");
                matrix_display(&arr);    
            }
            test_error(ok == 0, "Funkcja matrix_read() niepoprawnie pobrała dane do macierzy");

            printf("#####START#####");
            matrix_destroy(&arr);
            printf("#####END#####");

            test_no_heap_leakage();
            onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci - limit ustawiony na 0 bajtów
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci - limit ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
            printf("***START***\n");
            int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
            printf("\n***END***\n");
            test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci - limit ustawiony na 136 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci - limit ustawiony na 136 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(136);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci - limit ustawiony na 144 bajtów
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci - limit ustawiony na 144 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(144);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na brak pamięci - limit ustawiony na 152 bajtów
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na brak pamięci - limit ustawiony na 152 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(152);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Reakcja na brak pamięci - limit ustawiony na 160 bajtów
//
void MTEST5(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(5, "Reakcja na brak pamięci - limit ustawiony na 160 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(160);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Reakcja na brak pamięci - limit ustawiony na 168 bajtów
//
void MTEST6(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(6, "Reakcja na brak pamięci - limit ustawiony na 168 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(168);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Reakcja na brak pamięci - limit ustawiony na 176 bajtów
//
void MTEST7(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(7, "Reakcja na brak pamięci - limit ustawiony na 176 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(176);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Reakcja na brak pamięci - limit ustawiony na 184 bajtów
//
void MTEST8(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(8, "Reakcja na brak pamięci - limit ustawiony na 184 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(184);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Reakcja na brak pamięci - limit ustawiony na 192 bajtów
//
void MTEST9(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(9, "Reakcja na brak pamięci - limit ustawiony na 192 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(192);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Reakcja na brak pamięci - limit ustawiony na 200 bajtów
//
void MTEST10(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(10, "Reakcja na brak pamięci - limit ustawiony na 200 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(200);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Reakcja na brak pamięci - limit ustawiony na 208 bajtów
//
void MTEST11(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(11, "Reakcja na brak pamięci - limit ustawiony na 208 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(208);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Reakcja na brak pamięci - limit ustawiony na 216 bajtów
//
void MTEST12(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(12, "Reakcja na brak pamięci - limit ustawiony na 216 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(216);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Reakcja na brak pamięci - limit ustawiony na 224 bajtów
//
void MTEST13(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(13, "Reakcja na brak pamięci - limit ustawiony na 224 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(224);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Reakcja na brak pamięci - limit ustawiony na 232 bajtów
//
void MTEST14(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(14, "Reakcja na brak pamięci - limit ustawiony na 232 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(232);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Reakcja na brak pamięci - limit ustawiony na 240 bajtów
//
void MTEST15(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(15, "Reakcja na brak pamięci - limit ustawiony na 240 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(240);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Reakcja na brak pamięci - limit ustawiony na 248 bajtów
//
void MTEST16(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(16, "Reakcja na brak pamięci - limit ustawiony na 248 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(248);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Reakcja na brak pamięci - limit ustawiony na 256 bajtów
//
void MTEST17(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(17, "Reakcja na brak pamięci - limit ustawiony na 256 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(256);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Reakcja na brak pamięci - limit ustawiony na 264 bajtów
//
void MTEST18(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(18, "Reakcja na brak pamięci - limit ustawiony na 264 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(264);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji destroy_array_2d
            UTEST2, // Sprawdzanie poprawności działania funkcji destroy_array_2d
            UTEST3, // Sprawdzanie poprawności działania funkcji destroy_array_2d
            UTEST4, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST5, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST6, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST7, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST8, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST9, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST10, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST11, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST12, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST13, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 680 bajtów)
            UTEST14, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 608 bajtów)
            UTEST15, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 3597780 bajtów)
            UTEST16, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 0 bajtów)
            UTEST17, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 96 bajtów)
            UTEST18, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 120 bajtów)
            UTEST19, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 144 bajtów)
            UTEST20, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 168 bajtów)
            UTEST21, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 192 bajtów)
            UTEST22, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 216 bajtów)
            UTEST23, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 240 bajtów)
            UTEST24, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 264 bajtów)
            UTEST25, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 288 bajtów)
            UTEST26, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 312 bajtów)
            UTEST27, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 336 bajtów)
            UTEST28, // Sprawdzanie reakcji funkcji matrix_create na limit pamięci (limit sterty ustawiono na 360 bajtów)
            UTEST29, // Sprawdzanie poprawności działania funkcji matrix_create
            UTEST30, // Sprawdzanie poprawności działania funkcji matrix_display
            UTEST31, // Sprawdzanie poprawności działania funkcji matrix_read
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(31); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci - limit ustawiony na 0 bajtów
            MTEST2, // Reakcja na brak pamięci - limit ustawiony na 136 bajtów
            MTEST3, // Reakcja na brak pamięci - limit ustawiony na 144 bajtów
            MTEST4, // Reakcja na brak pamięci - limit ustawiony na 152 bajtów
            MTEST5, // Reakcja na brak pamięci - limit ustawiony na 160 bajtów
            MTEST6, // Reakcja na brak pamięci - limit ustawiony na 168 bajtów
            MTEST7, // Reakcja na brak pamięci - limit ustawiony na 176 bajtów
            MTEST8, // Reakcja na brak pamięci - limit ustawiony na 184 bajtów
            MTEST9, // Reakcja na brak pamięci - limit ustawiony na 192 bajtów
            MTEST10, // Reakcja na brak pamięci - limit ustawiony na 200 bajtów
            MTEST11, // Reakcja na brak pamięci - limit ustawiony na 208 bajtów
            MTEST12, // Reakcja na brak pamięci - limit ustawiony na 216 bajtów
            MTEST13, // Reakcja na brak pamięci - limit ustawiony na 224 bajtów
            MTEST14, // Reakcja na brak pamięci - limit ustawiony na 232 bajtów
            MTEST15, // Reakcja na brak pamięci - limit ustawiony na 240 bajtów
            MTEST16, // Reakcja na brak pamięci - limit ustawiony na 248 bajtów
            MTEST17, // Reakcja na brak pamięci - limit ustawiony na 256 bajtów
            MTEST18, // Reakcja na brak pamięci - limit ustawiony na 264 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(18); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}