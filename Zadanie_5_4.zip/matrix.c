#include "matrix.h"
#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int matrix_create(struct matrix_t *macierz, int szerokosc, int wysokosc)
{
    if (macierz == NULL || wysokosc < 1 || szerokosc < 1)
        return 1;

    macierz->width = szerokosc;
    macierz->height = wysokosc;

    macierz->ptr = malloc(wysokosc * sizeof(int*));
    if (macierz->ptr == NULL)
    {
        return 2;
    }

    for (int i = 0; i < wysokosc; ++i)
    {
        *(macierz->ptr + i) = malloc(szerokosc * sizeof(int));
        if (*(macierz->ptr + i) == NULL)
        {
            for (int j = 0; j < i; ++j)
            {
                free(*(macierz->ptr + j));
            }
            free(macierz->ptr);
            return 2;
        }
    }

    return SUCCES;
}

int matrix_read(struct matrix_t *macierz)
{
    if (macierz == NULL || macierz->ptr == NULL || macierz->width < 1 || macierz->height < 1)
        return 1;

    int szerokosc = macierz->width;
    int wysokosc = macierz->height;

    for (int i = 0; i < wysokosc; ++i)
    {
        for (int j = 0; j < szerokosc; ++j)
        {
            int num;
            if(scanf("%d", &num) != 1)
            {
                return 2;
            }
            *(*(macierz->ptr + i) + j) = num;
        }
    }

    return SUCCES;
}
void matrix_display(const struct matrix_t *macierz)
{
    if (macierz == NULL || macierz->ptr == NULL || macierz->width < 1 || macierz->height < 1)
        return;

    int szerokosc = macierz->width;
    int wysokosc = macierz->height;

    for (int i = 0; i < wysokosc; ++i)
    {
        for (int j = 0; j < szerokosc; ++j)
        {
            printf("%d ", *(*(macierz->ptr + i) + j));
        }
        printf("\n");
    }
}
void matrix_destroy(struct matrix_t *macierz)
{
    if (macierz == NULL ||macierz->width < 1 || macierz->height < 1)
        return;

    for (int i = 0; i < macierz->height; i++)
    {
        free(*(macierz->ptr + i));
    }
    free(macierz->ptr);
}
