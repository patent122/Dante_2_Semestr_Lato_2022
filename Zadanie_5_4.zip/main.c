#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
    int wysokosc, szerokosc, blad;
    struct matrix_t macierz;

    printf("Podaj szerokość i wysokość: ");
    if (scanf("%d %d", &szerokosc, &wysokosc) != 2)
    {
        printf("Incorrect input\n");
        return INCORECT_INPUT;
    }

    if (wysokosc < 1 || szerokosc < 1)
    {
        printf("Incorrect input data\n");
        return INCORECT_INPUT_DATA;
    }

    blad = matrix_create(&macierz, szerokosc, wysokosc);
    switch (blad)
    {
        case 1:
            printf("Incorrect input data\n");
            return INCORECT_INPUT_DATA;
        case 2:
            printf("Failed to allocate memory\n");
            return FAILED_TO_ALLOCATE_MEMORY;
        default:
            break;
    }

    printf("Podaj wartości: ");
    blad = matrix_read(&macierz);
    switch (blad)
    {
        case 1:
            matrix_destroy(&macierz);
            printf("Incorrect input data\n");
            return INCORECT_INPUT_DATA;
        case 2:
            matrix_destroy(&macierz);
            printf("Incorrect input\n");
            return INCORECT_INPUT;
        default:
            break;
    }

    matrix_display(&macierz);
    matrix_destroy(&macierz);
    return 0;
}
