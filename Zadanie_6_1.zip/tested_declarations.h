/*
 * Test dla zadania Ech, Ci Studenci 4
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-21 20:46:05.477266
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta


        struct student_t;

        struct student_t* read(int *err_code);
        void show(const struct student_t* p);
        void destroy(struct student_t **s);

        

#endif // _TESTED_DECLARATIONS_H_