#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tested_declarations.h"
#include "rdebug.h"

#define SET_PTR_SAFE(d, s) if (d) *d = s

struct student_t 
{
    char name[20];
    char surname[40];
    int index;
};

struct student_t* read(int *err_code);
void destroy(struct student_t **p);
void show(const struct student_t* p);
int parse_until_comma(char* destination, int limit);

int main()
{
    struct student_t *p = malloc(sizeof(struct student_t));
    int exit_code;

    if (p == NULL)
    {
        printf("Failed to allocate memory");
        return 8;        
    }
    free(p);

    printf("Podaj dane: ");
    p = read(&exit_code);
    if (exit_code == 4)
    {
        printf("Failed to allocate memory");
        return 8;
    }
    else if (exit_code != 0)
    {
        printf("Incorrect input");
    }
    else
    {
        show(p);
    }
    destroy(&p);
    return exit_code;
}

struct student_t* read(int *err_code)
{
    struct student_t *p = malloc(sizeof(struct student_t));
    if (p == NULL)
    {
        SET_PTR_SAFE(err_code, 4);
        return NULL;
    }
    memset(p, 0, sizeof(struct student_t));
    if (!parse_until_comma(p->name, 19))
    {
        SET_PTR_SAFE(err_code, 1);
        free(p);
        return NULL;
    }
    if (!parse_until_comma(p->surname, 39))
    {
        SET_PTR_SAFE(err_code, 2);
        free(p);
        return NULL;
    }
    if (!scanf("%d", &p->index))
    {
        SET_PTR_SAFE(err_code, 3);
        free(p);
        return NULL;
    }
    SET_PTR_SAFE(err_code, 0);
    return p;
    
}

void show(const struct student_t* p)
{
    if (p == NULL)
    {
        return;
    }
    printf("%s %s, %d", p->name, p->surname, p->index);
}

int parse_until_comma(char* destination, int limit)
{
    int c, index = 0, result = 0, in_state = 0;
    while ((c = getc(stdin)) != '\n' && c != -1 && index <= limit)
    {
        if (c == ',')
        {
            result = 1;
            break;
        }
        else if (c == ' ' && !in_state)
        {
            continue;
        }
        *(destination + index++) = (char)c;
        in_state = 1;
    }
    *(destination + index) = '\0';
    return result;
}

void destroy(struct student_t **p)
{
    if (p != NULL)
    {
        free(*p);
        *p = NULL;
    }
}
