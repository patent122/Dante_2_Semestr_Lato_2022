#include <stdio.h>
#include "for_loop.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main() {
    void (*funkcje[4])(double);
    *(funkcje + 0) = print_value;
    *(funkcje + 1) = print_accumulated;
    *(funkcje + 2) = print_square;
    *(funkcje + 3) = print_abs;
    double poczatek, krok, koniec;
    int operacja;
    printf("Podaj poczatek, krok i koniec przedzialu: ");
    if (scanf("%lf %lf %lf", &poczatek, &krok, &koniec) != 3) {
        printf("Incorrect input");
        return 1;
    }
    if ((poczatek > koniec && krok > 0) || (poczatek < koniec && krok < 0) || krok == 0) {
        printf("Incorrect input data");
        return 2;
    }
    printf("Podaj rodzaj operacji: ");
    if (scanf("%d", &operacja) != 1) {
        printf("Incorrect input");
        return 1;
    }
    if (operacja < 0 || operacja > 3) {
        printf("Incorrect input data");
        return 2;
    }
    for_loop(poczatek, krok, koniec, *(funkcje + operacja));
    return 0;
}
