#include <stdio.h>
#include "for_loop.h"
#include "tested_declarations.h"
#include "rdebug.h"

void for_loop(double poczatek, double krok, double koniec, void(*funkcja)(double)) {
    if (funkcja == NULL) {
        return;
    }
    if (krok == 0) {
        return;
    }
    if (krok < 0) {
        if (poczatek <= koniec)
            return;
    }
    else {
        if (poczatek >= koniec)
            return;
    }
    funkcja(poczatek);
    for_loop(poczatek + krok, krok, koniec, funkcja);
}

void print_value(double v) {
    printf("%lf ", v);
}

void print_accumulated(double v) {
    static double akumulator = 0;
    akumulator += v;
    printf("%lf ", akumulator);
}

void print_square(double v) {
    printf("%lf ", v * v);
}

void print_abs(double v) {
    if (v < 0) {
        v = -v;
    }
    printf("%lf ", v);
}
