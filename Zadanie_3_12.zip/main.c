#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "tested_declarations.h"
#include "rdebug.h"

int power(int base, int a);
int decode(const char* filename, char* txt, int size);
int encode(const char* input, char* txt, const char* output);
void wyczysc_wejscie();

int main()
{
    char sciezka[31];
    char sciezka_wyjscie[31];
    char bufor[1000];
    int blad;

    printf("Do you want to encode (E/e) or decode (D/d) a message? ");
    int odpowiedz = getchar();

    if (odpowiedz == 'd' || odpowiedz == 'D')
    {
        wyczysc_wejscie();
        printf("Enter input file name: ");
        scanf("%30s", sciezka);

        blad = decode(sciezka, bufor, 1000);
        switch (blad)
        {
        case 2:
            printf("Couldn't open file\n");
            return 4;
        case 3:
            printf("File corrupted\n");
            return 6;
        }
        printf("%s", bufor);
    }
    else if (odpowiedz == 'e' || odpowiedz == 'E') //e E
    {
        wyczysc_wejscie();
        printf("Enter a message to be encoded:: ");
        scanf("%1000[^\n]s", bufor);
        printf("Enter input file name: ");
        scanf("%30s", sciezka);
        printf("Enter output file name: ");
        scanf("%30s", sciezka_wyjscie);
        blad = encode(sciezka, bufor, sciezka_wyjscie);
        switch (blad)
        {
        case 0:
            printf("File saved\n");
            return 0;
        case 2:
            printf("Couldn't open file\n");
            return 4;
        case 4:
            printf("Couldn't create file\n");
            return 5;
        case 3:
            printf("File corrupted\n");
            return 6;
        }
    }
    else
    {
        printf("Incorrect input data\n");
        return 1;
    }
    return 0;
}


void wyczysc_wejscie(void) {
    int znak;
    do {
        znak = getchar();
    } while (znak != '\n' && znak != EOF);
}

int power(int base, int a) {
    if (a == 0)
    {
        return 1;
    }
    return (base * power(base, a - 1));
}

int decode(const char* filename, char* txt, int size)
{
    if (filename == NULL || txt == NULL || size < 1)
    {
        return 1;
    }

    FILE* plik;
    int ile;
    int px = 0;
    int ile_kod_ascii = 0;
    int dlugosc = 0;

    if ((plik = fopen(filename, "r")) == NULL)
    {
        return 2;
    }
    while (1)
    {
        if (fscanf(plik, "%d", &ile) != 1)
        {
            fclose(plik);
            return 3;
        }
        if (dlugosc >= size - 1)
        {
            break;
        }
        if (ferror(plik) != 0)
        {
            fclose(plik);
            return 3;
        }
        if (ile % 2 == 1)
        {
            ile_kod_ascii += power(2, 7 - px);
            px++;
        }
        else
        {
            px++;
        }

        if (px == 8)
        {
            *(txt + dlugosc) = (char)ile_kod_ascii;
            ile_kod_ascii = 0;
            px = 0;
            dlugosc++;
        }
    }
    *(txt + size - 1) = '\0';
    fclose(plik);
    return 0;
}
int encode(const char* input, char* txt, const char* output)
{
    if (input == NULL || txt == NULL || output == NULL)
    {
        return 1;
    }

    FILE* plik1, * plik2;
    int blad;
    int ile = 0;

    if ((plik1 = fopen(input, "r")) == NULL)
    {
        return 2;
    }
    if ((plik2 = fopen(output, "w")) == NULL)
    {
        fclose(plik1);
        return 4;
    }
    int ile2 = 0;
    int rozmiar = 0;
    while (fscanf(plik1, "%d", &ile2) == 1)
    {
        ile++;
    }

    int rozmiar2 = (int)strlen(txt);
    if (ile / 8 <= rozmiar2)
    {
        fclose(plik1);
        fclose(plik2);
        return 3;
    }
    fseek(plik1, 0L, SEEK_SET);
    char znak;
    int szerokosc = 0;
    int wysokosc;
    while ((znak = fgetc(plik1)) != '\n')
    {
        if (znak == ' ') szerokosc++;
    }
    wysokosc = ile / szerokosc;
    fseek(plik1, 0L, SEEK_SET);
    int wysokosc2 = 0;
    while ((blad = fscanf(plik1, "%d", &ile2)) != EOF)
    {
        if (!blad)
        {
            fclose(plik1);
            fclose(plik2);
            return 3;
        }
        if (rozmiar % szerokosc == 0 && wysokosc2 < wysokosc && rozmiar > 0)
        {
            fprintf(plik2, "%c", '\n');
            wysokosc2++;
        }
        if (rozmiar <= rozmiar2 * 8)
        {
            ile2 = (ile2 & 0xFE) | ((*(txt + (rozmiar / 8)) & 1 << (7 - rozmiar % 8)) > 0);
        }
        else
        {
            if (ile2 % 2 == 1)
            {
                ile2--;
            }
        }
        blad = fprintf(plik2, "%d ", ile2);
        if (!blad)
        {
            fclose(plik1);
            fclose(plik2);
            return 3;
        }
        rozmiar++;
    }

    fclose(plik1);
    fclose(plik2);
    return 0;
}

