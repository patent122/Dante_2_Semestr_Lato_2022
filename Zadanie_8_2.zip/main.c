#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "tested_declarations.h"
#include "rdebug.h"

int concatenate(char* tekst, int ss, int nn, ...) {
    if (tekst == NULL || ss <= 0 || nn <= 0) {
        return 1;
    }
    unsigned int rozmiar = (unsigned int)ss;
    va_list list;
    va_start(list, nn);
    char* bufor_tekst = va_arg(list, char*);
    if (strlen(bufor_tekst) >= rozmiar) {
        va_end(list);
        return 2;
    }
    strcpy(tekst, bufor_tekst);
    int i;
    for (i = 1; i < nn; i++) {
        bufor_tekst = va_arg(list, char*);
        if (strlen(tekst) + 1 >= rozmiar) {
            va_end(list);
            return 2;
        }
        strcat(tekst, " ");
        if (strlen(tekst) + strlen(bufor_tekst) >= rozmiar) {
            va_end(list);
            return 2;
        }
        strcat(tekst, bufor_tekst);

    }
    va_end(list);
    return 0;
}

void loadText(char* bufor_tekst, int max) {
    int nn = 0;
    while (1) {
        char znak = getchar();
        if (znak == '\n') {
            break;
        }
        if (nn < max - 1) {
            *(bufor_tekst + nn) = znak;
            nn++;
        }
    }
    *(bufor_tekst + nn) = '\0';
}

int main() {
    char* cel = malloc(4004);
    if (cel == NULL) {
        printf("Failed to allocate memory");
        return 8;
    }
    char** wejscia = malloc(sizeof(char*) * 4);
    if (wejscia == NULL) {
        free(cel);
        printf("Failed to allocate memory");
        return 8;
    }
    *(wejscia) = malloc(1001);
    if (*(wejscia) == NULL) {
        free(cel);
        free(wejscia);
        printf("Failed to allocate memory");
        return 8;
    }
    *(wejscia + 1) = malloc(1001);
    if (*(wejscia + 1) == NULL) {
        free(*(wejscia));
        free(cel);
        free(wejscia);
        printf("Failed to allocate memory");
        return 8;
    }
    *(wejscia + 2) = malloc(1001);
    if (*(wejscia + 2) == NULL) {
        free(*(wejscia));
        free(*(wejscia + 1));
        free(cel);
        free(wejscia);
        printf("Failed to allocate memory");
        return 8;
    }
    *(wejscia + 3) = malloc(1001);
    if (*(wejscia + 3) == NULL) {
        free(*(wejscia));
        free(*(wejscia + 1));
        free(*(wejscia + 2));
        free(cel);
        free(wejscia);
        printf("Failed to allocate memory");
        return 8;
    }
    printf("Podaj liczbe tekstow do wprowadzenia: ");
    int ile;
    if (scanf("%d", &ile) != 1) {
        printf("Incorrect input");
        free(*(wejscia));
        free(*(wejscia + 1));
        free(*(wejscia + 2));
        free(*(wejscia + 3));

        free(cel);
        free(wejscia);
        return 1;
    }
    if (ile < 2 || ile > 4) {
        printf("Incorrect input data");
        free(*(wejscia));
        free(*(wejscia + 1));
        free(*(wejscia + 2));
        free(*(wejscia + 3));

        free(cel);
        free(wejscia);
        return 2;
    }
    getchar();
    printf("Podaj napisy: ");
    int i;
    for (i = 0; i < ile; i++) {
        loadText(*(wejscia + i), 1001);
        
    }
    if (ile == 2) {
        concatenate(cel, 4005, 2, *(wejscia), *(wejscia + 1));
    }
    if (ile == 3) {
        concatenate(cel, 4005, 3, *(wejscia), *(wejscia + 1), *(wejscia + 2));
    }
    if (ile == 4) {
        concatenate(cel, 4005, 4, *(wejscia), *(wejscia + 1), *(wejscia + 2), *(wejscia + 3));
    }

    printf("%s", cel);
    free(*(wejscia));
    free(*(wejscia + 1));
    free(*(wejscia + 2));
    free(*(wejscia + 3));
    free(cel);
    free(wejscia);
    return 0;
}
