/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Łączenie tekstów
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 11:31:34.885313
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                char *expected_result = "Yesterdays the past, tomorrows the future, but today is a gift. Thats why its called the present. - Bil Keane A computer lets you make more mistakes faster than any invention in human history - with the possible exceptions of handguns and tequila. - Author Unknown By far, the greatest danger of Artificial Intelligence is that people conclude too early that they understand it. - Eliezer Yudkowsky";
                char result[399];
                
                int res = concatenate(result, 399, 3, "Yesterdays the past, tomorrows the future, but today is a gift. Thats why its called the present. - Bil Keane", "A computer lets you make more mistakes faster than any invention in human history - with the possible exceptions of handguns and tequila. - Author Unknown", "By far, the greatest danger of Artificial Intelligence is that people conclude too early that they understand it. - Eliezer Yudkowsky");
        
                test_error(res == 0, "Funkcja concatenate() powinna zwrócić wartość 0, a zwróciła %d", res);                  
     
                if (!0)
                {

                    int ok = 1, i = 0;
        
                    while (*(result + i) && *(expected_result + i))
                    {
                        if (*(result + i) != *(expected_result + i))
                            ok = 0;
                        i++;
                    }
        
                    ok = ok && *(result + i) == *(expected_result + i);
                    if (!ok)
                    {
                        printf("Oczekiwany wynik: %s\n", expected_result);
                        printf("Otrzymany wynik: %s\n", result);
                    }
           
                    test_error(ok == 1, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa");
                }
     
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                char *expected_result = "Yesterdays the past, tomorrows the future, but today is a gift. Thats why its called the present. - Bil Keane A computer lets you make more mistakes faster than any invention in human history - with the possible exceptions of handguns and tequila. - Author Unknown By far, the greatest danger of Artificial Intelligence is that people conclude too early that they understand it. - Eliezer Yudkowsky";
                char result[398];
                
                int res = concatenate(result, 398, 3, "Yesterdays the past, tomorrows the future, but today is a gift. Thats why its called the present. - Bil Keane", "A computer lets you make more mistakes faster than any invention in human history - with the possible exceptions of handguns and tequila. - Author Unknown", "By far, the greatest danger of Artificial Intelligence is that people conclude too early that they understand it. - Eliezer Yudkowsky");
        
                test_error(res == 2, "Funkcja concatenate() powinna zwrócić wartość 2, a zwróciła %d", res);                  
     
                if (!2)
                {

                    int ok = 1, i = 0;
        
                    while (*(result + i) && *(expected_result + i))
                    {
                        if (*(result + i) != *(expected_result + i))
                            ok = 0;
                        i++;
                    }
        
                    ok = ok && *(result + i) == *(expected_result + i);
                    if (!ok)
                    {
                        printf("Oczekiwany wynik: %s\n", expected_result);
                        printf("Otrzymany wynik: %s\n", result);
                    }
           
                    test_error(ok == 1, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa");
                }
     
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                char *expected_result = "Yesterdays the past, tomorrows the future, but today is a gift. Thats why its called the present. - Bil Keane A computer lets you make more mistakes faster than any invention in human history - with the possible exceptions of handguns and tequila. - Author Unknown By far, the greatest danger of Artificial Intelligence is that people conclude too early that they understand it. - Eliezer Yudkowsky";
                char result[400];
                
                int res = concatenate(result, 400, 3, "Yesterdays the past, tomorrows the future, but today is a gift. Thats why its called the present. - Bil Keane", "A computer lets you make more mistakes faster than any invention in human history - with the possible exceptions of handguns and tequila. - Author Unknown", "By far, the greatest danger of Artificial Intelligence is that people conclude too early that they understand it. - Eliezer Yudkowsky");
        
                test_error(res == 0, "Funkcja concatenate() powinna zwrócić wartość 0, a zwróciła %d", res);                  
     
                if (!0)
                {

                    int ok = 1, i = 0;
        
                    while (*(result + i) && *(expected_result + i))
                    {
                        if (*(result + i) != *(expected_result + i))
                            ok = 0;
                        i++;
                    }
        
                    ok = ok && *(result + i) == *(expected_result + i);
                    if (!ok)
                    {
                        printf("Oczekiwany wynik: %s\n", expected_result);
                        printf("Otrzymany wynik: %s\n", result);
                    }
           
                    test_error(ok == 1, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa");
                }
     
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                char *expected_result = "The system of nature, of which man is a part, tends to be self-balancing, self-adjusting, self-cleansing.  Not so with technology.  - E.F. Schumacher\nA friend is someone who knows all about you and still loves you. - Elbert Hubbard Artificial intelligence, in fact, is obviously an intelligence transmitted by conscious subjects, an intelligence placed in equipment. It has a clear origin, in fact, in the intelligence of the human creators of such equipment. - Pope Benedict XVI";
                char result[481];
                
                int res = concatenate(result, 481, 2, "The system of nature, of which man is a part, tends to be self-balancing, self-adjusting, self-cleansing.  Not so with technology.  - E.F. Schumacher\nA friend is someone who knows all about you and still loves you. - Elbert Hubbard", "Artificial intelligence, in fact, is obviously an intelligence transmitted by conscious subjects, an intelligence placed in equipment. It has a clear origin, in fact, in the intelligence of the human creators of such equipment. - Pope Benedict XVI");
        
                test_error(res == 0, "Funkcja concatenate() powinna zwrócić wartość 0, a zwróciła %d", res);                  
     
                if (!0)
                {

                    int ok = 1, i = 0;
        
                    while (*(result + i) && *(expected_result + i))
                    {
                        if (*(result + i) != *(expected_result + i))
                            ok = 0;
                        i++;
                    }
        
                    ok = ok && *(result + i) == *(expected_result + i);
                    if (!ok)
                    {
                        printf("Oczekiwany wynik: %s\n", expected_result);
                        printf("Otrzymany wynik: %s\n", result);
                    }
           
                    test_error(ok == 1, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa");
                }
     
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                char *expected_result = "The great myth of our times is that technology is communication.-Libby Larsen  To iterate is human, to recurse divine. - L. Peter Deutsch";
                char result[138];
                
                int res = concatenate(result, 138, 3, "The great myth of our times is that technology is communication.-Libby Larsen", "", "To iterate is human, to recurse divine. - L. Peter Deutsch");
        
                test_error(res == 0, "Funkcja concatenate() powinna zwrócić wartość 0, a zwróciła %d", res);                  
     
                if (!0)
                {

                    int ok = 1, i = 0;
        
                    while (*(result + i) && *(expected_result + i))
                    {
                        if (*(result + i) != *(expected_result + i))
                            ok = 0;
                        i++;
                    }
        
                    ok = ok && *(result + i) == *(expected_result + i);
                    if (!ok)
                    {
                        printf("Oczekiwany wynik: %s\n", expected_result);
                        printf("Otrzymany wynik: %s\n", result);
                    }
           
                    test_error(ok == 1, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa");
                }
     
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    
        
                char *expected_result = "   To iterate is human, to recurse divine. - L. Peter Deutsch";
                char result[62];
                
                int res = concatenate(result, 62, 4, "", "", "", "To iterate is human, to recurse divine. - L. Peter Deutsch");
        
                test_error(res == 0, "Funkcja concatenate() powinna zwrócić wartość 0, a zwróciła %d", res);                  
     
                if (!0)
                {

                    int ok = 1, i = 0;
        
                    while (*(result + i) && *(expected_result + i))
                    {
                        if (*(result + i) != *(expected_result + i))
                            ok = 0;
                        i++;
                    }
        
                    ok = ok && *(result + i) == *(expected_result + i);
                    if (!ok)
                    {
                        printf("Oczekiwany wynik: %s\n", expected_result);
                        printf("Otrzymany wynik: %s\n", result);
                    }
           
                    test_error(ok == 1, "Wartość zwrócona przez funkcję concatenate() jest nieprawidłowa");
                }
     
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                
                int res = concatenate(NULL, 735, 4, "Whenever you find yourself on the side of the majority, it is time to reform (or pause and reflect). - Mark Twain", "For a list of all the ways technology has failed to improve the quality of life, please press three.  - Alice Kahn", "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");
                test_error(res == 1, "Funkcja concatenate() powinna zwrócić wartość 1, a zwróciła %d", res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                char result[735];

                int res = concatenate(result, 735, -4, "Whenever you find yourself on the side of the majority, it is time to reform (or pause and reflect). - Mark Twain", "For a list of all the ways technology has failed to improve the quality of life, please press three.  - Alice Kahn", "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");
                test_error(res == 1, "Funkcja concatenate() powinna zwrócić wartość 1, a zwróciła %d", res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                char result[735];
                int res = concatenate(result, -735, 4, "Whenever you find yourself on the side of the majority, it is time to reform (or pause and reflect). - Mark Twain", "For a list of all the ways technology has failed to improve the quality of life, please press three.  - Alice Kahn", "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");
                test_error(res == 1, "Funkcja concatenate() powinna zwrócić wartość 1, a zwróciła %d", res);


        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                char result[735];
                int res = concatenate(result, 735, 0, "Whenever you find yourself on the side of the majority, it is time to reform (or pause and reflect). - Mark Twain", "For a list of all the ways technology has failed to improve the quality of life, please press three.  - Alice Kahn", "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");
                test_error(res == 1, "Funkcja concatenate() powinna zwrócić wartość 1, a zwróciła %d", res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                int res = concatenate(NULL, 735, -4, "Whenever you find yourself on the side of the majority, it is time to reform (or pause and reflect). - Mark Twain", "For a list of all the ways technology has failed to improve the quality of life, please press three.  - Alice Kahn", "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");
                test_error(res == 1, "Funkcja concatenate() powinna zwrócić wartość 1, a zwróciła %d", res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji concatenate
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji concatenate", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                char result[735];

                int res = concatenate(result, 0, 4, "Whenever you find yourself on the side of the majority, it is time to reform (or pause and reflect). - Mark Twain", "For a list of all the ways technology has failed to improve the quality of life, please press three.  - Alice Kahn", "If you thought the advent of the Internet, the spread of cheap and efficient information technology, and the growing fragmentation of the consumer market were all going to help smaller companies thrive at the expense of the slow-moving giants of the Fortune 500, apparently you were wrong. - James Surowiecki", "The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");
                test_error(res == 1, "Funkcja concatenate() powinna zwrócić wartość 1, a zwróciła %d", res);

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci - limit pamięci ustawiony na 0
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci - limit pamięci ustawiony na 0", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci - limit pamięci ustawiony na 32
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci - limit pamięci ustawiony na 32", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(32);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci - limit pamięci ustawiony na 4036
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci - limit pamięci ustawiony na 4036", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(4036);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Reakcja na brak pamięci - limit pamięci ustawiony na 6038
//
void MTEST4(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(4, "Reakcja na brak pamięci - limit pamięci ustawiony na 6038", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(6038);
    
    //
    // -----------
    //
    
                 printf("***START***\n");
                 int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                 printf("\n***END***\n");
                 test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code); 
             
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Reakcja programu na ograniczoną pamięć, wystarczającą na wykonanie wszystkich operacji - limit pamięci ustawiony na 8040
//
void MTEST5(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(5, "Reakcja programu na ograniczoną pamięć, wystarczającą na wykonanie wszystkich operacji - limit pamięci ustawiony na 8040", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(8040);
    
    //
    // -----------
    //
    
             printf("***START***\n");
             int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
             printf("\n***END***\n");
             test_error(ret_code == 0, "Funkcja main zakończyła się kodem %d a powinna 0", ret_code); 
         
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST2, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST3, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST4, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST5, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST6, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST7, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST8, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST9, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST10, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST11, // Sprawdzanie poprawności działania funkcji concatenate
            UTEST12, // Sprawdzanie poprawności działania funkcji concatenate
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(12); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci - limit pamięci ustawiony na 0
            MTEST2, // Reakcja na brak pamięci - limit pamięci ustawiony na 32
            MTEST3, // Reakcja na brak pamięci - limit pamięci ustawiony na 4036
            MTEST4, // Reakcja na brak pamięci - limit pamięci ustawiony na 6038
            MTEST5, // Reakcja programu na ograniczoną pamięć, wystarczającą na wykonanie wszystkich operacji - limit pamięci ustawiony na 8040
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(5); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}