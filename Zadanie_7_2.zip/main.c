#include <stdio.h>
#include "int_operations.h"
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
    int a;
    int b;

    int operacja;

    printf("Dawaj liczby: ");
    if(scanf("%d %d", &a, &b) != 2)

    {
        printf("Incorrect input\n");
        return 1;
    }

    printf("Powiedz co robimy: ");
    if(scanf("%d", &operacja) != 1)

    {
        printf("Incorrect input\n");
        return 1;
    }

    if (operacja < 0 || operacja > 3)

    {
        printf("Incorrect input data\n");
        return 2;
    }

    int rezultacik = get_function(operacja)(a, b);


    printf("%d\n", rezultacik);


    return 0;
}
