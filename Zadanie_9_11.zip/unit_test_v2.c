/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Dodawanie
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-20 21:49:13.747705
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji add
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 0LLU;
        
                printf("#####START#####");
                unsigned long long result = add(0LLU, 0LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji add
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 2LLU;
        
                printf("#####START#####");
                unsigned long long result = add(1LLU, 1LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji add
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 1LLU;
        
                printf("#####START#####");
                unsigned long long result = add(1LLU, 0LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji add
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 1LLU;
        
                printf("#####START#####");
                unsigned long long result = add(0LLU, 1LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji add
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 18446744073709551615LLU;
        
                printf("#####START#####");
                unsigned long long result = add(18446744073709551614LLU, 1LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji add
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 18446744073709551615LLU;
        
                printf("#####START#####");
                unsigned long long result = add(1LLU, 18446744073709551614LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji add
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 15845594449105738903LLU;
        
                printf("#####START#####");
                unsigned long long result = add(4572870259816453908LLU, 11272724189289284995LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji add
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 15958650792491030463LLU;
        
                printf("#####START#####");
                unsigned long long result = add(7129140374308983129LLU, 8829510418182047334LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji add
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 9019060250231142155LLU;
        
                printf("#####START#####");
                unsigned long long result = add(5532823991289506516LLU, 3486236258941635639LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji add
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 10957936572080729820LLU;
        
                printf("#####START#####");
                unsigned long long result = add(8993539446333691127LLU, 1964397125747038693LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji add
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 13687883811402127504LLU;
        
                printf("#####START#####");
                unsigned long long result = add(9092123910763026195LLU, 4595759900639101309LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji add
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 3022010369701641414LLU;
        
                printf("#####START#####");
                unsigned long long result = add(2102328649312457260LLU, 919681720389184154LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji add
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 10049175091882118551LLU;
        
                printf("#####START#####");
                unsigned long long result = add(2890309380440193983LLU, 7158865711441924568LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji add
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 12513446905951234373LLU;
        
                printf("#####START#####");
                unsigned long long result = add(7162366415629845078LLU, 5351080490321389295LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji add
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 14071438238275765053LLU;
        
                printf("#####START#####");
                unsigned long long result = add(8352377188950675523LLU, 5719061049325089530LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji add
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 6129464538234494233LLU;
        
                printf("#####START#####");
                unsigned long long result = add(890391928153170867LLU, 5239072610081323366LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji add
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 8878914428757409365LLU;
        
                printf("#####START#####");
                unsigned long long result = add(4845031772869997332LLU, 4033882655887412033LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji add
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 17022012246282796732LLU;
        
                printf("#####START#####");
                unsigned long long result = add(8773017923253962639LLU, 8248994323028834093LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji add
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 8366415973504775303LLU;
        
                printf("#####START#####");
                unsigned long long result = add(3741457625869912805LLU, 4624958347634862498LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji add
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 6491076053386006687LLU;
        
                printf("#####START#####");
                unsigned long long result = add(3413696142447717063LLU, 3077379910938289624LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji add
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 9554170216779972464LLU;
        
                printf("#####START#####");
                unsigned long long result = add(4264189162853643726LLU, 5289981053926328738LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji add
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 6470916188918607717LLU;
        
                printf("#####START#####");
                unsigned long long result = add(372527306378858257LLU, 6098388882539749460LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji add
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 9717282605077618080LLU;
        
                printf("#####START#####");
                unsigned long long result = add(7666925302655486930LLU, 2050357302422131150LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji add
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 15701228961779378440LLU;
        
                printf("#####START#####");
                unsigned long long result = add(6400501697861503847LLU, 9300727263917874593LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji add
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 15651160679380394093LLU;
        
                printf("#####START#####");
                unsigned long long result = add(6856900202187367071LLU, 8794260477193027022LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji add
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 12005564728965555676LLU;
        
                printf("#####START#####");
                unsigned long long result = add(6319131809160014693LLU, 5686432919805540983LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji add
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 13399471805379474494LLU;
        
                printf("#####START#####");
                unsigned long long result = add(8696198148767054945LLU, 4703273656612419549LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji add
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 11851315463666239089LLU;
        
                printf("#####START#####");
                unsigned long long result = add(6944280329559838835LLU, 4907035134106400254LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji add
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 15985558534712375092LLU;
        
                printf("#####START#####");
                unsigned long long result = add(1958134832582172315LLU, 14027423702130202777LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji add
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 17833905053567470423LLU;
        
                printf("#####START#####");
                unsigned long long result = add(6412535790207298102LLU, 11421369263360172321LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji add
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 16972851422185343200LLU;
        
                printf("#####START#####");
                unsigned long long result = add(8642062467067638932LLU, 8330788955117704268LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji add
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 8132006704631587677LLU;
        
                printf("#####START#####");
                unsigned long long result = add(5157084620168251024LLU, 2974922084463336653LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji add
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 17551959208917494552LLU;
        
                printf("#####START#####");
                unsigned long long result = add(5984756080488883584LLU, 11567203128428610968LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji add
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 16602178488575756820LLU;
        
                printf("#####START#####");
                unsigned long long result = add(5380773691794094981LLU, 11221404796781661839LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji add
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 8707391860419610099LLU;
        
                printf("#####START#####");
                unsigned long long result = add(2174340629430244516LLU, 6533051230989365583LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji add
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 10205684536279730070LLU;
        
                printf("#####START#####");
                unsigned long long result = add(4411149016432250647LLU, 5794535519847479423LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji add
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 5092874177983346705LLU;
        
                printf("#####START#####");
                unsigned long long result = add(2441773030221015181LLU, 2651101147762331524LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji add
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 12811955872804611448LLU;
        
                printf("#####START#####");
                unsigned long long result = add(989993990122989541LLU, 11821961882681621907LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji add
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 8225253814575964951LLU;
        
                printf("#####START#####");
                unsigned long long result = add(5427315492558993703LLU, 2797938322016971248LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji add
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 1677957955625687731LLU;
        
                printf("#####START#####");
                unsigned long long result = add(32568263578345246LLU, 1645389692047342485LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji add
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 3828702039470894478LLU;
        
                printf("#####START#####");
                unsigned long long result = add(68108129926943504LLU, 3760593909543950974LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji add
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 4274756171510380949LLU;
        
                printf("#####START#####");
                unsigned long long result = add(2830934064037356717LLU, 1443822107473024232LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji add
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 9670188627765348920LLU;
        
                printf("#####START#####");
                unsigned long long result = add(4919929649659573019LLU, 4750258978105775901LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie poprawności działania funkcji add
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 13524867485725622875LLU;
        
                printf("#####START#####");
                unsigned long long result = add(3201616381958713723LLU, 10323251103766909152LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie poprawności działania funkcji add
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 10788464525806988401LLU;
        
                printf("#####START#####");
                unsigned long long result = add(2380144009822457608LLU, 8408320515984530793LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie poprawności działania funkcji add
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie poprawności działania funkcji add", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

                unsigned long long expected_result = 16856047979521709481LLU;
        
                printf("#####START#####");
                unsigned long long result = add(1381726525381825995LLU, 15474321454139883486LLU);
                printf("#####END#####");
                test_error(result == expected_result, "Funkcja add() powinna zwrócić %llu, a zwróciła %llu", expected_result, result);

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}




enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji add
            UTEST2, // Sprawdzanie poprawności działania funkcji add
            UTEST3, // Sprawdzanie poprawności działania funkcji add
            UTEST4, // Sprawdzanie poprawności działania funkcji add
            UTEST5, // Sprawdzanie poprawności działania funkcji add
            UTEST6, // Sprawdzanie poprawności działania funkcji add
            UTEST7, // Sprawdzanie poprawności działania funkcji add
            UTEST8, // Sprawdzanie poprawności działania funkcji add
            UTEST9, // Sprawdzanie poprawności działania funkcji add
            UTEST10, // Sprawdzanie poprawności działania funkcji add
            UTEST11, // Sprawdzanie poprawności działania funkcji add
            UTEST12, // Sprawdzanie poprawności działania funkcji add
            UTEST13, // Sprawdzanie poprawności działania funkcji add
            UTEST14, // Sprawdzanie poprawności działania funkcji add
            UTEST15, // Sprawdzanie poprawności działania funkcji add
            UTEST16, // Sprawdzanie poprawności działania funkcji add
            UTEST17, // Sprawdzanie poprawności działania funkcji add
            UTEST18, // Sprawdzanie poprawności działania funkcji add
            UTEST19, // Sprawdzanie poprawności działania funkcji add
            UTEST20, // Sprawdzanie poprawności działania funkcji add
            UTEST21, // Sprawdzanie poprawności działania funkcji add
            UTEST22, // Sprawdzanie poprawności działania funkcji add
            UTEST23, // Sprawdzanie poprawności działania funkcji add
            UTEST24, // Sprawdzanie poprawności działania funkcji add
            UTEST25, // Sprawdzanie poprawności działania funkcji add
            UTEST26, // Sprawdzanie poprawności działania funkcji add
            UTEST27, // Sprawdzanie poprawności działania funkcji add
            UTEST28, // Sprawdzanie poprawności działania funkcji add
            UTEST29, // Sprawdzanie poprawności działania funkcji add
            UTEST30, // Sprawdzanie poprawności działania funkcji add
            UTEST31, // Sprawdzanie poprawności działania funkcji add
            UTEST32, // Sprawdzanie poprawności działania funkcji add
            UTEST33, // Sprawdzanie poprawności działania funkcji add
            UTEST34, // Sprawdzanie poprawności działania funkcji add
            UTEST35, // Sprawdzanie poprawności działania funkcji add
            UTEST36, // Sprawdzanie poprawności działania funkcji add
            UTEST37, // Sprawdzanie poprawności działania funkcji add
            UTEST38, // Sprawdzanie poprawności działania funkcji add
            UTEST39, // Sprawdzanie poprawności działania funkcji add
            UTEST40, // Sprawdzanie poprawności działania funkcji add
            UTEST41, // Sprawdzanie poprawności działania funkcji add
            UTEST42, // Sprawdzanie poprawności działania funkcji add
            UTEST43, // Sprawdzanie poprawności działania funkcji add
            UTEST44, // Sprawdzanie poprawności działania funkcji add
            UTEST45, // Sprawdzanie poprawności działania funkcji add
            UTEST46, // Sprawdzanie poprawności działania funkcji add
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(46); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(0); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}