/*
 * Unit Test Bootstrap
 * Autor: Tomasz Jaworski, 2018-2020
 *
 * Test dla zadania Słowa
 * Autor testowanej odpowiedzi: Patryk Panek
 * Test wygenerowano automatycznie o 2022-06-19 19:17:07.990033
 *
 * Debug: 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>

#if !defined(__clang__) && !defined(__GNUC__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na swoim kompilatorze C.
#error System testow jednostkowych jest przeznaczony dla kompilatorów GCC/Clang.
#endif

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
// Zakomentuj poniższy błąd, jeżeli chcesz przetestować testy na platformie Windows.
#error System testow jednostkowych NIE jest przeznaczony dla testów uruchamianych na platformach Windows.
#endif

#define _RLDEBUG_API_
#include "unit_helper_v2.h"
#include "rdebug.h"

#include "tested_declarations.h"
#include "rdebug.h"

//
// Elementy globalne dla całego testu
//




//
//  Test 1: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 8 bajtów
//
void UTEST1(void)
{
    // informacje o teście
    test_start(1, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 8 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(8);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {""};

                char **words = split_words("");

                if (!0)
                    test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        
                else
                {
                    test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 0; ++i)
                        test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        
        
                    test_error(*(words + 0) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        
        
                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 8 bajtów
//
void UTEST2(void)
{
    // informacje o teście
    test_start(2, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 8 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(8);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {""};

                char **words = split_words("                         . -    ");

                if (!0)
                    test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        
                else
                {
                    test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 0; ++i)
                        test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        
        
                    test_error(*(words + 0) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        
        
                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 206 bajtów
//
void UTEST3(void)
{
    // informacje o teście
    test_start(3, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 206 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(206);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"I", "m", "looking", "forward", "to", "the", "future", "and", "feeling", "grateful", "for", "the", "past", "Mike", "Rowe"};

                char **words = split_words("I\'m looking forward to the future, and feeling grateful for the past. - Mike Rowe");

                if (!15)
                    test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        
                else
                {
                    test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 15; ++i)
                        test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        
        
                    test_error(*(words + 15) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        
        
                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 4: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 20 bajtów
//
void UTEST4(void)
{
    // informacje o teście
    test_start(4, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 20 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(20);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The"};

                char **words = split_words("The");

                if (!1)
                    test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        
                else
                {
                    test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 1; ++i)
                        test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        
        
                    test_error(*(words + 1) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        
        
                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 5: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1339 bajtów
//
void UTEST5(void)
{
    // informacje o teście
    test_start(5, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1339 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1339);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"I", "like", "the", "dreams", "of", "the", "future", "better", "than", "the", "history", "of", "the", "past", "Thomas", "Jefferson", "One", "of", "the", "biggest", "challenges", "to", "medicine", "is", "the", "incorporation", "of", "information", "technology", "in", "our", "practices", "Samuel", "Wilson", "Programming", "today", "is", "a", "race", "between", "software", "engineers", "striving", "to", "build", "bigger", "and", "better", "idiot", "proof", "programs", "and", "the", "Universe", "trying", "to", "produce", "bigger", "and", "better", "idiots", "So", "far", "the", "Universe", "is", "winning", "Rick", "Cook", "The", "trouble", "with", "having", "an", "open", "mind", "of", "course", "is", "that", "people", "will", "insist", "on", "coming", "along", "and", "trying", "to", "put", "things", "in", "it", "Terry", "Pratchett", "Diggers"};

                char **words = split_words("I like the dreams of the future better than the history of the past. - Thomas Jefferson\nOne of the biggest challenges to medicine is the incorporation of information technology in our practices. - Samuel Wilson\nProgramming today is a race between software engineers striving to build bigger and better idiot-proof programs, and the Universe trying to produce bigger and better idiots. So far, the Universe is winning. - Rick Cook\nThe trouble with having an open mind, of course, is that people will insist on coming along and trying to put things in it. - Terry Pratchett, Diggers");

                if (!96)
                    test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        
                else
                {
                    test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        
        
                    onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
        
                    for (int i = 0; i < 96; ++i)
                        test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        
        
                    test_error(*(words + 96) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        
        
                    destroy(words);
                }

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 6: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 304 bajtów
//
void UTEST6(void)
{
    // informacje o teście
    test_start(6, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 304 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(304);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Entrepreneurs", "are", "great", "at", "dealing", "with", "uncertainty", "and", "also", "very", "good", "at", "minimizing", "risk", "Thats", "the", "classic", "entrepreneur", "Mohnish", "Pabrai"};

                char input_text[] = "Entrepreneurs are great at dealing with uncertainty and also very good at minimizing risk.+Thats the classic entrepreneur.- Mohnish Pabrai";

                input_text[90] = 1;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 20; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 20) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 7: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 380 bajtów
//
void UTEST7(void)
{
    // informacje o teście
    test_start(7, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 380 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(380);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"We", "are", "not", "here", "to", "curse", "the", "darkness", "but", "to", "light", "the", "candle", "that", "can", "guide", "us", "thru", "that", "darkness", "to", "a", "safe", "and", "sane", "future", "John", "F", "Kennedy"};

                char input_text[] = "We are not here to curse the darkness, but to light the candle that can guide us thru that darkness to a safe and sane future. -+John F. Kennedy";

                input_text[128] = 2;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 29; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 29) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 8: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 300 bajtów
//
void UTEST8(void)
{
    // informacje o teście
    test_start(8, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 300 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(300);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Any", "fool", "can", "write", "code", "that", "a", "computer", "can", "unders", "and", "Good", "programmers", "write", "code", "that", "humans", "can", "understand", "Martin", "Fowler"};

                char input_text[] = "Any fool can write code that a computer can unders+and. Good programmers write code that humans can understand. - Martin Fowler";

                input_text[50] = 3;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 21; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 21) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 9: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 525 bajtów
//
void UTEST9(void)
{
    // informacje o teście
    test_start(9, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 525 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(525);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "best", "programmers", "are", "not", "marginally", "better", "than", "merely", "good", "ones", "They", "are", "an", "order", "of", "magnitude", "better", "measured", "by", "whatever", "standard", "c", "nceptual", "creativity", "speed", "ingenuity", "of", "design", "or", "problem", "solving", "ability", "Randall", "E", "Stross"};

                char input_text[] = "The best programmers are not marginally better than merely good ones. They are an order-of-magnitude better, measured by whatever standard: c+nceptual creativity, speed, ingenuity of design, or problem-solving ability. - Randall E. Stross";

                input_text[141] = 4;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 36; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 36) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 10: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1178 bajtów
//
void UTEST10(void)
{
    // informacje o teście
    test_start(10, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1178 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1178);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "Three", "Laws", "of", "Robotics", "A", "robot", "may", "not", "injure", "a", "human", "being", "or", "through", "inaction", "allow", "a", "human", "being", "to", "come", "to", "harm", "A", "robot", "must", "obey", "the", "orders", "given", "it", "by", "human", "beings", "except", "where", "such", "orders", "would", "conflict", "with", "the", "First", "Law", "A", "robot", "must", "protect", "its", "own", "existence", "as", "long", "as", "such", "protection", "does", "not", "conflict", "with", "the", "First", "or", "Second", "Law", "The", "Zeroth", "Law", "A", "robot", "may", "not", "harm", "humanity", "or", "by", "inaction", "allow", "hu", "anity", "to", "come", "to", "harm", "Isaac", "Asimov", "I", "Robot"};

                char input_text[] = "The Three Laws of Robotics: 1: A robot may not injure a human being or, through inaction, allow a human being to come to harm; 2: A robot must obey the orders given it by human beings except where such orders would conflict with the First Law; 3: A robot must protect its own existence as long as such protection does not conflict with the First or Second Law; The Zeroth Law: A robot may not harm humanity, or, by inaction, allow hu+anity to come to harm. - Isaac Asimov, I, Robot";

                input_text[433] = 5;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 89; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 89) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 11: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 344 bajtów
//
void UTEST11(void)
{
    // informacje o teście
    test_start(11, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 344 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(344);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Artificial", "intelligence", "is", "growing", "up", "fast", "as", "are", "robots", "whose", "facial", "expressions", "can", "elicit", "empathy", "and", "make", "your", "mirror", "neurons", "quiver", "Diane", "Ackerman"};

                char input_text[] = "Artificial intelligence is growing up fast, as are+robots whose facial expressions can elicit empathy and make your mirror neurons quiver. - Diane Ackerman";

                input_text[50] = 6;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 23; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 23) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 12: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 472 bajtów
//
void UTEST12(void)
{
    // informacje o teście
    test_start(12, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 472 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(472);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"It", "is", "good", "to", "love", "many", "things", "for", "therein", "lies", "the", "true", "strength", "and", "whosoever", "loves", "much", "performs", "much", "and", "can", "accomplish", "much", "and", "what", "is", "done", "in", "love", "is", "well", "done", "Vincent", "van", "Gogh"};

                char input_text[] = "It is good to love many things, for therein lies the true strength, and whosoever loves much performs much, and can accomplish+much, and what is done in love is well done. - Vincent van Gogh";

                input_text[126] = 7;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 35; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 35) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 13: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 245 bajtów
//
void UTEST13(void)
{
    // informacje o teście
    test_start(13, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 245 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(245);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Technology", "the", "knack", "of", "so", "arranging", "the", "world", "that", "we", "dont", "have", "to", "experi", "nce", "it", "Max", "Frisch"};

                char input_text[] = "Technology... the knack of so arranging the world that we dont have to experi+nce it.-Max Frisch";

                input_text[77] = 8;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 18; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 18) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 14: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1312 bajtów
//
void UTEST14(void)
{
    // informacje o teście
    test_start(14, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1312 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1312);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"A", "human", "being", "is", "a", "part", "of", "the", "whole", "called", "by", "us", "universe", "a", "part", "limited", "in", "time", "and", "space", "He", "experiences", "himself", "his", "thoughts", "and", "feeling", "as", "something", "separated", "from", "the", "rest", "a", "ind", "of", "optical", "delusion", "of", "his", "consciousness", "This", "delusion", "is", "a", "kind", "of", "prison", "for", "us", "restricting", "us", "to", "our", "personal", "desires", "and", "to", "affection", "for", "a", "few", "persons", "nearest", "to", "us", "Our", "task", "must", "be", "to", "free", "ourselves", "from", "this", "prison", "by", "widening", "our", "circle", "of", "compassion", "to", "embrace", "all", "living", "creatures", "and", "the", "whole", "of", "nature", "in", "its", "beauty", "Albert", "Einstein"};

                char input_text[] = "A human being is a part of the whole called by us universe, a part limited in time and space. He experiences himself, his thoughts and feeling as something separated from the rest, a +ind of optical delusion of his consciousness. This delusion is a kind of prison for us, restricting us to our personal desires and to affection for a few persons nearest to us. Our task must be to free ourselves from this prison by widening our circle of compassion to embrace all living creatures and the whole of nature in its beauty. - Albert Einstein";

                input_text[183] = 9;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 97; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 97) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 15: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1178 bajtów
//
void UTEST15(void)
{
    // informacje o teście
    test_start(15, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1178 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1178);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "Three", "Laws", "of", "Robotics", "A", "robot", "may", "not", "injure", "a", "human", "being", "or", "through", "inaction", "allow", "a", "human", "being", "to", "come", "to", "harm", "A", "robot", "must", "obey", "the", "orders", "given", "it", "by", "human", "beings", "except", "where", "such", "orders", "would", "conflict", "with", "the", "First", "Law", "A", "robot", "must", "protect", "its", "own", "exi", "tence", "as", "long", "as", "such", "protection", "does", "not", "conflict", "with", "the", "First", "or", "Second", "Law", "The", "Zeroth", "Law", "A", "robot", "may", "not", "harm", "humanity", "or", "by", "inaction", "allow", "humanity", "to", "come", "to", "harm", "Isaac", "Asimov", "I", "Robot"};

                char input_text[] = "The Three Laws of Robotics: 1: A robot may not injure a human being or, through inaction, allow a human being to come to harm; 2: A robot must obey the orders given it by human beings except where such orders would conflict with the First Law; 3: A robot must protect its own exi+tence as long as such protection does not conflict with the First or Second Law; The Zeroth Law: A robot may not harm humanity, or, by inaction, allow humanity to come to harm. - Isaac Asimov, I, Robot";

                input_text[279] = 10;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 89; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 89) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 16: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 171 bajtów
//
void UTEST16(void)
{
    // informacje o teście
    test_start(16, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 171 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(171);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Computers", "are", "usel", "ss", "They", "can", "only", "give", "you", "answers", "Pablo", "Picasso"};

                char input_text[] = "Computers are usel+ss. They can only give you answers. - Pablo Picasso";

                input_text[18] = 11;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 12; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 12) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 17: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 2506 bajtów
//
void UTEST17(void)
{
    // informacje o teście
    test_start(17, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 2506 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(2506);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"I", "think", "that", "its", "extraordinarily", "important", "that", "we", "in", "computer", "science", "keep", "fun", "in", "computing", "When", "it", "started", "out", "it", "was", "an", "awful", "lot", "of", "fun", "Of", "course", "the", "paying", "customers", "got", "shafted", "every", "now", "and", "then", "and", "after", "a", "while", "we", "began", "to", "take", "their", "complaints", "seriously", "We", "began", "to", "feel", "as", "if", "we", "really", "were", "responsible", "for", "the", "successful", "error", "free", "perfect", "use", "of", "these", "machines", "I", "dont", "think", "we", "are", "I", "think", "were", "responsible", "for", "stretching", "them", "setting", "them", "off", "in", "new", "direc", "ions", "and", "keeping", "fun", "in", "the", "house", "I", "hope", "the", "field", "of", "computer", "science", "never", "loses", "its", "sense", "of", "fun", "Above", "all", "I", "hope", "we", "dont", "become", "missionaries", "Dont", "feel", "as", "if", "youre", "Bible", "sales", "men", "The", "world", "has", "too", "many", "of", "those", "already", "What", "you", "know", "about", "computing", "other", "people", "will", "learn", "Dont", "feel", "as", "if", "the", "key", "to", "successful", "computing", "is", "only", "in", "your", "hands", "Whats", "in", "your", "hands", "I", "think", "and", "hope", "is", "intelligence", "the", "ability", "to", "see", "the", "machine", "as", "more", "than", "when", "you", "were", "first", "led", "up", "to", "it", "that", "you", "can", "make", "it", "more", "Alan", "J", "Perlis"};

                char input_text[] = "I think that its extraordinarily important that we in computer science keep fun in computing. When it started out it was an awful lot of fun. Of course the paying customers got shafted every now and then and after a while we began to take their complaints seriously. We began to feel as if we really were responsible for the successful error-free perfect use of these machines. I dont think we are. I think were responsible for stretching them setting them off in new direc+ions and keeping fun in the house. I hope the field of computer science never loses its sense of fun. Above all I hope we dont become missionaries. Dont feel as if youre Bible sales-men. The world has too many of those already. What you know about computing other people will learn. Dont feel as if the key to successful computing is only in your hands. Whats in your hands I think and hope is intelligence: the ability to see the machine as more than when you were first led up to it that you can make it more. - Alan J. Perlis";

                input_text[473] = 12;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 189; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 189) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 18: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 210 bajtów
//
void UTEST18(void)
{
    // informacje o teście
    test_start(18, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 210 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(210);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "truth", "does", "not", "change", "according", "to", "our", "a", "ility", "to", "stomach", "it", "Flannery", "OConnor"};

                char input_text[] = "The truth does not change according to our a+ility to stomach it. - Flannery OConnor";

                input_text[44] = 13;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 15; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 15) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 19: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 171 bajtów
//
void UTEST19(void)
{
    // informacje o teście
    test_start(19, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 171 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(171);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Computers", "are", "useless", "They", "can", "only", "give", "you", "ans", "ers", "Pablo", "Picasso"};

                char input_text[] = "Computers are useless. They can only give you ans+ers.-Pablo Picasso";

                input_text[49] = 14;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 12; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 12) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 20: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 531 bajtów
//
void UTEST20(void)
{
    // informacje o teście
    test_start(20, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 531 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(531);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "secret", "of", "living", "a", "life", "of", "excellence", "is", "merely", "a", "matter", "of", "thinking", "thoughts", "of", "excelle", "ce", "Really", "its", "a", "matter", "of", "programming", "our", "minds", "with", "the", "kind", "of", "information", "that", "will", "set", "us", "free", "Charles", "R", "Swindoll"};

                char input_text[] = "The secret of living a life of excellence is merely a matter of thinking thoughts of excelle+ce. Really, its a matter of programming our minds with the kind of information that will set us free. - Charles R. Swindoll";

                input_text[92] = 15;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 39; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 39) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 21: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 497 bajtów
//
void UTEST21(void)
{
    // informacje o teście
    test_start(21, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 497 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(497);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Everyone", "knows", "that", "debugging", "is", "twice", "as", "hard", "as", "writing", "a", "program", "in", "the", "first", "place", "So", "if", "youre", "as", "clever", "as", "you", "can", "e", "when", "you", "write", "it", "how", "will", "you", "ever", "debug", "it", "Brian", "W", "Kernighan"};

                char input_text[] = "Everyone knows that debugging is twice as hard as writing a program in the first place. So if youre as clever as you can +e when you write it, how will you ever debug it? - Brian W. Kernighan";

                input_text[121] = 16;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 38; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 38) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 22: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 270 bajtów
//
void UTEST22(void)
{
    // informacje o teście
    test_start(22, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 270 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(270);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Outside", "of", "a", "dog", "a", "book", "is", "mans", "best", "friend", "Inside", "of", "a", "dog", "its", "too", "dark", "to", "read", "Groucho", "Marx"};

                char input_text[] = "Outside of a dog, a book is mans best friend. Inside of a dog its too dark to read.+- Groucho Marx";

                input_text[83] = 17;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 21; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 21) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 23: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 506 bajtów
//
void UTEST23(void)
{
    // informacje o teście
    test_start(23, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 506 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(506);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "system", "is", "that", "there", "is", "no", "system", "That", "doesnt", "mean", "we", "dont", "have", "process", "Apple", "is", "a", "very", "disciplined", "company", "and", "we", "have", "great", "processes", "But", "thats", "not", "what", "its", "about", "Process", "makes", "you", "more", "efficient"};

                char input_text[] = "The system is that there is no system. That doesnt mean we dont have process. Apple is a very+disciplined company, and we have great processes. But thats not what its about. Process makes you more efficient. - ";

                input_text[93] = 18;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 37; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 37) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 24: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 701 bajtów
//
void UTEST24(void)
{
    // informacje o teście
    test_start(24, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 701 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(701);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"You", "need", "to", "earn", "how", "to", "select", "your", "thoughts", "just", "the", "same", "way", "you", "select", "your", "clothes", "every", "day", "This", "is", "a", "power", "you", "can", "cultivate", "If", "you", "want", "to", "control", "things", "in", "your", "life", "so", "bad", "work", "on", "the", "mind", "Thats", "the", "only", "thing", "you", "should", "be", "trying", "to", "control", "Elizabeth", "Gilbert"};

                char input_text[] = "You need to +earn how to select your thoughts just the same way you select your clothes every day. This is a power you can cultivate. If you want to control things in your life so bad, work on the mind. Thats the only thing you should be trying to control. - Elizabeth Gilbert";

                input_text[12] = 19;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 53; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 53) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 25: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 252 bajtów
//
void UTEST25(void)
{
    // informacje o teście
    test_start(25, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 252 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(252);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"You", "learn", "more", "from", "failure", "than", "from", "success", "Dont", "let", "it", "stop", "you", "Failu", "e", "builds", "character", "Unknown"};

                char input_text[] = "You learn more from failure than from success. Dont let it stop you. Failu+e builds character.- Unknown";

                input_text[74] = 20;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 18; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 18) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 26: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 358 bajtów
//
void UTEST26(void)
{
    // informacje o teście
    test_start(26, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 358 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(358);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"A", "computer", "lets", "you", "make", "more", "mistakes", "faster", "than", "any", "invention", "in", "human", "histo", "y", "with", "the", "possible", "exceptions", "of", "handguns", "and", "tequila", "Author", "Unknown"};

                char input_text[] = "A computer lets you make more mistakes faster than any invention in human histo+y - with the possible exceptions of handguns and tequila. - Author Unknown";

                input_text[79] = 21;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 25; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 25) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 27: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 138 bajtów
//
void UTEST27(void)
{
    // informacje o teście
    test_start(27, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 138 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(138);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"May", "you", "live", "very", "day", "of", "your", "life", "Jonathan", "Swift"};

                char input_text[] = "May you live +very day of your life. - Jonathan Swift";

                input_text[13] = 22;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 10; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 10) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 28: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 232 bajtów
//
void UTEST28(void)
{
    // informacje o teście
    test_start(28, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 232 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(232);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"You", "dont", "have", "to", "be", "great", "to", "start", "but", "you", "have", "to", "start", "to", "be", "great", "Zig", "Ziglar"};

                char input_text[] = "You dont have to be great to start, but you+have to start to be great. - Zig Ziglar";

                input_text[43] = 23;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 18; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 18) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 29: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 892 bajtów
//
void UTEST29(void)
{
    // informacje o teście
    test_start(29, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 892 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(892);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"When", "they", "first", "built", "the", "University", "of", "California", "at", "Irvine", "they", "just", "put", "the", "buildings", "in", "They", "did", "not", "put", "any", "sidewalks", "they", "just", "planted", "grass", "The", "next", "year", "they", "came", "back", "and", "put", "the", "sidewalks", "where", "the", "trails", "were", "in", "the", "grass", "Perl", "is", "just", "that", "kind", "of", "language", "It", "is", "not", "designed", "from", "first", "principles", "Perl", "is", "those", "sidewalks", "n", "the", "grass", "Larry", "Wall"};

                char input_text[] = "When they first built the University of California at Irvine they just put the buildings in. They did not put any sidewalks, they just planted grass. The next year, they came back and put the sidewalks where the trails were in the grass. Perl is just that kind of language. It is not designed from first principles. Perl is those sidewalks +n the grass. - Larry Wall";

                input_text[340] = 24;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 66; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 66) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 30: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 256 bajtów
//
void UTEST30(void)
{
    // informacje o teście
    test_start(30, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 256 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(256);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"People", "who", "are", "crazy", "enough", "to", "think", "they", "can", "change", "the", "world", "are", "the", "ones", "who", "do", "Rob", "Siltanen"};

                char input_text[] = "People who are crazy enough to think they can change the world,+are the ones who do.- Rob Siltanen";

                input_text[63] = 25;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 19; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 19) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 31: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 220 bajtów
//
void UTEST31(void)
{
    // informacje o teście
    test_start(31, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 220 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(220);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"I", "like", "the", "dreams", "of", "the", "future", "better", "than", "the", "history", "of", "the", "past", "Thomas", "efferson"};

                char input_text[] = "I like the dreams of the future better than the history of the past. - Thomas +efferson";

                input_text[78] = 26;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 16; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 16) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 32: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 241 bajtów
//
void UTEST32(void)
{
    // informacje o teście
    test_start(32, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 241 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(241);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Wise", "men", "speak", "because", "they", "have", "something", "to", "say", "fools", "because", "they", "have", "to", "say", "something", "Plato"};

                char input_text[] = "Wise men speak because they have something to say; fools because they have to say something. + Plato";

                input_text[93] = 27;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 17; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 17) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 33: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 499 bajtów
//
void UTEST33(void)
{
    // informacje o teście
    test_start(33, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 499 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(499);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Programming", "today", "is", "a", "race", "between", "software", "engineers", "striving", "to", "build", "bigger", "and", "better", "idiot", "proof", "programs", "and", "the", "universe", "trying", "to", "build", "bigger", "and", "better", "idiots", "So", "far", "the", "universe", "is", "winning", "Rick", "Cook"};

                char input_text[] = "Programming today is a race between software engineers striving to build bigger and better idiot-proof programs, and the universe trying to build bigger and better idiots. So far, the universe+is winning. - Rick Cook";

                input_text[192] = 28;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 35; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 35) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 34: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 388 bajtów
//
void UTEST34(void)
{
    // informacje o teście
    test_start(34, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 388 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(388);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"We", "are", "not", "here", "to", "curse", "the", "darkness", "but", "to", "light", "the", "candle", "that", "can", "guide", "us", "thru", "that", "darkness", "to", "a", "sa", "e", "and", "sane", "future", "John", "F", "Kennedy"};

                char input_text[] = "We are not here to curse the darkness, but to light the candle that can guide us thru that darkness to a sa+e and sane future. - John F. Kennedy";

                input_text[107] = 29;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 30; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 30) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 35: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 510 bajtów
//
void UTEST35(void)
{
    // informacje o teście
    test_start(35, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 510 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(510);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Teaching", "is", "a", "very", "noble", "profession", "that", "shapes", "the", "character", "caliber", "and", "future", "of", "an", "individual", "If", "the", "people", "remember", "m", "as", "a", "good", "teacher", "that", "will", "be", "the", "biggest", "honour", "for", "me", "A", "P", "J", "Abdul", "Kalam"};

                char input_text[] = "Teaching is a very noble profession that shapes the character, caliber, and future of an individual. If the people remember m+ as a good teacher, that will be the biggest honour for me. - A. P. J. Abdul Kalam";

                input_text[125] = 30;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 38; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 38) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 36: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 226 bajtów
//
void UTEST36(void)
{
    // informacje o teście
    test_start(36, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 226 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(226);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "man", "who", "does", "not", "read", "has", "no", "dvantage", "over", "the", "man", "who", "cannot", "read", "Mark", "Twain"};

                char input_text[] = "The man who does not read has no +dvantage over the man who cannot read. - Mark Twain";

                input_text[33] = 31;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 17; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 17) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 37: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 251 bajtów
//
void UTEST37(void)
{
    // informacje o teście
    test_start(37, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 251 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(251);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Sometimes", "you", "wake", "up", "Sometimes", "the", "fall", "kills", "you", "And", "sometimes", "when", "you", "fall", "you", "fly", "Neil", "Gaiman"};

                char input_text[] = "Sometimes you wake up. Sometimes the fall kills you. And sometimes, when you fall, you fly. -+Neil Gaiman";

                input_text[93] = 32;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 18; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 18) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 38: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 173 bajtów
//
void UTEST38(void)
{
    // informacje o teście
    test_start(38, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 173 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(173);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Technology", "is", "anything", "that", "wasnt", "around", "when", "you", "were", "born", "Alan", "Kay"};

                char input_text[] = "Technology+is anything that wasnt around when you were born.-Alan Kay";

                input_text[10] = 33;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 12; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 12) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 39: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 701 bajtów
//
void UTEST39(void)
{
    // informacje o teście
    test_start(39, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 701 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(701);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Jobs", "offshoring", "began", "with", "manufacturing", "but", "the", "rise", "of", "the", "high", "speed", "Internet", "made", "it", "possible", "to", "move", "offshore", "tradable", "professional", "skills", "such", "as", "software", "engineering", "information", "technology", "various", "forms", "of", "engineering", "architecture", "accounting", "and", "even", "the", "edical", "reading", "of", "MRIs", "and", "CT", "Scans", "Paul", "Craig", "Roberts"};

                char input_text[] = "Jobs offshoring began with manufacturing, but the rise of the high-speed Internet made it possible to move offshore tradable professional skills, such as software engineering, information technology, various forms of engineering, architecture, accounting, and even the +edical reading of MRIs and CT-Scans. - Paul Craig Roberts";

                input_text[269] = 34;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 47; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 47) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 40: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 371 bajtów
//
void UTEST40(void)
{
    // informacje o teście
    test_start(40, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 371 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(371);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "greatest", "task", "before", "civiliz", "tion", "at", "present", "is", "to", "make", "machines", "what", "they", "ought", "to", "be", "the", "slaves", "instead", "of", "the", "masters", "of", "men", "Havelock", "Ellis"};

                char input_text[] = "The greatest task before civiliz+tion at present is to make machines what they ought to be, the slaves, instead of the masters of men. - Havelock Ellis";

                input_text[32] = 35;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 27; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 27) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 41: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 311 bajtów
//
void UTEST41(void)
{
    // informacje o teście
    test_start(41, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 311 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(311);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Man", "is", "least", "himself", "when", "e", "talks", "in", "his", "own", "person", "Give", "him", "a", "mask", "and", "he", "will", "tell", "you", "the", "truth", "Oscar", "Wilde"};

                char input_text[] = "Man is least himself when +e talks in his own person. Give him a mask, and he will tell you the truth. - Oscar Wilde";

                input_text[26] = 36;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 24; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 24) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 42: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 451 bajtów
//
void UTEST42(void)
{
    // informacje o teście
    test_start(42, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 451 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(451);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Is", "the", "system", "going", "to", "flatten", "you", "out", "and", "deny", "you", "your", "humanity", "or", "are", "you", "going", "to", "be", "able", "to", "make", "us", "of", "the", "system", "to", "the", "attainment", "of", "human", "purposes", "Joseph", "Campbell"};

                char input_text[] = "Is the system going to flatten you out and deny you your humanity, or are you going to be able to make us+ of the system to the attainment of human purposes? - Joseph Campbell";

                input_text[105] = 37;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 34; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 34) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 43: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 181 bajtów
//
void UTEST43(void)
{
    // informacje o teście
    test_start(43, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 181 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(181);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Technology", "is", "anything", "that", "wasnt", "around", "when", "y", "u", "were", "born", "Alan", "Kay"};

                char input_text[] = "Technology is anything that wasnt around when y+u were born.-Alan Kay";

                input_text[47] = 38;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 13; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 13) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 44: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 202 bajtów
//
void UTEST44(void)
{
    // informacje o teście
    test_start(44, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 202 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(202);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "truth", "does", "not", "change", "according", "to", "our", "ability", "to", "stomach", "it", "Flannery", "OConnor"};

                char input_text[] = "The truth does not change according to our ability to stomach it. + Flannery OConnor";

                input_text[66] = 39;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 14; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 14) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 45: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 364 bajtów
//
void UTEST45(void)
{
    // informacje o teście
    test_start(45, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 364 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(364);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Today", "billions", "of", "mobile", "devices", "with", "extraordinary", "power", "are", "uniting", "with", "advancements", "in", "robotics", "rtificial", "intelligence", "nanotechnology", "and", "so", "much", "more", "Steve", "Mollenkopf"};

                char input_text[] = "Today, billions of mobile devices with extraordinary power are uniting with advancements in robotics +rtificial intelligence, nanotechnology, and so much more. - Steve Mollenkopf";

                input_text[101] = 40;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 23; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 23) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 46: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 193 bajtów
//
void UTEST46(void)
{
    // informacje o teście
    test_start(46, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 193 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(193);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Technology", "is", "a", "word", "that", "describes", "something", "that", "doesnt", "work", "yet", "Douglas", "Adams"};

                char input_text[] = "Technology is a word that describes something that doesnt work yet+-Douglas Adams";

                input_text[66] = 41;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 13; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 13) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 47: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 131 bajtów
//
void UTEST47(void)
{
    // informacje o teście
    test_start(47, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 131 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(131);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"They", "dont", "make", "bugs", "like", "Bunny", "anymore", "Olav", "Mjelde"};

                char input_text[] = "They dont make bugs like Bunny anymore. -+Olav Mjelde.";

                input_text[41] = 42;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 9; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 9) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 48: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 325 bajtów
//
void UTEST48(void)
{
    // informacje o teście
    test_start(48, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 325 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(325);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"A", "computer", "will", "do", "what", "you", "tell", "it", "to", "do", "but", "that", "may", "be", "much", "different", "from", "what", "you", "had", "in", "mind", "Joseph", "Weize", "baum"};

                char input_text[] = "A computer will do what you tell it to do, but that may be much different from what you had in mind.  - Joseph Weize+baum";

                input_text[116] = 43;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 25; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 25) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 49: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 340 bajtów
//
void UTEST49(void)
{
    // informacje o teście
    test_start(49, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 340 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(340);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "greatest", "achievement", "of", "humanity", "is", "not", "its", "works", "of", "art", "scie", "ce", "or", "technology", "but", "the", "recognition", "of", "its", "own", "dysfunction", "Eckhart", "Tolle"};

                char input_text[] = "The greatest achievement of humanity is not its works of art, scie+ce, or technology, but the recognition of its own dysfunction.-Eckhart Tolle";

                input_text[66] = 44;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 24; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 24) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 50: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 225 bajtów
//
void UTEST50(void)
{
    // informacje o teście
    test_start(50, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 225 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(225);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"I", "was", "never", "really", "insane", "except", "upon", "occasions", "when", "m", "heart", "was", "touched", "Edgar", "Allan", "Poe"};

                char input_text[] = "I was never really insane except upon occasions when m+ heart was touched. - Edgar Allan Poe";

                input_text[54] = 45;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 16; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 16) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 51: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 288 bajtów
//
void UTEST51(void)
{
    // informacje o teście
    test_start(51, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 288 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(288);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Man", "the", "living", "creature", "the", "crea", "ing", "individual", "is", "always", "more", "important", "than", "any", "established", "style", "or", "system", "Bruce", "Lee"};

                char input_text[] = "Man, the living creature, the crea+ing individual, is always more important than any established style or system. - Bruce Lee";

                input_text[34] = 46;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 20; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 20) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 52: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 228 bajtów
//
void UTEST52(void)
{
    // informacje o teście
    test_start(52, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 228 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(228);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"I", "think", "Microsoft", "named", "Net", "so", "it", "wouldnt", "show", "up", "in", "a", "Unix", "directory", "li", "ting", "Oktal"};

                char input_text[] = "I think Microsoft named .Net so it wouldnt show up in a Unix directory li+ting. - Oktal";

                input_text[73] = 47;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 17; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 17) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 53: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 250 bajtów
//
void UTEST53(void)
{
    // informacje o teście
    test_start(53, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 250 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(250);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Sometimes", "you", "wake", "up", "Sometimes", "the", "fall", "kills", "yo", "And", "sometimes", "when", "you", "fall", "you", "fly", "Neil", "Gaiman"};

                char input_text[] = "Sometimes you wake up. Sometimes the fall kills yo+. And sometimes, when you fall, you fly. - Neil Gaiman";

                input_text[50] = 48;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 18; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 18) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 54: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 252 bajtów
//
void UTEST54(void)
{
    // informacje o teście
    test_start(54, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 252 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(252);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Programming", "is", "like", "kicking", "yourself", "in", "the", "face", "sooner", "or", "later", "your", "n", "se", "will", "bleed", "Kyle", "Woodbury"};

                char input_text[] = "Programming is like kicking yourself in the face, sooner or later your n+se will bleed. - Kyle Woodbury";

                input_text[72] = 49;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 18; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 18) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 55: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 226 bajtów
//
void UTEST55(void)
{
    // informacje o teście
    test_start(55, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 226 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(226);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"To", "live", "is", "the", "rarest", "thing", "in", "the", "world", "Most", "people", "exist", "tha", "is", "all", "Oscar", "Wilde"};

                char input_text[] = "To live is the rarest thing in the world. Most people exist, tha+ is all. - Oscar Wilde";

                input_text[64] = 50;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 17; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 17) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 56: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 580 bajtów
//
void UTEST56(void)
{
    // informacje o teście
    test_start(56, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 580 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(580);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"If", "you", "treat", "an", "individual", "as", "he", "is", "he", "will", "remain", "how", "he", "is", "But", "if", "you", "treat", "him", "as", "if", "he", "were", "what", "he", "ought", "to", "be", "and", "could", "be", "he", "will", "become", "what", "he", "ought", "to", "be", "and", "could", "be", "Johann", "Wolfgang", "von", "Goethe"};

                char input_text[] = "If you treat an individual as he is, he will remain how he is. But if you treat him as if he were what he ought to be and could be,+he will become what he ought to be and could be. - Johann Wolfgang von Goethe";

                input_text[131] = 51;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 46; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 46) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 57: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 398 bajtów
//
void UTEST57(void)
{
    // informacje o teście
    test_start(57, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 398 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(398);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"PHP", "is", "a", "minor", "evil", "perpetrated", "and", "created", "by", "incompetent", "amateurs", "whereas", "Perl", "is", "a", "great", "and", "insidious", "evil", "perpetrated", "by", "skilled", "but", "perverted", "professionals", "Jon", "Ribbens"};

                char input_text[] = "PHP is a minor evil perpetrated and created by incompetent amateurs, whereas Perl is a great and+insidious evil, perpetrated by skilled but perverted professionals. - Jon Ribbens";

                input_text[96] = 52;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 27; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 27) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 58: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 188 bajtów
//
void UTEST58(void)
{
    // informacje o teście
    test_start(58, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 188 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(188);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Computer", "programming", "has", "always", "been", "a", "self", "taught", "maverick", "occupation", "Ellen", "Ullman"};

                char input_text[] = "Computer programming has always been+a self-taught, maverick occupation. - Ellen Ullman";

                input_text[36] = 53;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 12; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 12) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 59: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 160 bajtów
//
void UTEST59(void)
{
    // informacje o teście
    test_start(59, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 160 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(160);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Computers", "ha", "e", "lots", "of", "memory", "but", "no", "imagination", "Author", "Unknown"};

                char input_text[] = "Computers ha+e lots of memory but no imagination.  - Author Unknown";

                input_text[12] = 54;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 11; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 11) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 60: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 179 bajtów
//
void UTEST60(void)
{
    // informacje o teście
    test_start(60, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 179 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(179);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Whether", "you", "think", "you", "can", "or", "think", "you", "cant", "youre", "right", "Henry", "Ford"};

                char input_text[] = "Whether you think you can or think you cant, youre right.+ Henry Ford";

                input_text[57] = 55;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 13; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 13) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 61: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 283 bajtów
//
void UTEST61(void)
{
    // informacje o teście
    test_start(61, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 283 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(283);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Whenever", "you", "find", "yourself", "on", "the", "side", "o", "the", "majority", "it", "is", "time", "to", "reform", "or", "pause", "and", "reflect", "Mark", "Twain"};

                char input_text[] = "Whenever you find yourself on the side o+ the majority, it is time to reform (or pause and reflect). - Mark Twain";

                input_text[40] = 56;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 21; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 21) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 62: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 641 bajtów
//
void UTEST62(void)
{
    // informacje o teście
    test_start(62, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 641 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(641);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"There", "was", "a", "time", "when", "idealistic", "folksingers", "such", "as", "myself", "believed", "that", "Reality", "TV", "was", "a", "programming", "vogue", "that", "would", "peak", "and", "recede", "leaving", "only", "its", "hardiest", "show", "offs", "Instead", "it", "has", "metastasized", "like", "toxic", "mold", "filling", "every", "nook", "and", "opening", "new", "crannies", "James", "olcott"};

                char input_text[] = "There was a time when idealistic folksingers such as myself believed that Reality TV was a programming vogue that would peak and recede, leaving only its hardiest show-offs. Instead, it has metastasized like toxic mold, filling every nook and opening new crannies. - James +olcott";

                input_text[273] = 57;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 45; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 45) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 63: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 261 bajtów
//
void UTEST63(void)
{
    // informacje o teście
    test_start(63, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 261 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(261);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"A", "langua", "e", "that", "doesnt", "affect", "the", "way", "you", "think", "about", "programming", "is", "not", "worth", "knowing", "Alan", "J", "Perlis"};

                char input_text[] = "A langua+e that doesnt affect the way you think about programming is not worth knowing. - Alan J. Perlis";

                input_text[8] = 58;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 19; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 19) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 64: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 525 bajtów
//
void UTEST64(void)
{
    // informacje o teście
    test_start(64, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 525 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(525);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "best", "programmers", "are", "not", "marginally", "better", "than", "merely", "good", "ones", "They", "are", "an", "order", "of", "magnitude", "better", "measured", "by", "whatever", "s", "andard", "conceptual", "creativity", "speed", "ingenuity", "of", "design", "or", "problem", "solving", "ability", "Randall", "E", "Stross"};

                char input_text[] = "The best programmers are not marginally better than merely good ones. They are an order-of-magnitude better, measured by whatever s+andard: conceptual creativity, speed, ingenuity of design, or problem-solving ability. - Randall E. Stross";

                input_text[131] = 59;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 36; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 36) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 65: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 374 bajtów
//
void UTEST65(void)
{
    // informacje o teście
    test_start(65, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 374 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(374);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"There", "are", "only", "two", "ays", "to", "live", "your", "life", "One", "is", "as", "though", "nothing", "is", "a", "miracle", "The", "other", "is", "as", "though", "everything", "is", "a", "miracle", "Albert", "Einstein"};

                char input_text[] = "There are only two +ays to live your life. One is as though nothing is a miracle. The other is as though everything is a miracle. - Albert Einstein";

                input_text[19] = 60;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 28; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 28) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 66: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 137 bajtów
//
void UTEST66(void)
{
    // informacje o teście
    test_start(66, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 137 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(137);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Pain", "is", "temporary", "Quitting", "lasts", "forever", "Lance", "Ar", "strong"};

                char input_text[] = "Pain is temporary. Quitting lasts forever. - Lance Ar+strong";

                input_text[53] = 61;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 9; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 9) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 67: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 192 bajtów
//
void UTEST67(void)
{
    // informacje o teście
    test_start(67, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 192 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(192);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"It", "does", "no", "do", "to", "dwell", "on", "dreams", "and", "forget", "to", "live", "J", "K", "Rowling"};

                char input_text[] = "It does no+ do to dwell on dreams and forget to live. - J.K. Rowling";

                input_text[10] = 62;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 15; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 15) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 68: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 120 bajtów
//
void UTEST68(void)
{
    // informacje o teście
    test_start(68, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 120 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(120);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"he", "unexamined", "life", "is", "not", "worth", "living", "Socrates"};

                char input_text[] = "+he unexamined life is not worth living. - Socrates";

                input_text[0] = 63;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 8; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 8) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 69: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 244 bajtów
//
void UTEST69(void)
{
    // informacje o teście
    test_start(69, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 244 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(244);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"It", "is", "impossible", "to", "work", "in", "information", "technology", "without", "also", "engaging", "in", "social", "engineering", "Jaron", "Lanier"};

                char input_text[] = "It is+impossible to work in information technology without also engaging in social engineering. - Jaron Lanier";

                input_text[5] = 64;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 16; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 16) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 70: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 269 bajtów
//
void UTEST70(void)
{
    // informacje o teście
    test_start(70, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 269 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(269);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Do", "not", "dwell", "in", "the", "past", "do", "not", "dream", "of", "th", "future", "concentrate", "the", "mind", "on", "the", "present", "moment", "Buddha"};

                char input_text[] = "Do not dwell in the past, do not dream of th+ future, concentrate the mind on the present moment. - Buddha";

                input_text[44] = 91;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 20; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 20) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 71: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 263 bajtów
//
void UTEST71(void)
{
    // informacje o teście
    test_start(71, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 263 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(263);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Technology", "is", "like", "a", "fish", "The", "longer", "it", "stays", "on", "the", "shelf", "the", "less", "desirable", "it", "becomes", "Andrew", "Heller"};

                char input_text[] = "Technology is like a+fish. The longer it stays on the shelf, the less desirable it becomes. - Andrew Heller";

                input_text[20] = 92;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 19; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 19) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 72: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 298 bajtów
//
void UTEST72(void)
{
    // informacje o teście
    test_start(72, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 298 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(298);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"I", "absolutely", "dont", "think", "a", "sentient", "artificial", "intelligence", "is", "going", "to", "wage", "war", "a", "ainst", "the", "human", "species", "Daniel", "H", "Wilson"};

                char input_text[] = "I absolutely dont think a sentient artificial intelligence is going to wage war a+ainst the human species. - Daniel H. Wilson";

                input_text[81] = 93;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 21; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 21) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 73: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 397 bajtów
//
void UTEST73(void)
{
    // informacje o teście
    test_start(73, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 397 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(397);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Considering", "the", "current", "sad", "state", "of", "our", "computer", "programs", "software", "development", "is", "clearly", "still", "a", "black", "art", "and", "cannot", "yet", "be", "called", "an", "engineering", "discipline", "Bill", "Clinton"};

                char input_text[] = "Considering the current sad state of our computer programs,+software development is clearly still a black art, and cannot yet be called an engineering discipline. - Bill Clinton";

                input_text[59] = 94;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 27; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 27) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 74: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 172 bajtów
//
void UTEST74(void)
{
    // informacje o teście
    test_start(74, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 172 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(172);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"It", "is", "easier", "to", "port", "a", "shell", "than", "a", "shell", "script", "Larry", "Wall"};

                char input_text[] = "It+is easier to port a shell than a shell script. - Larry Wall";

                input_text[2] = 95;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 13; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 13) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 75: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 350 bajtów
//
void UTEST75(void)
{
    // informacje o teście
    test_start(75, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 350 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(350);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"I", "always", "considered", "programming", "as", "being", "like", "modern", "day", "wizardry", "You", "could", "think", "of", "things", "in", "your", "mind", "and", "then", "mak", "them", "happen", "Jeff", "Minter"};

                char input_text[] = "I always considered programming as being like modern-day wizardry. You could think of things in your mind and then mak+ them happen. - Jeff Minter";

                input_text[118] = 96;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 25; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 25) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 76: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 873 bajtów
//
void UTEST76(void)
{
    // informacje o teście
    test_start(76, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 873 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(873);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"I", "love", "ou", "without", "knowing", "how", "or", "when", "or", "from", "where", "I", "love", "you", "simply", "without", "problems", "or", "pride", "I", "love", "you", "in", "this", "way", "because", "I", "do", "not", "know", "any", "other", "way", "of", "loving", "but", "this", "in", "which", "there", "is", "no", "I", "or", "you", "so", "intimate", "that", "your", "hand", "upon", "my", "chest", "is", "my", "hand", "so", "intimate", "that", "when", "I", "fall", "asleep", "your", "eyes", "close", "Pablo", "Neruda"};

                char input_text[] = "I love +ou without knowing how, or when, or from where. I love you simply, without problems or pride: I love you in this way because I do not know any other way of loving but this, in which there is no I or you, so intimate that your hand upon my chest is my hand, so intimate that when I fall asleep your eyes close. - Pablo Neruda";

                input_text[7] = 123;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 68; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 68) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 77: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 457 bajtów
//
void UTEST77(void)
{
    // informacje o teście
    test_start(77, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 457 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(457);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Some", "people", "worry", "that", "artifi", "ial", "intelligence", "will", "make", "us", "feel", "inferior", "but", "then", "anybody", "in", "his", "right", "mind", "should", "have", "an", "inferiority", "complex", "every", "time", "he", "looks", "at", "a", "flower", "Alan", "Kay"};

                char input_text[] = "Some people worry that artifi+ial intelligence will make us feel inferior, but then, anybody in his right mind should have an inferiority complex every time he looks at a flower. - Alan Kay";

                input_text[29] = 124;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 33; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 33) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 78: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 290 bajtów
//
void UTEST78(void)
{
    // informacje o teście
    test_start(78, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 290 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(290);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "new", "information", "technology", "Internet", "and", "e", "mail", "have", "practically", "eliminated", "the", "physical", "costs", "of", "comm", "nications", "Peter", "Drucker"};

                char input_text[] = "The new information technology... Internet and e-mail... have practically eliminated the physical costs of comm+nications. - Peter Drucker";

                input_text[111] = 125;

                char **words = split_words(input_text);

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 19; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 19) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 79: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 0 bajtów
//
void UTEST79(void)
{
    // informacje o teście
    test_start(79, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 80: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 256 bajtów
//
void UTEST80(void)
{
    // informacje o teście
    test_start(80, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 256 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(256);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 81: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 260 bajtów
//
void UTEST81(void)
{
    // informacje o teście
    test_start(81, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 260 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(260);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 82: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 267 bajtów
//
void UTEST82(void)
{
    // informacje o teście
    test_start(82, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 267 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(267);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 83: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 270 bajtów
//
void UTEST83(void)
{
    // informacje o teście
    test_start(83, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 270 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(270);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 84: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 274 bajtów
//
void UTEST84(void)
{
    // informacje o teście
    test_start(84, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 274 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(274);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 85: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 280 bajtów
//
void UTEST85(void)
{
    // informacje o teście
    test_start(85, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 280 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(280);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 86: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 289 bajtów
//
void UTEST86(void)
{
    // informacje o teście
    test_start(86, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 289 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(289);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 87: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 292 bajtów
//
void UTEST87(void)
{
    // informacje o teście
    test_start(87, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 292 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(292);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 88: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 297 bajtów
//
void UTEST88(void)
{
    // informacje o teście
    test_start(88, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 297 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(297);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 89: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 301 bajtów
//
void UTEST89(void)
{
    // informacje o teście
    test_start(89, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 301 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(301);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 90: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 310 bajtów
//
void UTEST90(void)
{
    // informacje o teście
    test_start(90, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 310 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(310);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 91: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 314 bajtów
//
void UTEST91(void)
{
    // informacje o teście
    test_start(91, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 314 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(314);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 92: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 325 bajtów
//
void UTEST92(void)
{
    // informacje o teście
    test_start(92, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 325 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(325);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 93: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 328 bajtów
//
void UTEST93(void)
{
    // informacje o teście
    test_start(93, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 328 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(328);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 94: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 334 bajtów
//
void UTEST94(void)
{
    // informacje o teście
    test_start(94, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 334 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(334);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 95: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 338 bajtów
//
void UTEST95(void)
{
    // informacje o teście
    test_start(95, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 338 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(338);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 96: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 343 bajtów
//
void UTEST96(void)
{
    // informacje o teście
    test_start(96, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 343 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(343);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 97: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 348 bajtów
//
void UTEST97(void)
{
    // informacje o teście
    test_start(97, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 348 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(348);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 98: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 356 bajtów
//
void UTEST98(void)
{
    // informacje o teście
    test_start(98, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 356 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(356);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 99: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 361 bajtów
//
void UTEST99(void)
{
    // informacje o teście
    test_start(99, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 361 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(361);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 100: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 370 bajtów
//
void UTEST100(void)
{
    // informacje o teście
    test_start(100, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 370 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(370);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 101: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 378 bajtów
//
void UTEST101(void)
{
    // informacje o teście
    test_start(101, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 378 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(378);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 102: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 382 bajtów
//
void UTEST102(void)
{
    // informacje o teście
    test_start(102, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 382 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(382);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 103: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 387 bajtów
//
void UTEST103(void)
{
    // informacje o teście
    test_start(103, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 387 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(387);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 104: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 395 bajtów
//
void UTEST104(void)
{
    // informacje o teście
    test_start(104, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 395 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(395);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 105: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 401 bajtów
//
void UTEST105(void)
{
    // informacje o teście
    test_start(105, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 401 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(401);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 106: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 405 bajtów
//
void UTEST106(void)
{
    // informacje o teście
    test_start(106, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 405 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(405);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 107: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 417 bajtów
//
void UTEST107(void)
{
    // informacje o teście
    test_start(107, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 417 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(417);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 108: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 423 bajtów
//
void UTEST108(void)
{
    // informacje o teście
    test_start(108, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 423 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(423);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 109: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 426 bajtów
//
void UTEST109(void)
{
    // informacje o teście
    test_start(109, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 426 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(426);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 110: Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 430 bajtów
//
void UTEST110(void)
{
    // informacje o teście
    test_start(110, "Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 430 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(430);
    
    //
    // -----------
    //
    

                char **words = split_words("The Answer to the Great Question... Of Life, the Universe and Everything... Is... Forty-two, said Deep Thought, with infinite majesty and calm. - Douglas Adams, The Hitchhikers Guide to the Galaxy");

                test_error(words == NULL, "Funkcja split_words() powinna zwrócić NULL");        

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 111: Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 20 bajtów
//
void UTEST111(void)
{
    // informacje o teście
    test_start(111, "Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 20 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(20);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The"};
                const char *expected_sorted_array[] = {"The"};

                char **words = split_words("The");

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 1; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 1) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                int res = sort_words(words);

                test_error(res == 0, "Funkcja sort_words() powinna zwrócić 0, a zwróciła %d", res);        
                
                for (int i = 0; i < 1; ++i)
                    test_error(strcmp(expected_sorted_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_sorted_array[i], words[i]);        

                test_error(*(words + 1) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 112: Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 35 bajtów
//
void UTEST112(void)
{
    // informacje o teście
    test_start(112, "Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 35 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(35);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"The", "flower"};
                const char *expected_sorted_array[] = {"The", "flower"};

                char **words = split_words("The flower");

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 2; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 2) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                int res = sort_words(words);

                test_error(res == 0, "Funkcja sort_words() powinna zwrócić 0, a zwróciła %d", res);        
                
                for (int i = 0; i < 2; ++i)
                    test_error(strcmp(expected_sorted_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_sorted_array[i], words[i]);        

                test_error(*(words + 2) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 113: Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 1789 bajtów
//
void UTEST113(void)
{
    // informacje o teście
    test_start(113, "Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 1789 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1789);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Look", "again", "at", "that", "dot", "That", "s", "here", "That", "s", "home", "That", "s", "us", "On", "it", "everyone", "you", "love", "everyone", "you", "know", "everyone", "you", "ever", "heard", "of", "every", "human", "being", "who", "ever", "was", "lived", "out", "their", "lives", "The", "aggregate", "of", "our", "joy", "and", "suffering", "thousands", "of", "confident", "religions", "ideologies", "and", "economic", "doctrines", "every", "hunter", "and", "forager", "every", "hero", "and", "coward", "every", "creator", "and", "destroyer", "of", "civilization", "every", "king", "and", "peasant", "every", "young", "couple", "in", "love", "every", "mother", "and", "father", "hopeful", "child", "inventor", "and", "explorer", "every", "teacher", "of", "morals", "every", "corrupt", "politician", "every", "superstar", "every", "supreme", "leader", "every", "saint", "and", "sinner", "in", "the", "history", "of", "our", "species", "lived", "there", "on", "a", "mote", "of", "dust", "suspended", "in", "a", "sunbeam", "Carl", "Sagan", "Pale", "Blue", "Dot", "A", "Vision", "of", "the", "Human", "Future", "in", "Space"};
                const char *expected_sorted_array[] = {"A", "Blue", "Carl", "Dot", "Future", "Human", "Look", "On", "Pale", "Sagan", "Space", "That", "That", "That", "The", "Vision", "a", "a", "again", "aggregate", "and", "and", "and", "and", "and", "and", "and", "and", "and", "at", "being", "child", "civilization", "confident", "corrupt", "couple", "coward", "creator", "destroyer", "doctrines", "dot", "dust", "economic", "ever", "ever", "every", "every", "every", "every", "every", "every", "every", "every", "every", "every", "every", "every", "everyone", "everyone", "everyone", "explorer", "father", "forager", "heard", "here", "hero", "history", "home", "hopeful", "human", "hunter", "ideologies", "in", "in", "in", "in", "inventor", "it", "joy", "king", "know", "leader", "lived", "lived", "lives", "love", "love", "morals", "mote", "mother", "of", "of", "of", "of", "of", "of", "of", "of", "on", "our", "our", "out", "peasant", "politician", "religions", "s", "s", "s", "saint", "sinner", "species", "suffering", "sunbeam", "superstar", "supreme", "suspended", "teacher", "that", "the", "the", "their", "there", "thousands", "us", "was", "who", "you", "you", "you", "young"};

                char **words = split_words("\"Look again at that dot. That\'s here. That\'s home. That\'s us. On it everyone you love, everyone you know, everyone you ever heard of, every human being who ever was, lived out their lives. The aggregate of our joy and suffering, thousands of confident religions, ideologies, and economic doctrines, every hunter and forager, every hero and coward, every creator and destroyer of civilization, every king and peasant, every young couple in love, every mother and father, hopeful child, inventor and explorer, every teacher of morals, every corrupt politician, every \"superstar,\" every \"supreme leader,\" every saint and sinner in the history of our species lived there--on a mote of dust suspended in a sunbeam.\" - Carl Sagan, Pale Blue Dot: A Vision of the Human Future in Space");

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 130; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 130) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                int res = sort_words(words);

                test_error(res == 0, "Funkcja sort_words() powinna zwrócić 0, a zwróciła %d", res);        
                
                for (int i = 0; i < 130; ++i)
                    test_error(strcmp(expected_sorted_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_sorted_array[i], words[i]);        

                test_error(*(words + 130) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 114: Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 1106 bajtów
//
void UTEST114(void)
{
    // informacje o teście
    test_start(114, "Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 1106 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1106);
    
    //
    // -----------
    //
    

                const char *expected_array[] = {"Is", "artificial", "intelligence", "less", "than", "our", "intelligence", "Spike", "Jonze", "Two", "things", "are", "infinite", "the", "universe", "and", "human", "stupidity", "and", "I", "m", "not", "sure", "about", "the", "universe", "Albert", "Einstein", "You", "might", "not", "think", "that", "programmers", "are", "artists", "but", "programming", "is", "an", "extremely", "creative", "profession", "It", "s", "logic", "based", "creativity", "John", "Romero", "Information", "technology", "and", "business", "are", "becoming", "inextricably", "interwoven", "I", "don", "t", "think", "anybody", "can", "talk", "meaningfully", "about", "one", "without", "the", "talking", "about", "the", "other", "Bill", "Gates"};
                const char *expected_sorted_array[] = {"Albert", "Bill", "Einstein", "Gates", "I", "I", "Information", "Is", "It", "John", "Jonze", "Romero", "Spike", "Two", "You", "about", "about", "about", "an", "and", "and", "and", "anybody", "are", "are", "are", "artificial", "artists", "based", "becoming", "business", "but", "can", "creative", "creativity", "don", "extremely", "human", "inextricably", "infinite", "intelligence", "intelligence", "interwoven", "is", "less", "logic", "m", "meaningfully", "might", "not", "not", "one", "other", "our", "profession", "programmers", "programming", "s", "stupidity", "sure", "t", "talk", "talking", "technology", "than", "that", "the", "the", "the", "the", "things", "think", "think", "universe", "universe", "without"};

                char **words = split_words("Is artificial intelligence less than our intelligence? - Spike Jonze\nTwo things are infinite: the universe and human stupidity; and I\'m not sure about the universe. - Albert Einstein\nYou might not think that programmers are artists, but programming is an extremely creative profession. It\'s logic-based creativity. - John Romero\nInformation technology and business are becoming inextricably interwoven. I don\'t think anybody can talk meaningfully about one without the talking about the other. - Bill Gates");

                test_error(words != NULL, "Funkcja split_words() powinna zwrócić adres przydzielonej pamięci, a zwróciła NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                for (int i = 0; i < 76; ++i)
                    test_error(strcmp(expected_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_array[i], words[i]);        

                test_error(*(words + 76) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)

                int res = sort_words(words);

                test_error(res == 0, "Funkcja sort_words() powinna zwrócić 0, a zwróciła %d", res);        
                
                for (int i = 0; i < 76; ++i)
                    test_error(strcmp(expected_sorted_array[i], words[i]) == 0, "Funkcja split_words() niepoprawnie podzieliła wyrazy, pod indeksem %d powinno być %s, a jest %s", i, expected_sorted_array[i], words[i]);        

                test_error(*(words + 76) == NULL, "Funkcja split_words() powinna przypisać na końcu tablicy wartość NULL");        

                destroy(words);

                test_no_heap_leakage();
                onerror_terminate(); // przerwanie wszystkich testów jednostkowych (np. coś jest mocno nie tak z kodem)
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 115: Sprawdzanie poprawności działania funkcji sort_words
//
void UTEST115(void)
{
    // informacje o teście
    test_start(115, "Sprawdzanie poprawności działania funkcji sort_words", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            int res = sort_words(NULL);

            test_error(res == 1, "Funkcja sort_words() powinna zwrócić 1, a zwróciła %d", res);        

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 116: Sprawdzanie poprawności działania funkcji sort_words
//
void UTEST116(void)
{
    // informacje o teście
    test_start(116, "Sprawdzanie poprawności działania funkcji sort_words", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    
    //
    // -----------
    //
    

            char **words = NULL;

            int res = sort_words(words);

            test_error(res == 1, "Funkcja sort_words() powinna zwrócić 1, a zwróciła %d", res);        

        
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}



//
//  Test 1: Reakcja na brak pamięci; limit ustawiono na 0 bajtów
//
void MTEST1(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(1, "Reakcja na brak pamięci; limit ustawiono na 0 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(0);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                test_no_heap_leakage();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 2: Reakcja na brak pamięci; limit ustawiono na 1000 bajtów
//
void MTEST2(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(2, "Reakcja na brak pamięci; limit ustawiono na 1000 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(1000);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                test_no_heap_leakage();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}

//
//  Test 3: Reakcja na brak pamięci; limit ustawiono na 2216 bajtów
//
void MTEST3(int argc, char** argv, char** envp)
{
    // informacje o teście
    test_start(3, "Reakcja na brak pamięci; limit ustawiono na 2216 bajtów", __LINE__);

    // uwarunkowanie zasobów - pamięci, itd...
    test_file_write_limit_setup(33554432);
    rldebug_reset_limits();
    rldebug_heap_set_global_limit(2216);
    
    //
    // -----------
    //
    
                printf("***START***\n");
                int ret_code = rdebug_call_main(tested_main, argc, argv, envp);
                printf("\n***END***\n");
                test_error(ret_code == 8, "Funkcja main zakończyła się kodem %d a powinna 8", ret_code);
                test_no_heap_leakage();
            
    //
    // -----------
    //

    // przywrócenie podstawowych parametów przydzielania zasobów (jeśli to tylko możliwe)
    rldebug_reset_limits();
    test_file_write_limit_restore();
    
    test_ok();
}


enum run_mode_t { rm_normal_with_rld = 0, rm_unit_test = 1, rm_main_test = 2 };

int __wrap_main(volatile int _argc, char** _argv, char** _envp)
{
    int volatile vargc = _argc;
    char ** volatile vargv = _argv, ** volatile venvp = _envp;
	volatile enum run_mode_t run_mode = rm_unit_test; // -1
	volatile int selected_test = -1;

    if (vargc > 1)
	{
	    char* smode = strtok(vargv[1], ",");
	    char* stest = strtok(NULL, "");
		char *errptr = NULL;
		run_mode = (enum run_mode_t)strtol(smode, &errptr, 10);
		if (*errptr == '\x0')
		{
			memmove(vargv + 1, vargv + 2, sizeof(char*) * (vargc - 1));
			vargc--;

			if (stest != NULL)
			{
			    int val = (int)strtol(stest, &errptr, 10);
			    if (*errptr == '\x0')
			        selected_test = val;
			}
		}
	}

    // printf("runmode=%d; selected_test=%d\n", run_mode, selected_test);

    // inicjuj testy jednostkowe
    unit_test_init(run_mode, "unit_test_v2.c");
    test_limit_init();
    rldebug_set_reported_severity_level(MSL_FAILURE);

    if (run_mode == rm_normal_with_rld)
    {
        // konfiguracja ograniczników
        rldebug_reset_limits();
        

        // uruchom funkcję main Studenta a potem wyświetl podsumowanie sterty i zasobów
        volatile int ret_code = rdebug_call_main(tested_main, vargc, vargv, venvp);

        rldebug_reset_limits();
        

        int leaks_detected = rldebug_show_leaked_resources(0);
        if (leaks_detected)
            raise(SIGHEAP);

        return ret_code;
    }

    
    if (run_mode == rm_unit_test)
    {
        test_title("Testy jednostkowe");

        void (*pfcn[])(void) =
        { 
            UTEST1, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 8 bajtów
            UTEST2, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 8 bajtów
            UTEST3, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 206 bajtów
            UTEST4, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 20 bajtów
            UTEST5, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1339 bajtów
            UTEST6, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 304 bajtów
            UTEST7, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 380 bajtów
            UTEST8, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 300 bajtów
            UTEST9, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 525 bajtów
            UTEST10, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1178 bajtów
            UTEST11, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 344 bajtów
            UTEST12, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 472 bajtów
            UTEST13, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 245 bajtów
            UTEST14, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1312 bajtów
            UTEST15, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 1178 bajtów
            UTEST16, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 171 bajtów
            UTEST17, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 2506 bajtów
            UTEST18, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 210 bajtów
            UTEST19, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 171 bajtów
            UTEST20, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 531 bajtów
            UTEST21, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 497 bajtów
            UTEST22, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 270 bajtów
            UTEST23, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 506 bajtów
            UTEST24, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 701 bajtów
            UTEST25, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 252 bajtów
            UTEST26, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 358 bajtów
            UTEST27, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 138 bajtów
            UTEST28, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 232 bajtów
            UTEST29, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 892 bajtów
            UTEST30, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 256 bajtów
            UTEST31, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 220 bajtów
            UTEST32, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 241 bajtów
            UTEST33, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 499 bajtów
            UTEST34, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 388 bajtów
            UTEST35, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 510 bajtów
            UTEST36, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 226 bajtów
            UTEST37, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 251 bajtów
            UTEST38, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 173 bajtów
            UTEST39, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 701 bajtów
            UTEST40, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 371 bajtów
            UTEST41, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 311 bajtów
            UTEST42, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 451 bajtów
            UTEST43, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 181 bajtów
            UTEST44, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 202 bajtów
            UTEST45, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 364 bajtów
            UTEST46, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 193 bajtów
            UTEST47, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 131 bajtów
            UTEST48, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 325 bajtów
            UTEST49, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 340 bajtów
            UTEST50, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 225 bajtów
            UTEST51, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 288 bajtów
            UTEST52, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 228 bajtów
            UTEST53, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 250 bajtów
            UTEST54, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 252 bajtów
            UTEST55, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 226 bajtów
            UTEST56, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 580 bajtów
            UTEST57, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 398 bajtów
            UTEST58, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 188 bajtów
            UTEST59, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 160 bajtów
            UTEST60, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 179 bajtów
            UTEST61, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 283 bajtów
            UTEST62, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 641 bajtów
            UTEST63, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 261 bajtów
            UTEST64, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 525 bajtów
            UTEST65, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 374 bajtów
            UTEST66, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 137 bajtów
            UTEST67, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 192 bajtów
            UTEST68, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 120 bajtów
            UTEST69, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 244 bajtów
            UTEST70, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 269 bajtów
            UTEST71, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 263 bajtów
            UTEST72, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 298 bajtów
            UTEST73, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 397 bajtów
            UTEST74, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 172 bajtów
            UTEST75, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 350 bajtów
            UTEST76, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 873 bajtów
            UTEST77, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 457 bajtów
            UTEST78, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 290 bajtów
            UTEST79, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 0 bajtów
            UTEST80, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 256 bajtów
            UTEST81, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 260 bajtów
            UTEST82, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 267 bajtów
            UTEST83, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 270 bajtów
            UTEST84, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 274 bajtów
            UTEST85, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 280 bajtów
            UTEST86, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 289 bajtów
            UTEST87, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 292 bajtów
            UTEST88, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 297 bajtów
            UTEST89, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 301 bajtów
            UTEST90, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 310 bajtów
            UTEST91, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 314 bajtów
            UTEST92, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 325 bajtów
            UTEST93, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 328 bajtów
            UTEST94, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 334 bajtów
            UTEST95, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 338 bajtów
            UTEST96, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 343 bajtów
            UTEST97, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 348 bajtów
            UTEST98, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 356 bajtów
            UTEST99, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 361 bajtów
            UTEST100, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 370 bajtów
            UTEST101, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 378 bajtów
            UTEST102, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 382 bajtów
            UTEST103, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 387 bajtów
            UTEST104, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 395 bajtów
            UTEST105, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 401 bajtów
            UTEST106, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 405 bajtów
            UTEST107, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 417 bajtów
            UTEST108, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 423 bajtów
            UTEST109, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 426 bajtów
            UTEST110, // Sprawdzanie poprawności działania funkcji split_words - limit pamięci ustawiony na 430 bajtów
            UTEST111, // Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 20 bajtów
            UTEST112, // Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 35 bajtów
            UTEST113, // Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 1789 bajtów
            UTEST114, // Sprawdzanie poprawności działania funkcji sort_words - limit pamięci ustawiony na 1106 bajtów
            UTEST115, // Sprawdzanie poprawności działania funkcji sort_words
            UTEST116, // Sprawdzanie poprawności działania funkcji sort_words
            NULL
        };

        for (int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx]();

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(116); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem
        return EXIT_SUCCESS;
    }
    

    if (run_mode == rm_main_test)
    {
        test_title("Testy funkcji main()");

        void (*pfcn[])(int, char**, char**) =
        { 
            MTEST1, // Reakcja na brak pamięci; limit ustawiono na 0 bajtów
            MTEST2, // Reakcja na brak pamięci; limit ustawiono na 1000 bajtów
            MTEST3, // Reakcja na brak pamięci; limit ustawiono na 2216 bajtów
            NULL
        };

        for (volatile int idx = 0; pfcn[idx] != NULL && !test_get_session_termination_flag(); idx++)
        {
            if (selected_test == -1 || selected_test == idx + 1)
                pfcn[idx](vargc, vargv, venvp);

            // limit niezaliczonych testów, po jakim testy jednostkowe zostaną przerwane
            if (test_session_get_fail_count() >= 1000)
                test_terminate_session();
        }


        test_title("RLDebug :: Analiza wycieku zasobów");
        // sprawdź wycieki pamięci
        int leaks_detected = rldebug_show_leaked_resources(1);
        test_set_session_leaks(leaks_detected);

        // poinformuj serwer Mrówka o wyniku testu - podsumowanie
        test_title("Podsumowanie");
        if (selected_test == -1)
            test_summary(3); // wszystkie testy muszą zakończyć się sukcesem
        else
            test_summary(1); // tylko jeden (selected_test) test musi zakończyć się  sukcesem

        return EXIT_SUCCESS;
    }

    printf("*** Nieznana wartość RunMode: %d", (int)run_mode);
    abort();
}