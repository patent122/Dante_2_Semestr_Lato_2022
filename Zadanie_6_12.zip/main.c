#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "tested_declarations.h"
#include "rdebug.h"

char** blad(char** pamiec, char* bb, size_t rozmiar)
{
    free(bb);
    if (rozmiar)
        for (size_t i = 0; i < rozmiar; i++)
            free(*(pamiec + i));
    free(pamiec);
    return NULL;
}

char** split_words(const char* tekst)
{
    if (tekst == NULL)
        return NULL;

    char* bufor = NULL;
    char** rezultat = NULL;
    unsigned int result_size = 0;
    unsigned int buffer_size = 0;

    int trigger = 1;
    while (trigger)
    {
        if (*(tekst++) == '\0')
            trigger = 0;

        char znak = *(tekst - 1);
        if (isalpha(znak))
        {
            if (!buffer_size) 
            {
                char* tymczasowy = NULL;
                if ((tymczasowy = realloc(bufor, sizeof(char) * 2)) == NULL)
                    return blad(rezultat, bufor, result_size);
                else bufor = tymczasowy;

                buffer_size += 2;
            }
            else
            {
                char* tymczasowy = NULL;
                if ((tymczasowy = realloc(bufor, sizeof(char) * (++buffer_size))) == NULL)
                    return blad(rezultat, bufor, result_size);
                else bufor = tymczasowy;
            }

            *(bufor + (buffer_size - 2)) = znak;
            *(bufor + (buffer_size - 1)) = '\0';
        }
        else
        {
            if (!buffer_size)
                continue;

            char** tymczasowy = NULL;
            if ((tymczasowy = realloc(rezultat, sizeof(char*) * (++result_size))) == NULL)
                return blad(rezultat, bufor, --result_size);
            else rezultat = tymczasowy;

            *(rezultat + result_size - 1) = bufor;
            bufor = NULL;
            buffer_size = 0;
        }
    }

    if (result_size)
    {
        char** tymczasowy = NULL;
        if ((tymczasowy = realloc(rezultat, sizeof(char*) * (++result_size))) == NULL)
            return blad(rezultat, bufor, --result_size);
        else rezultat = tymczasowy;

        *(rezultat + result_size - 1) = NULL;
    }

    return rezultat;
}

int sort_words(char** slowa)
{
    if (slowa == NULL)
        return 1;

    if (*slowa == NULL)return 0;
    int changed = 1;
    while (changed) {
        changed = 0;
        for (int i = 0; *(slowa + i + 1) != NULL; i++) {
            if (strcmp(*(slowa + i), *(slowa + i + 1)) > 0) {
                char* tt = *(slowa + i);
                *(slowa + i) = *(slowa + i + 1);
                *(slowa + i + 1) = tt;
                changed = 1;
            }
        }
    }


    return 0;
}

void destroy(char** slowa)
{
    char** pamiec = slowa;

    while (*(pamiec++) != NULL)
        free(*(pamiec - 1));

    free(slowa);
}

int main()
{
    char* bufor = malloc(1000);
    if (bufor == NULL) {
        printf("Failed to allocate memory");
        return 8;
    }
    printf("Enter text:");
    scanf("%999[^\n]", bufor);

    char** kod_wyjscia = split_words(bufor);
    int ok = 0;
    for (int i = 0; *(bufor + i) != '\0'; i++) {
        if (isalpha(*(bufor + i))) {
            ok = 1;
            break;
        }
    }
    if (!ok) {
        printf("Nothing to show");
        free(bufor);
        return 0;
    }
    if (kod_wyjscia == NULL)
    {
        printf("Failed to allocate memory");
        free(bufor);
        return 8;
    }

    sort_words(kod_wyjscia);
    for (int i = 0; *(kod_wyjscia + i) != NULL; i++) {
        printf("%s\n", *(kod_wyjscia + i));
    }
    free(bufor);
    destroy(kod_wyjscia);
    return 0;
}
