#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include "tested_declarations.h"
#include "rdebug.h"

int main()
{
	FILE* file;
	char path[31];

	printf("Podaj sciezke do pliku: ");
	scanf("%30s", path);
	file = fopen(path, "wb");

	if (file == NULL)
	{
		printf("couldn't create file");
		return 5;
	}

	for (int i = 0; i < 100; i++)
	{
		fprintf(file, "%d\n", i);
	}

	fprintf(file, "%d", 100);
	fclose(file);
	printf("File saved");

	return 0;
}

